# CHANGELOG

## v13.0（2026-10-31）

**定位**：三方融合版。骨架 = ima v14.0（47 文件）；迁移 = codex v13.2（原库直升级 + FTS 无损）；
设计规格 = 豆包 v13.0（四轴/保护层级/十五步/FSRS/缺口/追话/发送三态/units）；底盘 = v11.1（八项保留）。
版本号由用户拍板定为 **13.0**（融合指南 6.5 原建议 `v14.0-final`，只改号不改实质）。

### 新增

- `src/kit/ids.mjs`：主键策略。旧库 INTEGER 复用（`MAX(id)+1`），TEXT 表自动降级，`sameId` 做跨类型比较。
- `src/kit/scope.mjs`：scope 归一与可见集。`chat:private` → `private:<qq>`，`shared` / `shared:%` / `global:<bot>` 全兼容；
  `scopeClause()` 产出「当前会话 + shared」的 SQL 片段，供四段召回共用。
- `src/kit/time.mjs`：TEXT / 毫秒双轨解析（`parseMs` / `refMs` / `daysSinceMs`），旧时间列不再得 NaN。
- `src/kit/units.mjs`：0–1 标度唯一入口（`toUnit` 以 1.5 为判据、`normalizeHormones`、`clamp01`）；
  同时保留旧层导出（`HORMONE_SCALE=100`、`hDisplay`）供老测试使用。
- `src/host/generic.mjs`：通用宿主适配器（`profile: 'generic'`），四个回调即可脱离 DSH 运行。
- `presets/generic.yml`、`docs/通用版-移植指南.md`：通用版配置与接入说明。
- `docs/逐段对照-融合说明书.md`：指南条款 × 三份源文原文 × 本包落点，逐段对照、原文照录。
- `tests/verify-chassis.mjs`（55 项）：v11.1 八项底盘 + 出口 E-1~E-4 + R/M 改动的可执行化。
- `tests/verify-upgrade.mjs`（45 项）：造 v11.1 真实 DDL 库（含 CHECK、0–100 激素、TEXT 时间）→ 直升级 → 逐行校验。
- `tests/verify-generic.mjs`（19 项）：无 DSH 环境下跑通启动 / 一轮对话 / 出口 / 群聊 / 定时器 / 二次启动幂等。

### 沙盒验证（2026-10-31，独立进程 + 真实库文件，35 场景 / 195 断言全绿）

- 覆盖：升级路径 10（fresh / 30 行 / 零行 / 3000 行 / 脏库 / 幂等 ×3 / 半途中断 / FTS / core 配额 / 激素归一）、
  运行时 15（写回三态 / scope 隔离 / 吞吐 / 候选 accept / 冷却 / FSRS / 缺口 / 硬闸 / 出口 / 预算 / 九类唤醒 / utility / 时间 / 状态恢复 / 通用宿主）、
  故障 5（损坏库 / 坏备份 / 目录缺失 / embed 抛错 / WAL 并发）、性能 3、回归 2。
- 日志：`docs/sandbox-log-2026-10-31.md`。
- 沙盒暴露并修复 3 处：

1. `db.mjs` fresh 分支不写 `kv.schema_version` → 补写，与升级分支口径一致。
2. `db.mjs` 指纹把本版本新增列也算进去，半途中断库续跑时被自己永久拒绝 → 指纹列 = 升级前列 − `columns.json` 新增列
   （`audit_status` / `time_granularity` 除外，二者 v11.1 就有）。
3. `time.mjs` `parseMs` 数字分支不换算秒级、TEXT 分支按本地时区解释无时区字符串 → 秒级 ×1000；补 `Z` 按 UTC 解析
   （与迁移回填 `strftime('%s', col)` 同口径）。

### 修复（相对 ima v14.0 骨架）

1. `engine.mjs` 用 `'m'+hex` 作 TEXT 主键插 INTEGER 主键表 → 改为 `nextId`（datatype mismatch 消失）。
2. `engine.mjs` 指纹去重 SQL 无 scope 约束 → 加 scope，跨会话不再误判重复。
3. `search.mjs` 默认 `scopes: ['chat:private','shared']` 在旧库匹配不到任何行 → 改为 `visibleScopes()` 推导。
4. `life-state.mjs` 只写 `state_json`，旧库列是 `snapshot_json NOT NULL` → 快照双列写。
5. `life-state.mjs` 激素 0–100 → 统一 0–1，旧值在 `recover` 时归一。
6. `schema.sql` 全部 TEXT 主键 → 全 INTEGER（`AUTOINCREMENT`）。
7. `candidates.mjs` accept 只改状态（违反 D3）→ 调 `writeMemory(force_direct)` 重跑 15 步，回写 `memory_id`。
8. `lifecycle.mjs` checkpoint id 用随机串 → `nextId`。
9. `columns.json` 目标版本 14 → 13。
10. 迁移缺备份 / 旧列指纹 / legacy 快照 / FTS 顺序 → 全部补齐（见下）。

### 升级（codex v13.2 第十四章）

- 首次写库前 `VACUUM INTO` 备份（保留最近 3 份）。
- 迁移前后逐行校验**旧列数据指纹**；不一致且 `upgrade.rollbackOnMismatch` 时拒绝启动。
- 旧行原样进 `legacy_rows`（含行级 fingerprint）。
- FTS 严格顺序：建表 → 摘触发器 → `rebuild` → 回填新列 → 装回触发器 → 再 `rebuild`（防首次 UPDATE 报 malformed）。
- 版本记录：`PRAGMA user_version = 13` + `kv.schema_version='13'` + `schema_migrations` + `upgrade_manifest`。
- 幂等：二次 `ensureSchema` 新增 0 列、不重复备份。

### 兼容口径

- 旧库 `memories.valid_to`、`scope` 等既有列**不重命名、不改写**；`_ms` 列只增。
- v11.1 的 CHECK 白名单是硬约束：`evidence_kind` 仅 `user_sentence/window_messages/model_inference/manual`；
  `time_granularity` 仅 `day/week/month/uncertain`；`cold_reason` 仅 `age/capacity`。写入前统一走 `norm*` 归一。
- 默认行为保持 v11.1：`route=false`、`autoArchive=false`、`speak.hardGate=false`；唯一默认生效的改动是注入冷却 6h。

### 断言

| 文件 | 项数 |
|---|---|
| `tests/verify.mjs` | 75 |
| `tests/verify12.mjs` | 82 |
| `tests/verify13.mjs` | 29 |
| `tests/verify-chassis.mjs` | 55 |
| `tests/verify-upgrade.mjs` | 45 |
| `tests/verify-generic.mjs` | 19 |
| **合计** | **305** |

另有 `scripts/doctor.mjs` 47 项结构自检。全部在 Node 24.21.0 下通过。

---

## v11.1（原底本，不在本包范围）

本包不修改 v11.1 的任何设计文档；八项底盘（双层定义 / LifeState / 四激素 / 九类唤醒 / 硬闸七条 /
900-700 预算 / 出口清洗 E-1~E-4 / 八类改动清单）逐项保留，由 `tests/verify-chassis.mjs` 守护。