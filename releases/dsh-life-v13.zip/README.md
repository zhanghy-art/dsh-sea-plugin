# dsh-life v13.0

DSH（DeepSeek Harness）上的**双层一生感**人格插件：内层是工程记忆系统，外层是可感知类脑层。

- 版本：**13.0.0**（v11.1 起可直接就地升级，逐版可回滚；不要求重装）
- 运行环境：Node ≥ 22.5（`node:sqlite` 内置），零第三方依赖
- 许可：MIT
- 设计依据：《DSH四方版本对比与融合适配指南》——骨架取 ima v14.0（47 文件）、迁移取 codex v13.2、设计规格取豆包 v13.0、底盘保留 v11.1
- 逐段对照与出处：[`docs/逐段对照-融合说明书.md`](docs/逐段对照-融合说明书.md)

---

## 一、从 11.1 升级（原地进行，不新建库）

**最短路径：替换代码 → 重启。** 插件启动时会自己给旧库补列、重建 FTS、校验旧列数据指纹，不新建库、不复制数据。

```bash
unzip -o dsh-life-v13.zip -d ~/.dsh/plugins/dsh-life   # 覆盖代码
# 重启 DSH，看日志：
#   [dsh-life] 原地升级：.../mind.db 新增 61 列，已重建 FTS 索引（旧列指纹一致，30 行）
```

想先看清楚它要改什么，再决定：

```bash
node scripts/migrate.mjs --db ~/.dsh/dsh-life/mind.db --dry-run   # 只打印，不写库
```

不想让它自动改：`config.yml` 里加 `autoMigrate: false`。

> 升级验证已真跑：造一个 v11.1 真实 DDL 库（含全部 CHECK 约束 / 旧 0–100 激素 / TEXT 时间），
> 迁移后校验「备份可打开、旧列指纹逐行一致、旧行快照进 legacy_rows、PK 仍是 INTEGER、CHECK 值未被改写、
> TEXT 时间未被改写、`created_at_ms` 已回填、FTS 中文可搜且首次 UPDATE 不报 malformed、scope 不串、
> 二次幂等、新增行可用、候选 accept 真落库」，**45 项全 PASS**（`tests/verify-upgrade.mjs`）。

```bash
# 1) 覆盖代码（只增文件，不删你的 self-made/）
unzip -o dsh-life-v13.zip -d ~/.dsh/plugins/dsh-life

# 2) 就地升级数据库（自动备份 + 只加列/表，不动数据）
node scripts/migrate.mjs --db ~/.dsh/dsh-life/mind.db

# 3) 重启 DSH
```

升级后**行为默认保持 11.1**：

| 能力 | 升级后默认 | 说明 |
|---|---|---|
| 分舱路由 | `route: false`（兼容模式） | 想用就改 config.yml 的 `capabilities.route: true` |
| 自动归档 | `autoArchive: false` | 想省钱再打开 |
| 主动行为硬闸 | 软加项（`speak.hardGate: false`） | 想严格就设 `hardGate: true` |
| 注入冷却 | 6 小时 | 唯一默认生效的改动，可设 0 关闭 |
| 激素标度 | 0–1（旧 0–100 值在启动时自动归一） | 快照同时写 `state_json` 与 `snapshot_json` |

回滚：停插件 → 把 `mind.db.v13.bak.*` 覆盖回原路径 → 换回 11.1 代码。**数据零丢失。**

---

## 二、全新安装

```bash
node scripts/migrate.mjs --db ~/.dsh/dsh-life/mind.db   # 库不存在时不建；首次启动由插件自己建
cp config.example.yml ~/.dsh/dsh-life/config.yml
dsh plugin add file:///绝对路径/dsh-life
```

---

## 三、目录与职责

| 文件 | 职责 |
|---|---|
| `schema.sql` | 全量表结构（`memories` 主键 INTEGER，时间列 TEXT + `_ms` 双写；11 张辅助表 + FTS5 trigram） |
| `migrations/columns.json` | 迁移契约：`target_version: 13`、28 个 memories 列、42 条辅助表补列、`_ms` 回填 SQL |
| `migrations/tables.sql` | 幂等建表（由 schema.sql 生成，执行顺序见文件头） |
| `src/index.mjs` | 插件装配（onPreStep / onTurnStopping / tick 15min） |
| `src/kit/config.mjs` | 全部可调参数的唯一来源（`VERSION='13.0'`、`SCHEMA_VERSION=13`） |
| `src/kit/db.mjs` | 打开库、备份、旧列指纹、十步 `ensureSchema`、事务、kv |
| `src/kit/ids.mjs` | 主键策略：旧库 INTEGER 复用，TEXT 表自动降级 |
| `src/kit/scope.mjs` | scope 归一与可见集（旧库 `private:` / `group:` / `shared:` 全部兼容） |
| `src/kit/time.mjs` | TEXT / 毫秒双轨解析（旧时间列不再得 NaN） |
| `src/kit/units.mjs` | 0–1 标度换算（`toUnit` / `normalizeHormones` / `clamp01`） |
| `src/memory/text.mjs` | 归一化、Jaccard、dice、惊讶度、否定极性 |
| `src/memory/weight.mjs` | effWeight、双通道门槛、保护层级配额、core 准入/退出、转冷 |
| `src/memory/engine.mjs` | 写入管线 15 步、配额、写入读回三态、核心准入、转冷扫描 |
| `src/memory/search.mjs` | 四段召回（scope 前置）、注入冷却、注入日志 |
| `src/memory/region-router.mjs` | 分舱路由（七舱，默认关） |
| `src/memory/embedding-cache.mjs` | LRU 500 + 磁盘 + 预热 |
| `src/memory/candidates.mjs` | 候选五状态 + 三重去重 + accept 重跑写入管线 |
| `src/memory/evidence.mjs` | 证据独立性 + core 晋升 |
| `src/memory/fsrs.mjs` | 复习调度（2^hits，封顶 180 天） |
| `src/memory/gaps.mjs` | 缺口池 + REM + 顿悟 |
| `src/reflex/activation.mjs` | 反射激活度累积（阈值 0.55 / 显式 +0.45 / 15min×0.85） |
| `src/life/life-state.mjs` | LifeState、lifeTick、恢复、快照限容（四激素 0–1、六维惯性） |
| `src/life/attention.mjs` | 注意力倾斜（门槛后重排） |
| `src/life/sleep.mjs` | 睡眠分段结算 |
| `src/session/lifecycle.mjs` | L1–L4、冷层、交接纪要、五项重置检查、20 轮归档 |
| `src/prompt/composer.mjs` | 预算硬分配（900/700）、稳定前缀顺序、状态行 |
| `src/outlet/cleaner.mjs` | 出口清洗 E-1~E-4、工具裁剪、回声窗 |
| `src/govern/constitution.mjs` | L0 宪法锁、分级审批、主动计划闸 |
| `src/maintenance/nightly.mjs` | 夜间巩固、熔断、容量报告 |
| `src/action/speak.mjs` | speakWeight / speakBonus / utility 十项 / 迟滞 / 七道硬闸 / 追话 |
| `scripts/migrate.mjs` | 就地升级外壳（复用 `ensureSchema`，带 dry-run 与报告） |
| `scripts/doctor.mjs` | 47 项硬自检（环境/文件/库结构/治理/维护） |
| `tests/verify.mjs` | 75 项基线断言 |
| `tests/verify12.mjs` | 82 项 v12.1 新增断言 |
| `tests/verify13.mjs` | 29 项 v13.0 收敛断言 |
| `tests/verify-chassis.mjs` | 55 项 v11.1 底盘保留断言（八项底盘 + 出口 + R/M 改动） |
| `tests/verify-upgrade.mjs` | 45 项 v11.1 → v13.0 原库直升级验证 |
| `docs/逐段对照-融合说明书.md` | 指南条款 × 三份源文原文 × 本包落点，逐段对照 |

---

## 四、运行与验证

```bash
node tests/verify.mjs           # 75 PASS
node tests/verify12.mjs         # 82 PASS
node tests/verify13.mjs         # 29 PASS
node tests/verify-chassis.mjs   # 55 PASS（v11.1 底盘保留）
node tests/verify-upgrade.mjs   # 45 PASS（造 v11.1 真库 → 升级 → 逐行校验）
node scripts/doctor.mjs         # 47 项硬检查
node sea/sea-server.mjs         # 识海面板，只读，8765
```

合计 **286 项断言**，全部通过（Node 24.21.0）。

---

## 五、代码阅读顺序（给要接手的人）

1. `kit/config.mjs` → 所有参数在这里，先知道有哪些旋钮
2. `kit/` 的 `ids/scope/time/units` → 四个适配层，决定旧库怎么被读
3. `memory/text.mjs` + `memory/weight.mjs` → 评分的地基（纯函数，无副作用）
4. `memory/engine.mjs` → 一条记忆怎么被写进来（15 步）
5. `memory/search.mjs` → 一条记忆怎么被想起来（4 段召回）
6. `reflex/activation.mjs` + `life/life-state.mjs` → 她的状态怎么动
7. `session/lifecycle.mjs` + `prompt/composer.mjs` → 上下文怎么拼、怎么清
8. `outlet/cleaner.mjs` → 最后一道门
9. `index.mjs` → 以上全部怎么串起来

前 5 步都是纯函数，可以脱离 DSH 单独跑测试；第 9 步才依赖宿主。