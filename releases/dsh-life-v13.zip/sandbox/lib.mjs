// sandbox/lib.mjs — 沙盒测试公共层（隔离目录、v11.1 造库、计时、结果收集）
// 只用于测试，不进入交付包。
import { DatabaseSync } from 'node:sqlite';
import { mkdirSync, rmSync, existsSync, cpSync, writeFileSync, statSync, readdirSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

// 沙盒随包分发，固定位于 <包>/sandbox/，所以被测包根就是上一级
export const PKG = join(dirname(fileURLToPath(import.meta.url)), '..');
export const OWNER = '10086';
export const SCOPE = `private:${OWNER}`;
export const DAY = 86400000;
export const iso = (ms) => new Date(ms).toISOString().slice(0, 19).replace('T', ' ');

// ---------- v11.1 的真实 DDL（与 tests/verify-upgrade.mjs 同源，CHECK 约束一个字都不能省） ----------
export const V11_DDL = `
CREATE TABLE memories (
  id                    INTEGER PRIMARY KEY AUTOINCREMENT,
  scope                 TEXT NOT NULL,
  subject_qq            TEXT,
  category              TEXT NOT NULL,
  fact                  TEXT NOT NULL COLLATE NOCASE,
  tags                  TEXT,
  evidence              TEXT,
  evidence_kind         TEXT CHECK (evidence_kind IN
                         ('user_sentence','window_messages','model_inference','manual')),
  evidence_ref          TEXT,
  source_kind           TEXT,
  source_id             TEXT,
  raw                   TEXT,
  importance            REAL DEFAULT 0.5 CHECK (importance BETWEEN 0 AND 1),
  emotional_salience    REAL DEFAULT 0    CHECK (emotional_salience BETWEEN 0 AND 1),
  relationship_salience REAL DEFAULT 0    CHECK (relationship_salience BETWEEN 0 AND 1),
  happened_at           TEXT,
  time_granularity      TEXT CHECK (time_granularity IN ('day','week','month','uncertain')),
  created_at            TEXT NOT NULL,
  confirmed_at          TEXT,
  emotion               TEXT,
  emotion_intensity     REAL DEFAULT 0,
  bot_feeling           TEXT,
  bot_feeling_intensity REAL DEFAULT 0,
  perspective           TEXT,
  attr_key              TEXT,
  attr_value            TEXT,
  supersedes            INTEGER REFERENCES memories(id),
  invalid_reason        TEXT CHECK (invalid_reason IN
                         ('conflict','superseded','expired','manual','audit')),
  valid_to              TEXT,
  recall_count          INTEGER DEFAULT 0,
  last_recalled         TEXT,
  uses                  INTEGER DEFAULT 0,
  cold                  INTEGER DEFAULT 0,
  cold_reason           TEXT CHECK (cold_reason IN ('age','capacity')),
  cold_at               TEXT,
  audit_status          TEXT DEFAULT 'ok' CHECK (audit_status IN ('ok','suspect','unsupported')),
  vec                   BLOB,
  vec_model             TEXT
);
CREATE INDEX idx_mem_scope_cat   ON memories(scope, category, cold);
CREATE INDEX idx_mem_subject     ON memories(subject_qq, cold);
CREATE INDEX idx_mem_attr        ON memories(attr_key, scope);
CREATE INDEX idx_mem_confirmed   ON memories(confirmed_at);
CREATE VIRTUAL TABLE mem_fts USING fts5(
  fact, tags, content='memories', content_rowid='id', tokenize='trigram'
);
CREATE TABLE narratives (
  id INTEGER PRIMARY KEY AUTOINCREMENT, period TEXT, kind TEXT, text TEXT,
  audit_status TEXT DEFAULT 'ok', created_at TEXT
);
CREATE TABLE candidates (
  id INTEGER PRIMARY KEY AUTOINCREMENT, scope TEXT NOT NULL, text TEXT,
  kind TEXT, payload TEXT, evidence TEXT, status TEXT DEFAULT 'pending',
  created_at TEXT, expires_at TEXT
);
CREATE TABLE relationships (
  scope TEXT PRIMARY KEY, closeness REAL DEFAULT 0.5, trust REAL DEFAULT 0.5,
  stage TEXT DEFAULT 'normal', updated_at TEXT
);
CREATE TABLE promises (
  id INTEGER PRIMARY KEY AUTOINCREMENT, scope TEXT NOT NULL, direction TEXT,
  text TEXT, due_at TEXT, status TEXT DEFAULT 'pending', created_at TEXT
);
CREATE TABLE milestones (
  id INTEGER PRIMARY KEY AUTOINCREMENT, scope TEXT NOT NULL, text TEXT,
  happened_at TEXT, created_at TEXT
);
CREATE TABLE reflexes (
  id INTEGER PRIMARY KEY AUTOINCREMENT, scope TEXT NOT NULL, trigger TEXT,
  response TEXT, pain_level REAL DEFAULT 0.5, activation REAL DEFAULT 0,
  last_fired_at TEXT, fire_count INTEGER DEFAULT 0, created_at TEXT
);
CREATE TABLE injection_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT, memory_id TEXT NOT NULL, scope TEXT,
  kind TEXT, injected_at INTEGER NOT NULL, turn_id TEXT
);
CREATE TABLE edges (
  from_id TEXT NOT NULL, to_id TEXT NOT NULL, type TEXT NOT NULL,
  weight REAL DEFAULT 0.5, created_at INTEGER NOT NULL,
  PRIMARY KEY (from_id, to_id, type)
);
CREATE TABLE life_state (
  id         INTEGER PRIMARY KEY CHECK (id = 1),
  revision   INTEGER NOT NULL,
  state_json TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE life_events (
  event_id   TEXT PRIMARY KEY,
  event_type TEXT NOT NULL,
  event_json TEXT NOT NULL,
  created_at TEXT NOT NULL,
  applied_at TEXT
);
CREATE TABLE life_snapshots (
  revision      INTEGER PRIMARY KEY,
  snapshot_json TEXT NOT NULL,
  state_hash    TEXT NOT NULL,
  created_at    TEXT NOT NULL
);
CREATE TABLE action_proposals (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  kind       TEXT NOT NULL,
  reason     TEXT,
  utility    REAL,
  status     TEXT NOT NULL,
  expires_at TEXT
);
CREATE TABLE memories_archive (
  id INTEGER, archived_at TEXT, reason TEXT, payload TEXT
);
CREATE TABLE kv (k TEXT PRIMARY KEY, v TEXT, updated_at INTEGER);
`;

/** 造一个 v11.1 库。opts: { rows=30, dirty=false, state=true } */
export function makeV11(dbPath, { rows = 30, dirty = false, now = Date.now() } = {}) {
  rmSync(dbPath, { force: true });
  rmSync(dbPath + '-wal', { force: true });
  rmSync(dbPath + '-shm', { force: true });
  const db = new DatabaseSync(dbPath);
  db.exec('PRAGMA journal_mode=WAL;');
  db.exec(V11_DDL);
  const ins = db.prepare(`INSERT INTO memories
    (scope, subject_qq, category, fact, tags, evidence, evidence_kind, evidence_ref,
     source_kind, source_id, raw, importance, emotional_salience, relationship_salience,
     happened_at, time_granularity, created_at, confirmed_at, emotion, perspective,
     attr_key, attr_value, cold, audit_status)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
  for (let i = 0; i < rows; i++) {
    const t = now - (i + 1) * DAY;
    ins.run(
      SCOPE, OWNER,
      i % 5 === 0 ? 'person' : i % 3 === 0 ? 'promise' : 'fact',
      `旧库第${i}条记忆：主人的习惯条目${i}`,
      '["习惯","旧库"]',
      `原话片段 ${i}`,
      'user_sentence', `m${1000 + i}`,
      'user', OWNER,
      `这是第 ${i} 条记忆的原话全文，升级后必须原样保留`,
      0.5 + (i % 5) * 0.05, i % 3 === 0 ? 0.4 : 0, i % 4 === 0 ? 0.3 : 0,
      iso(t), 'day', iso(t), i % 2 === 0 ? iso(t) : null,
      i % 3 === 0 ? 'happy' : null, 'user',
      i % 4 === 0 ? 'food' : null, i % 4 === 0 ? `面条${i}` : null,
      0, 'ok'
    );
  }
  if (rows >= 3) {
    db.prepare(`UPDATE memories SET invalid_reason='superseded', valid_to=? WHERE id=2`).run(iso(now - 9 * DAY));
    db.prepare(`UPDATE memories SET cold=1, cold_reason='age', cold_at=? WHERE id=3`).run(iso(now - 8 * DAY));
  }
  if (dirty) {
    const extra = [
      ['private:10001', null, 'fact', 'NULL 时间的记忆', null, null, null, null, null, null, '没有时间', 0.5, 0, 0, null, null, iso(now - 400 * DAY), null, null, 'user', null, null, 0, 'ok'],
      [SCOPE, OWNER, 'fact', '超长记忆：' + '很长'.repeat(600), null, null, null, null, null, null, 'x'.repeat(2000), 0.9, 0, 0, null, 'uncertain', iso(now - 500 * DAY), null, null, 'user', null, null, 0, 'ok'],
      [SCOPE, OWNER, 'fact', '表情符号 🐋🌊 与 Unicode 测试', '["emoji"]', null, 'user_sentence', 'm1', 'user', OWNER, '原话带 emoji 🐋', 0.7, 0, 0, null, null, iso(now - 600 * DAY), null, null, 'user', null, null, 0, 'ok'],
      [SCOPE, OWNER, 'fact', 'audit 可疑的一条', null, null, null, null, null, null, null, 0.6, 0, 0, null, null, iso(now - 700 * DAY), null, null, 'user', null, null, 0, 'suspect'],
    ];
    const st = db.prepare(`INSERT INTO memories
      (scope, subject_qq, category, fact, tags, evidence, evidence_kind, evidence_ref,
       source_kind, source_id, raw, importance, emotional_salience, relationship_salience,
       happened_at, time_granularity, created_at, confirmed_at, emotion, perspective,
       attr_key, attr_value, cold, audit_status)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
    for (const r of extra) st.run(...r);
  }
  db.prepare(`INSERT INTO life_state(id, revision, state_json, updated_at) VALUES(1, 41, ?, ?)`)
    .run(JSON.stringify({
      schemaVersion: 12, revision: 41,
      needs: { social: 0.44, curiosity: 0.5, rest: 0.6, mood: 0.55, closeness: 0.5, energy: 0.7 },
      hormones: { cortisol: 30, dopamine: 50, oxytocin: 40, serotonin: 60 },
      energy: 0.7, phase: 'evening',
      social: { lastUserAt: 0, lastBotAt: 0, lastProactiveAt: 0, silentStreak: 0, proactiveBackoffMinutes: 120 },
      relationship: { closeness: 0.5, trust: 0.5, stage: 'normal' },
      counters: { proactiveToday: 0, proactiveThisHour: 0, emotionInjectToday: 0, dayKey: '2026-10-29', stateLineAt: 0 },
      flags: { safeMode: false, shadowMode: false, deepNight: false },
    }), iso(now - DAY));
  db.prepare(`INSERT INTO life_events(event_id, event_type, event_json, created_at, applied_at)
              VALUES('ev1','tick','{"n":1}',?,NULL)`).run(iso(now - DAY));
  db.prepare(`INSERT INTO injection_log(memory_id, scope, kind, injected_at, turn_id) VALUES('7',?, 'auto', ?, 't1')`)
    .run(SCOPE, now - 3600000);
  db.close();
}

export function openRaw(dbPath) {
  const db = new DatabaseSync(dbPath);
  db.exec('PRAGMA journal_mode=WAL;');
  return db;
}

export function colsOf(db, t) {
  try { return db.prepare(`PRAGMA table_info("${t}")`).all().map(r => r.name); } catch { return []; }
}

export function fileSize(p) {
  try { return statSync(p).size; } catch { return -1; }
}

export function dirSize(dir) {
  let total = 0;
  try {
    for (const f of readdirSync(dir)) {
      const p = join(dir, f);
      const s = statSync(p);
      total += s.isDirectory() ? dirSize(p) : s.size;
    }
  } catch { /* ignore */ }
  return total;
}

/** 结果收集器：一个场景一组断言 + 证据 + 耗时 */
export class Recorder {
  constructor() { this.scenarios = []; this.cur = null; }
  begin(id, title, purpose) {
    this.cur = { id, title, purpose, asserts: [], evidence: [], ms: 0, error: null, startedAt: Date.now() };
    this.scenarios.push(this.cur);
    return this.cur;
  }
  ok(name, cond, got) {
    this.cur.asserts.push({ name, pass: !!cond, got });
    return !!cond;
  }
  eq(name, actual, expected) {
    const pass = JSON.stringify(actual) === JSON.stringify(expected);
    this.cur.asserts.push({ name, pass, got: pass ? actual : { actual, expected } });
    return pass;
  }
  note(name, value) { this.cur.evidence.push({ name, value }); }
  end() {
    if (!this.cur) return;
    this.cur.ms = Date.now() - this.cur.startedAt;
    this.cur = null;
  }
  fail(e) {
    if (this.cur) { this.cur.error = e && (e.stack || String(e)); }
  }
  get totals() {
    let p = 0, f = 0;
    for (const s of this.scenarios) for (const a of s.asserts) (a.pass ? p++ : f++);
    return { pass: p, fail: f, scenarios: this.scenarios.length, errors: this.scenarios.filter(s => s.error).length };
  }
}