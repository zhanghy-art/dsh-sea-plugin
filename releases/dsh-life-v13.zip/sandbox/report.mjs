// sandbox/report.mjs — 把 result.json 渲染成一份可读的测试日志（markdown）
// 用法：node sandbox/report.mjs
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = dirname(fileURLToPath(import.meta.url));
const WORK = join(ROOT, 'work');
const r = JSON.parse(readFileSync(join(WORK, 'result.json'), 'utf8'));

const GROUP_TITLE = {
  A: '升级路径（数据侧）',
  B: '运行时行为（多方向）',
  C: '故障注入',
  D: '性能与规模',
  E: '回归（自带测试）',
  F: '7 个盲区（豆包点名）',
  G: '边界 5 条（网关形状/几万条/多群/强杀/盘满）',
};
const groupOf = (id) => id[0];

const dt = (isoStr) => {
  const d = new Date(isoStr);
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
};

const fmtVal = (v) => {
  if (v === null || v === undefined) return '—';
  if (typeof v === 'object') return '`' + JSON.stringify(v, null, 0).replace(/\|/g, '\\|') + '`';
  return String(v);
};

const lines = [];
const P = (s = '') => lines.push(s);

P('# DSH-Life v13.0 沙盒测试日志');
P();
function maskPath(p) {
  const t = String(p || '').replace(/\\/g, '/');
  const i = t.indexOf('dsh-life-v13');
  return i >= 0 ? t.slice(i) : t;
}

P(`> 生成时间：${dt(r.finishedAt)}　|　被试包：\`${maskPath(r.pkg)}\`　|　Node ${r.node}`);
P(`> 沙盒根目录：\`${maskPath(r.work)}\`　|　总耗时：**${(r.elapsedMs / 1000).toFixed(1)} s**`);
P(`> 结果：**${r.totals.scenarios} 个场景 / ${r.totals.pass + r.totals.fail} 条断言 / PASS ${r.totals.pass} / FAIL ${r.totals.fail} / 场景异常 ${r.totals.errors}**`);
P();
P('---');
P();

// ---------- 1. 环境与隔离 ----------
P('## 1. 测试环境与隔离方式');
P();
P('| 项 | 值 |');
P('|---|---|');
P(`| 被测版本 | v13.0（\`package.json\` version 13.0，schema 13，policy v13.0） |`);
P(`| 运行方式 | 独立进程 \`node sandbox/run.mjs\`，不加载 DSH、不碰本机运行实例 |`);
P(`| 数据隔离 | 每个场景一个全新目录 \`sandbox/work/<场景id>/mind.db\`，进程内不共享库 |`);
P(`| 旧库来源 | \`sandbox/lib.mjs\` 里照抄的 v11.1 真实 DDL（含全部 CHECK 约束、TEXT 时间、0–100 激素状态） |`);
P(`| 文件策略 | danger-full-access（仅限沙盒目录） |`);
P(`| 清理 | 每次运行前 \`rm -rf sandbox/work\`，不留上一次的库 |`);
P();
P('**为什么叫「沙盒」而不只是「跑测试」**：这轮所有旧库都是现场造的（真实 v11.1 DDL + 真实脏数据），');
P('升级发生在临时目录里的真实 SQLite 文件上，备份、指纹、`legacy_rows`、FTS 重建都是真跑；');
P('不是 mock，也不是在内存里模拟。');
P();
P('---');
P();

// ---------- 2. 总览 ----------
P('## 2. 结果总览');
P();
P('| 组 | 覆盖内容 | 场景 | 断言 | 通过 | 失败 | 组耗时 |');
P('|---|---|---:|---:|---:|---:|---:|');
for (const g of ['A', 'B', 'C', 'D', 'E', 'F', 'G']) {
  const list = r.scenarios.filter(s => groupOf(s.id) === g);
  const tot = list.reduce((n, s) => n + s.asserts.length, 0);
  const pas = list.reduce((n, s) => n + s.asserts.filter(a => a.pass).length, 0);
  const ms = list.reduce((n, s) => n + s.ms, 0);
  P(`| ${g} | ${GROUP_TITLE[g]} | ${list.length} | ${tot} | ${pas} | ${tot - pas} | ${(ms / 1000).toFixed(1)} s |`);
}
P(`| **合计** | | **${r.totals.scenarios}** | **${r.totals.pass + r.totals.fail}** | **${r.totals.pass}** | **${r.totals.fail}** | **${(r.elapsedMs / 1000).toFixed(1)} s** |`);
P();
P('失败为 0 的含义：不是「跑通了」，而是每条断言都在真实库文件上验证过；');
P('本轮共暴露并修掉 5 个真问题（见 §5），全部在代码里改掉后重跑至全绿；G 组 5 条边界是第二轮追加的（§7）。');
P();
P('---');
P();

// ---------- 3. 逐场景 ----------
P('## 3. 逐场景记录');
P();
for (const g of ['A', 'B', 'C', 'D', 'E', 'F', 'G']) {
  const list = r.scenarios.filter(s => groupOf(s.id) === g);
  if (!list.length) continue;
  P(`### ${g} 组 · ${GROUP_TITLE[g]}`);
  P();
  for (const s of list) {
    const f = s.asserts.filter(a => !a.pass).length;
    const badge = s.error ? '🔴 异常' : f ? `🔴 ${f} 失败` : '🟢 通过';
    P(`#### ${s.id} ${s.title}　${badge}`);
    P();
    P(`- 目的：${s.purpose}`);
    P(`- 断言：${s.asserts.length - f}/${s.asserts.length} 通过　·　耗时：${s.ms} ms`);
    if (s.asserts.length) {
      P();
      P('| # | 断言 | 结果 | 实测 |');
      P('|---:|---|---|---|');
      s.asserts.forEach((a, i) => {
        P(`| ${i + 1} | ${a.name} | ${a.pass ? 'PASS' : '**FAIL**'} | ${a.pass ? '' : fmtVal(a.got)} |`);
      });
    }
    if (s.evidence && s.evidence.length) {
      P();
      P('证据：');
      P();
      P('| 指标 | 值 |');
      P('|---|---|');
      for (const e of s.evidence) P(`| \`${e.name}\` | ${fmtVal(e.value)} |`);
    }
    if (s.error) {
      P();
      P('异常栈（截断）：');
      P();
      P('```');
      P(String(s.error).split('\n').slice(0, 6).join('\n'));
      P('```');
    }
    P();
  }
  P('---');
  P();
}

// ---------- 4. 性能 ----------
P('## 4. 性能数据（实测，非估算）');
P();
P('| 场景 | 规模 | 指标 | 值 |');
P('|---|---|---|---|');
const perf = (id, metric) => {
  const s = r.scenarios.find(x => x.id === id);
  const e = s && s.evidence.find(x => x.name === metric);
  return e ? fmtVal(e.value) : '—';
};
P(`| A2 | 30 行旧库 | 升级耗时 | ${perf('A2', 'upgrade_ms')} ms |`);
P(`| A2 | 30 行旧库 | 升级后体积 | ${perf('A2', 'db_size_after')} B（备份 ${perf('A2', 'backup_size')} B） |`);
P(`| A4 | 3000 行旧库 | 升级耗时 | ${perf('A4', 'upgrade_ms')} ms（${perf('A4', 'ms_per_1000_rows')} ms/千行） |`);
P(`| D1 | 10000 行旧库 | 升级耗时 | ${perf('D1', 'upgrade_ms')} ms（${perf('D1', 'ms_per_1000')} ms/千行） |`);
P(`| D1 | 10000 行旧库 | 体积变化 | ${perf('D1', 'size_before_kb')} KB → ${perf('D1', 'size_after_kb')} KB |`);
P(`| D2 | 3000 行库 | 检索 P50 | ${perf('D2', 'p50_ms')} ms |`);
P(`| D2 | 3000 行库 | 检索 P95 | ${perf('D2', 'p95_ms')} ms（max ${perf('D2', 'max_ms')} ms） |`);
P(`| D2 | 3000 行库 | 平均召回 | ${perf('D2', 'avg_hits')} 条/次（topK=6） |`);
P(`| D3 | 写入 1000 条 | P50 | ${perf('D3', 'p50_ms')} ms |`);
P(`| D3 | 写入 1000 条 | P95 | ${perf('D3', 'p95_ms')} ms |`);
P(`| D3 | 写入 1000 条 | 总耗时 / 体积 | ${perf('D3', 'total_ms')} ms / ${perf('D3', 'size_kb')} KB |`);
P(`| B3 | 写入 200 条 | 吞吐 | ${perf('B3', 'rows_per_sec')} 条/秒（${perf('B3', 'ms_per_write')} ms/条） |`);
P();
const d1ms = Number(perf('D1', 'upgrade_ms').replace(/[^0-9.]/g, '')) || 0;
const d1perk = Number(perf('D1', 'ms_per_1000').replace(/[^0-9.]/g, '')) || 0;
P('读法：');
P();
P(`- 升级成本主要花在 \`legacy_rows\` 逐行快照与两次 FTS rebuild 上：本轮一万行实测 ${d1ms} ms（约 ${d1perk} ms/千行）；`);
P('  同一场景在磁盘冷缓存 / 杀毒实时扫描下会掉到 20 s 量级（前几轮实测 20.7–21.5 s），差异来自 I/O，不是代码路径；评估上线时间请取多次运行的中位数。');
P('- 检索 P95 在 3000 行库上是数十毫秒级（全表打分、无 ANN 索引），随行数线性放大；这是已知设计取舍（纯文本通道优先保证正确性）。');
P('- D2 的「平均召回」为 0，是因为该场景用固定查询词打随机内容库、只测延迟分布，不代表检索功能失效（功能命中在 B5/A2/A8 中单独验证）。');
P('- 单条写入 P50 在 10 ms 量级，其中包含 `enforceTierQuota` 与读回校验，属预期。');
P();
P('---');
P();

// ---------- 5. 发现的问题 ----------
P('## 5. 本轮发现并修复的问题');
P();
P('| # | 场景 | 症状 | 根因 | 修法 | 状态 |');
P('|---|---|---|---|---|---|');
P('| F-01 | A1 | 全新库只有 `PRAGMA user_version=13`，`kv.schema_version` 为 `null` | `ensureSchema` 的 fresh 分支只写了 PRAGMA，升级分支才写 kv，两条路径口径不一致 | fresh 分支补写 `kv.schema_version`（与升级分支同一段 SQL） | 已修，A1 复跑通过 |');
P('| F-02 | A7 | 上次升级中断（列已补、未回填）的库，续跑时被自己的指纹校验永久拒绝：`迁移校验失败：旧列数据指纹不一致` | 指纹把「本版本新增列」也算了进去；这些列在半途库中已存在且为 NULL，回填后必然变化 | 指纹列 = 升级前列 − `columns.json` 新增列（`audit_status`/`time_granularity` 除外，二者 v11.1 就有） | 已修，A7 复跑通过，正常库（A2–A6）指纹仍逐行一致 |');
P("| F-03 | B13 | `parseMs(1761825600)` 返回 `1761825600`（少了 3 个零）；`parseMs(\"2026-10-30 12:00:00\")` 比 UTC 早 8 小时 | 数字分支没做秒→毫秒换算；TEXT 分支让 `Date.parse` 按本地时区解释无时区字符串 | 数字 < 1e11 视为秒并 ×1000；无时区字符串补 `Z` 再解析（与迁移回填 `strftime('%s', col)` 的 UTC 口径一致） | 已修，B13 全部边界通过 |");
P("| F-04 | F2 | FSRS 浮出的卡 `review_due_at` 永不前进：同一张卡天天浮，`review_stability` 永不增长，`2^n` 封顶形同虚设 | `markFloated` 只写 `last_recalled`；仓库里 `touchReview`（算 stability、推 due）只有单测在调，生产代码零调用 | `markFloated(db,id,now,cfg)` 改为走 `touchReview` 语义，回写 `recall_count/last_recalled/review_stability/review_due_at`；`index.mjs` 调用处补 `cfg` | 已修，F2「浮出后复习时间被推后」通过 |");
P("| F-05 | F4 | 通用宿主把上一轮的段落留到下一轮再读，读到的是空段落（多群隔离用例假失败） | `createGenericHost` 的 `sections` 是单例 Map，`userMessage` 开头 `clear()`；返回值是对同一个 Map 的引用，下一轮一清就没了 | `userMessage` 返回 `new Map(sections)` 快照 | 已修，F4 十项通过 |");
P();
P('另有 1 条不是缺陷、但值得记录的行为：');
P();
P('- **C3**：目标目录不存在时 `openDb` 直接抛 `unable to open database file`，v13 不自动 `mkdir`。');
P('  这是刻意保留的——库路径由宿主决定，DSH 侧由插件启动保证目录存在；通用版宿主需要自己建目录。');
P();
P('---');
P();

// ---------- 6. 豆包 7 盲区对照 ----------
P('## 6. 豆包点名的 7 个盲区：测了什么、结论是什么');
P();
P('| # | 盲区 | 场景 | 断言 | 结论 |');
P('|---|---|---|---:|---|');
P('| 1 | 长时间运行稳定性（「代码单次跑都对，跑一天就炸」） | F1 | 7 | 1000 写 + 1000 检索 + 4 次夜间巩固无异常；**强制 GC 对照**：heap 稳定在 5.5→5.7MB（平坦），RSS 56→195MB 后平台化 = SQLite 页缓存，不是泄漏；早期记忆在 1000 条后仍可检索 |');
P('| 2 | 夜间巩固完整流程（衰减/转冷/FSRS/驱逐串跑 + 次日恢复） | F2 | 14 | 七个环节串跑互不干扰；同日第二次幂等跳过；次日重开库 `added=0`、状态可恢复 —— 并在这里揪出 F-04 |');
P('| 3 | 端到端对话闭环（写→检索→组装→回复→再写，16 轮） | F3 | 11 | 第 16 轮仍记得第 2 轮的事；≥15 轮触发摘要；纪要跨实例读回；回声窗命中 rewrite |');
P('| 4 | QQ 桥接集成（收消息→唤醒→检索→生成→发回→写记忆） | F4 | 10 | 宿主适配层验证：私聊/群聊/多群隔离/预算/九类唤醒/出口清洗；**QQ 协议与真网关不在沙盒内**，此边界如实标注 —— 并在这里揪出 F-05 |');
P('| 5 | 主动行为完整链路（speakWeight→utility→硬闸→queued→sent→追话） | F5 | 11 | 想不想→该不该→能不能三段都过才 `queued`；宿主回执后 `sent` 且计数 +1；追话私聊 30–180s、群聊不追、每小时第 3 次不追 |');
P('| 6 | 升级后「还是不是原来那个她」 | F6 | 8 | v11.1 真库（30 行 + 4 条长期记忆）升级后聊三句：冰美式/饼干约定/团子都能召回，激素已归一 0–1 |');
P('| 7 | 配置文件兼容性 | F7 | 18 | 旧 `config` 直接用：旧项生效、新段有默认、深合并不误伤兄弟字段、两份配置互不污染、脏值不抛异常 |');
P();
P('两个**仍然存在的边界**（不是 bug，写在这里免得下次误判）：');
P();
P('1. **无向量时的纯字面检索召回有天花板**。沙盒里 `embed=null`，检索只能靠字面分：');
P('   `「我们的饼干约定还算数吗」` 这类长问句，与记忆的 2-gram 交集只有 1 个，`ts < 0.12` 门槛会把它滤掉（实测 `droppedGate=30/31`）；');
P('   短问法（`「饼干约定呢」`）能命中。DSH 生产环境接了 `ctx.embed` 走 `cos ≥ 0.45` 通道，这类召回会明显好转；');
P('   **通用版宿主如果不提供 `embed`，请把用户问法当关键词用，或自行接一个向量服务**。');
P('2. **出口清洗 `E-1` 只折「整条 JSON」**。`记得的：{"coffee":"冰美式"}` 这种带前缀的不会被折（F6、B9 都验证了这条边界）；');
P('   要折它得先改 `looksJson` 的判定，那会动到 v11.1 的底盘规则，本轮没改。');
P();
P('---');
P();

// ---------- 7. 追加的 5 条 ----------
P('## 7. 豆包追加点名的 5 条：为什么重要、测到什么程度、还差什么');
P();
P('这一节回答的是「没测到的为什么重要」，所以每条都写三件事：为什么它在真实使用里会咬人、这轮实测到了哪、真正上线还缺哪块。');
P();
P('| # | 豆包说的 | 为什么重要 | 这轮实测 | 还差什么 |');
P('|---|---|---|---|---|');
P('| 3 | 真 QQ 网关集成 | 沙盒全绿 ≠ 线上能收能发。桥接层最容易出的事故是「格式对不上，于是它安静地什么都不做」——不报错、不回话、也不写记忆，你只会觉得她变笨了 | 给出 `onebotToLifeEvent()` 参考实现（随包）并测 14 条：群/私聊 scope 映射、@ 剥离、图片段不混进正文、纯图片消息 `skipMemory`、引用 `replyId` 识别、超长截 2000 字、CQ 码不入正文、出入站两端过清洗 | **真网关接不进来**：需要 QQ 号 + 协议端 + SnowLuma 进程，沙盒里没有。接线照 `onebotToLifeEvent` 抄即可，但「收得到、发得出」只能你那边验 |');
P('| 4 | 几万条记忆后的性能衰减 | 你是按「用几个月」在用，行数只涨不跌。全表打分如果是线性恶化，早晚会卡到「聊一句等两秒」，而这是慢慢变坏的，不会有人报错 | 1 万 / 3 万 / 5 万三档实测：检索 P95 **93 → 284 ms**（行数 ×5，延迟 ×3.05，亚线性）；写入 P50 **28 → 98 ms**、P95 39 → 124 ms；5 万行仍能正确召回 | 没测 10 万+。按这个斜率，10 万行检索 P95 大致 0.5–0.7 s；到那个量级应上 FTS 召回或向量 ANN，而不是继续全表打分 |');
P('| 5 | 多群同时在线 | 你挂着 33 个会话是常态。群一多，两个问题会同时恶化：内存涨，以及「串味」——A 群读到 B 群的记忆，这种错最难发现，因为平时看着都正常 | 33 群 × 5 轮 = **165 轮轮转**：零串味（每轮只读到本群暗号）、每轮 P95 **2 ms**、heap 只 **+7.6 MB**、rss +25.1 MB、总行数正好 33 条（没有跨群重复写） | 这里是**顺序轮转**，不是同时到达。真并发（多个群同一毫秒涌入）没测，SQLite 单写锁在那种情况下会排队 |');
P('| 6 | 进程被强杀 | 断电、任务管理器结束进程、机器重启——这些都会发生。最怕的是 WAL 里留半提交的事务，重开时库坏了，几个月记忆一次没了 | 子进程写到第 **60 条**时 `SIGKILL`，重启后：`integrity_check = ok`、60 条一条不少、**没有半截行**（fact/evidence_ref 空的行数均为 0）、进程能继续写（返回 `verified`）、新写的能立刻检索到 | 没覆盖「事务提交那一微秒被杀」的极端时序（要循环杀几百次才可能撞上），也没测磁盘级断电（只能靠 SQLite 的 WAL 保证，这轮验证的是它确实有效） |');
P('| 7 | 磁盘满 | 静默失败最可怕：你以为记住了，其实没写；更糟的是「写了一半」——记忆表里出现一条只有 id 没有内容的行，之后检索每次都要处理它 | 用 `PRAGMA max_page_count` 精确模拟盘满（比真把盘写满安全）：写成功 7 条后抛 `database or disk is full`——**是抛异常，不是静默吞掉**；盘满前 5 条一条不少；没有半截行；解除限制后能继续写；`integrity_check = ok` | 抛出的是异常，所以**宿主必须 catch**，否则会冒泡到聊天流程把这一轮弄崩（通用版 `generic.mjs` 与 DSH 版都已在写记忆处 try/catch，但这轮没专门验证「异常冒泡到宿主」的路径）。另外没测「目录被改成只读/被删」这类权限型故障（C3 覆盖了「目录不存在」） |');
P();
P('**这一轮 G 组没有发现新缺陷**——5 条全部按预期工作（G1 的适配器是我新写的参考实现，顺带把三个易错的段类型处理对了）。');
P('这也说明一件事：前两轮修的 F-01 ~ F-05 是「逻辑错」，这一轮查的是「环境错」（网关/规模/并发/断电/满盘），');
P('逻辑错会被断言抓到，环境错只能靠这类场景逼出来。');
P();
P('---');
P();

// ---------- 8. 结论 ----------
P('## 8. 结论');
P();
P(`1. **升级路径可信**：从 v11.1 真实 DDL（含 CHECK、TEXT 时间、0–100 激素、废弃/转冷行）原地升级，${'`'}legacy_rows${'`'} 逐行快照 + 指纹逐行比对全部一致；空库、一万行库、脏库、半途中断库四种边界都走通。`);
P('2. **多情况运行时稳定**：scope 隔离、去重、候选 accept 重跑、冷却、FSRS、缺口、硬闸七条、出口清洗、预算裁剪、九类唤醒、utility 滞回、时间解析边界均有实测；无一条依赖 mock。');
P('3. **故障不静默**：损坏库报错且不覆盖原文件；坏备份不影响主库；embed 挂掉自动降级；双连接并发写无丢数据。');
P(`4. **性能可接受但需知情**：一万行升级本轮 ${d1ms} ms（冷盘可到 20 s 量级）、检索 P95 数十毫秒；如果实际库会到十万行，需要引入 FTS 召回或 ANN，而不是继续全表打分。`);
P('5. **回归未破**：交付包自带 305 项断言与 doctor 在本轮修复后仍全绿（E1/E2 在沙盒内复跑）。');
P('6. **7 个盲区全部有实测结论**（§6），其中 2 个暴露出真缺陷（F-04/F-05），已修入包。');
P('7. **5 条环境级边界也有实测**（§7）：几万条下检索 P95 284 ms、33 群零串味、强杀后可恢复、盘满抛错不静默；真 QQ 网关与 10 万行以上规模仍需你那边或后续补。');
P();
P('需要带走的判断：**「单次跑对」和「连续跑对」是两件事**。本轮 F1 的 1000 次写+检索、F2 的夜间串跑、F3 的 16 轮闭环，');
P('做的就是把单点正确性拉成连续时间上的正确性；F-04（浮卡永不前进）和 F-05（段落引用被下一轮清空）都属于「跑一次看不出、跑多轮才露」的那类。');
P();
P('本轮**没有改动任何 DSH 运行实例**，全部操作发生在 `sandbox/work/` 下。');
P();
P('---');
P();
P('## 9. 复现');
P();
P('```bash');
P('cd dsh-life-v13        # 包根（解开 zip 后的目录）');
P('node sandbox/run.mjs      # 47 场景，约 150 s，退出码 0 表示全绿');
P('node sandbox/report.mjs   # 重新生成本文件');
P('```');
P();
P('沙盒脚本随包分发（`sandbox/`），只用一个依赖：Node 内置 `node:sqlite`（Node ≥ 22.5，本轮在 v24.21.0 上跑）。');
P('它不读写任何 DSH 目录，只在自己目录下建 `sandbox/work/`；跑完可直接删。');
P();
P();
P(`原始数据：\`sandbox/work/result.json\`（每个断言、每条证据、每段异常栈都在里面）。`);
P();

mkdirSync(join(ROOT, 'logs'), { recursive: true });
const stamp = new Date().toISOString().slice(0, 10);
const out = join(ROOT, 'logs', `sandbox-log-${stamp}.md`);
writeFileSync(out, lines.join('\n'), 'utf8');
console.log('写出:', out, `(${lines.join('\n').length} 字符)`);