// sandbox/run.mjs — 沙盒测试总调度
// 用法：node sandbox/run.mjs
// 产物：sandbox/work/result.json（原始结果） + 控制台摘要
import { rmSync, mkdirSync, writeFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { Recorder, PKG } from './lib.mjs';
import { runA } from './scenarios/a-upgrade.mjs';
import { runB } from './scenarios/b-runtime.mjs';
import { runC } from './scenarios/c-fault.mjs';
import { runD } from './scenarios/d-perf.mjs';
import { runE } from './scenarios/e-regression.mjs';
import { runF } from './scenarios/f-blindspots.mjs';
import { runG } from './scenarios/g-edge.mjs';

const ROOT = dirname(fileURLToPath(import.meta.url));
const WORK = join(ROOT, 'work');

rmSync(WORK, { recursive: true, force: true });
mkdirSync(WORK, { recursive: true });
const work = (name) => {
  const d = join(WORK, name);
  mkdirSync(d, { recursive: true });
  return d;
};

const startedAt = new Date();
const t0 = Date.now();
const rec = new Recorder();

console.log('沙盒根目录:', WORK);
console.log('被测包   :', PKG);
console.log('Node     :', process.version);
console.log('');

const groups = [
  ['A', '升级路径（数据侧）', () => runA(rec, work)],
  ['B', '运行时行为（多情况）', () => runB(rec, work)],
  ['C', '故障注入', () => runC(rec, work)],
  ['D', '性能与规模', () => runD(rec, work)],
  ['E', '回归（自带测试）', () => runE(rec)],
  ['F', '7 个盲区（豆包点名：长跑/夜间/闭环/桥接/主动/升级后/配置）', () => runF(rec, work)],
  ['G', '边界 5 条（真网关形状/几万条衰减/33 群并发/强杀恢复/磁盘满）', () => runG(rec, work)],
];

for (const [g, title, fn] of groups) {
  const before = rec.scenarios.length;
  console.log(`\n===== ${g} 组：${title} =====`);
  try {
    await fn();
  } catch (e) {
    console.error(`[${g}] 组级异常:`, e && e.message);
    if (rec.cur) { rec.fail(e); rec.end(); }
  }
  for (const s of rec.scenarios.slice(before)) {
    const f = s.asserts.filter(a => !a.pass).length;
    const flag = s.error ? 'ERR' : f ? 'FAIL' : 'OK';
    console.log(`${flag.padEnd(4)} ${s.id.padEnd(4)} ${s.title}  (${s.asserts.length} 项, ${s.ms}ms)`);
    for (const a of s.asserts.filter(x => !x.pass)) {
      console.log(`       ✗ ${a.name}  got=${String(JSON.stringify(a.got) ?? 'undefined').slice(0, 200)}`);
    }
    if (s.error) console.log('       ! ' + String(s.error).split('\n').slice(0, 4).join('\n       ! '));
  }
}

const totals = rec.totals;
const finishedAt = new Date();
const result = {
  pkg: PKG,
  node: process.version,
  startedAt: startedAt.toISOString(),
  finishedAt: finishedAt.toISOString(),
  elapsedMs: Date.now() - t0,
  totals,
  scenarios: rec.scenarios,
  work: WORK,
};
writeFileSync(join(WORK, 'result.json'), JSON.stringify(result, null, 2), 'utf8');

console.log('\n================ 汇总 ================');
console.log(`场景 ${totals.scenarios} 个 / 断言 ${totals.pass + totals.fail} 条`);
console.log(`PASS ${totals.pass} / FAIL ${totals.fail} / ERR ${totals.errors}`);
console.log(`总耗时 ${(result.elapsedMs / 1000).toFixed(1)}s`);
console.log(`原始结果: ${join(WORK, 'result.json')}`);
process.exitCode = totals.fail > 0 || totals.errors > 0 ? 1 : 0;