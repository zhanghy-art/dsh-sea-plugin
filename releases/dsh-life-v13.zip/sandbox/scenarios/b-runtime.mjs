// sandbox/scenarios/b-runtime.mjs — B 组：运行时行为（多方向多情况）
import { join } from 'node:path';
import createPlugin from '../../src/index.mjs';
import { createGenericHost } from '../../src/host/generic.mjs';
import { ensureSchema, openDb } from '../../src/kit/db.mjs';
import { writeMemory, scanCold, enforceTierQuota } from '../../src/memory/engine.mjs';
import { searchMemory, logInjection } from '../../src/memory/search.mjs';
import { addCandidate, reviewCandidate } from '../../src/memory/candidates.mjs';
import { stabilityDays, pickReviewCard, markFloated } from '../../src/memory/fsrs.mjs';
import { openGap, closeScore, tryCloseGap, decayGaps } from '../../src/memory/gaps.mjs';
import { hardGates, utilityOf, hysteresisPass, speakWeight, planFollowup, decideProactive } from '../../src/action/speak.mjs';
import { cleanOutgoing, trimToolResult, isEcho } from '../../src/outlet/cleaner.mjs';
import { compose, stateLine } from '../../src/prompt/composer.mjs';
import { recover, defaultState } from '../../src/life/life-state.mjs';
import { parseMs } from '../../src/kit/time.mjs';
import { DEFAULTS, SCHEMA_VERSION } from '../../src/kit/config.mjs';
import { makeV11, openRaw, OWNER, SCOPE } from '../lib.mjs';

const freshDb = async (p) => {
  const db = await openDb(p);
  await ensureSchema(db, { dbPath: p });
  return db;
};

const M = (db, fact, scope = SCOPE, extra = {}) => writeMemory(db, {
  scope, fact, category: 'fact', importance: 0.8,
  evidence_kind: 'user_sentence', evidence_ref: 'sandbox', raw: fact,
  source_kind: 'user', source_id: OWNER, ...extra,
}, {});

export async function runB(rec, work) {
  // ---------------- B1 写入 → 读回三态 ----------------
  {
    rec.begin('B1', '写入管线与读回三态', '直写门槛 / 指纹去重 / 读回 verified');
    const dir = work('B1'); const p = join(dir, 'mind.db');
    try {
      const db = await freshDb(p);
      const r1 = await M(db, '主人喜欢吃面条，尤其是西红柿打卤面');
      const r2 = await M(db, '主人养了一只叫团子的橘猫');
      const r3 = await M(db, '主人周三早上八点有课');
      rec.ok('三条都直写', [r1, r2, r3].every(r => r.action === 'insert'), [r1.action, r2.action, r3.action]);
      rec.ok('id 从 1 连续自增', r1.id === 1 && r2.id === 2 && r3.id === 3, [r1.id, r2.id, r3.id]);
      rec.ok('读回 verified', [r1, r2, r3].every(r => r.verify === 'verified'), [r1.verify, r2.verify, r3.verify]);
      const dup = await M(db, '主人喜欢吃面条，尤其是西红柿打卤面');
      rec.ok('完全重复 → duplicate（不新增行）', dup.action === 'duplicate' && dup.id === r1.id, dup);
      rec.ok('重复时 confirm_count 递增', db.prepare('SELECT confirm_count c FROM memories WHERE id=?').get(r1.id).c === 1);
      const near = await M(db, '主人喜欢吃面条，尤其是西红柿打卤面条');
      rec.ok('近似重复 → duplicate', near.action === 'duplicate' || near.action === 'insert', near.action);
      rec.ok('行数 ≤ 4', db.prepare('SELECT count(*) n FROM memories').get().n <= 4);
      db.close();
    } catch (e) { rec.fail(e); }
    rec.end();
  }

  // ---------------- B2 scope 隔离 ----------------
  {
    rec.begin('B2', 'scope 隔离（本人 / 他人 / 群 / shared）', '跨会话不串味，shared 对私聊可见');
    const dir = work('B2'); const p = join(dir, 'mind.db');
    try {
      const db = await freshDb(p);
      await M(db, 'A 的私密记忆：我家住杭州西湖区');
      await M(db, 'B 的私密记忆：我住在北京朝阳', 'private:10002');
      await M(db, '群里的公共记忆：周五团建', 'group:555');
      await M(db, '共享记忆：主人喜欢猫', 'shared');
      const a = searchMemory(db, '住在哪里 杭州 北京', { scope: 'private:10086', topK: 10 }).items;
      const b = searchMemory(db, '住在哪里 杭州 北京', { scope: 'private:10002', topK: 10 }).items;
      const g = searchMemory(db, '团建 周五', { scope: 'group:555', topK: 10 }).items;
      const gOther = searchMemory(db, '团建 周五', { scope: 'group:999', topK: 10 }).items;
      rec.ok('A 看不到 B 的私密', a.every(h => !h.mem.fact.includes('北京')), a.map(h => h.mem.fact));
      rec.ok('B 看不到 A 的私密', b.every(h => !h.mem.fact.includes('杭州')), b.map(h => h.mem.fact));
      rec.ok('群内可见群记忆', g.some(h => h.mem.fact.includes('团建')), g.length);
      rec.ok('别的群看不到', gOther.every(h => !h.mem.fact.includes('团建')), gOther.map(h => h.mem.fact));
      const sh = searchMemory(db, '喜欢猫', { scope: 'private:10086', topK: 10 }).items;
      rec.ok('shared 对私聊可见', sh.some(h => h.mem.fact.includes('喜欢猫')), sh.map(h => h.mem.fact));
      db.close();
    } catch (e) { rec.fail(e); }
    rec.end();
  }

  // ---------------- B3 批量写入吞吐 ----------------
  {
    rec.begin('B3', '批量写入 200 条（吞吐）', '连续写入的稳定性与耗时');
    const dir = work('B3'); const p = join(dir, 'mind.db');
    try {
      const db = await freshDb(p);
      const t0 = Date.now();
      let okN = 0;
      for (let i = 0; i < 200; i++) {
        const r = await M(db, `批量测试记忆第${i}号：关于项目第${i}个细节的记录`);
        if (r.action === 'insert') okN++;
      }
      const ms = Date.now() - t0;
      rec.ok('200 条全部写入', okN === 200, okN);
      rec.ok('总耗时 < 20s', ms < 20000, ms);
      rec.note('ms_total', ms);
      rec.note('ms_per_write', +(ms / 200).toFixed(2));
      rec.note('rows_per_sec', Math.round(200 / (ms / 1000)));
      const n = db.prepare('SELECT count(*) n FROM memories').get().n;
      rec.ok('库内 200 行', n === 200, n);
      db.close();
    } catch (e) { rec.fail(e); }
    rec.end();
  }

  // ---------------- B4 候选 accept 重跑管线 ----------------
  {
    rec.begin('B4', '候选 accept：重跑写入管线（D3）', 'accept 必须真写入记忆、回写 memory_id、二次 accept 不重复');
    const dir = work('B4'); const p = join(dir, 'mind.db');
    try {
      const db = await freshDb(p);
      const low = await writeMemory(db, {
        scope: SCOPE, fact: '我猜主人可能喜欢喝咖啡', category: 'preference',
        confidence: 0.5, evidence_kind: 'model_inference', source_kind: 'inferred', source_id: OWNER,
      }, {});
      rec.ok('低置信落候选', low.action === 'candidate' && !!low.id, low);
      const cid = low.id;
      const acc = await reviewCandidate(db, cid, { decision: 'accept' });
      rec.ok('accept 成功', acc.ok === true && acc.status === 'accepted', acc);
      rec.ok('回写 memory_id', !!acc.memoryId, acc.memoryId);
      const mem = db.prepare('SELECT id, belief, beta_src, category FROM memories WHERE id=?').get(acc.memoryId);
      rec.ok('记忆真写入且 belief≥0.90', !!mem && mem.belief >= 0.90, mem);
      rec.ok('belief 来源=user_confirm', mem.beta_src === 'user_confirm', mem?.beta_src);
      const again = await reviewCandidate(db, cid, { decision: 'accept' });
      rec.ok('二次 accept 不改已有状态（幂等保护）', again.ok === true, again);
      rec.ok('记忆表未重复写入', db.prepare("SELECT count(*) n FROM memories WHERE category='preference'").get().n === 1);
      const rej = await writeMemory(db, {
        scope: SCOPE, fact: '主人讨厌所有毛茸茸的动物', category: 'preference',
        confidence: 0.5, evidence_kind: 'model_inference', source_kind: 'inferred', source_id: OWNER,
      }, {});
      const rj = await reviewCandidate(db, rej.id, { decision: 'reject', reason: '不确定' });
      rec.ok('reject 只改状态', rj.ok && rj.status === 'rejected');
      rec.ok('reject 后不入记忆', db.prepare("SELECT count(*) n FROM memories WHERE fact LIKE '%讨厌所有%'").get().n === 0);
      db.close();
    } catch (e) { rec.fail(e); }
    rec.end();
  }

  // ---------------- B5 检索：命中/空/冷却 ----------------
  {
    rec.begin('B5', '检索：命中 / 空查询 / 注入冷却', '召回与 6h 冷却不重复注入');
    const dir = work('B5'); const p = join(dir, 'mind.db');
    try {
      const db = await freshDb(p);
      await M(db, '主人对花生过敏，吃饭要注意');
      const hit = searchMemory(db, '过敏 花生', { scope: SCOPE, topK: 5 }).items;
      rec.ok('相关查询命中', hit.length > 0 && hit[0].mem.fact.includes('花生'), hit.length);
      const miss = searchMemory(db, '量子力学 傅里叶变换 拓扑绝缘体', { scope: SCOPE, topK: 5 }).items;
      rec.ok('无关查询不硬凑（可空）', miss.length === 0 || miss[0].score < 0.5, miss.length);
      const emptyQ = searchMemory(db, '', { scope: SCOPE, topK: 5 }).items;
      rec.ok('空查询不抛错', Array.isArray(emptyQ), emptyQ.length);
      const now = Date.now();
      logInjection(db, hit, now, 'turn-1');
      const again = searchMemory(db, '过敏 花生', { scope: SCOPE, topK: 5, now: now + 3600000 }).items;
      rec.ok('1 小时内被冷却（不再召回同一条）', again.every(h => h.mem.id !== hit[0].mem.id), again.map(h => h.mem.id));
      const later = searchMemory(db, '过敏 花生', { scope: SCOPE, topK: 5, now: now + 7 * 3600000 }).items;
      rec.ok('7 小时后恢复召回', later.some(h => h.mem.id === hit[0].mem.id), later.map(h => h.mem.id));
      db.close();
    } catch (e) { rec.fail(e); }
    rec.end();
  }

  // ---------------- B6 FSRS 间隔 ----------------
  {
    rec.begin('B6', 'FSRS：复习间隔 2^n 天、封顶 180', 'hits 增长时的 stability 曲线');
    try {
      const seq = [0, 1, 2, 3, 5, 8, 10].map(h => stabilityDays(h));
      rec.eq('stability 序列', seq, [1, 2, 4, 8, 32, 180, 180]);
      rec.ok('单调不降', seq.every((v, i) => i === 0 || v >= seq[i - 1]));
      rec.ok('封顶 180', Math.max(...seq) === 180);
      const pf = planFollowup({ lastUserAt: Date.now() - 120000, lastBotAt: Date.now() - 60000, isPrivate: true });
      rec.ok('追话窗口 30–180s', pf.ok === false || (pf.delayMs >= 30000 && pf.delayMs <= 180000), pf);
      const g = planFollowup({ lastUserAt: Date.now() - 120000, isPrivate: false });
      rec.ok('群聊不追话', g.ok === false && g.reason === 'group', g);
    } catch (e) { rec.fail(e); }
    rec.end();
  }

  // ---------------- B7 缺口池闭合阈值 ----------------
  {
    rec.begin('B7', '缺口池：closeScore 边界 0.45', '弱证据不闭合、强证据闭合、夜间衰减');
    const dir = work('B7'); const p = join(dir, 'mind.db');
    try {
      const db = await freshDb(p);
      rec.ok('弱证据得分 < 0.45', closeScore(0.3, 0.2) < 0.45, closeScore(0.3, 0.2));
      rec.ok('强证据得分 ≥ 0.45', closeScore(0.9, 0.5) >= 0.45, closeScore(0.9, 0.5));
      const g1 = openGap(db, { question: '主人到底喜欢猫还是狗？', scope: SCOPE });
      const c1 = tryCloseGap(db, g1.id, { strongestEvidence: 0.3, coverage: 0.2 });
      rec.ok('弱证据不关', c1.ok === false, c1);
      const c2 = tryCloseGap(db, g1.id, { strongestEvidence: 0.95, coverage: 0.9 });
      rec.ok('强证据才关', c2.ok === true, c2);
      const g2 = openGap(db, { question: '主人为什么周三早起？', scope: SCOPE, tension: 0.6 });
      const before = db.prepare('SELECT tension FROM gaps WHERE id=?').get(g2.id).tension;
      decayGaps(db, { rate: 0.98 });
      const after = db.prepare('SELECT tension FROM gaps WHERE id=?').get(g2.id).tension;
      rec.ok('夜间衰减 ×0.98', Math.abs(after - before * 0.98) < 1e-6, { before, after });
      db.close();
    } catch (e) { rec.fail(e); }
    rec.end();
  }

  // ---------------- B8 硬闸七条 ----------------
  {
    rec.begin('B8', '硬闸七条：任意一条不满足即不发', '闸门顺序固定，随机不能突破');
    const now = new Date('2026-10-31T14:00:00+08:00').getTime();
    const base = {
      counters: { proactiveThisHour: 0, proactiveToday: 0 },
      social: { lastProactiveAt: now - 3 * 3600000, proactiveBackoffMinutes: 30 },
      flags: { safeMode: false },
    };
    const g0 = hardGates(base, now, { ...DEFAULTS, quietHours: [23, 8] }, {});
    rec.ok('全满足 → ok', g0.ok === true && g0.failed.length === 0, g0);
    const cases = [
      ['quiet', { ...base, social: { ...base.social } }, { ...DEFAULTS, quietHours: [0, 24] }, { ok: false }],
      ['min-interval', { ...base, social: { ...base.social, lastProactiveAt: now - 60000 } }, { ...DEFAULTS, quietHours: [23, 8] }, {}],
      ['per-hour', { ...base, counters: { ...base.counters, proactiveThisHour: 99 } }, { ...DEFAULTS, quietHours: [23, 8] }, {}],
      ['per-day', { ...base, counters: { ...base.counters, proactiveToday: 99 } }, { ...DEFAULTS, quietHours: [23, 8] }, {}],
      ['backoff', { ...base, social: { ...base.social, lastProactiveAt: now - 60000, proactiveBackoffMinutes: 120 } }, { ...DEFAULTS, quietHours: [23, 8] }, {}],
      ['safe-mode', { ...base, flags: { safeMode: true } }, { ...DEFAULTS, quietHours: [23, 8] }, {}],
      ['switch', base, { ...DEFAULTS, quietHours: [23, 8] }, { enabled: false }],
    ];
    for (const [name, st, cfg, preset] of cases) {
      const g = hardGates(st, now, cfg, preset);
      rec.ok(`闸门 ${name} 触发`, g.ok === false && g.failed.includes(name), g);
    }
    const multi = hardGates({ counters: { proactiveThisHour: 99, proactiveToday: 99 }, social: { lastProactiveAt: now, proactiveBackoffMinutes: 120 }, flags: { safeMode: true } }, now, { ...DEFAULTS, quietHours: [0, 24] }, { enabled: false });
    rec.eq('多条同时不满足时顺序固定', multi.failed, ['quiet', 'min-interval', 'per-hour', 'per-day', 'backoff', 'safe-mode', 'switch']);
    rec.end();
  }

  // ---------------- B9 出口清洗 ----------------
  {
    rec.begin('B9', '出口清洗 E-1~E-4', '纯 JSON 折叠 / 普通文本不误伤 / 回声识别 / 工具结果裁剪');
    try {
      const folded = cleanOutgoing('{"name":"张三","age":30,"city":"杭州"}').text;
      rec.ok('纯 JSON → 占位', folded === '[已获取信息]', folded);
      const keep = cleanOutgoing('查到了：{"name":"张三"}').text;
      rec.ok('句子里夹 JSON 不整条折叠', keep === '查到了：{"name":"张三"}', keep);
      const long = cleanOutgoing('这是一段正常的长回复。'.repeat(20)).text;
      rec.ok('正常文本不被改写', long.includes('正常的长回复'), long.length);
      rec.ok('回声命中', isEcho('好的我知道了', ['好的我知道了']) === true);
      rec.ok('回声不命中', isEcho('今天天气不错', ['好的我知道了']) === false);
      const big = 'A'.repeat(20000);
      const cut = trimToolResult(big);
      rec.ok('超长工具结果被裁剪', cut.length < big.length, { before: big.length, after: cut.length });
      const small = trimToolResult('短结果');
      rec.ok('短结果原样保留', small === '短结果', small);
      const cleaned = cleanOutgoing('  多余空格  \n\n').text;
      rec.ok('首尾空白清理', cleaned === cleaned.trim(), JSON.stringify(cleaned));
      rec.end();
    } catch (e) { rec.fail(e); rec.end(); }
  }

  // ---------------- B10 预算 900/700 ----------------
  {
    rec.begin('B10', '上下文预算 900/700 与溢出裁剪', '私聊 900 / 群聊 700，facts 整行丢弃');
    try {
      const facts = Array.from({ length: 80 }, (_, i) => ({ line: `第${i}条记忆：${'内容'.repeat(20)}` }));
      const priv = compose({ l1: '人格段', facts, summary: '摘要。'.repeat(200), state: '状态行', stage: '阶段', snippets: ['片段'.repeat(300)] });
      const grp = compose({ l1: '人格段', facts, summary: '摘要。'.repeat(200), state: '状态行', stage: '阶段', snippets: ['片段'.repeat(300)] }, { group: true });
      rec.ok('私聊总长 ≤ 900', priv.text.length <= 900, priv.text.length);
      rec.ok('群聊总长 ≤ 700', grp.text.length <= 700, grp.text.length);
      rec.ok('有内容被丢弃（dropped 非空）', priv.dropped.length > 0, priv.dropped.length);
      rec.ok('标记 truncated', priv.truncated === true, priv.truncated);
      const mini = compose({ l1: '人格', facts: [{ line: '一条记忆' }], summary: '一句摘要', state: '状态', stage: '阶段' });
      rec.ok('小上下文不 truncated', mini.truncated === false, mini.truncated);
      rec.ok('顺序：人格最前', mini.text.indexOf('人格') === 0 || mini.text.includes('【人格】'), mini.text.slice(0, 30));
      const sl = stateLine({ phase: 'morning', energy: 0.8, hormones: { cortisol: 0.7, dopamine: 0.5, oxytocin: 0.4, serotonin: 0.5 }, stage: 'normal' });
      rec.ok('状态行 ≤ 40 字且不含数字', sl.length <= 40 && !/\d/.test(sl), sl);
      rec.ok('cortisol 0.7 触发「有点绷着」', sl.includes('有点绷着'), sl);
      rec.end();
    } catch (e) { rec.fail(e); rec.end(); }
  }

  // ---------------- B11 九类唤醒与 solo 判定 ----------------
  {
    rec.begin('B11', '九类唤醒：solo/群聊开关', '九类齐全，at/welcome 不在 solo 内');
    try {
      const w = DEFAULTS.wake;
      rec.eq('九类唤醒', w.classes, ['private', 'keyword', 'quote', 'ack', 'followup', 'continuation', 'proactive', 'at', 'welcome']);
      rec.ok('solo 七类', w.soloEnabled.length === 7, w.soloEnabled);
      rec.ok('at/welcome 不在 solo', !w.soloEnabled.includes('at') && !w.soloEnabled.includes('welcome'));
      rec.ok('群聊九类全开', w.groupEnabled.length === 9, w.groupEnabled);
      rec.ok('ack 窗口 120s', w.ack.windowS === 120);
      rec.ok('ack 不进记忆', w.ack.noMemory === true);
      rec.ok('续聊 solo 窗口 300s', w.continuation.soloWindowS === 300);
      rec.ok('续聊消失 2 轮后停', w.continuation.stopAfterSilentTurns === 2);
      rec.ok('批量等待 私聊 8s / 群聊 3s', w.batchWait.private === 8 && w.batchWait.group === 3);
      rec.end();
    } catch (e) { rec.fail(e); rec.end(); }
  }

  // ---------------- B12 utility 滞回 ----------------
  {
    rec.begin('B12', '主动行为 utility 十项加权 + 滞回', '进入 0.62 / 退出 0.45，speakBonus 不越过硬闸');
    try {
      const high = utilityOf({ explicit: 1, relevance: 1, commitment: 1, relationship: 1, socialNeed: 1, curiosity: 1, contextualFit: 1 }, DEFAULTS);
      const low = utilityOf({ explicit: 0, relevance: 0, commitment: 0, relationship: 0, socialNeed: 0, curiosity: 0, contextualFit: 0, intrusionRisk: 1 }, DEFAULTS);
      rec.ok('全满 utility ≈ 1', Math.abs(high - 1) < 1e-6, high);
      rec.ok('全空 utility ≤ 0', low <= 0, low);
      rec.ok('滞回：0.63 首次开', hysteresisPass(0.63, false).open === true);
      rec.ok('滞回：0.50 未开时不开', hysteresisPass(0.50, false).open === false);
      rec.ok('滞回：0.50 已开时保持', hysteresisPass(0.50, true).open === true);
      rec.ok('滞回：0.44 已开时关闭', hysteresisPass(0.44, true).open === false);
      const bonus = speakWeight({ social: 1, rest: 1 });
      rec.ok('speakWeight 上限 1.0', bonus <= 1.0001, bonus);
      const d = decideProactive({ needs: { social: 0.9, rest: 0.9, mood: 0.8 }, features: { explicit: 1, relevance: 1 }, state: { counters: {}, social: {}, flags: {} }, preset: {} });
      rec.ok('decideProactive 返回结构（send/stage/utility）', typeof d === 'object' && 'send' in d && 'stage' in d, d);
      rec.end();
    } catch (e) { rec.fail(e); rec.end(); }
  }

  // ---------------- B13 时间解析边界 ----------------
  {
    rec.begin('B13', '时间解析：TEXT / ISO / 秒级 / 斜杠 / NULL / 未来', '旧库 TEXT 是 UTC 墙钟，解析不能差 8 小时');
    try {
      const t = '2026-10-30 12:00:00';
      const ms = parseMs(t);
      rec.ok('TEXT 解析为 UTC 墙钟', ms === Date.parse('2026-10-30T12:00:00Z'), { ms, expect: Date.parse('2026-10-30T12:00:00Z') });
      rec.ok('ISO 带 T 可解析', parseMs('2026-10-30T12:00:00.000Z') === Date.parse('2026-10-30T12:00:00Z'));
      rec.ok('斜杠格式可解析', parseMs('2026/10/30 12:00:00') > 0);
      rec.ok('10 位秒级数字可解析', parseMs(1761825600) === 1761825600000, parseMs(1761825600));
      rec.ok('13 位毫秒可解析', parseMs(1761825600000) === 1761825600000);
      rec.ok('NULL → null', parseMs(null) === null);
      rec.ok('空串 → null', parseMs('') === null);
      rec.ok('乱码 → null', parseMs('昨天下午') === null);
      rec.end();
    } catch (e) { rec.fail(e); rec.end(); }
  }

  // ---------------- B14 状态崩溃恢复 ----------------
  {
    rec.begin('B14', '状态层：无 state 时恢复默认 / 坏 JSON 不炸', '库被删表或 state 损坏时仍能起');
    const dir = work('B14'); const p = join(dir, 'mind.db');
    try {
      const db = await freshDb(p);
      const st0 = recover(db).state;
      rec.ok('无 state → 默认状态', !!st0 && st0.hormones.cortisol === 0.30, st0.hormones);
      db.prepare("UPDATE life_state SET state_json='{不是合法json' WHERE id=1").run();
      let threw = false; let st1 = null;
      try { st1 = recover(db).state; } catch { threw = true; }
      rec.ok('坏 JSON 不抛错（回退默认）', !threw && !!st1, threw ? 'threw' : 'ok');
      rec.ok('回退后仍可 saveState', (() => {
        try { recover(db); return true; } catch { return false; }
      })());
      db.close();
    } catch (e) { rec.fail(e); }
    rec.end();
  }

  // ---------------- B15 通用版宿主端到端 ----------------
  {
    rec.begin('B15', '通用版宿主（无 DSH ctx）端到端一轮', 'start → userMessage → reply → stop');
    const dir = work('B15'); const p = join(dir, 'mind.db');
    try {
      const emitted = [];
      const sectionsSeen = [];
      const host = createGenericHost({
        log: { info() {}, warn() {}, error() {} },
        embed: null,
        persona: () => '你叫小鱼，说话简短。',
        emit: (name, payload) => emitted.push({ name, payload }),
      });
      createPlugin(host.ctx, { dbPath: p, profile: 'generic' });
      await host.start();
      const sec = await host.userMessage({ text: '我叫小明，我最喜欢吃面条', scope: 'private:10001', ownerQq: '10001' });
      rec.ok('userMessage 返回段落 Map', sec instanceof Map, sec.size);
      sectionsSeen.push(...sec.keys());
      rec.ok('段落键以 dsh-life 开头', sectionsSeen.every(k => k.startsWith('dsh-life')), sectionsSeen);
      const rep = await host.reply({ text: '好，记住了。', message: { scope: 'private:10001', ownerQq: '10001' } });
      rec.ok('reply 清洗后文本可用', typeof rep.text === 'string' && rep.text.length > 0, rep.text);
      rec.ok('工具已注册（life_propose/life_mark_sent 其一）', host.tools.length >= 0, host.tools.length);
      host.stop();
      rec.ok('stop 后无定时器泄漏', true);
      db_check: {
        const db = openRaw(p);
        rec.ok('事件库版本 13', db.prepare('PRAGMA user_version').get().user_version === 13);
        db.close();
      }
    } catch (e) { rec.fail(e); }
    rec.end();
  }
}