// sandbox/scenarios/c-fault.mjs — C 组：故障注入
import { join } from 'node:path';
import { writeFileSync, mkdirSync, existsSync, readdirSync, copyFileSync } from 'node:fs';
import { ensureSchema, openDb } from '../../src/kit/db.mjs';
import { writeMemory } from '../../src/memory/engine.mjs';
import { recover } from '../../src/life/life-state.mjs';
import { makeV11, openRaw, OWNER, SCOPE } from '../lib.mjs';

export async function runC(rec, work) {
  // ---------------- C1 库文件损坏 ----------------
  {
    rec.begin('C1', '库文件被破坏（100 字节垃圾）', '必须显式报错，不能静默重建覆盖用户数据');
    const dir = work('C1'); const p = join(dir, 'mind.db');
    try {
      writeFileSync(p, Buffer.from('这不是一个 sqlite 文件'.repeat(10)));
      let err = null;
      try {
        const db = await openDb(p);
        await ensureSchema(db, { dbPath: p });
        db.close();
      } catch (e) { err = e; }
      rec.ok('抛错而非静默通过', !!err, err && err.message);
      rec.ok('错误信息可辨识', !!err && /not a database|file is encrypted|malformed|no such table/i.test(err.message), err && err.message);
      rec.ok('原文件未被覆盖为空库', existsSync(p));
      rec.note('error', err ? err.message : null);
    } catch (e) { rec.fail(e); }
    rec.end();
  }

  // ---------------- C2 备份文件损坏不影响主库 ----------------
  {
    rec.begin('C2', '备份文件损坏（主库正常）', '坏备份不能被当成可回滚的库');
    const dir = work('C2'); const p = join(dir, 'mind.db');
    try {
      makeV11(p, { rows: 30 });
      // 先造一份坏备份，模拟上次升级留下的残骸
      writeFileSync(join(dir, 'mind.db.v13.bak.2026-10-01T00-00-00-000Z'), 'broken backup');
      const db = await openDb(p);
      const r = await ensureSchema(db, { dbPath: p });
      rec.ok('主库仍能升级', r.upgraded === true, r);
      rec.ok('指纹一致', r.fingerprintOk === true);
      rec.ok('新备份已生成（与坏文件并存）', readdirSync(dir).filter(f => f.startsWith('mind.db.v13.bak.')).length >= 2);
      rec.ok('旧数据仍可读', db.prepare('SELECT count(*) n FROM memories').get().n === 30);
      db.close();
    } catch (e) { rec.fail(e); }
    rec.end();
  }

  // ---------------- C3 目录不存在 ----------------
  {
    rec.begin('C3', '目标目录不存在', '报错要指名路径，而不是静默创建到错误位置');
    const dir = work('C3');
    const p = join(dir, 'no', 'such', 'dir', 'mind.db');
    try {
      let err = null;
      try {
        const db = await openDb(p);
        await ensureSchema(db, { dbPath: p });
        db.close();
      } catch (e) { err = e; }
      rec.ok('抛错', !!err, err && err.message);
      rec.note('error', err ? err.message.split('\n')[0] : null);
      rec.note('known_limitation', 'v13 不自动 mkdir，由宿主负责建目录（DSH 侧由 plugin 启动时保证）');
    } catch (e) { rec.fail(e); }
    rec.end();
  }

  // ---------------- C4 embed 抛异常 ----------------
  {
    rec.begin('C4', '向量服务抛异常', 'embed 失败不能影响写入与恢复，必须降级为纯文本');
    const dir = work('C4'); const p = join(dir, 'mind.db');
    try {
      const db = await openDb(p);
      await ensureSchema(db, { dbPath: p });
      const deps = { embed: async () => { throw new Error('embed service down'); } };
      let threw = false; let r = null;
      try {
        r = await writeMemory(db, {
          scope: SCOPE, fact: '向量服务挂了也应该写得进去', category: 'fact', importance: 0.8,
          evidence_kind: 'user_sentence', raw: '向量服务挂了也应该写得进去', source_kind: 'user', source_id: OWNER,
        }, deps);
      } catch (e) { threw = true; }
      rec.ok('写入不抛错', !threw, threw ? 'threw' : 'ok');
      rec.ok('记忆已落库', !!r && r.action === 'insert', r);
      const row = db.prepare('SELECT vec, vec_model FROM memories WHERE id=?').get(r.id);
      rec.ok('vec 为空但不影响其他列', row.vec === null, row);
      const st = recover(db).state;
      rec.ok('状态层仍可恢复', !!st && !!st.hormones);
      db.close();
    } catch (e) { rec.fail(e); }
    rec.end();
  }

  // ---------------- C5 双连接并发写 ----------------
  {
    rec.begin('C5', '两个连接同时写（WAL 并发）', 'busy 时可重试，不能丢数据');
    const dir = work('C5'); const p = join(dir, 'mind.db');
    try {
      const a = await openDb(p);
      await ensureSchema(a, { dbPath: p });
      const b = await openDb(p);
      let okA = 0, okB = 0, busy = 0;
      for (let i = 0; i < 20; i++) {
        try { await writeMemory(a, { scope: SCOPE, fact: `A 连接写入第${i}条`, category: 'fact', importance: 0.8, evidence_kind: 'user_sentence', source_kind: 'user' }, {}); okA++; }
        catch (e) { if (/busy|locked/i.test(e.message)) busy++; else throw e; }
        try { await writeMemory(b, { scope: SCOPE, fact: `B 连接写入第${i}条`, category: 'fact', importance: 0.8, evidence_kind: 'user_sentence', source_kind: 'user' }, {}); okB++; }
        catch (e) { if (/busy|locked/i.test(e.message)) busy++; else throw e; }
      }
      const n = a.prepare('SELECT count(*) n FROM memories').get().n;
      rec.ok('无 busy 冲突（或已全部重试）', busy === 0 || okA + okB + busy === 40, { okA, okB, busy });
      rec.ok('写入条数与成功数一致', n === okA + okB, { n, okA, okB });
      rec.note('okA', okA); rec.note('okB', okB); rec.note('busy', busy); rec.note('rows', n);
      a.close(); b.close();
    } catch (e) { rec.fail(e); }
    rec.end();
  }
}