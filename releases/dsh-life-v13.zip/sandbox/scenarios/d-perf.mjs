// sandbox/scenarios/d-perf.mjs — D 组：性能与规模
import { join } from 'node:path';
import { statSync } from 'node:fs';
import { ensureSchema, openDb } from '../../src/kit/db.mjs';
import { writeMemory } from '../../src/memory/engine.mjs';
import { searchMemory } from '../../src/memory/search.mjs';
import { makeV11, fileSize, OWNER, SCOPE } from '../lib.mjs';

const pct = (arr, p) => {
  const s = [...arr].sort((a, b) => a - b);
  return s[Math.min(s.length - 1, Math.floor(s.length * p))];
};

export async function runD(rec, work) {
  // ---------------- D1 一万行升级 ----------------
  {
    rec.begin('D1', '一万行旧库升级', '规模上限下的耗时与体积');
    const dir = work('D1'); const p = join(dir, 'mind.db');
    try {
      makeV11(p, { rows: 10000 });
      const before = fileSize(p);
      const db = await openDb(p);
      const t0 = Date.now();
      const r = await ensureSchema(db, { dbPath: p });
      const ms = Date.now() - t0;
      rec.ok('升级成功且指纹一致', r.upgraded && r.fingerprintOk, r);
      rec.ok('一万行保留', db.prepare('SELECT count(*) n FROM memories').get().n === 10000);
      rec.ok('legacy_rows 一万行', db.prepare('SELECT count(*) n FROM legacy_rows').get().n === 10000);
      rec.ok('耗时 < 180s', ms < 180000, ms);
      rec.note('rows', 10000);
      rec.note('upgrade_ms', ms);
      rec.note('size_before_kb', Math.round(before / 1024));
      rec.note('size_after_kb', Math.round(fileSize(p) / 1024));
      rec.note('ms_per_1000', Math.round(ms / 10));
      db.close();
    } catch (e) { rec.fail(e); }
    rec.end();
  }

  // ---------------- D2 大库检索延迟 ----------------
  {
    rec.begin('D2', '一万行库检索 100 次（延迟分布）', 'P50 / P95 是否可接受');
    const dir = work('D2'); const p = join(dir, 'mind.db');
    try {
      makeV11(p, { rows: 3000 });
      const db = await openDb(p);
      await ensureSchema(db, { dbPath: p });
      const queries = ['主人 习惯', '面条 西红柿', '橘猫 团子', '周三 上课', '生日 十月', '熬夜 睡觉'];
      const times = [];
      let total = 0;
      for (let i = 0; i < 100; i++) {
        const q = queries[i % queries.length];
        const t0 = process.hrtime.bigint();
        const hits = searchMemory(db, q, { scope: SCOPE, topK: 6 }).items;
        const t1 = process.hrtime.bigint();
        const ms = Number(t1 - t0) / 1e6;
        times.push(ms); total += hits.length;
      }
      const p50 = pct(times, 0.5), p95 = pct(times, 0.95), max = Math.max(...times);
      rec.ok('P50 < 120ms', p50 < 120, p50.toFixed(1));
      rec.ok('P95 < 400ms', p95 < 400, p95.toFixed(1));
      rec.note('p50_ms', +p50.toFixed(1));
      rec.note('p95_ms', +p95.toFixed(1));
      rec.note('max_ms', +max.toFixed(1));
      rec.note('avg_hits', +(total / 100).toFixed(2));
      db.close();
    } catch (e) { rec.fail(e); }
    rec.end();
  }

  // ---------------- D3 写入延迟 ----------------
  {
    rec.begin('D3', '写入 1000 条（延迟与库体积增长）', '单条写入成本是否线性');
    const dir = work('D3'); const p = join(dir, 'mind.db');
    try {
      const db = await openDb(p);
      await ensureSchema(db, { dbPath: p });
      const times = [];
      const t0 = Date.now();
      for (let i = 0; i < 1000; i++) {
        const s = process.hrtime.bigint();
        await writeMemory(db, {
          scope: SCOPE, fact: `写入压测第${i}条：关于第${i}个话题的具体内容描述`,
          category: 'fact', importance: 0.7, evidence_kind: 'user_sentence',
          raw: `第${i}条原话`, source_kind: 'user', source_id: OWNER,
        }, {});
        times.push(Number(process.hrtime.bigint() - s) / 1e6);
      }
      const total = Date.now() - t0;
      const p50 = pct(times, 0.5), p95 = pct(times, 0.95);
      rec.ok('P50 < 30ms', p50 < 30, p50.toFixed(2));
      rec.ok('P95 < 80ms', p95 < 80, p95.toFixed(2));
      rec.ok('1000 条总耗时 < 30s', total < 30000, total);
      rec.note('total_ms', total);
      rec.note('p50_ms', +p50.toFixed(2));
      rec.note('p95_ms', +p95.toFixed(2));
      rec.note('size_kb', Math.round(statSync(p).size / 1024));
      db.close();
    } catch (e) { rec.fail(e); }
    rec.end();
  }
}