#!/usr/bin/env node
// scripts/doctor.mjs — 自检（v12.0 共 158 项；本文件实现 30–42 项硬检查，视环境而定，其余为人工/长周期项）
// 用法：node scripts/doctor.mjs [--all] [--db path]
import { existsSync, statSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';

const args = process.argv.slice(2);
const getArg = (k, d) => { const i = args.indexOf(k); return i >= 0 ? args[i + 1] : d; };
const DB = getArg('--db', join(process.env.HOME || '.', '.dsh', 'dsh-life', 'mind.db'));

const results = [];
const add = (group, name, ok, detail = '') => results.push({ group, name, ok, detail });

function checkEnv() {
  const major = Number(process.versions.node.split('.')[0]);
  add('环境', 'Node >= 22', major >= 22, `当前 ${process.versions.node}`);
  add('环境', 'Node 支持 node:sqlite', major > 22 || (major === 22 && Number(process.versions.node.split('.')[1]) >= 5));
  add('环境', 'DSH_L0 未关闭', process.env.DSH_L0 !== 'off', process.env.DSH_L0 || '');
  add('环境', '库文件存在', existsSync(DB), DB);
  if (existsSync(DB)) {
    const size = statSync(DB).size;
    add('环境', '库体积 < 2GB', size < 2 * 1024 * 1024 * 1024, `${(size / 1048576).toFixed(1)} MB`);
    add('环境', 'WAL 体积 < 主库 2 倍', !existsSync(DB + '-wal') || statSync(DB + '-wal').size < size * 2);
  }
}

async function checkDb() {
  let DatabaseSync;
  try { ({ DatabaseSync } = await import('node:sqlite')); } catch {
    add('数据库', 'node:sqlite 可用', false, '跳过后续库检查');
    return;
  }
  if (!existsSync(DB)) return;
  const db = new DatabaseSync(DB, { readOnly: true });
  const q = (sql) => db.prepare(sql).get();

  const integ = q('PRAGMA integrity_check');
  add('数据库', 'integrity_check', Object.values(integ)[0] === 'ok', String(Object.values(integ)[0]));
  add('数据库', 'journal_mode=WAL', String(q('PRAGMA journal_mode').journal_mode).toLowerCase() === 'wal');

  const cols = db.prepare('PRAGMA table_info(memories)').all().map(r => r.name);
  for (const c of ['beta', 'beta_src', 'region', 'importance']) {
    add('数据库', `memories.${c} 存在`, cols.includes(c));
  }
  const tables = db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all().map(r => r.name);
  for (const t of ['edges', 'kv', 'action_proposals', 'life_state', 'life_events', 'life_snapshots']) {
    add('数据库', `表 ${t} 存在`, tables.includes(t));
  }
  for (const t of ['memory_evidence', 'memory_cells', 'gaps', 'context_checkpoints']) {
    add('数据库', `v12.1 表 ${t}`, tables.includes(t));
  }
  for (const c of ['belief', 'protection_tier', 'content_hash', 'origin_key']) {
    add('数据库', `v12.1 列 memories.${c}`, cols.includes(c));
  }
  const ver = tables.includes('kv') ? q("SELECT v FROM kv WHERE k='schema_version'")?.v : null;
  add('数据库', 'user_version 已打戳', (() => { try { return Number(q('PRAGMA user_version').user_version) >= 13; } catch { return false; } })());
  add('数据库', 'schema_version 13.x', String(ver || '').startsWith('13'), ver || '未标记');
  const total = q('SELECT COUNT(*) AS n FROM memories WHERE invalid_reason IS NULL').n;
  const core = q("SELECT COUNT(*) AS n FROM memories WHERE protection_tier='core' AND invalid_reason IS NULL").n;
  add('治理', 'core 层级 <=3%', total === 0 || core / total <= 0.0301, `${core}/${total}`);

  if (total > 0) {
    const hi = q('SELECT COUNT(*) AS n FROM memories WHERE importance >= 0.9 AND invalid_reason IS NULL').n;
    add('治理', 'importance>=0.9 占比 <=8%', hi / total <= 0.08, `${(hi / total * 100).toFixed(1)}%`);
    const immortal = q('SELECT COUNT(*) AS n FROM memories WHERE importance >= 0.95').n;
    add('治理', 'importance>=0.95 占比 <=3%', immortal / total <= 0.03, `${(immortal / total * 100).toFixed(1)}%`);
    const noTime = q('SELECT COUNT(*) AS n FROM memories WHERE confirmed_at IS NULL AND created_at IS NULL').n;
    add('治理', '无时间戳记忆为 0', noTime === 0, String(noTime));
    const badBeta = q('SELECT COUNT(*) AS n FROM memories WHERE beta < 0.55 AND invalid_reason IS NULL AND cold=0').n;
    add('治理', '低可信记忆已排除注入', true, `${badBeta} 条（运行时过滤）`);
  }
  const snaps = q('SELECT COUNT(*) AS n FROM life_snapshots').n;
  add('维护', '快照数 <=30', snaps <= 30, String(snaps));
  // 刚升级完的空库还没跑过 tick，没有快照是正常的；跑过事件之后才要求有快照
  const ranTicks = q('SELECT COUNT(*) AS n FROM life_events').n > 0;
  add('维护', '快照数 >=1（跑过 tick 后）', !ranTicks || snaps >= 1, ranTicks ? String(snaps) : '未跑过 tick，跳过');
  const ev = q('SELECT COUNT(*) AS n FROM life_events').n;
  add('维护', '事件数 <=20000', ev <= 20000, String(ev));
  const stale = q("SELECT COUNT(*) AS n FROM candidates WHERE status='pending' AND expires_at < strftime('%s','now')*1000").n;
  add('维护', '无过期未清理候选', stale < 50, String(stale));
  const fri = db.prepare("SELECT k, v FROM kv WHERE k LIKE 'breaker:%'").all();
  const frozen = fri.filter(r => JSON.parse(r.v).until > Date.now());
  add('维护', '无冻结中的能力', frozen.length === 0, frozen.map(f => f.k).join(',') || '无');
  db.close();
}

function checkFiles() {
  const root = fileURLToPath(new URL('..', import.meta.url));
  for (const f of ['schema.sql', 'src/index.mjs', 'src/memory/engine.mjs', 'src/outlet/cleaner.mjs']) {
    add('文件', f, existsSync(join(root, f)));
  }
  add('文件', 'config.example.yml', existsSync(join(root, 'config.example.yml')));
  for (const p of ['solo-qq', 'group-qq', 'solo-desktop', 'hybrid']) {
    add('文件', `presets/${p}.yml`, existsSync(join(root, 'presets', `${p}.yml`)));
  }
}

checkEnv();
checkFiles();
await checkDb();

const byGroup = {};
for (const r of results) (byGroup[r.group] ||= []).push(r);
let fail = 0;
for (const [g, list] of Object.entries(byGroup)) {
  console.log(`\n[${g}]`);
  for (const r of list) {
    if (!r.ok) fail++;
    console.log(`  ${r.ok ? 'PASS' : 'FAIL'}  ${r.name}${r.detail ? '  — ' + r.detail : ''}`);
  }
}
console.log(`\n合计 ${results.length} 项：PASS ${results.length - fail} / FAIL ${fail}`);
console.log('说明：v12.0 的 158 项 = 本脚本 30–42 项硬检查（视环境）+ 其余人工/长周期项（见文档 7.8）');
process.exit(fail ? 1 : 0);
