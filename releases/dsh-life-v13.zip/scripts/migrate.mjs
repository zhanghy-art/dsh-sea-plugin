#!/usr/bin/env node
// scripts/migrate.mjs — v11.1 / v12.x → v13.0 原地升级
// 单一事实源：src/kit/db.mjs:ensureSchema。本脚本只是「带报告的外壳」，
// 插件首次启动走的也是同一个函数，因此脚本升级与启动升级的结果必然一致（codex 第十四章）。
//
// 用法：
//   node scripts/migrate.mjs --db <path> --dry-run    # 只看要做什么
//   node scripts/migrate.mjs --db <path>              # 真升级（自动备份）
//   node scripts/migrate.mjs --db <path> --json       # 机器可读报告
//   node scripts/migrate.mjs --db <path> --no-backup  # 不生成副本（不建议）
//
// 原则（codex v13.2 第 14 章）：
//   只加不删；备份在位；迁移前后逐行校验旧列数据指纹；旧行快照落 legacy_rows；
//   失败即停，库文件仍可打开（VACUUM INTO 备份可原地覆盖回去）。
import { existsSync, statSync, writeFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { openDb, ensureSchema, legacyFingerprint } from '../src/kit/db.mjs';
import { adoptLegacyState } from '../src/life/life-state.mjs';
import { DEFAULTS, VERSION, SCHEMA_VERSION } from '../src/kit/config.mjs';

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..');
const args = process.argv.slice(2);
const getArg = (k, d) => { const i = args.indexOf(k); return i >= 0 ? args[i + 1] : d; };
const DRY = args.includes('--dry-run');
const JSON_OUT = args.includes('--json');
const NO_BACKUP = args.includes('--no-backup');
const DB = getArg('--db', join(process.env.HOME || '.', '.dsh', 'dsh-life', 'mind.db'));

const report = { db: DB, version: VERSION, target: SCHEMA_VERSION, dryRun: DRY, steps: [], ok: true };
const log = (step, status, detail = '') => {
  report.steps.push({ step, status, detail });
  if (status === 'FAIL') report.ok = false;
  if (!JSON_OUT) console.log(`[${status}] ${step}${detail ? ' — ' + detail : ''}`);
};

const colsOf = (db, t) => {
  try { return db.prepare(`PRAGMA table_info(${t})`).all().map(r => r.name); }
  catch { return []; }
};

async function main() {
  if (!existsSync(DB)) {
    // 不新建空库：首次安装由插件启动自己建（doctor 也按这个约定检查）
    log('库文件', 'fresh', '不存在，不新建；首次启动时由 ensureSchema 建库');
    if (JSON_OUT) console.log(JSON.stringify(report, null, 2));
    return;
  }

  const before = statSync(DB);
  if (!JSON_OUT) console.log(`原地升级：直接修改 ${DB}（不新建、不复制数据）`);

  const db = await openDb(DB, { create: true });
  db.exec('PRAGMA journal_mode=WAL;');

  // ---------- 0. 升级前：importance 快照（便于事后 diff 你手工调过的分数） ----------
  if (!DRY) {
    try {
      const rows = db.prepare(
        "SELECT id, category, importance, emotional_salience, confirmed_at FROM memories " +
        "WHERE invalid_reason IS NULL ORDER BY importance DESC"
      ).all();
      const csv = ['id,category,importance,emotional_salience,confirmed_at']
        .concat(rows.map(r => [r.id, r.category, r.importance, r.emotional_salience, r.confirmed_at].join(',')))
        .join('\n');
      const snap = `${DB}.importance-${new Date().toISOString().replace(/[:.]/g, '')}.csv`;
      writeFileSync(snap, csv);
      log('importance 快照', 'ok', `${rows.length} 条 → ${snap}`);
    } catch (e) { log('importance 快照', 'degraded', e.message); }
  }

  // ---------- 1. 升级前指纹（旧列逐行，供事后比对） ----------
  const beforeFp = (() => {
    try {
      const cols = colsOf(db, 'memories')
        .filter(c => !/^(belief|beta|novelty|activation|protection_tier|evidence_count|confirm_count|review_stability|review_due_at|content_hash|origin_key|last_injected_at|scope_migrated|valid_from_ms|valid_to_ms|created_at_ms|confirmed_at_ms|last_recalled_ms|cold_at_ms|superseded_by|raw_kept|anchor_place|anchor_time|vec_model|happened_at_ms|evidence_kind_v13)$/.test(c));
      return legacyFingerprint(db, 'memories', cols);
    } catch (e) { return { hash: 'skip:' + e.message, count: -1 }; }
  })();

  // ---------- 2. dry-run：只列出差异 ----------
  if (DRY) {
    const have = new Set(colsOf(db, 'memories'));
    const plan = JSON.parse((await import('node:fs')).readFileSync(join(ROOT, 'migrations', 'columns.json'), 'utf8'));
    const missing = plan.columns.map(c => c.name).filter(n => !have.has(n));
    log('计划', 'plan', `memories 缺 ${missing.length} 列：` + (missing.join(',') || '无'));
    log('计划', 'plan', `辅助表补列 ${(plan.table_column_patches || []).length} 条；不实际执行`);
    log('计划', 'plan', '真跑时会：备份 → 迁移 → 指纹比对 → legacy_rows 快照 → 打戳');
    if (JSON_OUT) console.log(JSON.stringify(report, null, 2));
    db.close();
    return;
  }

  // ---------- 3. 交给 ensureSchema（备份 / ALTER / FTS / 回填 / 指纹 / 台账 全在里面） ----------
  const res = await ensureSchema(db, {
    dbPath: DB,
    cfg: { ...DEFAULTS, upgrade: { ...DEFAULTS.upgrade, backup: !NO_BACKUP } },
    log: (s, st, d) => log(s, st ?? 'ok', d ?? ''),
  });
  Object.assign(report, { fresh: res.fresh, added: res.added, rebuilt: res.rebuilt,
    upgraded: res.upgraded, backupPath: res.backupPath, fingerprintOk: res.fingerprintOk });
  log('schema', res.upgraded ? 'ok' : 'noop',
    res.upgraded ? `新增 ${res.added} 列，FTS 已重建` : '已是 v13 结构，无需变更');

  // ---------- 3.5 状态层接管：v11 三表 → v13 单行 state_json ----------
  // 这一步不做，记忆还在、但她会「失忆地醒来」：六维/激素/关系全归零。
  try {
    const ad = adoptLegacyState(db, DEFAULTS);
    if (ad.adopted) {
      log('状态接管', 'ok', `revision ${ad.revision}｜needs ${JSON.stringify(ad.needs)}｜激素 ${JSON.stringify(ad.hormones)}｜关系 ${JSON.stringify(ad.relationship)}`);
    } else {
      log('状态接管', 'noop', '无需迁移：' + (ad.reason || '已有 v13 状态'));
    }
    report.state = ad;
  } catch (e) {
    log('状态接管', 'FAIL', e.message);
  }

  // ---------- 4. 升级后指纹比对（同一列集） ----------
  try {
    // ensureSchema 内部已做过一次比对；这里只是把结论写进脚本报告
    const same = res.fingerprintOk !== false;
    log('旧列指纹', same ? 'ok' : 'FAIL',
      same ? `${beforeFp.count} 行逐列一致` : 'ensureSchema 报告指纹不一致（旧列数据被改动）');
  } catch (e) { log('旧列指纹', 'degraded', e.message); }

  // ---------- 5. 完整性 + 幂等 ----------
  const integ = db.prepare('PRAGMA integrity_check').get();
  log('完整性检查', Object.values(integ)[0] === 'ok' ? 'ok' : 'FAIL', String(Object.values(integ)[0]));

  const again = await ensureSchema(db, { dbPath: DB, cfg: { ...DEFAULTS, upgrade: { ...DEFAULTS.upgrade, backup: false } } });
  log('幂等自检', again.added === 0 && !again.rebuilt ? 'ok' : 'FAIL',
    again.added === 0 ? '再跑一次不产生新变更' : `再跑仍新增 ${again.added} 列`);

  report.counts = {
    memories: db.prepare('SELECT COUNT(*) AS n FROM memories').get().n,
    candidates: db.prepare('SELECT COUNT(*) AS n FROM candidates').get().n,
    evidence: db.prepare('SELECT COUNT(*) AS n FROM memory_evidence').get().n,
    legacy_rows: db.prepare('SELECT COUNT(*) AS n FROM legacy_rows').get().n,
    upgrade_manifest: db.prepare('SELECT COUNT(*) AS n FROM upgrade_manifest').get().n,
  };
  log('数据盘点', 'ok', JSON.stringify(report.counts));

  const uv = db.prepare('PRAGMA user_version').get().user_version;
  log('版本戳', Number(uv) === SCHEMA_VERSION ? 'ok' : 'FAIL', `user_version=${uv}（期望 ${SCHEMA_VERSION}）`);

  db.close();

  // ---------- 6. 证明仍是同一个文件 ----------
  const after = statSync(DB);
  const sameFile = before.ino === after.ino;
  log('同一文件校验', sameFile ? 'ok' : 'degraded',
    `inode ${before.ino} → ${after.ino}，size ${before.size} → ${after.size} bytes`);
  report.inPlace = { path: DB, sizeBefore: before.size, sizeAfter: after.size };

  if (JSON_OUT) console.log(JSON.stringify(report, null, 2));
  else {
    console.log('\n下一步：');
    console.log('  1) node scripts/doctor.mjs                     # 结构自检');
    console.log('  2) node tests/verify.mjs && node tests/verify12.mjs && node tests/verify13.mjs');
    console.log('  3) 回滚：停插件，把 *.v13.bak.* 覆盖回原路径（数据零丢失）');
  }
  if (!report.ok) process.exit(1);
}

main().catch(e => {
  if (JSON_OUT) console.log(JSON.stringify({ ok: false, error: e.message }, null, 2));
  else console.error('迁移失败：', e.message);
  process.exit(1);
});