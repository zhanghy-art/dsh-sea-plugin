// scripts/verify-install.mjs — 装机后自检：确认「装进去了、而且真的在用」
//
// 只读 + 一次可回滚的写入探针。检查的是**真实运行库**（默认 ~/.dsh/dsh-life/mind.db，
// 可用 --db 指定，或设 DSH_LIFE_DB），不是临时库。每条检查都把实测值打出来，不给「通过/不通过」的黑箱。
//
// 用法：node scripts/verify-install.mjs [--db <path>] [--scope private:10086] [--allow-write]

import os from 'node:os';
import path from 'node:path';
import { existsSync } from 'node:fs';
import { openDb } from '../src/kit/db.mjs';
import { DEFAULTS } from '../src/kit/config.mjs';
import { recover } from '../src/life/life-state.mjs';
import { searchMemory } from '../src/memory/search.mjs';
import { writeMemory } from '../src/memory/engine.mjs';
import { nextId } from '../src/kit/ids.mjs';

const args = process.argv.slice(2);
const arg = (k, d) => { const i = args.indexOf('--' + k); return i >= 0 && args[i + 1] ? args[i + 1] : d; };
const DB = arg('db', process.env.DSH_LIFE_DB || path.join(os.homedir(), '.dsh', 'dsh-life', 'mind.db'));
const SCOPE = arg('scope', 'private:10086');
const OWNER = arg('owner', '10086');
// 自检必须用「配了 owner 的 cfg」跑：ownerQq 为空时 scope 放宽（单用户默认），
// 会让「跨 scope 不泄漏」这条假失败。
const CFG = { ...DEFAULTS, ownerQq: OWNER };
const WRITE = args.includes('--allow-write');

const R = { pass: 0, fail: 0, rows: [] };
const ok = (name, cond, got) => { R[cond ? 'pass' : 'fail']++; R.rows.push({ ok: !!cond, name, got }); };

if (!existsSync(DB)) { console.error('库不存在：' + DB); process.exit(2); }
const db = await openDb(DB);

// 1. 结构与版本
const uv = db.prepare('PRAGMA user_version').get().user_version;
ok('PRAGMA user_version = 13', Number(uv) === 13, uv);
const kv = db.prepare("SELECT v FROM kv WHERE k='schema_version'").get();
ok('kv.schema_version = 13', kv && String(kv.v) === '13', kv && kv.v);
const tables = db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' AND name NOT LIKE '%_fts%'").all().map((r) => r.name);
ok('表数量 ≥ 30（v13 全量结构）', tables.length >= 30, tables.length);
for (const t of ['memories', 'memory_evidence', 'candidates', 'gaps', 'context_checkpoints', 'reflexes', 'action_proposals', 'life_state', 'life_events', 'life_snapshots']) {
  ok('表存在：' + t, tables.includes(t), tables.includes(t));
}

// 2. 数据量
const n = db.prepare('SELECT COUNT(*) AS n FROM memories').get().n;
ok('memories 行数 > 0', n > 0, n);
const byTier = db.prepare('SELECT protection_tier AS t, COUNT(*) AS n FROM memories GROUP BY protection_tier').all();
ok('保护层级有分布（core/stable/normal）', byTier.length >= 2, byTier);
const byCat = db.prepare('SELECT category AS c, COUNT(*) AS n FROM memories GROUP BY category').all();
ok('category 有分布', byCat.length >= 2, byCat);
const noRaw = db.prepare('SELECT COUNT(*) AS n FROM memories WHERE raw IS NULL').get().n;
ok('raw 全保留（0 条空）', noRaw === 0, noRaw);
const noHash = db.prepare('SELECT COUNT(*) AS n FROM memories WHERE content_hash IS NULL').get().n;
ok('content_hash 全有（0 条空）', noHash === 0, noHash);

// 3. 状态可恢复且是 0–1 标度
const rec = recover(db, DEFAULTS);
const h = rec.state.hormones;
const all01 = Object.values(h).every((v) => v >= 0 && v <= 1);
ok('激素四轴都在 0–1', all01, h);
ok('激素有值（不是全 0）', Object.values(h).some((v) => v > 0), h);
ok('revision > 0', rec.state.revision > 0, rec.state.revision);

// 4. 检索能召回（用真实库里的词，不是造的词）
const probes = ['维生素', '饼干', '记忆库', '主人'];
let hitTotal = 0;
for (const q of probes) {
  const r = searchMemory(db, q, { cfg: CFG, scope: SCOPE, topK: 5 });
  const items = r.items || [];
  hitTotal += items.length;
  ok('检索「' + q + '」有命中', items.length > 0, { n: items.length, first: items[0]?.mem?.fact?.slice(0, 40) });
}
ok('四个探针合计命中 ≥ 6', hitTotal >= 6, hitTotal);

// 5. 隔离：别的 scope 查不到本 scope 的东西
const other = searchMemory(db, '维生素', { cfg: CFG, scope: 'private:9999999999', topK: 5 });
ok('跨 scope 检索为空（不泄漏）', (other.items || []).length === 0, (other.items || []).length);

// 6. 写入探针（默认不写，--allow-write 才写，且写完立刻删）
if (WRITE) {
  const before = n;
  const w = await writeMemory(db, {
    fact: '装机自检探针（可删）：' + new Date().toISOString(),
    category: 'fact', scope: SCOPE, subject_qq: OWNER,
    source_kind: 'owner', source_id: OWNER,
    evidence_kind: 'manual', evidence_ref: 'verify-install', raw: 'verify-install',
    force_direct: true,
  }, { cfg: CFG });
  ok('写入返回 verified', w.verify === 'verified', w);
  const after = db.prepare('SELECT COUNT(*) AS n FROM memories').get().n;
  ok('写入后行数 +1', after === before + 1, { before, after });
  const hit = searchMemory(db, '装机自检探针', { cfg: CFG, scope: SCOPE, topK: 3 });
  ok('刚写的能被检索到', (hit.items || []).some((x) => x.mem.id === w.id), (hit.items || []).length);
  db.prepare("DELETE FROM memories WHERE id = ?").run(w.id);
  db.prepare('DELETE FROM memory_evidence WHERE memory_id = ?').run(w.id);
  const back = db.prepare('SELECT COUNT(*) AS n FROM memories').get().n;
  ok('探针已删除（行数复原）', back === before, { before, back });
}

console.log(JSON.stringify({ db: DB, scope: SCOPE, pass: R.pass, fail: R.fail, rows: R.rows }, null, 1));
console.log(`\n${R.pass} PASS / ${R.fail} FAIL`);
process.exit(R.fail ? 1 : 0);