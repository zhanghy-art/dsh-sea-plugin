#!/usr/bin/env node
// scripts/verify-plugin.mjs — 证明「装上了，而且真的在用」
//
// 为什么单有 doctor/verify-install 不够：
//   doctor 检查的是库结构与数据，verify-install 检查的是引擎能读写；
//   但这个插件是挂在 DSH 上的，真正决定「用没用」的是三件事：
//     1) DSH 的 ctx 形状能不能被适配层接住（systemPrompt.context / session/event / tools.register）
//     2) 收到一条用户消息后，注入段里到底有没有内容（空段 = 装了不用）
//     3) 主动行为工具注册了没有
//   本脚本用「假 ctx」把这三条各跑一遍，不需要重启宿主。
//
// 用法：
//   node scripts/verify-plugin.mjs --db <path> --owner <qq> [--write]
//   --write 会真的走一轮 preStep（会写 injection_log / last_recalled），默认只读。
import { apply } from '../src/host/dsh.mjs';

const args = process.argv.slice(2);
const arg = (k, d) => { const i = args.indexOf('--' + k); return i >= 0 ? args[i + 1] : d; };
const DB = arg('db', '<db-path>');
const OWNER = String(arg('owner', '10086'));
const WRITE = args.includes('--write');

const rows = [];
const ok = (name, cond, got) => { rows.push({ ok: !!cond, name, got }); };
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

const logs = [];
const sections = [];
const handlers = [];
const tools = [];

const ctx = {
  log: {
    info: (...a) => { logs.push(['I', a.join(' ')]); },
    warn: (...a) => { logs.push(['W', a.join(' ')]); },
    error: (...a) => { logs.push(['E', a.join(' ')]); },
  },
  systemPrompt: { context: (seg) => { sections.push(seg); } },
  on: (evt, cb) => { handlers.push({ evt, cb }); },
  tools: { register: (t) => { tools.push(t); } },
  emit: () => {},
};

async function main() {
  // ---- 1) 加载适配层 ----
  let rt = null, loadErr = null;
  try { rt = apply(ctx, { dbPath: DB, ownerQq: OWNER, profile: 'dsh', autoMigrate: false }); }
  catch (e) { loadErr = e; }
  await sleep(1200);

  ok('适配层 apply() 不抛错', !loadErr, loadErr ? String(loadErr.message || loadErr) : 'ok');
  ok('注册了注入段（systemPrompt.context）', sections.length > 0, { count: sections.length, names: sections.map(s => s.name) });
  ok('订阅了 session/event', handlers.some(h => h.evt === 'session/event'), handlers.map(h => h.evt));
  ok('ready 日志出现（库已打开）', logs.some(([l, m]) => l === 'I' && /已就绪|新建库|原地升级|库结构/.test(m)),
    logs.filter(([l]) => l === 'I').slice(0, 4).map(x => x[1]));
  ok('没有 error 级日志', !logs.some(([l]) => l === 'E'), logs.filter(([l]) => l === 'E').map(x => x[1]));

  // ---- 2) 发一条用户消息，看注入段有没有内容 ----
  const ev = handlers.find(h => h.evt === 'session/event');
  if (ev) {
    ev.cb(null, { type: 'user/message', data: { text: '提醒我吃维生素' } });
    await sleep(WRITE ? 2000 : 800);
  }
  const segText = typeof sections[0]?.text === 'function' ? sections[0].text() : '';
  ok('注入段文本非空', segText.length > 0, { chars: segText.length, head: String(segText).slice(0, 120) });
  ok('注入段含记忆内容（命中维生素相关）', /维生素|肌酸|提醒/.test(segText), { chars: segText.length });

  // ---- 3) 工具 ----
  // 沙盒/命令行环境没有 @deepseek-ai/dsh-tools，会走「取不到就不注册」的告警分支——这不是失败，
  // 是环境缺包；在 DSH 进程里会真的注册。这里只断言「告警说清楚了」而不是静默。
  const toolWarn = logs.find(([l, m]) => l === 'W' && /dsh-tools/.test(m));
  ok('工具注册路径有明确日志（注册成功或说明缺包）', tools.length > 0 || !!toolWarn,
    { registered: tools.map(t => t.name), warn: toolWarn ? toolWarn[1] : null });

  // ---- 4) 状态：证明接管过来的是「原来的她」 ----
  const { DatabaseSync } = await import('node:sqlite');
  const db = new DatabaseSync(DB, { readOnly: true });
  const st = db.prepare("SELECT revision, schema_version, state_json FROM life_state WHERE id = 1 OR id = 'singleton'").get();
  const state = st?.state_json ? JSON.parse(st.state_json) : null;
  ok('life_state 有 v13 状态', !!state, { revision: st?.revision, schema: st?.schema_version });
  ok('状态是 id=1 单行（v13 口径）', !!db.prepare('SELECT 1 x FROM life_state WHERE id = 1').get(), null);
  ok('revision 保留（≥ v11 的 210）', Number(st?.revision) >= 210, { revision: st?.revision });
  ok('激素是 0–1 标度', state && Object.values(state.hormones || {}).every(v => v <= 1.001),
    state ? state.hormones : null);
  ok('六维 needs 齐全', state && ['social', 'curiosity', 'rest', 'mood', 'closeness', 'energy'].every(k => typeof state.needs?.[k] === 'number'),
    state ? state.needs : null);
  ok('关系带过来了', state && typeof state.relationship?.closeness === 'number', state ? state.relationship : null);
  ok('记忆条数 ≥ 339', db.prepare('SELECT COUNT(*) n FROM memories').get().n >= 339,
    db.prepare('SELECT COUNT(*) n FROM memories').get().n);
  ok('user_version = 13', db.prepare('PRAGMA user_version').get().user_version === 13,
    db.prepare('PRAGMA user_version').get().user_version);
  db.close();

  // ---- 输出 ----
  const pass = rows.filter(r => r.ok).length;
  console.log(JSON.stringify({ db: DB, owner: OWNER, writeMode: WRITE, pass, total: rows.length, rows }, null, 2));
  if (pass !== rows.length) process.exitCode = 1;
}

main().catch(e => { console.error('自检异常：', e.stack || e); process.exit(1); });