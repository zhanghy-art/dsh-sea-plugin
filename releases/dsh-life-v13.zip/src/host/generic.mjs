// src/host/generic.mjs — 通用宿主适配器（config.yml 里 profile: generic）
//
// 目的：让同一套记忆核 / 状态核 / 出口清洗跑在 DSH 之外的宿主上（QQ 直连、微信、自建 Web、CLI），
// 宿主只需实现四个回调，不必理解 DSH 的 cordis ctx：
//
//   const api = createGenericHost({
//     log: console,                                  // {info,warn,error}
//     embed: async (text) => number[] | null,        // 向量；没有就返回 null（检索自动降为文本通道）
//     persona: () => '你叫小鱼……',                   // L1 人格段（不占记忆预算）
//     emit: (name, payload) => {},                   // 需要宿主配合的事件：dsh-life:summarize / archive
//   });
//   const plugin = createPlugin(api.ctx, { dbPath: '/path/mind.db', profile: 'generic' });
//   await api.start();
//
//   // 每轮用户说话前：
//   const sections = await api.userMessage({ text, scope: 'private:10001', ownerQq: '10001' });
//   // 把 sections 里的段落拼进你的系统提示（key → text）
//   // 模型回复完成后：
//   const reply = await api.reply({ text: modelOutput, message: { scope: 'private:10001', ownerQq: '10001' } });
//   // reply.text 就是清洗后可以直接发出去的文字；reply.rewrite 为 true 表示命中回声窗，建议让模型换一句
//
// 与 DSH 版的差别只有三处，其余代码完全共用：
//   1) 没有 ctx.lifecycle 的自动钩子 —— 由 api.userMessage / api.reply 显式驱动；
//   2) 没有 platform 的 systemPrompt 注入 —— 段落写进 api.sections，由宿主自己拼；
//   3) 没有 DSH 的定时器 —— 用 setInterval 起 15 分钟 tick，宿主退出时调 api.stop()。

export function createGenericHost(hooks = {}) {
  const sink = hooks.log ?? console;
  const slots = { onReady: null, onPreStep: null, onTurnStopping: null };
  const tools = [];
  const sections = new Map();
  const timers = [];

  const bind = (level) => (...args) => {
    const fn = sink?.[level] ?? sink?.log;
    if (typeof fn === 'function') fn.apply(sink, args);
  };

  const ctx = {
    log: { info: bind('info'), warn: bind('warn'), error: bind('error') },
    // 向量能力：交给宿主；没有就返回 null（引擎会退回纯文本打分，不报错）
    embed: hooks.embed,
    systemPrompt: {
      persona: () => (typeof hooks.persona === 'function' ? hooks.persona() : (hooks.persona ?? '')),
      section: (key, text) => { sections.set(key, text); },
    },
    emit: (name, payload) => { try { hooks.emit?.(name, payload); } catch { /* 事件不影响主流程 */ } },
    lifecycle: {
      onReady: (fn) => { slots.onReady = fn; },
      onPreStep: (fn) => { slots.onPreStep = fn; },
      onTurnStopping: (fn) => { slots.onTurnStopping = fn; },
    },
    timer: {
      every: (ms, fn) => {
        const t = setInterval(() => { try { fn(); } catch (e) { ctx.log.error('[dsh-life] tick failed: ' + e.message); } }, ms);
        if (typeof t.unref === 'function') t.unref();   // 不阻止宿主进程退出
        timers.push(t);
        return t;
      },
    },
    tools: { register: (tool) => { tools.push(tool); return tool; } },
  };

  const api = {
    ctx,
    sections,          // 宿主读取：key → 文本段（dsh-life.memory / dsh-life.reflex / …）
    tools,             // 宿主读取：插件注册的工具（life_propose / life_mark_sent）
    async start() {
      if (slots.onReady) await slots.onReady();
      return api;
    },
    // 每轮用户输入之前调用；返回本轮应由宿主注入 prompt 的段落
    async userMessage({ text = '', scope = null, ownerQq = null, userId = null, groupId = null } = {}) {
      sections.clear();
      const ev = { message: { text, scope, ownerQq, userId, groupId } };
      if (slots.onPreStep) await slots.onPreStep(ev);
      // v13.0：返回快照。sections 是单例 Map，下一轮 userMessage 会 clear()，
      // 宿主若把返回值留到下一轮再读，会读到空段落（沙盒 F4 多群隔离就是被这个坑住的）。
      return new Map(sections);
    },
    // 模型生成完之后调用；返回清洗后的回复（就地改写 text）
    async reply({ text = '', message = {} } = {}) {
      const ev = { reply: { text, rewrite: false }, message };
      if (slots.onTurnStopping) await slots.onTurnStopping(ev);
      return ev.reply;
    },
    stop() { for (const t of timers) clearInterval(t); timers.length = 0; },
  };

  return api;
}

export default createGenericHost;