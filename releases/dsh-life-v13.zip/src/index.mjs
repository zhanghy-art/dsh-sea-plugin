// src/index.mjs — 插件装配（v11.1 的 index.ts 原地升级）
// DSH Cordis 插件的入口：只做装配，不写业务逻辑。
// 若你的 DSH 版本要求 TS，把本文件改名为 index.ts，
// 并把 JSDoc 类型注释换成 TS 类型标注即可，逻辑一行不用改。
import os from 'node:os';
import path from 'node:path';
import { DEFAULTS, mergeConfig } from './kit/config.mjs';
import { openDb, ensureSchema } from './kit/db.mjs';
import { nextId } from './kit/ids.mjs';
import { normalizeScope, isGroup as isGroupScope } from './kit/scope.mjs';
import { recover, saveState, lifeTick, defaultState, phaseOf, dayKeyOf } from './life/life-state.mjs';
import { searchMemory, logInjection } from './memory/search.mjs';
import { writeMemory, scanCold } from './memory/engine.mjs';
import { EmbeddingCache } from './memory/embedding-cache.mjs';
import { ActivationBook } from './reflex/activation.mjs';
import { SessionLifecycle, buildHandoffPrompt, validateHandoff } from './session/lifecycle.mjs';
import { compose, stateLine } from './prompt/composer.mjs';
import { cleanOutgoing, trimToolResult, isEcho, stripFrames } from './outlet/cleaner.mjs';
import { runNightly, Breaker } from './maintenance/nightly.mjs';
import { vetProposal } from './govern/constitution.mjs';
import { rerank, allowOnExplicitAsk } from './life/attention.mjs';
import { pickReviewCard, markFloated } from './memory/fsrs.mjs';
import { canSpeak, hardGates, pickWithRandom, planFollowup } from './action/speak.mjs';
import { remFromGaps, epiphany, decayGaps } from './memory/gaps.mjs';
import { settleLifecycle } from './life/sleep.mjs';

export default function createPlugin(ctx, userConfig = {}) {
  const cfg = mergeConfig(DEFAULTS, userConfig);
  const rt = {
    db: null, state: null, book: new ActivationBook(cfg), cache: null,
    session: null, breaker: null, ready: false, safeMode: false,
    recentSaid: [], turnId: 0,
  };

  // ---------- 装配：runtime/ready ----------
  ctx.lifecycle?.onReady?.(async () => {
    // 库路径优先级：显式配置 > 环境变量 DSH_LIFE_DB > ~/.dsh/dsh-life/mind.db
    // （Windows 上 process.env.HOME 是空的，必须走 os.homedir()）
    const dbPath = userConfig.dbPath || process.env.DSH_LIFE_DB
      || path.join(os.homedir(), '.dsh', 'dsh-life', 'mind.db');
    rt.db = await openDb(dbPath);
    // 原地建库/升级：同一个文件，不新建、不复制、不迁数据。
    // autoMigrate=false 可关掉自动升级（此时老库缺列会在检索时报错，需先跑 migrate）。
    const schemaInfo = userConfig.autoMigrate === false
      ? { fresh: false, added: 0, rebuilt: false, skipped: true }
      : await ensureSchema(rt.db, { dbPath, cfg, log: ctx.log });
    if (schemaInfo.backupPath) ctx.log?.info?.(`[dsh-life] 升级前已备份：${schemaInfo.backupPath}`);
    if (schemaInfo.fresh) ctx.log?.info?.(`[dsh-life] 新建库：${dbPath}`);
    else if (schemaInfo.added) ctx.log?.info?.(`[dsh-life] 原地升级：${dbPath} 新增 ${schemaInfo.added} 列${schemaInfo.rebuilt ? '，已重建 FTS 索引' : ''}`);
    else ctx.log?.info?.(`[dsh-life] 库结构已是最新：${dbPath}`);
    const rec = recover(rt.db, cfg);
    if (rec.safeMode) {
      rt.safeMode = true;
      rt.state = defaultState();
      ctx.log?.warn?.(`[dsh-life] safeMode: ${rec.reason}（只应答、不主动、不注入）`);
    } else {
      rt.state = rec.state;
    }
    rt.book.load(rt.db.prepare('SELECT * FROM reflexes').all());
    rt.cache = new EmbeddingCache(
      `${process.env.HOME}/.dsh/dsh-life/embed-cache.json`,
      (t) => ctx.embed?.(t) ?? Promise.resolve(null)
    );
    rt.session = new SessionLifecycle(rt.db, { cfg, root: `${process.env.HOME}/.dsh/dsh-life/cold` });
    rt.breaker = new Breaker(rt.db);
    rt.ready = true;
    ctx.log?.info?.('[dsh-life] ready, revision=' + rt.state.revision);
  });

  // ---------- 每轮：onPreStep ----------
  // 顺序：预热 → 检索 → 组装提示 → 记录注入（被动注入不刷 confirmed_at）
  ctx.lifecycle?.onPreStep?.(async (ev) => {
    if (!rt.ready || rt.safeMode) return;
    const text = ev?.message?.text || '';
    // v13.0：旧库 scope 是 private:<qq> / group:<id> / shared / global，
    // 新代码过去默认 'chat:private'，直接拿它查库一行都匹配不上（跨会话检索泄漏的反向事故）。
    const scope = normalizeScope(ev?.message?.scope, {
      ownerQq: cfg.ownerQq ?? ev?.message?.ownerQq ?? ev?.message?.userId,
      groupId: ev?.message?.groupId,
    });
    const now = Date.now();
    const group = isGroupScope(scope);
    rt.currentScope = scope;   // 给 life_remember 用：工具被调用时没有事件上下文，得靠这里记着

    rt.turnId += 1;
    rt.session.onTurn();
    rt.session.appendRaw(scope, 'user', text, now);

    // 1) 预热（不 await，把 200–400ms 藏进回复延迟）
    rt.cache.warm(text);

    // 2) 检索（分舱 → 双通道 → 边一跳 → 保底）
    let hits = { items: [], debug: {} };
    try {
      const qvec = await rt.cache.getOrCompute(text);
      hits = searchMemory(rt.db, text, {
        cfg, now, queryVec: qvec, scope,
        cooldownHours: cfg.memory.injectionCooldownHours,
      });
    } catch (e) {
      ctx.log?.warn?.('[dsh-life] search degraded: ' + e.message); // 降级：不注入，继续聊
    }

    // 2.5) 注意力倾斜：只在门槛之后重排，不改权重（3.10）
    if (cfg.attention?.enabled && hits.items.length) {
      hits.items = allowOnExplicitAsk(rerank(hits.items, rt.state.hormones, cfg), text);
    }

    // 2.6) 复习浮卡：每轮最多 1 条，只给“问什么”不给原文
    let reviewLine = '';
    try {
      const card = pickReviewCard(rt.db, {
        cfg, now, lastFloatAt: rt.lastFloatAt || 0,
        scoreOf: (m) => hits.items.find(x => x.mem.id === m.id)?.score ?? 0.4,
      });
      if (card) { reviewLine = card.prompt; rt.lastFloatAt = now; markFloated(rt.db, card.mem.id, now, cfg); }
    } catch { /* 浮卡失败不影响主流程 */ }

    // 3) 组装（稳定前缀在前；L1 → facts → summary → state → stage → snippets）
    const l1 = ctx.systemPrompt?.persona?.() || '';
    const facts = hits.items.map(it => ({ line: formatMemoryLine(it.mem, it.mode) }));
    const stateTxt = stateLine({
      phase: rt.state.phase, energy: rt.state.energy, hormones: rt.state.hormones,
      stage: rt.state.relationship.stage,
    });
    const handoff = rt.session.readHandoff(scope, now);
    const summary = handoff || '(无)';
    const composed = compose({
      l1, facts, summary,
      state: mayInjectState(rt.state, now) ? stateTxt : '',
      stage: '',
      snippets: reviewLine ? [{ line: reviewLine }] : [],
    }, { group });

    ctx.systemPrompt?.section?.('dsh-life.memory', composed.text);

    // 4) 记录注入
    if (hits.items.length) logInjection(rt.db, hits.items, now, `t${rt.turnId}`);
    rt.state.counters.stateLineAt = now;

    // 5) 反射激活度累积（每轮）
    const refs = rt.db.prepare('SELECT * FROM reflexes WHERE scope = ? OR scope = ?').all(scope, 'shared');
    for (const r of refs) {
      const explicit = text.includes(r.trigger);
      const sim = explicit ? 1 : textScoreLite(text, r.trigger);
      rt.book.bump(r.id, sim, explicit, r.pain_level);
    }
    const picked = rt.book.pick(now, dayKeyOf(now));
    if (picked) {
      const r = refs.find(x => x.id === picked.id);
      if (r && rt.state.counters.emotionInjectToday < cfg.reflex.maxDaily) {
        ctx.systemPrompt?.section?.('dsh-life.reflex', `【提醒】${r.response}`);
        rt.book.fire(picked.id, now, dayKeyOf(now));
        rt.state.counters.emotionInjectToday += 1;
      }
    }
    rt.book.persist(rt.db);
  });

  // ---------- 回复后：onTurnStopping（全局 try/catch，失败不阻断） ----------
  ctx.lifecycle?.onTurnStopping?.(async (ev) => {
    try {
      if (!rt.ready) return;
      const raw = ev?.reply?.text || '';
      const now = Date.now();

      // 1) 剥帧（插件侧兜底）
      let out = stripFrames(raw);

      // 2) 回声窗：10 分钟内不重复自己
      if (isEcho(out, rt.recentSaid, cfg)) {
        out = echoRewriteHint(out);       // 交给模型改写，不是直接丢
        ev.reply.rewrite = true;
      }
      rt.recentSaid.push(out);
      if (rt.recentSaid.length > 20) rt.recentSaid.shift();

      // 3) 出口清洗（发送前最后一道）
      const cleaned = cleanOutgoing(out);
      ev.reply.text = cleaned.text;

      // 4) 写回 L3 + 记忆判定（异步，不阻塞）
      const scope = normalizeScope(ev?.message?.scope, {
        ownerQq: cfg.ownerQq ?? ev?.message?.ownerQq ?? ev?.message?.userId,
        groupId: ev?.message?.groupId,
      });
      rt.session.appendRaw(scope, 'bot', cleaned.text, now);
      rt.currentScope = scope;
      if (rt.session.shouldSummarize()) {
        // 由上层模型侧生成摘要后调用 rt.session.saveHandoff(scope, text)
        ctx.emit?.('dsh-life:summarize', { scope, turns: 15 });
        rt.session.sinceSummary = 0;
      }

      // 5) 每 20 轮归档（先写纪要，再清空；纪要失败则不归档）
      if (rt.session.shouldArchive()) {
        if (rt.session.readHandoff(scope, now)) {
          rt.session.archive(scope, rt.session.readHandoff(scope, now), now);
          ctx.emit?.('dsh-life:archive', { scope });
        } else {
          ctx.log?.warn?.('[dsh-life] skip archive: 无有效纪要（宁缺勿编）');
        }
      }
    } catch (e) {
      ctx.log?.error?.('[dsh-life] turnStopping failed: ' + e.message); // 永不阻断回复
    }
  });

  // ---------- 定时：15 分钟 lifeTick + 夜间巩固 ----------
  ctx.timer?.every?.(15 * 60 * 1000, () => {
    try {
      if (!rt.ready) return;
      const now = Date.now();
      // 睡眠结算（分段，非总时长一次乘算）
      const settled = settleLifecycle(rt.state, { frozen: rt.state.flags?.safeMode, minutes: 15, now, cfg });
      rt.state = settled.skipped ? rt.state : settled.state;
      rt.state = lifeTick(rt.state, 15, now, cfg);
      rt.book.decayAll(15);
      saveState(rt.db, rt.state, now, cfg);
      if (new Date(now).getHours() >= 4) runNightly(rt.db, { now, cfg });
    } catch (e) {
      ctx.log?.error?.('[dsh-life] tick failed: ' + e.message);
    }
  });

  // ---------- 工具：主动计划闸 ----------
  ctx.tools?.register?.({
    name: 'life_propose',
    description: '主动开口前先提交计划，通过 evidence 校验才会发送',
    async run(proposal) {
      // 第一道：想不想说
      const sp = canSpeak(rt.state.needs, cfg);
      if (!sp.ok) return { sent: false, reason: 'speak-weight', speakWeight: sp.speakWeight };
      // 第三道：能不能说（硬闸）
      const gate = hardGates(rt.state, Date.now(), cfg, { preset: cfg.preset });
      if (!gate.ok) return { sent: false, reason: 'hard-gate:' + gate.failed.join(',') };
      const mem = proposal?.evidence_id
        ? rt.db.prepare('SELECT * FROM memories WHERE id = ?').get(proposal.evidence_id)
        : null;
      const vet = vetProposal(proposal, { memories: mem ? [mem] : [], saidRecently: rt.recentSaid });
      if (!vet.ok) return { sent: false, reason: vet.reason };
      // 只允许 queued：真正发送由宿主完成，插件不得自称 sent（v12.x 的假回执 bug）
      const pid = nextId(rt.db, 'action_proposals', 'p');
      rt.db.prepare('INSERT INTO action_proposals(id,intent,say,why,evidence_id,expected_effect,risk,status,created_at) VALUES(?,?,?,?,?,?,?,?,?)')
        .run(pid, proposal.intent, proposal.say, proposal.why, proposal.evidence_id,
             proposal.expected_effect || '', proposal.risk || 'low', 'queued', Date.now());
      return { queued: true, proposalId: pid, say: proposal.say, speakWeight: sp.speakWeight };
    },
  });

  // 宿主发送成功后回调，把 queued 变 sent（唯一合法入口）
  ctx.tools?.register?.({
    name: 'life_mark_sent',
    description: '宿主发送成功后调用，把 queued 的计划标记为 sent',
    async run({ proposal_id, host_message_id } = {}) {
      if (!proposal_id) return { ok: false, reason: 'missing-id' };
      const row = rt.db.prepare('SELECT status FROM action_proposals WHERE id = ?').get(proposal_id);
      if (!row) return { ok: false, reason: 'not-found' };
      if (row.status !== 'queued') return { ok: false, reason: 'not-queued', status: row.status };
      rt.db.prepare("UPDATE action_proposals SET status='sent', sent_at=? WHERE id=? AND status='queued'")
        .run(Date.now(), proposal_id);
      if (host_message_id) {
        rt.db.prepare('INSERT INTO kv(k,v,updated_at) VALUES(?,?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v')
          .run('last_sent:' + proposal_id, String(host_message_id), Date.now());
      }
      rt.state.social.lastProactiveAt = Date.now();
      rt.state.counters.proactiveToday = (rt.state.counters.proactiveToday || 0) + 1;
      return { ok: true, status: 'sent' };
    },
  });

  // ---------- 工具：记忆写入（对话里值得长期记住的事） ----------
  // v14.0 原包只有 life_propose / life_mark_sent，全包没有任何地方调用 writeMemory，
  // 引擎再完整也等于「装了不用」：库里 339 条全是 v11 时代留下的，v13 一条也写不进。
  // 这里补上唯一的写入通道 —— 由模型判断「这句值得记」，走完整 15 步管线
  // （宪法闸门 / 指纹去重 / 冲突判定 / 日配额 / 候选 / 读回三态），不直写脏数据。
  ctx.tools?.register?.({
    name: 'life_remember',
    description: '把一件值得长期记住的事写进记忆库。category 取 fact(事实)/preference(偏好)/person(人物)/promise(约定)/event(经历)；把握不大就传低 confidence，会自动进候选，不会硬写。',
    async run({ fact, category, confidence, evidence } = {}) {
      if (!fact || String(fact).trim().length < 2) return { ok: false, reason: 'empty' };
      if (String(fact).length > cfg.memory.maxChars) return { ok: false, reason: 'too-long' };
      try {
        const r = await writeMemory(rt.db, {
          fact: String(fact).trim(),
          category: category || 'fact',
          confidence: Number.isFinite(Number(confidence)) ? Number(confidence) : 0.8,
          source_kind: 'user_sentence',
          evidence_kind: 'user_sentence',
          evidence_ref: evidence || 'tool:life_remember',
          scope: rt.currentScope || (cfg.ownerQq ? `private:${cfg.ownerQq}` : 'solo'),
        }, { cfg, now: Date.now() });
        return { ok: r.action === 'insert' || r.action === 'candidate', ...r };
      } catch (e) {
        return { ok: false, reason: 'write-failed', message: e?.message };
      }
    },
  });

  return rt;
}

// ---------- 小工具 ----------
function formatMemoryLine(mem, mode) {
  const tag = mem.category === 'person' ? '人物' : mem.category === 'promise' ? '约定' : '事实';
  const hedge = mode === 'hedged' ? '（不太确定）' : '';
  return `[${tag}] ${mem.fact}${hedge}`;
}

/** 状态行注入闸：偏离 >0.10 且 60 分钟最多 1 次 */
function mayInjectState(state, now) {
  if (now - (state.counters.stateLineAt || 0) < 60 * 60000) return false;
  const target = 0.5;
  return Math.abs(state.needs.mood - target) > 0.10 || Math.abs(state.energy - target) > 0.10;
}

/** 轻量字面相似（不调模型；真向量走 cache） */
function textScoreLite(a, b) {
  if (!a || !b) return 0;
  let n = 0;
  for (let i = 0; i < b.length - 1; i++) if (a.includes(b.slice(i, i + 2))) n++;
  return Math.min(1, n / Math.max(1, b.length - 1));
}

function echoRewriteHint(text) {
  return text; // 由上层把 reply.rewrite=true 交给模型重写；此处保留原文兜底
}
