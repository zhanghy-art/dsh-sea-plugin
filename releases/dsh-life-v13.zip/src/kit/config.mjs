// src/kit/config.mjs — 全部可调参数的唯一来源（附录 A/B）
// v13.0 与 v14.0 的差别只有四处，其余数值与融合指南附录 A 完全一致：
//   1) hormone 从 0–100 改成 0–1（指南第 3 章共识第 1 条：数值统一 0–1）
//   2) speak 默认走「软加项」（speakBonus ≤ +0.12），硬否决要显式开 hardGate
//   3) 新增 upgrade 段（备份 / 指纹 / legacy_rows 快照），对应 codex 第 14 章
//   4) 新增 profile（dsh / generic），同一份代码两种宿主
export const VERSION = '13.0';
export const SCHEMA_VERSION = 13;
export const POLICY_VERSION = 'v13.0';

export const DEFAULTS = {
  profile: 'dsh',                // dsh = DSH 插件；generic = 宿主无关库
  preset: 'solo-qq',
  budget: { private: 900, group: 700, working: 60 },   // 硬分配，不是「约」
  quietHours: [23, 8],
  ownerQq: null,                 // generic 宿主必须显式给；dsh 由消息事件带
  memory: {
    maxChars: 500,
    dedupDice: 0.90,
    injectDedupDice: 0.60,
    conflictDice: 0.35,
    coldWeight: 0.20,
    injectionCooldownHours: 6,
    dailyQuotaPerGroup: 30,
    dailyQuotaGlobal: 200,
    importanceHighWatermark: 0.08,
    tierQuota: true,            // 是否执行层级配额治理（只改 tier，不改 importance）
    importanceQuota: false,     // 是否执行 importance 降级治理（默认关：尊重人工标定）
    immortalWatermark: 0.03,
    candidateDays: 7,
    candidateKeepDays: 30,
    rejectedDedupDays: 30,
    deferReviewDays: 3,
    rawMaxChars: 900,
    directWriteBelief: 0.90,
    candidateAcceptRerun: true, // D3：accept 必须重跑 15 步，而不是只改状态
  },
  retrieval: {
    scoreFloor: 0.08,
    textFloor: 0.12,
    cosFloor: 0.45,
    beliefFloor: 0.35,
    poolLimit: 2000,
    topK: 6,                 // v12.1：Top-6（原 Top-4）
    factSlots: 3,
    regionTopK: 6,
    regionMinHits: 2,
    regionScoreFloor: 0.4,
    edgeWeight: 0.6,
    routeBoostMax: 0.10,
    echoJaccard: 0.80,
    lenRatio: 0.85,
    diversityPenalty: 0.15,
    sharedForPrivate: true,  // 私聊可读 shared 家族；关掉只读自己
  },
  weight: {
    halfLife: { person: 180, fact: 180, rule: 180, preference: 90, promise: 90, event: 60, meme: 120 },
    base:      { person: 1.0, fact: 1.0, rule: 0.9, preference: 0.9, promise: 0.9, event: 0.7, meme: 0.6 },
    floor:     { person: 0.35, fact: 0, rule: 0.35, preference: 0, promise: 0, event: 0, meme: 0 },
    maxAgeDays: { person: 3650, fact: 3650, rule: 3650, preference: 730, promise: 730, event: 365, meme: 730 },
    coreHalfLifeFactor: 4,
    coreFloor: 0.45,
    ephemeralMaxAgeDays: 7,
    reviewIdleDays: 180,      // core 退出：180 天未验证（codex 提案 189，取整与半衰期对齐）
  },
  // 0–1 标度（指南共识第 1 条）。旧库里的 0–100 值在 recover 阶段按 units.mjs 换算。
  hormone: {
    init:  { cortisol: 0.30, dopamine: 0.50, oxytocin: 0.40, serotonin: 0.60 },
    decay: { cortisol: 0.97, dopamine: 0.98, oxytocin: 0.96, serotonin: 0.99 },
    floor: { cortisol: 0.10, dopamine: 0.15, oxytocin: 0.10, serotonin: 0.20 },
    cap: 0.97,
    scale: 0.30,              // delta 的缩放：激素变化永远比 needs 慢一个量级
  },
  needs: { inertia: 0.7, clamp: 0.08 },
  // 睡眠分段结算（不按总时长一次乘算）
  sleep: {
    normalRatePerMin: 0.002,    // 0–1 标度（1 小时 +12%）
    deepRatePerMin: 0.01,       // 1 小时 +60%，深睡 40 分钟可从 0 回满
    deepHours: [0, 6],
    lowEnergyThreshold: 0.20,
    naturalCap: 0.60,
    integralCapDays: 7,
  },
  // 注意力倾斜：只在门槛之后重排，不改权重
  attention: {
    enabled: true,
    crisisClasses: ['flash', 'spine'],
    tiers: [
      { cortisol: 0.80, hot: 3.0, cold: 0.10 },
      { cortisol: 0.55, hot: 1.8, cold: 0.40 },
      { cortisol: 0.00, hot: 1.0, cold: 1.00 },
    ],
  },
  reflex: {
    threshold: 0.55,
    explicitGain: 0.45,
    semanticGain: 0.35,
    decayPerTick: 0.85,
    zeroEps: 0.05,
    maxDaily: 3,
    maxPerReflexPerDay: 1,
    maxReflexes: 10,
  },
  // 升级安全默认：破坏性能力一律关，由用户显式开启（D7）
  capabilities: {
    routeKeyword: true,      // 关键词分舱：零模型成本，命中不足自动回退全库
    routeCentroid: false,    // 质心分舱：需要标定，默认关
    autoArchive: false,      // 自动清空上下文：高破坏性，默认关
    ftsSearch: false,        // FTS5 检索通道：默认关，全表扫描已够 5k–50k 行
  },
  lifecycle: {
    archiveTurns: 0,         // 0 = 关闭；开启后作为“占比触发”的兜底
    handoffChars: 200,
    handoffTTLHours: 24,
    handoffMaxTurns: 12,
    contextSoftLimit: 30000,
    compressAt: 0.70,       // 70% 生成交接
    resetAt: 0.90,          // 90% 强制重置
    keepRecentTokens: 20000,
    checkpointsPerScope: 20,
  },
  fsrs: {
    enabled: true,
    stabilityCap: 180,
    floatMinScore: 0.35,
    floatCooldownMinutes: 360,
    floatMaxPerTurn: 1,
  },
  gaps: {
    enabled: true,
    closeScoreFloor: 0.45,
    maxOpen: 20,
    epiphany: { dopamine: 0.12, cortisol: -0.10, serotonin: 0.08 },
  },
  speak: {
    enabled: true,
    floor: 0.40,
    restFloor: 0.08,
    // speakWeight = 0.15 + 0.50*social + 0.35*rest
    w: { base: 0.15, social: 0.50, rest: 0.35 },
    hardGate: false,          // 默认软加项（D4）；true 时 speakWeight 直接否决
    bonusWeight: 0.12,        // 软加项上限 +0.12
  },
  random: {
    leadThreshold: 0.15,     // 第一名领先第二名 ≥0.15 直接选第一名
    samplePool: 3,
    jitter: 0.10,
    policyVersion: POLICY_VERSION,
  },
  active: {
    minIntervalMin: 45,
    perHour: 1,
    perDay: 4,
    firstWeekPerDay: 1,
    backoff: { baseMin: 120, factor: 2, capMin: 1440 },
    // 主动四类事由（v11.1 10.6）：mingle 默认关 —— 群里“有人在吗”是活泼，单人私聊“在干嘛”是压力
    intents: ['promise', 'milestone', 'residue'],
    intentsAll: ['promise', 'milestone', 'residue', 'mingle'],
    intentWindows: { residue: [6, 10], mingle: [20, 22] },
    // utility 十项权重（v11.1 10.8 原文数值，改任何一项都必须重跑仿真）
    weights: {
      explicit: 0.22, relevance: 0.18, commitment: 0.18, relationship: 0.14,
      socialNeed: 0.12, curiosity: 0.08, contextualFit: 0.08,
      intrusionRisk: -0.20, repetitionRisk: -0.15, recentPenalty: -0.10,
    },
    utilityEnter: 0.62,       // 进入阈值（v11.1 实测标定，低权重要重跑仿真）
    utilityExit: 0.45,        // 滞回退出阈值
  },
  // 唤醒九类（v11.1 10.2）：solo 只用前七类，at / welcome 代码保留、开关关闭
  wake: {
    classes: ['private', 'keyword', 'quote', 'ack', 'followup', 'continuation', 'proactive', 'at', 'welcome'],
    soloEnabled: ['private', 'keyword', 'quote', 'ack', 'followup', 'continuation', 'proactive'],
    groupEnabled: ['private', 'keyword', 'quote', 'ack', 'followup', 'continuation', 'proactive', 'at', 'welcome'],
    ack: { maxChars: 8, windowS: 120, silentOnExpire: true, noMemory: true },
    continuation: { soloWindowS: 300, groupWindowS: 180, turns: 8, questionBonusTurns: 3, stopAfterSilentTurns: 2 },
    batchWait: { private: 8, group: 3 },       // 三段等待：私聊 8s / 群聊 3s（群聊 3 分钟是信号，单人 3 分钟什么都不是）
    followupWait: { private: 20, group: 8 },
    keywordHit: { private: 0, group: 3 },
  },
  followup: {
    enabled: true,
    delayMinS: 30,
    delayMaxS: 180,
    perHourMax: 2,
    maxBubbles: 3,
    privateOnly: true,
  },
  outlet: {
    jsonMinLen: 120,
    trimHead: 4096,
    trimTail: 1024,
    trimAt: 8192,
    echoWindowMin: 10,
    echoJaccard: 0.75,
  },
  // 升级安全（codex 第 14 章 / 指南 6.3）
  upgrade: {
    backup: true,             // 首写前用 SQLite backup API 出 .bak
    backupKeep: 3,
    verifyFingerprint: true,  // 迁移前后比对旧列数据指纹
    legacySnapshot: true,     // 把旧列原样存进 legacy_rows
    rollbackOnMismatch: true, // 指纹不一致则拒绝启动
  },
};

export function mergeConfig(base, patch) {
  const out = structuredClone(base);
  const walk = (a, b) => {
    for (const k of Object.keys(b || {})) {
      if (b[k] && typeof b[k] === 'object' && !Array.isArray(b[k])) {
        a[k] = walk(a[k] || {}, b[k]);
      } else if (b[k] !== undefined) {
        a[k] = b[k];
      }
    }
    return a;
  };
  return walk(out, patch || {});
}