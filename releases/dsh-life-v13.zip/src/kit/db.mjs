// src/kit/db.mjs — SQLite 适配层（node:sqlite，零依赖）
// Node >= 22.5 才内置 node:sqlite；DSH 侧要求 22.19+。
//
// v13.0 相对 v14.0 的四项升级（全部来自 codex v13.2 第 14 章 / 指南 6.3）：
//   1) 首次写库前先备份（VACUUM INTO 原子快照，不是复制文件）
//   2) 迁移前后比对「旧列数据指纹」，不一致就拒绝启动（旧数据必须逐行不变）
//   3) 旧列的原始快照落进 legacy_rows，任何时刻都能回答「升级前这行长什么样」
//   4) FTS 重建严格按「建表 → 摘触发器 → rebuild → 回填 → 恢复触发器 → 再 rebuild」
//      顺序错一步，旧库首次 UPDATE 就会报 database disk image is malformed
import { readFileSync, existsSync, readdirSync, unlinkSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { DEFAULTS, SCHEMA_VERSION, VERSION } from './config.mjs';

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..', '..');

export async function openDb(dbPath, { create = true } = {}) {
  let DatabaseSync;
  try {
    ({ DatabaseSync } = await import('node:sqlite'));
  } catch {
    throw new Error(
      '当前 Node 不支持 node:sqlite。请升级到 Node >= 22.5（推荐 22.19+ / 24.x）。' +
      '不要退回 better-sqlite3：Windows 编译失败率过高。'
    );
  }
  const db = new DatabaseSync(dbPath, { readOnly: !create });
  if (create) db.exec('PRAGMA journal_mode=WAL; PRAGMA synchronous=NORMAL; PRAGMA foreign_keys=ON;');
  return db;
}

/** 读文件（相对包根） */
const readRoot = (p) => readFileSync(join(ROOT, p), 'utf8');

function tableExists(db, name) {
  return !!db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name=?").get(name);
}

function colsOf(db, table) {
  try { return db.prepare(`PRAGMA table_info("${table}")`).all().map(r => r.name); }
  catch { return []; }
}

/**
 * 旧列数据指纹：按主键排序，把每行的旧列值序列化后累加 sha256。
 * 新列不参与 —— 我们要证明的是「升级没有改动任何一行旧数据」，不是「表没变」。
 */
export function legacyFingerprint(db, table, columns, keyColumn = 'id') {
  if (!columns.length) return { hash: 'empty', count: 0 };
  const cols = columns.map(c => `"${c}"`).join(',');
  let rows;
  try {
    rows = db.prepare(`SELECT ${cols} FROM "${table}" ORDER BY "${keyColumn}"`).all();
  } catch (e) {
    return { hash: 'error:' + e.message, count: -1 };
  }
  const h = createHash('sha256');
  for (const r of rows) {
    h.update(JSON.stringify(columns.map(c => (r[c] === undefined ? null : r[c]))));
    h.update('\n');
  }
  return { hash: h.digest('hex'), count: rows.length };
}

/** 备份：VACUUM INTO 生成紧凑的一致性快照；返回备份路径 */
export function backupDb(db, dbPath, { keep = 3 } = {}) {
  if (!dbPath || !existsSync(dbPath)) return null;
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const target = `${dbPath}.v13.bak.${stamp}`;
  db.exec(`VACUUM INTO '${target.replace(/'/g, "''")}'`);
  // 只留最近 keep 份，避免备份把磁盘吃满
  try {
    const dir = dirname(dbPath);
    const base = `${dbPath.split(/[\\/]/).pop()}.v13.bak.`;
    const olds = readdirSync(dir)
      .filter(f => f.startsWith(base))
      .sort();
    while (olds.length > keep) {
      const f = olds.shift();
      try { unlinkSync(join(dir, f)); } catch { /* 删不掉不影响主流程 */ }
    }
  } catch { /* ignore */ }
  return target;
}

/** 从 tables.sql 里抽出触发器 DDL（用于「摘掉再装回」） */
function triggerSqlOf(sqlText) {
  const out = [];
  const re = /CREATE TRIGGER[\s\S]*?END;/g;
  let m;
  while ((m = re.exec(sqlText))) out.push(m[0]);
  return out;
}

/**
 * 原地建库/升级（唯一入口）。
 * - 库不存在 → schema.sql 建（第一次、唯一一次）
 * - 库已存在 → 同一文件里补列、建表、建索引、重建 FTS；不新建库、不复制、不迁数据
 */
export async function ensureSchema(db, { dbPath = null, cfg = DEFAULTS, log = null } = {}) {
  const up = cfg.upgrade || DEFAULTS.upgrade;
  const hasMemories = tableExists(db, 'memories');

  // ---------- 全新库 ----------
  if (!hasMemories) {
    db.exec(readRoot('schema.sql'));
    db.exec(`PRAGMA user_version = ${SCHEMA_VERSION};`);
    // 与老库升级分支保持同一口径：kv 里也要有版本戳（沙盒 A1 暴露：fresh 只写了 PRAGMA）
    db.exec('CREATE TABLE IF NOT EXISTS kv (k TEXT PRIMARY KEY, v TEXT, updated_at INTEGER)');
    db.prepare(`INSERT INTO kv(k,v,updated_at) VALUES('schema_version',?,?)
                ON CONFLICT(k) DO UPDATE SET v=excluded.v, updated_at=excluded.updated_at`)
      .run(String(SCHEMA_VERSION), Date.now());
    try {
      db.prepare('INSERT OR REPLACE INTO upgrade_manifest(from_version,to_version,applied_at,added_columns,rebuilt_fts,verify_ok,note) VALUES(?,?,?,?,?,?,?)')
        .run('fresh', VERSION, Date.now(), 0, 1, 1, 'new database');
    } catch { /* 台账失败不影响主流程 */ }
    return { fresh: true, added: 0, rebuilt: true, upgraded: false, backupPath: null, fingerprintOk: true };
  }

  // ---------- 老库：原地升级 ----------
  const plan = JSON.parse(readRoot('migrations/columns.json'));
  const memCols = new Set(colsOf(db, 'memories'));
  const tablePatches = plan.table_column_patches || [];

  // 先算「要补多少」，决定是否需要备份/快照（不做无意义备份）
  const missingMem = plan.columns.filter(c => !memCols.has(c.name));
  const missingPatches = tablePatches.filter(p => tableExists(db, p.table) && !colsOf(db, p.table).includes(p.column));
  const ftsExists = !!db.prepare("SELECT name FROM sqlite_master WHERE name='mem_fts'").get();
  const needUpgrade = missingMem.length > 0 || missingPatches.length > 0 || !ftsExists;

  if (!needUpgrade) {
    return { fresh: false, added: 0, rebuilt: false, upgraded: false, backupPath: null, fingerprintOk: true };
  }

  // 1) 备份（只在真的要改库时做）
  let backupPath = null;
  if (up.backup !== false && dbPath) {
    try { backupPath = backupDb(db, dbPath, { keep: up.backupKeep ?? 3 }); }
    catch (e) { log?.warn?.(`[dsh-life] 备份失败：${e.message}（继续，但请先手动复制库文件）`); }
  }

  // 2) 升级前的旧列指纹与快照
  //    指纹的语义是「v11.1 的旧列一行都没变」。本版本引入的新列不参与：
  //    半途中断（上次已补列、未回填）时这些列存在但值为 NULL，回填后必然变化，
  //    若把它们算进指纹，续跑会被自己的校验永久拒绝启动（沙盒 A7 暴露）。
  //    audit_status / time_granularity 虽是 columns.json 中的条目，但 v11.1 就有，必须继续受校验。
  // time_granularity 虽在 V11_KEEP（v11.1 就有、要防被改），但本版本必须给 NULL 行补默认值，
  // 所以它同时又属于「会被回填改写」的列——两者冲突时以「不改写就无法启动」为准。
  const V11_KEEP = new Set(['audit_status']);
  // 反过来还有一组：v11.1 库里早就存在、但本版本迁移会主动改写它的列。
  // 这些列不能进指纹，否则「回填成功」反而被判成「旧数据被改」（实测 339 行库必踩）。
  const V13_WRITEBACK = new Set(['content_hash', 'review_stability', 'time_granularity']);
  const v13Cols = new Set(plan.columns.map(c => c.name));
  const beforeCols = colsOf(db, 'memories');
  const fpCols = beforeCols.filter(c => (!v13Cols.has(c) || V11_KEEP.has(c)) && !V13_WRITEBACK.has(c));
  const fpBefore = up.verifyFingerprint !== false
    ? legacyFingerprint(db, 'memories', fpCols, 'id')
    : { hash: 'skipped', count: 0 };

  // legacy_rows 表必须先存在才能存快照
  db.exec(`CREATE TABLE IF NOT EXISTS legacy_rows (
    table_name TEXT NOT NULL, row_key TEXT NOT NULL,
    legacy_json TEXT NOT NULL, fingerprint TEXT NOT NULL,
    captured_at INTEGER NOT NULL,
    PRIMARY KEY (table_name, row_key)
  );`);
  db.exec(`CREATE TABLE IF NOT EXISTS upgrade_manifest (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    from_version TEXT, to_version TEXT, applied_at INTEGER NOT NULL,
    added_columns INTEGER, rebuilt_fts INTEGER,
    legacy_fingerprint TEXT, legacy_rows_count INTEGER,
    post_fingerprint TEXT, verify_ok INTEGER,
    backup_path TEXT, note TEXT
  );`);

  let captured = 0;
  if (up.legacySnapshot !== false && beforeCols.length) {
    const cols = beforeCols.map(c => `"${c}"`).join(',');
    const rows = db.prepare(`SELECT ${cols} FROM memories ORDER BY id`).all();
    const st = db.prepare('INSERT OR REPLACE INTO legacy_rows(table_name,row_key,legacy_json,fingerprint,captured_at) VALUES(?,?,?,?,?)');
    const now = Date.now();
    for (const r of rows) {
      const json = JSON.stringify(r);
      const h = createHash('sha256').update(json).digest('hex').slice(0, 32);
      st.run('memories', String(r.id), json, h, now);
      captured++;
    }
  }

  // 3) 补列（memories）
  let added = 0;
  for (const c of missingMem) {
    db.exec(`ALTER TABLE memories ADD COLUMN ${c.name} ${c.def}`);
    added++;
  }

  // 4) 旧辅助表先补列（否则后面的索引会引用不存在的列）
  for (const p of missingPatches) {
    db.exec(`ALTER TABLE ${p.table} ADD COLUMN ${p.column} ${p.def}`);
    added++;
  }

  // 5) 建表/索引/触发器（幂等），但把 rebuild 与触发器创建摘出来单独排序
  const tablesSql = readRoot('migrations/tables.sql').replace(/INSERT INTO mem_fts\(mem_fts\) VALUES\('rebuild'\);?/g, '-- rebuild moved');
  const triggerSql = triggerSqlOf(tablesSql);
  const tablesNoTrigger = tablesSql.replace(/CREATE TRIGGER[\s\S]*?END;/g, '-- trigger moved');
  db.exec(tablesNoTrigger);

  // 6) FTS 严格顺序：摘触发器 → rebuild → 回填 → 装回触发器 → 再 rebuild
  const rebuilt = added > 0 || !ftsExists;
  if (rebuilt) {
    for (const t of ['mem_ai', 'mem_ad', 'mem_au']) {
      try { db.exec(`DROP TRIGGER IF EXISTS ${t}`); } catch { /* ignore */ }
    }
    db.exec("INSERT INTO mem_fts(mem_fts) VALUES('rebuild');");
  }

  // 7) 回填（幂等）
  for (const sql of [
    ...plan.columns.filter(c => c.backfill).map(c => c.backfill),
    ...(plan.post_migrate_sql || []),
  ]) {
    try { db.exec(sql); } catch { /* 单条回填失败不阻断启动 */ }
  }

  // 8) 装回触发器并再 rebuild 一次（此时新列已回填，索引与 content 表一致）
  if (rebuilt) {
    if (triggerSql.length) db.exec(triggerSql.join('\n'));
    else db.exec(`CREATE TRIGGER IF NOT EXISTS mem_ai AFTER INSERT ON memories BEGIN
      INSERT INTO mem_fts(rowid, fact, tags) VALUES (new.rowid, new.fact, new.tags); END;`);
    db.exec("INSERT INTO mem_fts(mem_fts) VALUES('rebuild');");
  } else if (triggerSql.length) {
    db.exec(triggerSql.join('\n'));
  }

  // 9) 迁移后指纹比对：旧列的值必须与迁移前完全一致
  let fingerprintOk = true;
  let fpAfter = { hash: 'skipped', count: 0 };
  if (up.verifyFingerprint !== false) {
    fpAfter = legacyFingerprint(db, 'memories', fpCols, 'id');
    fingerprintOk = fpAfter.hash === fpBefore.hash && fpAfter.count === fpBefore.count;
    if (!fingerprintOk && up.rollbackOnMismatch !== false) {
      throw new Error(
        `[dsh-life] 迁移校验失败：旧列数据指纹不一致（前 ${fpBefore.hash.slice(0, 12)}/${fpBefore.count} 行，` +
        `后 ${fpAfter.hash.slice(0, 12)}/${fpAfter.count} 行）。已生成备份：${backupPath || '（未开启备份）'}。` +
        '按指南 6.3 要求拒绝启动，请从备份恢复后重试。'
      );
    }
  }

  // 10) 版本戳（kv schema_version 不改写旧值口径；PRAGMA user_version 为准）
  db.exec('CREATE TABLE IF NOT EXISTS kv (k TEXT PRIMARY KEY, v TEXT, updated_at INTEGER)');
  db.prepare(`INSERT INTO kv(k,v,updated_at) VALUES('schema_version',?,?)
              ON CONFLICT(k) DO UPDATE SET v=excluded.v, updated_at=excluded.updated_at`)
    .run(String(SCHEMA_VERSION), Date.now());
  db.exec(`PRAGMA user_version = ${SCHEMA_VERSION};`);
  try {
    db.prepare('INSERT OR REPLACE INTO schema_migrations(version,label,applied_at,note) VALUES(?,?,?,?)')
      .run(SCHEMA_VERSION, VERSION, Date.now(), 'in-place');
  } catch { /* ignore */ }
  try {
    db.prepare(`INSERT INTO upgrade_manifest
      (from_version,to_version,applied_at,added_columns,rebuilt_fts,legacy_fingerprint,legacy_rows_count,post_fingerprint,verify_ok,backup_path,note)
      VALUES(?,?,?,?,?,?,?,?,?,?,?)`)
      .run('v11.x', VERSION, Date.now(), added, rebuilt ? 1 : 0,
           fpBefore.hash, captured, fpAfter.hash, fingerprintOk ? 1 : 0, backupPath, 'in-place');
  } catch { /* ignore */ }

  return { fresh: false, added, rebuilt, upgraded: true, backupPath, fingerprintOk };
}

/** 兼容旧调用名 */
export async function initSchema(db, opts) {
  return ensureSchema(db, opts);
}

/** 轻量事务包装：fn 内任何异常都回滚 */
export function tx(db, fn) {
  db.exec('BEGIN IMMEDIATE');
  try {
    const r = fn();
    db.exec('COMMIT');
    return r;
  } catch (e) {
    try { db.exec('ROLLBACK'); } catch { /* ignore */ }
    throw e;
  }
}

export function kvGet(db, k) {
  const row = db.prepare('SELECT v FROM kv WHERE k = ?').get(k);
  return row ? row.v : null;
}

export function kvSet(db, k, v) {
  db.prepare(
    'INSERT INTO kv(k, v, updated_at) VALUES(?, ?, ?) ' +
    'ON CONFLICT(k) DO UPDATE SET v = excluded.v, updated_at = excluded.updated_at'
  ).run(k, String(v), Date.now());
}