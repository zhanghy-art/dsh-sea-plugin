// src/kit/time.mjs — 时间双轨（v13.0 新增）
// 背景：v11.1 旧库的时间列是 TEXT（'2026-10-24 01:30:00' 这种），
//       而 v12.x/14.0 的新代码一律用毫秒数字比较。
//       两者混用会出现「daysSince 得到 NaN」→ effWeight 抛错 → 记忆整条被跳过。
// 裁定（融合指南 4.1，采 codex）：保留旧 TEXT 列不动，新增 *_ms 整数列；
//       新代码只写 *_ms、只读 *_ms；TEXT 列永远不覆盖。
// 这个文件是唯一的解析入口：旧值能读、新值能读、缺失能回退。

const TEXT_PATTERNS = [
  // 'YYYY-MM-DD HH:MM:SS' / 'YYYY-MM-DDTHH:MM:SS(.sss)(Z)'
  /^\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}(:\d{2})?(\.\d+)?(Z|[+-]\d{2}:?\d{2})?$/,
  // 'YYYY-MM-DD'
  /^\d{4}-\d{2}-\d{2}$/,
  // 'YYYY/MM/DD HH:MM:SS'
  /^\d{4}\/\d{2}\/\d{2}( \d{2}:\d{2}(:\d{2})?)?$/,
];

/** 任意时间值 → 毫秒；无法解析返回 null */
export function parseMs(v) {
  if (v == null || v === '') return null;
  if (typeof v === 'number') {
    if (!Number.isFinite(v)) return null;
    // 秒级时间戳（10 位及以下）→ 毫秒；13 位已是毫秒
    return v > 0 && v < 1e11 ? v * 1000 : v;
  }
  if (v instanceof Date) return v.getTime();
  const s = String(v).trim();
  if (!s) return null;
  // 纯数字字符串：秒级(10位)自动升到毫秒
  if (/^\d+$/.test(s)) {
    const n = Number(s);
    if (s.length <= 10) return n * 1000;
    return n;
  }
  for (const re of TEXT_PATTERNS) {
    if (!re.test(s)) continue;
    const norm = s.replace(/\//g, '-').replace(' ', 'T');
    // v11.1 的 TEXT 时间列是 UTC 墙钟（迁移回填用 strftime('%s', col)，也按 UTC 解释）。
    // Date.parse 对无时区的 'YYYY-MM-DDTHH:mm:ss' 按本地时区处理，会整体偏 8 小时，
    // 进而影响 coreEligible 的 7 天门槛、180 天退出与 daysSinceMs。这里显式补 Z。
    const hasZone = /(Z|[+-]\d{2}:?\d{2})$/i.test(norm);
    const t = Date.parse(hasZone ? norm : norm + 'Z');
    if (Number.isFinite(t)) return t;
  }
  const fallback = Date.parse(s);
  return Number.isFinite(fallback) ? fallback : null;
}

/**
 * 一条记忆的「参照时间」：确认时间优先，其次创建时间。
 * 优先 *_ms（新写），回退 TEXT 旧列（不迁移、不改写）。
 */
export function refMs(mem, now = null) {
  if (!mem) return now;
  return (
    parseMs(mem.confirmed_at_ms) ??
    parseMs(mem.confirmed_at) ??
    parseMs(mem.created_at_ms) ??
    parseMs(mem.created_at) ??
    null
  );
}

export function daysSinceMs(mem, now = Date.now()) {
  const t = refMs(mem);
  if (t == null) return null;
  return (now - t) / 86400000;
}

/** 事件发生时间（happened_at 优先于 created_at） */
export function happenedMs(mem) {
  if (!mem) return null;
  return (
    parseMs(mem.happened_at_ms) ??
    parseMs(mem.happened_at) ??
    refMs(mem)
  );
}

/** 写库时的时间列对：{..._ms} 是唯一被新代码消费的部分 */
export function msColumns(now) {
  return {
    created_at_ms: now,
    confirmed_at_ms: now,
    valid_from_ms: now,
    happened_at_ms: now,
  };
}

/** 展示层用：毫秒 → 'YYYY-MM-DD HH:mm' */
export function fmtMs(ms) {
  const t = parseMs(ms);
  if (t == null) return '';
  const d = new Date(t);
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
}