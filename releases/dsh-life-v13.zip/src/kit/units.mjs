// src/kit/units.mjs — 标度边界
// 两层语义，刻意并存（不是二选一、不是删旧换新）：
//   · 旧层（v11.1/v12.x 遗产）：HORMONE_SCALE=100、h01/hDisplay/assertUnitConsistent —— 保留原语义，
//     任何引用旧标度的调用点都不会因为升级而断（verify13 的 T67 组依赖这一层）。
//   · 新层（v13.0 主标度）：toUnit / normalizeHormones / clamp01 —— 运行时统一 0–1（指南共识第 1 条）。
//   toUnit 同时吃 0–1 与 0–100 两种输入（阈值 1.5 判定），所以新旧调用可以共存而不误判。
export const HORMONE_SCALE = 100;                  // 旧 0–100 标度（v11.1/v12.x）
export const LEGACY_HORMONE_SCALE = HORMONE_SCALE;
export const HORMONE_SCALE_V13 = 1;                // v13.0 运行时标度

const clamp01 = (v) => Math.max(0, Math.min(1, Number(v ?? 0)));

/**
 * 任意标度 → 0–1。
 * 判定阈值 1.5：0–100 标度下最小值是 floor 10，0–1 标度下不存在 1.5，两个区间不重叠。
 */
export function toUnit(v) {
  const n = Number(v ?? 0);
  if (!Number.isFinite(n)) return 0;
  return clamp01(n > 1.5 ? n / HORMONE_SCALE : n);
}

/** 旧名兼容：激素 → 0–1（历史上就是 /100，现在对两种输入都成立） */
export const h01 = toUnit;

/** 激素 → 面板显示值（0–100，四舍五入到整数） */
export const hDisplay = (v) => Math.round(toUnit(v) * 100);

/** needs/energy 的 0–1 → 面板显示（0–100） */
export const nDisplay = (v) => Math.round(clamp01(v) * 100);

/** 面板输入 0–100 → needs 0–1 */
export const nFromDisplay = (v) => clamp01(Number(v ?? 0) / 100);

/** 激素对象整体归一（迁移、启动恢复、外部注入都要过这一道） */
export function normalizeHormones(h) {
  const out = {};
  for (const k of ['cortisol', 'dopamine', 'oxytocin', 'serotonin']) out[k] = toUnit(h?.[k]);
  return out;
}

/**
 * 断言用：任何跨标度写入都必须经过这里，禁止直接乘除 100。
 * kind='hormone' 继续接受 0–100（旧调用点），kind='need'/'energy' 严格 0–1（v13 运行时）。
 */
export function assertUnitConsistent(name, value, kind) {
  const max = kind === 'hormone' ? HORMONE_SCALE : HORMONE_SCALE_V13;
  if (typeof value !== 'number' || !Number.isFinite(value) || value < 0 || value > max) {
    throw new Error(`[units] ${name} 越界：${value}（${kind} 的合法范围 0–${max}）`);
  }
  return value;
}

export { clamp01 };