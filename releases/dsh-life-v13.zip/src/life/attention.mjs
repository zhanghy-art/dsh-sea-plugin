// src/life/attention.mjs — 注意力倾斜（3.10，来自一号，采纳 codex 的边界）
// 铁律不变：不写 memories、不进 effWeight、不改可信度。
// 这里改的是“已经过门槛的候选之间的展示顺序”，不是“能不能进”。
// v13.0：激素标度改成 0–1，阈值与倍率改成从 config.attention.tiers 读（不再硬编码 0.55/0.80）。
import { DEFAULTS } from '../kit/config.mjs';
import { toUnit } from '../kit/units.mjs';

/** cortisol 归一化到 0–1（旧库 0–100 值也能吃，toUnit 会判） */
export function cortisolNorm(hormones) {
  return toUnit(hormones?.cortisol ?? DEFAULTS.hormone.init.cortisol);
}

/** 按 tiers 取倍率：高危 3.0 / 中 1.8 / 低 1.0；被压低的类别不丢弃，只排后面 */
export function attentionFactor(mem, hormones, cfg = DEFAULTS) {
  if (!cfg.attention.enabled) return 1;
  const c = cortisolNorm(hormones);
  const cls = [mem.category, mem.protection_tier, mem.emotion].filter(Boolean);
  const isHot = cls.some(x => cfg.attention.crisisClasses.includes(x)) ||
    (Number(mem.emotional_salience ?? 0) >= 0.7 && mem.emotion === 'negative');
  for (const t of cfg.attention.tiers) {
    if (c >= t.cortisol) return isHot ? t.hot : t.cold;
  }
  return 1;
}

/** 门槛之后重排：score' = score * factor，返回新数组，不改原 score */
export function rerank(items, hormones, cfg = DEFAULTS) {
  if (!cfg.attention.enabled) return items;
  return items
    .map(it => ({ ...it, attention: attentionFactor(it.mem, hormones, cfg) }))
    .map(it => ({ ...it, rankScore: it.score * it.attention }))
    .sort((a, b) => b.rankScore - a.rankScore);
}

/** 被压低的记忆不许“问不出来”：用户明确追问时必须能答（豆包 3.1.1 的例外） */
export function allowOnExplicitAsk(items, query) {
  const asking = /(那个|上次|之前|还记得|是不是说过)/.test(String(query || ''));
  if (!asking) return items;
  return [...items].sort((a, b) => b.score - a.score);
}