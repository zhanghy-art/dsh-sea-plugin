// src/maintenance/nightly.mjs — 夜间巩固 + 长期维护（第十九章）
import { DEFAULTS } from '../kit/config.mjs';
import { kvGet, kvSet } from '../kit/db.mjs';
import { scanCold } from '../memory/engine.mjs';
import { effWeight } from '../memory/weight.mjs';

export const EVENT_KEEP_DAYS = 90;
export const EVENT_KEEP_ROWS = 20000;
export const CANDIDATE_KEEP_DAYS = 30;
export const INJECTION_LOG_DAYS = 30;

/** 能力熔断：连续失败 3 次 → 冻结 24h（12.8） */
export class Breaker {
  constructor(db, { threshold = 3, freezeHours = 24 } = {}) {
    this.db = db; this.threshold = threshold; this.freezeHours = freezeHours;
  }
  key(cap) { return `breaker:${cap}`; }
  fail(cap, now = Date.now()) {
    const raw = kvGet(this.db, this.key(cap));
    const s = raw ? JSON.parse(raw) : { n: 0, until: 0 };
    s.n += 1;
    if (s.n >= this.threshold) { s.until = now + this.freezeHours * 3600000; s.n = 0; }
    kvSet(this.db, this.key(cap), JSON.stringify(s));
    return { frozen: s.until > now, until: s.until };
  }
  ok(cap) { kvSet(this.db, this.key(cap), JSON.stringify({ n: 0, until: 0 })); }
  isFrozen(cap, now = Date.now()) {
    const raw = kvGet(this.db, this.key(cap));
    if (!raw) return { frozen: false };
    const s = JSON.parse(raw);
    return { frozen: s.until > now, until: s.until };
  }
  list() {
    const rows = this.db.prepare("SELECT k, v FROM kv WHERE k LIKE 'breaker:%'").all();
    return rows.map(r => ({ cap: r.k.slice(8), ...JSON.parse(r.v) }));
  }
}

/**
 * 夜间任务：04:00 之后任意时刻跑一次，同日幂等（last_nightly_day）。
 * @param db
 * @param opts { now, cfg, buildEdges?: ()=>{inserted:number}, narrate?: ()=>void }
 */
export function runNightly(db, opts = {}) {
  const now = opts.now || Date.now();
  const cfg = opts.cfg || DEFAULTS;
  const dayKey = new Date(now).toISOString().slice(0, 10);
  const last = kvGet(db, 'last_nightly_day');
  if (last === dayKey && !opts.force) return { skipped: true, dayKey };

  const report = { dayKey, candidates: 0, events: 0, cold: 0, edges: 0, wal: 'ok', archive: 0 };

  // 1) 候选过期与清理
  report.candidates = db.prepare(
    "UPDATE candidates SET status = 'expired' WHERE status = 'pending' AND expires_at < ?"
  ).run(now).changes ?? 0;
  db.prepare('DELETE FROM candidates WHERE status != ? AND created_at < ?')
    .run('pending', now - CANDIDATE_KEEP_DAYS * 86400000);

  // 2) 事件保留：90 天 + 2 万条
  db.prepare('DELETE FROM life_events WHERE created_at < ?').run(now - EVENT_KEEP_DAYS * 86400000);
  const n = db.prepare('SELECT COUNT(*) AS n FROM life_events').get().n;
  if (n > EVENT_KEEP_ROWS) {
    const over = n - EVENT_KEEP_ROWS;
    db.prepare('DELETE FROM life_events WHERE event_id IN (SELECT event_id FROM life_events ORDER BY created_at ASC LIMIT ?)')
      .run(over);
  }
  report.events = n;

  // 3) 注入日志 30 天
  db.prepare('DELETE FROM injection_log WHERE injected_at < ?').run(now - INJECTION_LOG_DAYS * 86400000);

  // 4) 转冷
  report.cold = scanCold(db, now, cfg, effWeight).length;

  // 5) 边生成（可选回调，避免夜间多一次模型调用）
  if (opts.buildEdges) {
    try { report.edges = opts.buildEdges()?.inserted ?? 0; } catch { report.edges = -1; }
  }

  // 6) 失效记录归档（归档成功才删）
  const dead = db.prepare(
    'SELECT id, invalid_reason FROM memories WHERE invalid_reason IS NOT NULL LIMIT 500'
  ).all();
  for (const d of dead) {
    const row = db.prepare('SELECT * FROM memories WHERE id = ?').get(d.id);
    db.prepare('INSERT INTO memories_archive(id, archived_at, reason, payload) VALUES(?,?,?,?)')
      .run(d.id, now, d.invalid_reason, JSON.stringify(row));
    db.prepare('DELETE FROM memories WHERE id = ?').run(d.id);
    report.archive += 1;
  }

  // 7) WAL 截断（必须放在最后）
  try { db.exec('PRAGMA wal_checkpoint(TRUNCATE);'); } catch { report.wal = 'failed'; }

  kvSet(db, 'last_nightly_day', dayKey);
  return report;
}

/** 容量与配额总表（19.6）的口径检查 */
export function capacityReport(db) {
  const q = (sql, ...a) => db.prepare(sql).get(...a);
  return {
    memories: q('SELECT COUNT(*) AS n FROM memories').n,
    cold: q('SELECT COUNT(*) AS n FROM memories WHERE cold = 1').n,
    hot: q('SELECT COUNT(*) AS n FROM memories WHERE cold = 0 AND invalid_reason IS NULL').n,
    candidates: q("SELECT COUNT(*) AS n FROM candidates WHERE status = 'pending'").n,
    events: q('SELECT COUNT(*) AS n FROM life_events').n,
    snapshots: q('SELECT COUNT(*) AS n FROM life_snapshots').n,
    snapshotBytes: q('SELECT COALESCE(SUM(size_bytes),0) AS n FROM life_snapshots').n,
    injections: q('SELECT COUNT(*) AS n FROM injection_log').n,
    edges: q('SELECT COUNT(*) AS n FROM edges').n,
  };
}
