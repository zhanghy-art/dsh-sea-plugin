// src/memory/candidates.mjs — 候选六状态机（11.x，采纳六号+codex）
// pending → accepted / rejected / deferred / expired
// v13.0 关键修复（D3）：accept 不再「只改状态」。
//   v12.x/14.0 的 accept 只把 candidates.status 改成 accepted，记忆表一行都没多，
//   等于「审核通过 = 什么都没发生」。现在 accept 会拿候选原文重跑 15 步写入管线。
import { DEFAULTS } from '../kit/config.mjs';
import { nextId } from '../kit/ids.mjs';
import { normalizeScope } from '../kit/scope.mjs';
import { cosine } from './search.mjs';
import { writeMemory } from './engine.mjs';
import { dice } from './text.mjs';

export const STATUS = ['pending', 'accepted', 'rejected', 'deferred', 'expired'];

/** 三重去重：指纹 → 来源键 → 语义相似（v13.0：指纹/来源键都带 scope，避免跨会话误判） */
export function tripleDedup(db, { text, fingerprint, originKey, vec, scope = null, cfg = DEFAULTS }) {
  const sc = scope ? normalizeScope(scope, { ownerQq: cfg.ownerQq }) : null;
  const byFp = sc
    ? db.prepare("SELECT id, status FROM candidates WHERE json_extract(payload,'$.fingerprint') = ? AND scope = ? LIMIT 1").get(fingerprint, sc)
    : db.prepare("SELECT id, status FROM candidates WHERE json_extract(payload,'$.fingerprint') = ? LIMIT 1").get(fingerprint);
  if (byFp) return { dup: true, reason: 'fingerprint', id: byFp.id };
  const byOrigin = sc
    ? db.prepare("SELECT id FROM candidates WHERE json_extract(payload,'$.origin_key') = ? AND scope = ? LIMIT 1").get(originKey, sc)
    : db.prepare("SELECT id FROM candidates WHERE json_extract(payload,'$.origin_key') = ? LIMIT 1").get(originKey);
  if (byOrigin) return { dup: true, reason: 'origin_key', id: byOrigin.id };
  if (vec) {
    const rows = sc
      ? db.prepare("SELECT id, payload FROM candidates WHERE status = 'pending' AND scope = ? ORDER BY created_at DESC LIMIT 50").all(sc)
      : db.prepare("SELECT id, payload FROM candidates WHERE status = 'pending' ORDER BY created_at DESC LIMIT 50").all();
    for (const r of rows) {
      try {
        const p = JSON.parse(r.payload || '{}');
        if (p.vec && cosine(vec, Float32Array.from(p.vec)) >= 0.88) return { dup: true, reason: 'semantic', id: r.id };
      } catch { /* ignore */ }
    }
  }
  return { dup: false };
}

/** 新建候选：raw 原文暂存在候选里，转正才写进 memories.raw */
export function addCandidate(db, c, { now = Date.now(), cfg = DEFAULTS } = {}) {
  const id = nextId(db, 'candidates', 'c');
  const payload = JSON.stringify({
    fingerprint: c.fingerprint, origin_key: c.originKey,
    vec: c.vec ? Array.from(c.vec) : null,
  });
  db.prepare(`INSERT INTO candidates
    (id, scope, subject_qq, text, kind, payload, category, evidence, evidence_kind, evidence_ref,
     msg_ids, source_kind, source_id, confidence, status, created_at, expires_at,
     fingerprint, origin_key, raw_text)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(
    id, normalizeScope(c.scope, { ownerQq: cfg.ownerQq }), c.subject_qq ?? null,
    String(c.text).slice(0, cfg.memory.rawMaxChars), c.kind || 'fact', payload,
    c.category || 'fact', c.evidence ?? null, c.evidence_kind ?? 'inferred', c.evidence_ref ?? null,
    (c.msg_ids || []).join(','), c.source_kind ?? 'inferred', c.source_id ?? null,
    Number(c.confidence ?? 0.7), 'pending', now, now + cfg.memory.candidateDays * 86400000,
    c.fingerprint ?? null, c.originKey ?? null, String(c.text).slice(0, cfg.memory.rawMaxChars)
  );
  return { id, status: 'pending' };
}

/**
 * 审核候选。
 * accept：重跑写入管线（人工确认 = user_confirm，belief 0.90，直写通道）
 * reject/defer：只改状态
 */
export async function reviewCandidate(db, id, { decision, reason = '', now = Date.now(), cfg = DEFAULTS } = {}) {
  const row = db.prepare('SELECT * FROM candidates WHERE id = ?').get(id);
  if (!row) return { ok: false, reason: 'not-found' };

  if (decision === 'accept') {
    const res = await writeMemory(db, {
      scope: row.scope,
      subject_qq: row.subject_qq,
      fact: row.raw_text || row.text,
      raw: row.raw_text || row.text,
      category: row.category || 'fact',
      tags: null,
      evidence: row.evidence || row.text,
      evidence_kind: 'manual',
      evidence_ref: `candidate:${row.id}`,
      source_kind: row.source_kind || 'user',
      source_id: row.source_id,
      belief_src: 'user_confirm',
      // 人工审核通过 → 走直写通道，不再二次落回候选（否则 accept 又变成空操作）
      force_direct: cfg.memory.candidateAcceptRerun !== false,
      confidence: 1,
    }, { cfg, now });
    const memoryId = res?.id ?? null;
    db.prepare("UPDATE candidates SET status='accepted', reviewed_at=?, status_reason=?, memory_id=? WHERE id=?")
      .run(now, reason || 'accepted', memoryId, id);
    return { ok: true, status: 'accepted', memoryId, action: res?.action, raw_text: row.raw_text || row.text };
  }
  if (decision === 'reject') {
    db.prepare("UPDATE candidates SET status='rejected', reviewed_at=?, status_reason=? WHERE id=?").run(now, reason, id);
    return { ok: true, status: 'rejected' };
  }
  if (decision === 'defer') {
    const after = now + cfg.memory.deferReviewDays * 86400000;
    db.prepare("UPDATE candidates SET status='deferred', reviewed_at=?, review_after=?, status_reason=? WHERE id=?").run(now, after, reason, id);
    return { ok: true, status: 'deferred', review_after: after };
  }
  return { ok: false, reason: 'bad-decision' };
}

/** 过期扫描 + rejected 30 天去重窗口 */
export function sweepCandidates(db, now = Date.now(), cfg = DEFAULTS) {
  const expired = db.prepare("UPDATE candidates SET status='expired' WHERE status='pending' AND expires_at < ?").run(now).changes ?? 0;
  const rejected = db.prepare("SELECT text FROM candidates WHERE status='rejected' AND reviewed_at > ?").all(now - cfg.memory.rejectedDedupDays * 86400000);
  db.prepare("DELETE FROM candidates WHERE status IN ('expired','rejected') AND created_at < ?")
    .run(now - cfg.memory.candidateKeepDays * 86400000);
  return { expired, rejectedTexts: rejected.map(r => r.text) };
}

/** rejected 窗口内同义候选不得再次入池 */
export function blockedByRejected(candidateText, rejectedTexts, threshold = 0.82) {
  for (const t of rejectedTexts) if (dice(candidateText, t) >= threshold) return true;
  return false;
}