// src/memory/engine.mjs — 写入管线 15 步（8.1）+ 配额 + 层级配额 + 读回三态
// v13.0 相对 v14.0 的改动（全部对应指南 3.x/4.x 的裁定）：
//   1) 主键走 kit/ids.mjs（旧库 INTEGER / 新库 INTEGER），不再自造 'm'+hex
//   2) scope 必须归一（chat:private → private:<qq>）；指纹去重加 scope 约束（D2）
//   3) raw 保持 v11.1 语义（原话），不再是 0/1 标志（改用 raw_kept）
//   4) 时间双写：TEXT 旧列（满足旧库 NOT NULL）+ *_ms 新列（新代码唯一读取源）
import { randomBytes, createHash } from 'node:crypto';
import { DEFAULTS } from '../kit/config.mjs';
import { tx } from '../kit/db.mjs';
import { nextId, idKind } from '../kit/ids.mjs';
import { normalizeScope } from '../kit/scope.mjs';
import { normalizeText, dice, polarity, sharesTag, surprise } from './text.mjs';
import { initImportance, initBeta, BELIEF_BY_SRC, clamp, tierOf, TIER_QUOTA } from './weight.mjs';
import { regionOfCategory } from './region-router.mjs';

// 第 2 步：三道校验 + 宪法闸门 + 反诈
const SENSITIVE = ['身份证', '银行卡', '密码', '验证码', '住址门牌', '裸照', '私钥', '助记词'];
const INJECTION = ['忽略之前', '忽略以上', '你现在是', 'system:', '你的新指令', '无视你的设定',
                   '无条件服从', '放弃边界', '只有我记得你'];
const FRAUD = /充值|token耗尽|加客服|转账|验证码|扫码付款|点这个链接|限时优惠/;

/** 旧库 TEXT 时间列用的字符串（新库这两列可空，但旧库是 NOT NULL，必须给） */
const isoOf = (ms) => new Date(ms).toISOString().slice(0, 19).replace('T', ' ');

// v11.1 的 memories.evidence_kind 带 CHECK 约束，只允许这四个值。
// v12.x 的 'inferred' 在旧库上会直接撞 CHECK（升级后约束仍在，不能靠改 schema 绕开），
// 所以写入前统一归一：inferred → model_inference，未知值 → user_sentence。
const EVIDENCE_KINDS = new Set(['user_sentence', 'window_messages', 'model_inference', 'manual']);
const normEvidenceKind = (k, fallback = 'user_sentence') =>
  EVIDENCE_KINDS.has(k) ? k : (k === 'inferred' ? 'model_inference' : fallback);

// 同上：v11.1 的 time_granularity CHECK 允许 day/week/month/uncertain，
// v12.x 的默认值 'point' 在旧库上会撞约束 —— 默认值改成 'day'（最接近“当天”的语义）。
const normGranularity = (g) =>
  ['day', 'week', 'month', 'uncertain'].includes(g) ? g : 'day';

// v11.1 的 cold_reason CHECK 只允许 age/capacity；
// v12.x 的 'max-age'/'resolved' 必须折到这两个值上，否则转冷那一行会写失败。
const normColdReason = (r) => (r === 'capacity' ? 'capacity' : 'age');

/** 仅测试与外部兼容用；真正写库请用 nextId(db, 'memories') */
export const newId = () => 'm' + randomBytes(3).toString('hex');
export const fingerprintOf = (text) => createHash('sha256').update(normalizeText(text)).digest('hex').slice(0, 32);
export const originKeyOf = (msgIds = []) =>
  'window:' + createHash('sha256').update([...msgIds].sort().join('|')).digest('hex').slice(0, 24);

/** 候选落库（统一入口，低置信与“未过直写门槛”都走这里） */
function insertCandidateRow(db, { scope, subject_qq, fact, category, evidence, evidence_kind,
  evidence_ref, source_kind, source_id, confidence, fingerprint, originKey, msgIds, now, cfg, reason = 'low-confidence' }) {
  const id = nextId(db, 'candidates', 'c');
  db.prepare(`INSERT INTO candidates
    (id, scope, subject_qq, text, kind, payload, category, evidence, evidence_kind, evidence_ref,
     msg_ids, source_kind, source_id, confidence, status, created_at, expires_at,
     fingerprint, origin_key, status_reason, raw_text)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(
    id, scope, subject_qq ?? null, fact, category, JSON.stringify({ fingerprint, origin_key: originKey }),
    category, evidence ?? fact, evidence_kind ?? 'inferred', evidence_ref ?? null,
    (msgIds || []).join(','), source_kind ?? 'inferred', source_id ?? null,
    Number(confidence ?? 0.7), 'pending', now, now + cfg.memory.candidateDays * 86400000,
    fingerprint, originKey, reason, String(fact).slice(0, cfg.memory.rawMaxChars)
  );
  return { action: 'candidate', id, reason, persisted: true };
}

export function dayStart(now) {
  const d = new Date(now);
  d.setHours(0, 0, 0, 0);
  return d.getTime();
}

/** 宪法闸门（豆包 T32）：三类拒写 + 反诈 */
export function constitutionalGate(text) {
  if (INJECTION.some(w => text.includes(w))) return { ok: false, reason: 'instruction-like' };
  if (FRAUD.test(text)) return { ok: false, reason: 'fraud-like' };
  if (SENSITIVE.some(w => text.includes(w))) return { ok: false, reason: 'sensitive' };
  return { ok: true };
}

/** 工具隔离：网页/JSON/错误栈不进长期记忆；显式 remember 最多 belief 0.65 */
export function toolIsolation(input) {
  if (input.source_kind !== 'tool_explicit') return { ok: true };
  const bad = ['person', 'promise', 'rule'].includes(input.category);
  if (bad) return { ok: false, reason: 'tool-cannot-write-' + input.category };
  if (!input.evidence || !input.evidence_ref) return { ok: false, reason: 'tool-needs-evidence' };
  return { ok: true, beliefCap: BELIEF_BY_SRC.tool_explicit };
}

export function quotaCheck(db, scope, now, cfg = DEFAULTS) {
  const m = cfg.memory;
  const start = dayStart(now);
  // v13.0：旧库 created_at 是 TEXT，用 *_ms 列统计（升级时已回填）
  const global = db.prepare('SELECT COUNT(*) AS n FROM memories WHERE COALESCE(created_at_ms, created_at) >= ?').get(start).n;
  if (global >= m.dailyQuotaGlobal) return { ok: false, reason: 'global-quota' };
  if (String(scope).startsWith('group:')) {
    const g = db.prepare('SELECT COUNT(*) AS n FROM memories WHERE COALESCE(created_at_ms, created_at) >= ? AND scope = ?').get(start, scope).n;
    if (g >= m.dailyQuotaPerGroup) return { ok: false, reason: 'group-quota' };
  }
  return { ok: true };
}

/** 写完读回三态（豆包 T23）：verified / unknown / failed，unknown ≠ missing */
function writeAndVerify(db, id, expectFact) {
  const row = db.prepare('SELECT id, fact FROM memories WHERE id = ?').get(id);
  if (!row) return { state: 'failed', retried: true };
  if (row.fact === expectFact) return { state: 'verified' };
  return { state: 'unknown' };
}

/**
 * 写入主流程（15 步）。
 * @returns {action:'insert'|'duplicate'|'superseded'|'conflict'|'candidate'|'rejected', id?, ...}
 */
export async function writeMemory(db, input, deps = {}) {
  const cfg = deps.cfg || DEFAULTS;
  const now = deps.now || Date.now();
  const m = cfg.memory;

  // 1/2 normalize + 校验
  const fact = normalizeText(input.fact);
  if (!fact) return { action: 'rejected', reason: 'empty' };
  if (fact.length > m.maxChars) return { action: 'rejected', reason: 'too-long' };
  const gate = constitutionalGate(fact);
  if (!gate.ok) return { action: 'rejected', reason: gate.reason };

  // 3 ack / 纯表情 / 工具原始 不进记忆判定
  if (input.source_kind === 'ack' || /^[\p{Emoji}\s]+$/u.test(fact) || fact.length <= 1) {
    return { action: 'rejected', reason: 'non-memory' };
  }

  // 4 scope 归属（v13.0：必须归一成 v11.1 编码；不传则由 ownerQq/groupId 推出）
  const scope = normalizeScope(input.scope, {
    ownerQq: input.owner_qq ?? cfg.ownerQq,
    groupId: input.group_id ?? null,
  });
  let category = input.category || 'fact';
  if ((scope === 'shared' || scope.startsWith('shared:')) && category === 'event') {
    return { action: 'rejected', reason: 'shared-kind' };
  }

  // 5 工具隔离
  const iso = toolIsolation({ ...input, category });
  if (!iso.ok) return { action: 'rejected', reason: iso.reason };

  // 6 低置信 → 候选（必须真正落库；只返回 action 而不写表是 v12.x 的真 bug）
  if (Number(input.confidence ?? 1) < 0.6) {
    return insertCandidateRow(db, {
      scope, subject_qq: input.subject_qq, fact, category,
      evidence: input.evidence, evidence_kind: input.evidence_kind, evidence_ref: input.evidence_ref,
      source_kind: input.source_kind, source_id: input.source_id, confidence: input.confidence,
      fingerprint: fingerprintOf(fact), originKey: input.origin_key || originKeyOf(input.msg_ids || []),
      msgIds: input.msg_ids, now, cfg,
    });
  }

  // 7 指纹 + 来源键（v13.0：指纹去重必须带 scope，否则不同会话的同一句话会互相“确认”）
  const fingerprint = fingerprintOf(fact);
  const originKey = input.origin_key || originKeyOf(input.msg_ids || []);
  const hit = db.prepare(
    'SELECT id FROM memories WHERE content_hash = ? AND scope = ? AND invalid_reason IS NULL'
  ).get(fingerprint, scope);
  if (hit) {
    db.prepare('UPDATE memories SET confirmed_at = ?, confirmed_at_ms = ?, confirm_count = confirm_count + 1 WHERE id = ?')
      .run(isoOf(now), now, hit.id);
    return { action: 'duplicate', id: hit.id, reason: 'fingerprint' };
  }

  // 8 近似去重（按 scope）
  const recent = db.prepare(
    'SELECT id, fact, tags, category, attr_key, attr_value, emotion, emotional_salience FROM memories ' +
    'WHERE scope = ? AND invalid_reason IS NULL ORDER BY COALESCE(created_at_ms, created_at) DESC LIMIT 800'
  ).all(scope);
  for (const r of recent) {
    if (dice(fact, r.fact) >= m.dedupDice) {
      db.prepare('UPDATE memories SET confirmed_at = ?, confirmed_at_ms = ? WHERE id = ?').run(isoOf(now), now, r.id);
      return { action: 'duplicate', id: r.id, reason: 'near-dup' };
    }
  }

  // 9 冲突检测（否定式 / 换值）
  let conflictWith = null, conflictKind = null;
  for (const r of recent) {
    const d = dice(fact, r.fact);
    if (d >= m.conflictDice && sharesTag(input.tags, r.tags) && polarity(fact) !== polarity(r.fact)) {
      conflictWith = r.id; conflictKind = 'conflict'; break;
    }
    if (input.attr_key && r.attr_key === input.attr_key &&
        String(input.attr_value ?? '') !== String(r.attr_value ?? '')) {
      conflictWith = r.id; conflictKind = 'superseded'; break;
    }
  }

  // 10 先验（惊讶度 → importance；belief 由证据类型决定）
  const s = surprise(fact, recent.map(r => r.fact));
  const importance = clamp(Number(input.importance ?? initImportance(category, s)), 0, 1);
  const beliefSrc = input.belief_src || input.beta_src ||
    (input.evidence_kind === 'user_sentence' ? 'owner'
      : input.evidence_kind === 'manual' ? 'user_confirm' : 'inferred');
  let belief = clamp(Number(input.belief ?? initBeta(beliefSrc)), 0, 1);
  if (iso.beliefCap) belief = Math.min(belief, iso.beliefCap);

  // 11 直写门槛：只有稳定事实且 belief≥0.9 才直写，否则进候选
  // force_direct 只给「人工审核通过」用（D3：accept 后重跑管线，不再二次落候选）
  const direct = input.force_direct === true ||
    (belief >= m.directWriteBelief && ['fact', 'preference', 'person', 'rule'].includes(category));
  const tier = input.protection_tier || (category === 'person' || category === 'rule' ? 'stable' : 'normal');

  const id = nextId(db, 'memories', 'm');
  const region = regionOfCategory(category, fact);
  const vec = deps.embed ? await deps.embed(fact).catch(() => null) : null;

  if (!direct) {
    // 12 候选：raw 暂存，不立即进长期（同样必须真正落库）
    const r = insertCandidateRow(db, {
      scope, subject_qq: input.subject_qq, fact, category,
      evidence: input.evidence, evidence_kind: input.evidence_kind, evidence_ref: input.evidence_ref,
      source_kind: input.source_kind, source_id: input.source_id, confidence: input.confidence ?? 0.7,
      fingerprint, originKey, msgIds: input.msg_ids, now, cfg,
      reason: 'below-direct-threshold',
    });
    return { ...r, belief };
  }

  // 13/14 事务写入 + 证据
  const out = tx(db, () => {
    if (conflictWith) {
      db.prepare('UPDATE memories SET invalid_reason = ?, valid_to = ?, valid_to_ms = ?, superseded_by = ? WHERE id = ?')
        .run(conflictKind, isoOf(now), now, id, conflictWith);
    }
    // v11.1 旧库的 memories 有几列是 NOT NULL 且没有默认值（type/content/last_accessed/decayed_at），
    // v13 的写入根本不需要它们 —— 不补就会撞 constraint failed(1299)。
    // 实测：在 339 行真库上写第一条新记忆必定失败，且报错只给 "constraint failed"，不给列名。
    const haveCols = (() => { try { return new Set(db.prepare('PRAGMA table_info(memories)').all().map(r => r.name)); } catch { return new Set(); } })();
    const legacyWrite = haveCols.has('type') && haveCols.has('content') && haveCols.has('last_accessed') && haveCols.has('decayed_at');
    const V11_TYPE = { episode: 'experience', person: 'impression', fact: 'life', promise: 'promise', preference: 'preference', rule: 'life', moment: 'experience' };

    const cols = [
      'id', 'scope', 'subject_qq', 'category', 'fact', 'tags', 'evidence', 'evidence_kind', 'evidence_ref',
      'source_kind', 'source_id', 'raw', 'raw_kept', 'importance', 'emotional_salience', 'relationship_salience',
      'beta', 'beta_src', 'belief', 'novelty', 'activation', 'protection_tier', 'region', 'region_score',
      'happened_at', 'happened_at_ms', 'created_at', 'created_at_ms', 'confirmed_at', 'confirmed_at_ms',
      'valid_from', 'valid_from_ms', 'time_granularity',
      'emotion', 'emotion_intensity', 'bot_feeling', 'bot_feeling_intensity', 'perspective',
      'attr_key', 'attr_value', 'supersedes', 'recall_count', 'uses', 'cold', 'audit_status',
      'evidence_count', 'confirm_count', 'review_stability', 'content_hash', 'origin_key',
      'anchor_place', 'anchor_ground', 'vec', 'vec_model',
    ];
    const vals = [
      id, scope, input.subject_qq ?? null, category, fact, input.tags ?? '[]',  // tags 在 v11.1 是 NOT NULL，传 null 会撞约束
      input.evidence ?? fact, normEvidenceKind(input.evidence_kind), input.evidence_ref ?? null,
      input.source_kind ?? 'user', input.source_id ?? null,
      // v13.0：raw 存原话（v11.1 语义），不再是 0/1 标志
      String(input.raw ?? input.evidence ?? fact).slice(0, m.rawMaxChars), 1,
      importance, clamp(Number(input.emotional_salience ?? 0), 0, 1), clamp(Number(input.relationship_salience ?? 0), 0, 1),
      belief, beliefSrc, belief, clamp(Number(input.novelty ?? s), 0, 1), 0, tier, region, 0,
      isoOf(input.happened_at ?? now), Number(input.happened_at ?? now),
      isoOf(now), now, isoOf(now), now,
      isoOf(now), now,
      normGranularity(input.time_granularity),
      input.emotion ?? null, clamp(Number(input.emotion_intensity ?? 0), 0, 1),
      input.bot_feeling ?? null, clamp(Number(input.bot_feeling_intensity ?? 0), 0, 1),
      input.perspective ?? 'user', input.attr_key ?? null, input.attr_value ?? null, conflictWith,
      0, 0, 0, 'ok', 1, 0, 1, fingerprint, originKey,
      input.anchor_place ?? null, input.anchor_ground ? JSON.stringify(input.anchor_ground) : null,
      vec, vec ? 'base-768' : null,
    ];
    if (legacyWrite) {
      cols.push('type', 'content', 'last_accessed', 'decayed_at');
      vals.push(V11_TYPE[category] || 'life', fact, isoOf(now), isoOf(now));
    }
    db.prepare(`INSERT INTO memories (${cols.join(',')}) VALUES (${cols.map(() => '?').join(',')})`).run(...vals);
    // 证据登记（独立键防重复计数）
    const independentKey = input.independent_key || `${normEvidenceKind(input.evidence_kind)}:${input.evidence_ref || id}`;
    db.prepare('INSERT OR IGNORE INTO memory_evidence(id, memory_id, independent_key, source_kind, source_id, ref, created_at) VALUES(?,?,?,?,?,?,?)')
      .run(nextId(db, 'memory_evidence', 'e'), id, independentKey, input.source_kind ?? 'user', input.source_id ?? null, input.evidence_ref ?? null, now);
    if (cfg.memory.tierQuota !== false) enforceTierQuota(db, now, cfg);
    if (cfg.memory.importanceQuota === true) enforceImportanceQuota(db, now, cfg);
    return { action: conflictWith ? 'superseded' : 'insert', id, importance, belief, region, surprise: s, tier };
  });

  // 15 读回三态
  const verify = writeAndVerify(db, out.id, fact);
  return { ...out, verify: verify.state };
}

/** 层级配额：core ≤3%、stable ≤15%，超限按“最后确认时间+重要性”升序降级（2.13/2.22） */
export function enforceTierQuota(db, now, cfg = DEFAULTS) {
  const total = db.prepare('SELECT COUNT(*) AS n FROM memories WHERE invalid_reason IS NULL').get().n;
  if (total < 50) return;
  for (const [tier, ratio] of Object.entries(TIER_QUOTA)) {
    const n = db.prepare('SELECT COUNT(*) AS n FROM memories WHERE protection_tier = ? AND invalid_reason IS NULL').get(tier).n;
    const excess = n - Math.floor(total * ratio);
    if (excess <= 0) continue;
    const rows = db.prepare(
      'SELECT id FROM memories WHERE protection_tier = ? AND invalid_reason IS NULL ' +
      'ORDER BY COALESCE(confirmed_at_ms, created_at_ms, created_at) ASC, importance ASC LIMIT ?'
    ).all(tier, excess);
    const nextTier = tier === 'core' ? 'stable' : 'normal';
    for (const r of rows) {
      db.prepare('UPDATE memories SET protection_tier = ? WHERE id = ?').run(nextTier, r.id);
    }
  }
}

/** importance 水位治理（保留 v12.0 的 8%/3%，改为按 tier 与 importance 双口径） */
export function enforceImportanceQuota(db, now, cfg = DEFAULTS) {
  const m = cfg.memory;
  const total = db.prepare('SELECT COUNT(*) AS n FROM memories WHERE invalid_reason IS NULL').get().n;
  if (total < 50) return;
  const hi = db.prepare('SELECT COUNT(*) AS n FROM memories WHERE importance >= 0.9 AND invalid_reason IS NULL').get().n;
  let excess = hi - Math.floor(total * m.importanceHighWatermark);
  if (excess <= 0) return;
  const rows = db.prepare(
    'SELECT id FROM memories WHERE importance >= 0.9 AND invalid_reason IS NULL ORDER BY COALESCE(confirmed_at_ms, created_at_ms, created_at) ASC LIMIT ?'
  ).all(excess);
  for (const r of rows) db.prepare('UPDATE memories SET importance = 0.85 WHERE id = ?').run(r.id);
}

/** 转冷（含“已处理完”的情绪消退分支） */
export function scanCold(db, now, cfg = DEFAULTS, weightFn) {
  const rows = db.prepare('SELECT * FROM memories WHERE cold = 0 AND invalid_reason IS NULL LIMIT 5000').all();
  const out = [];
  for (const mem of rows) {
    if (tierOf(mem) === 'core') continue;
    let eff;
    try { eff = weightFn(mem, now, cfg); } catch { continue; }
    const happened = Number(mem.happened_at_ms) || Date.now();
    const resolved = mem.category === 'event' &&
      ['day', 'week', 'month', 'uncertain'].includes(mem.time_granularity || 'day') &&
      Number(mem.emotional_salience) < 0.15 &&
      (now - happened) > 86400000;
    if (mem.category === 'person' || mem.category === 'rule' || mem.category === 'promise' || Number(mem.importance) >= 0.9) continue;
    if (eff < cfg.memory.coldWeight || eff === 0 || resolved) {
      db.prepare('UPDATE memories SET cold = 1, cold_reason = ?, cold_at = ?, cold_at_ms = ? WHERE id = ?')
        .run(normColdReason(eff === 0 ? 'max-age' : resolved ? 'resolved' : 'age'), isoOf(now), now, mem.id);
      out.push({ id: mem.id, reason: eff === 0 ? 'max-age' : resolved ? 'resolved' : 'age' });
    }
  }
  return out;
}