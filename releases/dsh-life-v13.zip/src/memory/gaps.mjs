// src/memory/gaps.mjs — 缺口池与 REM 反思（第十八章，来自一号）
// 一句话：她不知道的事，不装懂，先记账；账本会自己发酵，闭不上就一直在。
// v13.0：gaps.id 改 INTEGER（旧库 TEXT 主键会自动降级，见 kit/ids.mjs）；
//        tension 标度 0–1（与激素、needs 统一，指南共识第 1 条）。
import { DEFAULTS } from '../kit/config.mjs';
import { nextId } from '../kit/ids.mjs';
import { clamp01 } from '../kit/units.mjs';

/** 缺口 id：新库走 INTEGER 自增，旧库（TEXT 主键）自动降级成 'g…' */
export const newGapId = (db) => nextId(db, 'gaps', 'g');

/** 从一次“没答上来”生成缺口；tension 越高越容易在梦里被翻出来（0–1） */
export function openGap(db, { question, scope = 'shared', tension = 0.50, now = Date.now() } = {}) {
  const id = newGapId(db);
  const t = clamp01(tension);
  db.prepare('INSERT INTO gaps(id, scope, question, tension, created_at) VALUES(?,?,?,?,?)')
    .run(id, scope, String(question).slice(0, 200), t, now);
  // 到期张力衰减由夜间算子处理，这里只做上限控制
  const open = db.prepare('SELECT COUNT(*) AS n FROM gaps WHERE resolved = 0').get().n;
  if (open > DEFAULTS.gaps.maxOpen) {
    db.prepare('DELETE FROM gaps WHERE id IN (SELECT id FROM gaps WHERE resolved=0 ORDER BY tension ASC LIMIT ?)')
      .run(open - DEFAULTS.gaps.maxOpen);
  }
  return { id, tension: t };
}

/** 闭合分：strongestEvidence*(0.5+0.5*coverage)，<0.45 不闭合（豆包 2.x） */
export function closeScore(strongestEvidence, coverage) {
  return Math.min(1, strongestEvidence) * (0.5 + 0.5 * Math.min(1, coverage));
}

export function tryCloseGap(db, gapId, { strongestEvidence = 0, coverage = 0, closedBy = 'evidence', now = Date.now() } = {}) {
  const s = closeScore(strongestEvidence, coverage);
  if (s < DEFAULTS.gaps.closeScoreFloor) return { ok: false, score: s };
  db.prepare('UPDATE gaps SET resolved = 1, closed_by = ?, closed_at = ?, coverage = ? WHERE id = ?')
    .run(closedBy, now, coverage, gapId);
  return { ok: true, score: s };
}

/** 夜间：张力随时间衰减（未解决的事会淡，但不会自动消失） */
export function decayGaps(db, { now = Date.now(), rate = 0.98 } = {}) {
  db.prepare('UPDATE gaps SET tension = tension * ? WHERE resolved = 0').run(rate);
  db.prepare('DELETE FROM gaps WHERE resolved = 1 AND closed_at < ?').run(now - 90 * 86400000);
  return db.prepare('SELECT COUNT(*) AS n FROM gaps WHERE resolved = 0').get().n;
}

/** REM：挑一条张力最高的缺口，生成一句“梦里想不明白的事”（≤50 字，非事实） */
export function remFromGaps(db, { limit = 1, threshold = 0.30 } = {}) {
  const rows = db.prepare('SELECT id, question, tension FROM gaps WHERE resolved = 0 AND tension >= ? ORDER BY tension DESC LIMIT ?')
    .all(threshold, limit);
  return rows.map(r => ({
    gapId: r.id,
    text: `（梦见在问「${String(r.question).slice(0, 14)}」，没得到答案）`,
    tension: r.tension,
  }));
}

/** 顿悟：缺口被一次对话偶然补上 → 奖励（只动激素，不动权重，守外层铁律） */
export function epiphany(db, gapId, state, cfg = DEFAULTS) {
  const g = db.prepare('SELECT * FROM gaps WHERE id = ?').get(gapId);
  if (!g || g.resolved) return null;
  db.prepare('UPDATE gaps SET resolved = 1, closed_by = ?, closed_at = ?, tension = 0 WHERE id = ?')
    .run('epiphany', Date.now(), gapId);
  const e = DEFAULTS.gaps.epiphany;
  if (state?.hormones) {
    const cap = cfg.hormone.cap ?? 0.97;
    // 增量本身是 0–1 标度的小量（0.12 / -0.10 / 0.08），直接加，上限用 cap 而不是 100
    state.hormones.dopamine = Math.min(cap, Number(state.hormones.dopamine ?? 0.50) + e.dopamine);
    state.hormones.cortisol = Math.max(cfg.hormone.floor.cortisol, Number(state.hormones.cortisol ?? 0.30) + e.cortisol);
    state.hormones.serotonin = Math.min(cap, Number(state.hormones.serotonin ?? 0.60) + e.serotonin);
  }
  return { closed: gapId, reward: e };
}