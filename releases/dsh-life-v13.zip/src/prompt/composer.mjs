// src/prompt/composer.mjs — 预算硬分配 + 稳定前缀顺序（2.10 / 6.2 / 18.6）
import { DEFAULTS } from '../kit/config.mjs';

const SLOTS_PRIVATE = [
  ['l1', Infinity],      // 人格层另有上限，不占注入预算
  ['facts', 480],
  ['summary', 120],
  ['state', 50],
  ['stage', 80],
  ['snippets', 150],     // 片段 100 + 梦境 50
];
const SLOTS_GROUP = [
  ['l1', Infinity],
  ['facts', 400],
  ['summary', 120],
  ['state', 30],
  ['stage', 70],
  ['snippets', 80],
];

/**
 * 严格顺序：L1 → facts → summary → state → stage → snippets
 * 稳定前缀在前，易变内容在后（命中上下文缓存）。
 * @returns {{text:string, usedChars:number, dropped:string[], byKind:object, truncated:boolean}}
 */
export function compose({ l1 = '', facts = [], summary = '', state = '', stage = '', snippets = [] },
                        { group = false } = {}) {
  const slots = group ? SLOTS_GROUP : SLOTS_PRIVATE;
  const parts = [];
  const dropped = [];
  const byKind = {};
  let truncated = false;

  const put = (kind, text) => {
    if (!text) return;
    parts.push(`【${label(kind)}】${text}`);
    byKind[kind] = (byKind[kind] || 0) + String(text).length;
  };

  // L1 人格：整段必带，不参与 900 字预算
  if (l1) put('l1', String(l1).slice(0, 1600));

  // facts：整行丢弃，绝不截半句
  const factCap = slots.find(s => s[0] === 'facts')[1];
  let used = 0;
  const kept = [];
  for (const f of facts) {
    const line = typeof f === 'string' ? f : f.line;
    if (!line) continue;
    if (used + line.length > factCap) { dropped.push('fact:' + line.slice(0, 12)); continue; }
    kept.push(line);
    used += line.length;
  }
  if (kept.length) put('facts', kept.join('\n'));

  // summary：按句号截断（可截，因为是摘要）
  if (summary) {
    const cap = slots.find(s => s[0] === 'summary')[1];
    let s = String(summary);
    if (s.length > cap) { s = cutSentence(s, cap); truncated = true; }
    put('summary', s);
  }

  if (state) {
    const cap = slots.find(s => s[0] === 'state')[1];
    put('state', String(state).slice(0, cap));
  }
  if (stage) {
    const cap = slots.find(s => s[0] === 'stage')[1];
    put('stage', String(stage).slice(0, cap));
  }

  // snippets：整行丢
  const snipCap = slots.find(s => s[0] === 'snippets')[1];
  let snipUsed = 0;
  const snips = [];
  for (const s of snippets) {
    const line = typeof s === 'string' ? s : s.line;
    if (!line) continue;
    if (snipUsed + line.length > snipCap) { dropped.push('snippet:' + line.slice(0, 12)); continue; }
    snips.push(line); snipUsed += line.length;
  }
  if (snips.length) put('snippets', snips.join('\n'));

  const text = parts.join('\n');
  const budget = group ? 700 : 900;
  const memChars = text.length - (l1 ? ('【人格】' + String(l1).slice(0, 1600)).length : 0);

  return {
    text,
    usedChars: Math.min(memChars, budget),
    rawChars: text.length,
    dropped,
    byKind,
    truncated: truncated || dropped.length > 0,
    budget,
  };
}

function label(kind) {
  return { l1: '人格', facts: '记忆', summary: '摘要', state: '状态', stage: '阶段背景', snippets: '片段' }[kind] || kind;
}

function cutSentence(s, cap) {
  if (s.length <= cap) return s;
  const head = s.slice(0, cap);
  const idx = Math.max(head.lastIndexOf('。'), head.lastIndexOf('；'), head.lastIndexOf('，'));
  return idx > cap * 0.5 ? head.slice(0, idx + 1) : head;
}

/** 状态行：纯文字、不带数字、≤40 字（17.4 硬约束）
 *  v13.0：激素标度改 0–1，阈值同步为 0.60 / 0.65 / 0.30（原来写的是 60/65/30） */
export function stateLine({ phase, energy, hormones, stage }) {
  const h = hormones || {};
  const adj = [];
  if ((h.cortisol ?? 0) >= 0.60) adj.push('有点绷着');
  else if ((h.dopamine ?? 0) >= 0.65) adj.push('心情不错');
  else if ((h.oxytocin ?? 0) >= 0.60) adj.push('有点黏人');
  else if ((h.serotonin ?? 0) <= 0.30) adj.push('有点低落');
  const e = energy >= 0.75 ? '精力足' : energy >= 0.5 ? '还行' : '有点累';
  const st = { deep_trust: '很熟', familiar: '熟悉', normal: '普通', wary: '警惕' }[stage] || '普通';
  const phaseCn = { morning: '早上', peak: '上午', afternoon: '下午', evening: '傍晚', night: '夜里' }[phase] || '';
  const line = [phaseCn, e, ...adj, st].filter(Boolean).join('·');
  return line.slice(0, 40);
}
