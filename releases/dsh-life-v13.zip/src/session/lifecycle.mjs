// src/session/lifecycle.mjs — L1–L4 四层 + 周期归档（第十八章）
import { existsSync, mkdirSync, appendFileSync, readFileSync, readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';
import { DEFAULTS } from '../kit/config.mjs';
import { kvGet, kvSet } from '../kit/db.mjs';
import { nextId } from '../kit/ids.mjs';
import { shingles } from '../memory/text.mjs';

export class SessionLifecycle {
  constructor(db, opts = {}) {
    this.db = db;
    this.cfg = opts.cfg || DEFAULTS;
    this.root = opts.root || join(process.env.HOME || '.', '.dsh', 'dsh-life', 'cold');
    this.turns = Number(opts.turns || 0);
    this.sinceSummary = Number(opts.sinceSummary || 0);
    this.ctxTokens = Number(opts.ctxTokens || 0);
  }

  // ---------- L3 冷层 ----------
  pathOf(scope, now = Date.now()) {
    const d = new Date(now);
    const day = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    return join(this.root, scope.replace(/[:/]/g, '_'), `${day}.md`);
  }

  appendRaw(scope, role, text, now = Date.now()) {
    const p = this.pathOf(scope, now);
    mkdirSync(join(p, '..'), { recursive: true });
    const line = `- ${new Date(now).toISOString()} [${role}] ${String(text).replace(/\n/g, ' ')}\n`;
    appendFileSync(p, line, 'utf8');
  }

  /** 冷层召回：关键词命中，最多扫最近 20 个文件，≤900 字 */
  recallCold(scope, query, opts = {}) {
    const limit = opts.limit || 900;
    const maxFiles = opts.maxFiles || 20;
    const dir = join(this.root, scope.replace(/[:/]/g, '_'));
    if (!existsSync(dir)) return { text: '', hits: 0 };
    const files = readdirSync(dir)
      .filter(f => f.endsWith('.md'))
      .map(f => ({ f, t: statSync(join(dir, f)).mtimeMs }))
      .sort((a, b) => b.t - a.t)
      .slice(0, maxFiles);
    const words = Object.keys(Object.fromEntries([...shingles(query)].map(s => [s, 1])));
    const picked = [];
    let chars = 0;
    for (const { f } of files) {
      const lines = readFileSync(join(dir, f), 'utf8').split('\n');
      for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        if (!line) continue;
        let hit = 0;
        for (const w of words) if (w.length > 1 && line.includes(w)) hit++;
        if (!hit) continue;
        const block = [lines[i - 1] || '', line, lines[i + 1] || ''].join('\n').trim();
        if (chars + block.length > limit) return { text: picked.join('\n'), hits: picked.length };
        picked.push(block);
        chars += block.length;
      }
    }
    return { text: picked.join('\n'), hits: picked.length };
  }

  // ---------- 计数与归档 ----------
  onTurn() {
    this.turns += 1;
    this.sinceSummary += 1;
    return { turns: this.turns, sinceSummary: this.sinceSummary };
  }

  shouldSummarize() { return this.sinceSummary >= 15; }

  /**
   * 双触发（18.10，合并六号的“20 轮”与 codex 的“70%/90%”）：
   * 先到者生效——轮数兜底省钱，占比兜底防断片。
   */
  shouldArchive(ctxRatio = 0) {
    const L = this.cfg.lifecycle;
    if (this.cfg.capabilities?.autoArchive === false) return false;   // 默认关，升级不改行为
    const byTurns = L.archiveTurns > 0 && this.turns >= L.archiveTurns;
    const byRatio = ctxRatio >= L.resetAt;
    const byTokens = this.ctxTokens >= L.contextSoftLimit;
    return byTurns || byRatio || byTokens;
  }

  /** 是否需要先生成交接（70% 时提前准备），不重置 */
  shouldPrepare(ctxRatio = 0) {
    return ctxRatio >= this.cfg.lifecycle.compressAt;
  }

  /** 重置前五项硬检查（12.3）：任一项不过就不重置，宁可不重置也不断片 */
  preResetChecks({ handoffText = '', hasUnflushedEvents = false, pendingProposals = 0, l1Ok = true } = {}) {
    const checks = [
      ['handoff-present', String(handoffText || '').trim().length > 0],
      ['handoff-shape', String(handoffText || '').includes('刚才在聊')],
      ['events-flushed', !hasUnflushedEvents],
      ['proposals-closed', pendingProposals === 0],
      ['l1-intact', l1Ok !== false],
    ];
    const failed = checks.filter(c => !c[1]).map(c => c[0]);
    return { ok: failed.length === 0, failed };
  }

  /** 写检查点：只存“怎么接上”，不存事实断言 */
  saveCheckpoint(scope, { handoff, msgIds = [], revision = 0, now = Date.now() } = {}) {
    // v13.0：id 走 nextId（新库 INTEGER 自增 / 旧库 TEXT 降级），不再用 Math.random 造 TEXT 主键
    const id = nextId(this.db, 'context_checkpoints', 'k');
    this.db.prepare('INSERT INTO context_checkpoints(id, scope, revision, handoff, msg_ids, created_at) VALUES(?,?,?,?,?,?)')
      .run(id, scope, revision, String(handoff).slice(0, 400), msgIds.join(','), now);
    const n = this.db.prepare('SELECT COUNT(*) AS n FROM context_checkpoints WHERE scope = ?').get(scope).n;
    const cap = this.cfg.lifecycle.checkpointsPerScope || 20;
    if (n > cap) {
      this.db.prepare(
        'DELETE FROM context_checkpoints WHERE id IN (SELECT id FROM context_checkpoints WHERE scope = ? ORDER BY created_at ASC LIMIT ?)'
      ).run(scope, n - cap);
    }
    return { id };
  }

  /** 恢复：读最近检查点（重启或重置后接续用） */
  latestCheckpoint(scope) {
    return this.db.prepare(
      'SELECT * FROM context_checkpoints WHERE scope = ? ORDER BY created_at DESC LIMIT 1'
    ).get(scope) || null;
  }

  // ---------- L4 交接 ----------
  saveHandoff(scope, text, now = Date.now()) {
    const clean = String(text || '').slice(0, this.cfg.lifecycle.handoffChars);
    kvSet(this.db, `handoff:${scope}`, JSON.stringify({ text: clean, at: now, used: 0 }));
    return clean;
  }

  /** 只在 24h / 12 轮内注入；过期自动淡出 */
  readHandoff(scope, now = Date.now()) {
    const raw = kvGet(this.db, `handoff:${scope}`);
    if (!raw) return null;
    let h;
    try { h = JSON.parse(raw); } catch { return null; }
    const ageH = (now - h.at) / 3600000;
    if (ageH > this.cfg.lifecycle.handoffTTLHours || h.used >= this.cfg.lifecycle.handoffMaxTurns) return null;
    h.used += 1;
    kvSet(this.db, `handoff:${scope}`, JSON.stringify(h));
    return h.text;
  }

  /** 归档（每 20 轮）：调用方负责先提炼摘要再传进来 */
  archive(scope, handoffText, now = Date.now()) {
    this.saveHandoff(scope, handoffText, now);
    kvSet(this.db, `archived_at:${scope}`, now);
    this.turns = 0;
    this.sinceSummary = 0;
    this.ctxTokens = 0;
    return { ok: true, handoffChars: String(handoffText || '').length };
  }
}

/** L4 纪要模板（6.4）：生成失败宁可不写 */
export function buildHandoffPrompt(recentTurns) {
  return [
    '把下面这段对话压缩成一段交接纪要，严格按三行输出，每行不超过 60 字：',
    '1) 刚才在聊：<做什么，一句>',
    '2) 没说完的：<约定/待办，无则写“无”>',
    '3) 他那时的状态：<只写可观察的，不写推断>',
    '禁止新增对话中没出现的人物、时间、因果。',
    '',
    recentTurns.map(t => `${t.role}: ${t.text}`).join('\n').slice(-2000),
  ].join('\n');
}

/** 校验纪要合规：超长、出现新实体的，退回重写 */
export function validateHandoff(text, recentTurns) {
  const t = String(text || '');
  if (t.length > 200) return { ok: false, reason: 'too-long' };
  if (!t.includes('刚才在聊')) return { ok: false, reason: 'missing-shape' };
  const src = recentTurns.map(x => x.text).join('');
  const names = t.match(/[\u4e00-\u9fa5]{2,3}(?=说|问|提到)/g) || [];
  for (const n of names) if (!src.includes(n)) return { ok: false, reason: 'new-entity:' + n };
  return { ok: true };
}
