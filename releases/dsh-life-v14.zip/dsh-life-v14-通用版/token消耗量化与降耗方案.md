# token 消耗量化与降耗方案（v14.1.2）

> 前提：**效果与功能一条都不能少**。所以本方案的推荐路径里不含 `toolset:'lite'`——
> 它默认关闭，只作为「主人自己愿意临时换挡」的可选项保留。

## 0. 主人给的实测读数（2026-11-06 20:42）

```
283 轮 · 1359 步 · 426 tok/s
202M tok · 缓存命中 95%
```

随后主人补充：「现在又降到 389 了」。

> 说明：`426 tok/s` 是 DSH 状态栏的**实时吞吐**（最近一个采样窗口内 input+output 的 token 速率），
> 不是「dsh-life 插件每小时烧多少」。它由三件事相乘决定：
> **① 单轮上下文大小 × ② 单位时间内的轮数 × ③ 缓存命中率**。
> 插件能影响①，决定②的是宿主（qq-bridge 的唤醒频率），③取决于前缀是否稳定。

## 1. 先把账拆开：一次唤醒到底花在哪

实测（`materials/measure-runtime.mjs` → `measure-token-opt-v2.json`，A 配置 = 默认 full）：

| 组成 | 字符 | 估算 token | 占比 |
|---|---|---|---|
| 13 个工具的 schema | 1356 | 1424 | **91.2%** |
| 固定工具提示（`dsh.mjs:138` 硬编码） | 67 | 70 | 4.5% |
| memory 注入（每轮平均） | 65 | 68 | 4.3% |
| **合计（dsh-life 每次唤醒固定开销）** | 1488 | **1562** | 100% |

（`estTok` 按中文 ~1.05 token/字估算；字符数是硬数据。memory 平均 65 字符是 7 轮实测均值，
单轮最多 106 字符 —— 说明记忆段本身已经是「按预算截断」后的结果。）

另外 `dsh-life.policy`（1711 字符 ≈ 1797 token）在真机上**没有**被注入 ——
`src/host/dsh.mjs:126-141` 的回调只读 `dsh-life.memory` + `dsh-life.reflex`，不读 policy。
这是天然省下的，但也意味着策略约束在真机上没生效（已知，不在本轮修）。

**关键判断：工具 schema 占了 88.7% 的固定开销。** 所以「13 个工具是不是太贵」这个问题的答案是：
**贵，但贵在 schema，不在工具数量本身**——13 个工具平均每个 104 字符，这个密度是健康的。

## 2. 三条降耗路径（按「功能是否减少」排序）

### 路径 A：`skipIdleTurn` —— 空唤醒轮复用上一轮注入（**功能零减少**）

**做了什么**：定时空唤醒（`timeout`/`replyCheck`/`proactiveCheck`/`bootstrap`/`admin`）时，
不重算注入，直接复用上一轮的 `dsh-life.memory` / `dsh-life.reflex` 段，逐字节相同。

**为什么省**：① 不重新查库、不重新组装；② 上下文前缀**一字不改**，prompt cache 稳定命中。

**实测**：
- 四配置测量（`materials/measure-token-opt-v2.json`）：配置 C（只开 skipIdleTurn）的 t4/t5/t6 三个 idle 轮，memory 段全是 `79` 字符，与 t3 **逐字节相同**；而配置 A（默认）t4 被重算成 `56`。
- 真库副本 R-12/R-13：`3 个空唤醒轮全部复用`、`idleSkips=3`。

**默认值**：`false`（零行为变化，可整包回退）。开启方法见 §4。

**代价**：空唤醒轮看到的是「上一刻的记忆快照」。这是**设计上正确**的——空唤醒本来就没有新信息，
重新算一遍只会得到同样的东西，白烧 token。

### 路径 B：抑制闹钟到期前的空唤醒（**功能零减少**）

见 `解决方案/补丁04-抑制定时空唤醒/README.md`。

**做了什么**：她设了「六点醒」的闹钟，三点到六点之间不再被 `replyCheck`/`proactiveCheck`/
`triggers.probability` 反复拉起。真人找她（@/名字/提问/拍一拍/关键词/新消息）**照常唤醒**。

**为什么这是最大的杠杆**：每次空唤醒 = 一整个完整轮（上下文重发 + 一次模型调用）。
把「3 点到 6 点之间醒 8 次」变成「6 点醒 1 次」，这一段的消耗直接降到 1/8。

**实测**：判定表 24/24（`自检.mjs`）、沙盒 H8 16/16。

**代价**：无。闹钟到点照常醒，主动机会照常排（只是不插队）。

### 路径 C：`toolset:'lite'` —— **默认关闭，本方案不推荐**

**做了什么**：只注册 5 个核心工具（`life_remember`/`life_propose`/`life_mark_sent`/`life_recall`/`life_status`），
砍掉 8 个（`life_sleep`/`life_delivery_poll`/`life_delivery_ack`/`life_gap`/`life_lifebook`/
`life_persona_review`/`life_memory_review`/`life_forget`）。

**实测收益**：固定开销 1562 → 695 token，**省 55.5%**。

**为什么不推荐**：**这就是「减少功能」**。主人明确要求「效果功能不能减少，只能优化不能减少」。
所以：
- `toolset` 默认值 = `'full'`（13 个工具，一个不少）
- `lite` 保留为可选开关，但**不写进任何推荐配置**
- 沙盒 H2 专门断言「默认 full 下注册 13 个、dropped()=0」，防止有人误改默认值

## 3. 诚实的边界：插件管不了什么

| 组成 | 谁决定 | dsh-life 能改吗 |
|---|---|---|
| 13 工具 schema（1424 tok） | 插件注册 | 能，但只能靠删工具（=减功能）或不注册 |
| 固定工具提示（70 tok） | `dsh.mjs:138` 硬编码 | 能，但只有 70 tok |
| memory 注入（111 tok） | 插件 composer | 能，压到 0 就丢记忆 |
| **会话历史累积** | 宿主 DSH | **不能** |
| **人设基座 / 系统提示** | 宿主 DSH | **不能** |
| **唤醒次数（乘数）** | qq-bridge | **不能**（走补丁04） |
| **模型吐字速度** | 服务端 / 硬件 | **不能** |

**所以**：`426 → ≤200` 不可能只靠插件做到。能把 426 打下来的组合是
**「补丁04（少醒）+ skipIdleTurn（醒了不重算）+ cache 命中（前缀稳定）」**，
插件侧能保证的是：**空唤醒轮的增量 ≈ 0，正常轮的固定开销不膨胀**。

## 4. 怎么开（一行配置，随时可回退）

`package.json` 的插件配置里加：

```json
{
  "v14": {
    "skipIdleTurn": true,
    "toolset": "full"
  }
}
```

- `skipIdleTurn: true` —— 开路径 A（功能零减少）
- `toolset: "full"` —— 明确保持 13 工具（默认值，写出来只是让人一眼看到没被减）
- 想整包回退：把 `skipIdleTurn` 改回 `false`，行为立刻回到 v14.1.1 原样

## 5. 可复现的量化命令

```bash
# 四配置固定开销对比（输出 JSON）
node materials/measure-token-opt.mjs

# 单次唤醒构成拆解
node materials/measure-runtime.mjs

# 真库副本上的实际表现（memory 字符数 / idleSkips）
cd 代码 && node ../../materials/real-db-call.mjs
```

实测基线（`materials/measure-runtime.json` + `measure-token-opt-v2.json`）：

```json
{
  "toolCount": 13,
  "toolChars": 1356,
  "toolSchemaEstTok": 1424,
  "toolHintChars": 67,
  "toolHintEstTok": 70,
  "memAvgChars": 65,
  "memEstTok": 68,
  "perWakeFixedTokens": 1562
}
```

> `identicalMemoryTurns: 3` —— 7 轮里有 3 轮的 memory 与上一轮**逐字节完全相同**。
> 这 3 轮就是 `skipIdleTurn` 能白省的对象（不重算 = 前缀不变 = cache 命中）。

四配置对比（同一套 7 轮对话，`measure-token-opt-v2.json`）：

| 配置 | 工具 | schema | memory | 固定提示 | **每次唤醒合计** | 省 |
|---|---|---|---|---|---|---|
| A 默认（full，不跳过） | 13 | 1424 | 68 | 70 | **1562** | — |
| B `toolset:'lite'` | 5 | 557 | 68 | 70 | **695** | 867（55.5%） |
| C `skipIdleTurn` | 13 | 1424 | 78 | 70 | **1572** | 0（省在 cache） |
| D lite + skipIdle | 5 | 557 | 78 | 70 | **705** | 857（54.9%） |

## 6. 和其它方案横向对比的接口

为了让豆包的测试结果能直接对上，请统一用这三个口径：

| 口径 | 定义 | 本包数值 |
|---|---|---|
| **单次唤醒固定开销** | 工具 schema + 固定提示 + memory 注入，token 数 | 1562（full） / 695（lite） |
| **空唤醒增量** | 定时类空唤醒轮相对上一轮新增的 token | 0（skipIdleTurn 开） |
| **唤醒次数** | 同一时间窗内 `sendWakePromptV2` 实际投递次数 | 补丁04 前/后对比 |

只要这三个数对上，横比就是同口径的。
