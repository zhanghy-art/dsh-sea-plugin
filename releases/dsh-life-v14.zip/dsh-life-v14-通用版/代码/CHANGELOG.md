# CHANGELOG

## v14.1.1（2026-11-05）· 通用版：真库实证 + ima 能力合并

> 基线来自 codex 14.1.0（571 断言全绿）。这一版不是"再写一版"，是把三方材料里
> 真正经得起本机真库检验的部分合进来，并把"从没在老库上跑过"这个致命盲区补上。

### 修复（真库实证出来的，三版都有）

- **P0 老库表结构错位**（最严重）：真库 `life_events` 仍是 v11.1 的 DDL
  （`seq/at/kind/payload/delta/revision/applied_at/type/event_id/created_at`），
  而三版 v14 的 schema.sql 写的是 v12+ 新结构。`CREATE TABLE IF NOT EXISTS` 对已存在的表
  不重建，于是真库上 `INSERT INTO life_events` 直接报
  `table life_events has no column named event_type`，被上层 catch 吞掉——
  **这就是 v13 装完后"事件流 type 全 NULL、提案 created_at 全空、队列只进不出"的总根因**。
  修法：新增 `src/kit/legacy-shape.mjs`，对 6 张表（life_events / action_proposals /
  memories_archive / milestones / promises / narratives）做整表重建 + 逐行搬运，
  老列全部保留为可空列，行数校验不过就 ROLLBACK。
- **P4 脏数据治理**：新增 `src/kit/dirty-data.mjs`，清 6 类脏数据——
  名为 `undefined` 的脏列、`life_state` 的 `singleton` 空壳残行、
  `'1793539724176.0'` 这种带 .0 尾巴的毫秒串、722 条早已过期却一直挂着 pending 的提案、
  完全同列的重复索引、以及多套向量模型混跑。全程 dry-run 可先看，单事务，每步失败只 warn。
- **TEXT 亲和性时间尾巴**：`life_state.updated_at` / `life_snapshots.created_at` 在 v11.1
  老库是 TEXT 类型，传 JS number 进去 SQLite 会先当 REAL 再转 TEXT，落库变成
  `'1793824621501.0'`，每次写都留一条，脏数据永远清不干净（二次启动必被判成 mixed-time）。
  修法：`saveState` 直接传**字符串**。
- **版本戳不推进**：v13 建的库列齐、索引齐、结构也对，`ensureSchema` 判 `upgraded:false`
  直接返回，`user_version` 永远停在 13。修法：版本戳本身参与 `needUpgrade` 判定。

### 合并（ima 独有、codex 缺的）

- `src/life/persona-drift.mjs`：人格慢漂移，只出 diff、owner 终审 apply 才落快照，
  `TIER_OK` 只认 user/owner/self/manual 来源；配套 `life_persona_review` 工具。
- `src/life/sleep-stage.mjs` 的 `sleepWindow` / `inSleepWindow`：睡眠窗口支持
  `cfg.sleep.window = 'auto' | {start,end}`，跨零点正确。
- `src/life/delivery.mjs` 的 `classifySleepReply` / `sleepShortReply`：睡着时三级处理——
  主人私聊命中紧急词回一句极短、主人私聊普通消息排队、群聊直接丢。
- `src/life/sleep-stage.mjs` 的 `archiveDreams` / `dreamsByNight` + `dreams` 表：
  dreamLog 超 softLimit 才归档，梦永远不进 memories。
- `src/memory/recall-card.mjs` 的 `allowRaw`：raw 原文只给 owner 私聊。
- 夜间钩子 `archiveDreams` / `personaDiff` 接进 `nightlyOpts`。

### 统一（三方各自的内部矛盾）

- `SCHEMA_VERSION` 13 → **14**（codex 的 `verify-final-gates.mjs:27` 本来就在断言 14，
  其余四处断言 13，是它自己内部矛盾）；`edges.basis` 并入 schema.sql / tables.sql。
- 包名三处统一为 `dsh-life-v14`（package.json / src/host/dsh.mjs / cordis.patch.yml）——
  install-log 里记过的"装了不跑"三根因之一。
- 三项高风险能力默认从 `false` 改为 `'shadow'`：算完回滚、只留审计，默认不生效但可观测。
- `scripts/doctor.mjs` 两处：默认库路径改用 `os.homedir()`（Windows 上 HOME 为空会变成
  `./.dsh/...`）、版本检查从"必须 13.x"改为">= 13"。

### 验证（全部本机实跑）

- `npm test`：16 套件 **663 / 663 通过**（原 14 套件 572 条 + 新并入 ima 的 p4 37 条、p5 54 条）；
- 沙盒：47 场景 / **315 断言 / 0 失败 / 0 错误**，116s；
- 模块自检：52 模块 / 127 依赖边 / 0 循环 / 0 孤儿；
- 隐私扫描：PASS；
- 中文检索：6 例全 rr=1.00 / leaks=0；
- **真库副本实测**（13.3MB，340 条记忆 / 1074 条事件 / 735 条提案）：
  ensureSchema 678ms，6 张表全部宽松化、行数一行不少、写入全部从 FAIL 转 OK，
  过期提案 722 → 0，二次启动 `upgraded=false` 不备份；链路测试 22/22；
  安装自检 27/27；插件装配自检 16/16。

## v14.1.0（2026-11-05）· 最终交叉验证与融合候选

### 新增

- `prompts/` 完整提示词包、manifest 和安全加载器；
- 启动时自动注入三段常驻提示词，夜间审计与 handoff 按任务加载；
- 12 例中文检索评测、Recall@K / MRR / scope leakage 门禁；
- `edges.basis` 可选迁移工具，默认 dry-run；
- DSH 适配融合报告，包含接口、文件映射、裁决项和验收标准。

### 修复

- FTS5 候选现在把自身 BM25 相关度带入门槛，不再出现“FTS 命中但被最终门槛丢弃”；
- LIKE 短查询获得明确字面分，短词回退不会只剩 0 分；
- optional migration 模块纳入源码依赖图，并由 `life_status` 只读自检；
- IMA 14.1 新版 559 项单测和 47/315 沙盒复跑通过；
- WorkBuddy 旧报告中“IMA 无 src”的结论已确认只适用于旧 delta，不适用于本轮 106 文件完整包。

### 验证

- `npm test`：**571 / 571 通过**；
- 模块：**49 / 120 / 0 循环 / 0 孤儿**；
- 中文固定集：Recall@5=1.0、MRR=1.0、leakage=0；
- 隐私扫描：PASS；
- 沙盒：47 场景 / 315 断言 / 0 失败 / 0 错误。

## v14.0.0-codex.4（2026-11-05）· 三方交叉验证终稿

本轮在 `.3` 上完成 IMA merged、WorkBuddy 最新 523 版和 ArcDream Hub v0.1.2 的交叉验证。IMA 实测 552 断言与 47/315 沙盒通过；WorkBuddy 实测 523 断言与 47/315 沙盒通过。

### 第三轮修复

- 旧库盖章统一使用白名单内的 `manual`，具体原因保存在 `anchor_ground.retractNote`；
- 旧库缺少 `valid_to_ms` 时使用分层回退，仍保留可解释原因；
- `life_gap`、候选审核、冲突解除、`life_forget` 绑定当前 scope，拒绝跨会话 id；
- 梦的缺口、高情绪记忆和注入日志全部按可见 scope 取数，梦事件保存 scope；
- `life_status` 的历史梦和一致性抽样按当前 scope 过滤；
- 缺口数量上限按 scope 淘汰，避免一个会话挤掉另一个会话的缺口。

以 v13.0 + WorkBuddy 候选包为底，保留其 482 项通过断言，并修复交叉验证确认的 24 项缺口。

### 修复

- **真实经过时间**：用 `counters.lastTickAt` 分段追赶最多 72 小时，合盖 8 小时不再只结算 15 分钟。
- **单一 energy 所有权**：v14 睡眠路径只由 `sleep-stage` 管理 energy，不再叠加 v13 回血、阶段回血和相位收敛三套力。
- **盖章记录不被夜删**：夜间归档只标冷并留档，不再从 `memories` 物理删除 superseded/retracted。
- **Windows 路径**：数据库、缓存、冷层统一走 `homeDir()/lifeDir()`，HOME 为空时不再生成字面 `undefined/`。
- **结构化评价**：新增 `appraisal` 模块，事件评价与实际生效结果写入 additive `life_events`，PAD 只从状态和评价派生。
- **长期可回放**：评价/梦/印记/冲突事件走独立保留策略（730 天 / 100,000 条）并加类型时间索引；普通运行事件仍按 90 天 / 20,000 条清理。
- **三态灰度**：高风险 `rerank/autoExtract/beliefPool/imprint` 支持 `off/shadow/on`，shadow 走真实路径但在 savepoint 中回滚，只留审计事件。
- **隐私门禁**：新增 `scripts/privacy-scan.mjs`，扫描真实本机路径、凭据和长 token，挂在 `npm test` 与 `privacy:scan`。
- **睡眠队列**：新增 `life_sleep / life_delivery_poll / life_delivery_ack`，睡眠时不假称已发送。
- **FTS/BM25 真接线**：长查询走 FTS5 候选 + BM25 参与过门槛前的字面分；短词自动回退 LIKE。
- **证据链**：`memory_evidence` 写入原话 quote、消息 id、断言时间。
- **分层召回**：新增 `life_recall`，第一层返回紧凑卡，第二层按 id 返回证据/原文。
- **缺口闭环**：新增 `life_gap`，支持 open/close/epiphany。
- **5 万行写入**：按写路径移走每轮 tier 配额全表扫描，增加 scope/visible 复合索引后重测通过。

### 验证

- `npm test`：**553 项全绿**。
- `check-modules`：46 模块 / 115 依赖边 / 0 循环 / 0 孤儿 / 0 缺失导入。
- 全量沙盒：47 场景 / 315 断言 / 0 失败 / 0 错误。

### 边界

- 仍是 DSH 插件核心，不是完整 QQ 桥接或世界沙盘。
- 睡眠默认按 `quietHours` 和状态自动推进，宿主可用 `life_sleep` 手动覆盖。
- 主动消息只提供 durable queue 与回执契约，真实投递仍需宿主适配。
- `persona` 慢漂移、GPU rerank、CPU/ONNX cross-encoder 保持可选，不阻塞核心。

---

## v13.0（2026-10-31）

**定位**：三方融合版。骨架 = ima v14.0（47 文件）；迁移 = codex v13.2（原库直升级 + FTS 无损）；
设计规格 = 豆包 v13.0（四轴/保护层级/十五步/FSRS/缺口/追话/发送三态/units）；底盘 = v11.1（八项保留）。
版本号由用户拍板定为 **13.0**（融合指南 6.5 原建议 `v14.0-final`，只改号不改实质）。

### 新增

- `src/kit/ids.mjs`：主键策略。旧库 INTEGER 复用（`MAX(id)+1`），TEXT 表自动降级，`sameId` 做跨类型比较。
- `src/kit/scope.mjs`：scope 归一与可见集。`chat:private` → `private:<qq>`，`shared` / `shared:%` / `global:<bot>` 全兼容；
  `scopeClause()` 产出「当前会话 + shared」的 SQL 片段，供四段召回共用。
- `src/kit/time.mjs`：TEXT / 毫秒双轨解析（`parseMs` / `refMs` / `daysSinceMs`），旧时间列不再得 NaN。
- `src/kit/units.mjs`：0–1 标度唯一入口（`toUnit` 以 1.5 为判据、`normalizeHormones`、`clamp01`）；
  同时保留旧层导出（`HORMONE_SCALE=100`、`hDisplay`）供老测试使用。
- `src/host/generic.mjs`：通用宿主适配器（`profile: 'generic'`），四个回调即可脱离 DSH 运行。
- `presets/generic.yml`、`docs/通用版-移植指南.md`：通用版配置与接入说明。
- `docs/逐段对照-融合说明书.md`：指南条款 × 三份源文原文 × 本包落点，逐段对照、原文照录。
- `tests/verify-chassis.mjs`（55 项）：v11.1 八项底盘 + 出口 E-1~E-4 + R/M 改动的可执行化。
- `tests/verify-upgrade.mjs`（45 项）：造 v11.1 真实 DDL 库（含 CHECK、0–100 激素、TEXT 时间）→ 直升级 → 逐行校验。
- `tests/verify-generic.mjs`（19 项）：无 DSH 环境下跑通启动 / 一轮对话 / 出口 / 群聊 / 定时器 / 二次启动幂等。

### 沙盒验证（2026-10-31，独立进程 + 真实库文件，35 场景 / 195 断言全绿）

- 覆盖：升级路径 10（fresh / 30 行 / 零行 / 3000 行 / 脏库 / 幂等 ×3 / 半途中断 / FTS / core 配额 / 激素归一）、
  运行时 15（写回三态 / scope 隔离 / 吞吐 / 候选 accept / 冷却 / FSRS / 缺口 / 硬闸 / 出口 / 预算 / 九类唤醒 / utility / 时间 / 状态恢复 / 通用宿主）、
  故障 5（损坏库 / 坏备份 / 目录缺失 / embed 抛错 / WAL 并发）、性能 3、回归 2。
- 日志：`docs/sandbox-log-2026-10-31.md`。
- 沙盒暴露并修复 3 处：

1. `db.mjs` fresh 分支不写 `kv.schema_version` → 补写，与升级分支口径一致。
2. `db.mjs` 指纹把本版本新增列也算进去，半途中断库续跑时被自己永久拒绝 → 指纹列 = 升级前列 − `columns.json` 新增列
   （`audit_status` / `time_granularity` 除外，二者 v11.1 就有）。
3. `time.mjs` `parseMs` 数字分支不换算秒级、TEXT 分支按本地时区解释无时区字符串 → 秒级 ×1000；补 `Z` 按 UTC 解析
   （与迁移回填 `strftime('%s', col)` 同口径）。

### 修复（相对 ima v14.0 骨架）

1. `engine.mjs` 用 `'m'+hex` 作 TEXT 主键插 INTEGER 主键表 → 改为 `nextId`（datatype mismatch 消失）。
2. `engine.mjs` 指纹去重 SQL 无 scope 约束 → 加 scope，跨会话不再误判重复。
3. `search.mjs` 默认 `scopes: ['chat:private','shared']` 在旧库匹配不到任何行 → 改为 `visibleScopes()` 推导。
4. `life-state.mjs` 只写 `state_json`，旧库列是 `snapshot_json NOT NULL` → 快照双列写。
5. `life-state.mjs` 激素 0–100 → 统一 0–1，旧值在 `recover` 时归一。
6. `schema.sql` 全部 TEXT 主键 → 全 INTEGER（`AUTOINCREMENT`）。
7. `candidates.mjs` accept 只改状态（违反 D3）→ 调 `writeMemory(force_direct)` 重跑 15 步，回写 `memory_id`。
8. `lifecycle.mjs` checkpoint id 用随机串 → `nextId`。
9. `columns.json` 目标版本 14 → 13。
10. 迁移缺备份 / 旧列指纹 / legacy 快照 / FTS 顺序 → 全部补齐（见下）。

### 升级（codex v13.2 第十四章）

- 首次写库前 `VACUUM INTO` 备份（保留最近 3 份）。
- 迁移前后逐行校验**旧列数据指纹**；不一致且 `upgrade.rollbackOnMismatch` 时拒绝启动。
- 旧行原样进 `legacy_rows`（含行级 fingerprint）。
- FTS 严格顺序：建表 → 摘触发器 → `rebuild` → 回填新列 → 装回触发器 → 再 `rebuild`（防首次 UPDATE 报 malformed）。
- 版本记录：`PRAGMA user_version = 13` + `kv.schema_version='13'` + `schema_migrations` + `upgrade_manifest`。
- 幂等：二次 `ensureSchema` 新增 0 列、不重复备份。

### 兼容口径

- 旧库 `memories.valid_to`、`scope` 等既有列**不重命名、不改写**；`_ms` 列只增。
- v11.1 的 CHECK 白名单是硬约束：`evidence_kind` 仅 `user_sentence/window_messages/model_inference/manual`；
  `time_granularity` 仅 `day/week/month/uncertain`；`cold_reason` 仅 `age/capacity`。写入前统一走 `norm*` 归一。
- 默认行为保持 v11.1：`route=false`、`autoArchive=false`、`speak.hardGate=false`；唯一默认生效的改动是注入冷却 6h。

### 断言

| 文件 | 项数 |
|---|---|
| `tests/verify.mjs` | 75 |
| `tests/verify12.mjs` | 82 |
| `tests/verify13.mjs` | 29 |
| `tests/verify-chassis.mjs` | 55 |
| `tests/verify-upgrade.mjs` | 45 |
| `tests/verify-generic.mjs` | 19 |
| **合计** | **305** |

另有 `scripts/doctor.mjs` 47 项结构自检。全部在 Node 24.21.0 下通过。

---

## v11.1（原底本，不在本包范围）

本包不修改 v11.1 的任何设计文档；八项底盘（双层定义 / LifeState / 四激素 / 九类唤醒 / 硬闸七条 /
900-700 预算 / 出口清洗 E-1~E-4 / 八类改动清单）逐项保留，由 `tests/verify-chassis.mjs` 守护。
