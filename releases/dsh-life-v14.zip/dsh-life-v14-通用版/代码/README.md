# dsh-life v14.1.1 · 通用版

以 v13.0 为唯一底座的升级包（**不是新造**）：保留 v13 的 memory / LifeState / 15-step / scope / 迁移安全，在此基础上接通真实经过时间、睡眠阶段与队列、结构化评价、FTS/BM25/向量/rerank、候选治理与分层召回，并补上三方 v14 材料都没做的一件事——**在老库上真的跑一遍**。

- 包版本：**14.1.1**；能力版本 `14.1`，schema 版本 **14**（`edges.basis` 已并入 schema）
- 基线：codex 14.1.0（571 断言全绿）→ 本版合并 ima 独有能力 + 修 P0 老库结构错位，共 **16 套件 663 断言**
- 运行环境：Node ≥ 22.5（`node:sqlite` 内置），零第三方依赖
- 许可：MIT
- 总闸：`capabilities.v14=false` 关闭新增运行路径；`autoExtract / beliefPool / imprint / rerank` 默认 `'shadow'`（算完回滚、只留审计）
- 交叉验证记录：`docs/CODEX-CROSS-VALIDATION.md`
- DSH 适配融合报告：`docs/DSH-适配融合报告-v14.1.md`
- 提示词包：`prompts/`
- 中文检索评测：`eval/zh-retrieval.json`
- 原有 v13 对照：[`docs/逐段对照-融合说明书.md`](docs/逐段对照-融合说明书.md)

## v14 Codex tools

| Tool | Purpose |
|---|---|
| `life_recall` | first compact cards, then detail/evidence/raw by id |
| `life_sleep` | switch auto/sleep/awake and inspect stage |
| `life_delivery_poll` | host drains messages after wake-up |
| `life_delivery_ack` | host confirms successful delivery |
| `life_gap` | list/open/close/epiphany for unanswered questions |
| `life_lifebook` | promises, milestones, narratives, relationship snapshots |
| `life_memory_review` | candidate accept/reject/defer + conflicts |
| `life_status` | hormone basis, sleep queue, retrieval stats, capacity |

---

## 一、从 11.1 升级（原地进行，不新建库）

**最短路径：替换代码 → 重启。** 插件启动时会自己给旧库补列、重建 FTS、校验旧列数据指纹，不新建库、不复制数据。

```bash
# 按本包目录结构写入 ~/.dsh/plugins/dsh-life（单文件交付稿可直接逐文件落盘）
# 重启 DSH，看日志：
#   [dsh-life] 原地升级：.../mind.db 新增 61 列，已重建 FTS 索引（旧列指纹一致，30 行）
```

想先看清楚它要改什么，再决定：

```bash
node scripts/migrate.mjs --db ~/.dsh/dsh-life/mind.db --dry-run   # 只打印，不写库
```

不想让它自动改：`config.yml` 里加 `autoMigrate: false`。

> 升级验证已真跑：造一个 v11.1 真实 DDL 库（含全部 CHECK 约束 / 旧 0–100 激素 / TEXT 时间），
> 迁移后校验「备份可打开、旧列指纹逐行一致、旧行快照进 legacy_rows、PK 仍是 INTEGER、CHECK 值未被改写、
> TEXT 时间未被改写、`created_at_ms` 已回填、FTS 中文可搜且首次 UPDATE 不报 malformed、scope 不串、
> 二次幂等、新增行可用、候选 accept 真落库」，**45 项全 PASS**（`tests/verify-upgrade.mjs`）。

```bash
# 1) 覆盖代码（只增文件，不删你的 self-made/）
# 将本包目录结构同步到 ~/.dsh/plugins/dsh-life

# 2) 就地升级数据库（自动备份 + 只加列/表，不动数据）
node scripts/migrate.mjs --db ~/.dsh/dsh-life/mind.db

# 3) 重启 DSH
```

升级后**行为默认保持 11.1**：

| 能力 | 升级后默认 | 说明 |
|---|---|---|
| 分舱路由 | `route: false`（兼容模式） | 想用就改 config.yml 的 `capabilities.route: true` |
| 自动归档 | `autoArchive: false` | 想省钱再打开 |
| 主动行为硬闸 | 软加项（`speak.hardGate: false`） | 想严格就设 `hardGate: true` |
| 注入冷却 | 6 小时 | 唯一默认生效的改动，可设 0 关闭 |
| 激素标度 | 0–1（旧 0–100 值在启动时自动归一） | 快照同时写 `state_json` 与 `snapshot_json` |

回滚：停插件 → 把 `mind.db.v13.bak.*` 覆盖回原路径 → 换回 11.1 代码。**数据零丢失。**

---

## 二、全新安装

```bash
node scripts/migrate.mjs --db ~/.dsh/dsh-life/mind.db   # 库不存在时不建；首次启动由插件自己建
cp config.example.yml ~/.dsh/dsh-life/config.yml
dsh plugin add file:///绝对路径/dsh-life
```

---

## 三、目录与职责

| 文件 | 职责 |
|---|---|
| `schema.sql` | 全量表结构（`memories` 主键 INTEGER，时间列 TEXT + `_ms` 双写；11 张辅助表 + FTS5 trigram） |
| `migrations/columns.json` | 迁移契约：`target_version: 14`、29 个 memories 列、42 条辅助表补列、`_ms` 回填 SQL |
| `migrations/tables.sql` | 幂等建表（由 schema.sql 生成，执行顺序见文件头） |
| `src/index.mjs` | 插件装配（onPreStep / onTurnStopping / tick 15min） |
| `src/kit/config.mjs` | 全部可调参数的唯一来源（`VERSION='14.1'`、`SCHEMA_VERSION=14`） |
| `src/kit/legacy-shape.mjs` | **v14 新增**：老库表结构错位修复（6 张表整表重建 + 逐行搬运 + 行数校验） |
| `src/kit/dirty-data.mjs` | **v14 新增**：6 类脏数据治理（脏列 / 残行 / 时间尾巴 / 过期提案 / 重复索引 / 多向量模型） |
| `src/kit/db.mjs` | 打开库、备份、旧列指纹、十步 `ensureSchema`、事务、kv |
| `src/kit/ids.mjs` | 主键策略：旧库 INTEGER 复用，TEXT 表自动降级 |
| `src/kit/scope.mjs` | scope 归一与可见集（旧库 `private:` / `group:` / `shared:` 全部兼容） |
| `src/kit/time.mjs` | TEXT / 毫秒双轨解析（旧时间列不再得 NaN） |
| `src/kit/units.mjs` | 0–1 标度换算（`toUnit` / `normalizeHormones` / `clamp01`） |
| `src/memory/text.mjs` | 归一化、Jaccard、dice、惊讶度、否定极性 |
| `src/memory/weight.mjs` | effWeight、双通道门槛、保护层级配额、core 准入/退出、转冷 |
| `src/memory/engine.mjs` | 写入管线 15 步、配额、写入读回三态、核心准入、转冷扫描 |
| `src/memory/search.mjs` | 四段召回（scope 前置）、注入冷却、注入日志 |
| `src/memory/region-router.mjs` | 分舱路由（七舱，默认关） |
| `src/memory/embedding-cache.mjs` | LRU 500 + 磁盘 + 预热 |
| `src/memory/candidates.mjs` | 候选五状态 + 三重去重 + accept 重跑写入管线 |
| `src/memory/evidence.mjs` | 证据独立性 + core 晋升 |
| `src/memory/fsrs.mjs` | 复习调度（2^hits，封顶 180 天） |
| `src/memory/gaps.mjs` | 缺口池 + REM + 顿悟 |
| `src/reflex/activation.mjs` | 反射激活度累积（阈值 0.55 / 显式 +0.45 / 15min×0.85） |
| `src/life/life-state.mjs` | LifeState、lifeTick、恢复、快照限容（四激素 0–1、六维惯性） |
| `src/life/attention.mjs` | 注意力倾斜（门槛后重排） |
| `src/life/sleep.mjs` | 睡眠分段结算 |
| `src/life/sleep-stage.mjs` | 睡眠阶段推进 + 睡眠窗口（`sleepWindow`/`inSleepWindow`）+ 梦境归档（`archiveDreams`） |
| `src/life/persona-drift.mjs` | 人格慢漂移：只出 diff，owner 终审 apply 才落快照 |
| `src/life/delivery.mjs` | 睡着时的三级投递（reply-short / queue / drop） |
| `src/session/lifecycle.mjs` | L1–L4、冷层、交接纪要、五项重置检查、20 轮归档 |
| `src/prompt/composer.mjs` | 预算硬分配（900/700）、稳定前缀顺序、状态行 |
| `src/outlet/cleaner.mjs` | 出口清洗 E-1~E-4、工具裁剪、回声窗 |
| `src/govern/constitution.mjs` | L0 宪法锁、分级审批、主动计划闸 |
| `src/maintenance/nightly.mjs` | 夜间巩固、熔断、容量报告 |
| `src/action/speak.mjs` | speakWeight / speakBonus / utility 十项 / 迟滞 / 七道硬闸 / 追话 |
| `scripts/migrate.mjs` | 就地升级外壳（复用 `ensureSchema`，带 dry-run 与报告） |
| `scripts/doctor.mjs` | 47 项硬自检（环境/文件/库结构/治理/维护） |
| `tests/verify.mjs` | 75 项基线断言 |
| `tests/verify12.mjs` | 82 项 v12.1 新增断言 |
| `tests/verify13.mjs` | 29 项 v13.0 收敛断言 |
| `tests/verify-chassis.mjs` | 55 项 v11.1 底盘保留断言（八项底盘 + 出口 + R/M 改动） |
| `tests/verify-upgrade.mjs` | 45 项 v11.1 → v13.0 原库直升级验证 |
| `tests/verify-v14-codex.mjs` | 40 项时间、睡眠、评价、证据、生活簿和审计验证 |
| `tests/verify-v14-cross2.mjs` | 31 项三方交叉验证：三态、72h、180 天、旧库 CHECK、scope 与隐私 |
| `tests/verify-prompt-eval.mjs` | 13 项提示词加载、注入和中文 Recall@K / MRR |
| `tests/verify-final-gates.mjs` | 5 项可选 `edges.basis` 迁移门禁 |
| `tests/verify-v14-p4.mjs` | 37 项人格漂移、睡眠窗口、梦境归档、投递分级（ima 并入） |
| `tests/verify-v14-p5.mjs` | 54 项 v14 能力全量集成（ima 并入） |
| `docs/逐段对照-融合说明书.md` | 指南条款 × 三份源文原文 × 本包落点，逐段对照 |

---

## 四、运行与验证

```bash
node tests/verify.mjs           # 75 PASS
node tests/verify12.mjs         # 82 PASS
node tests/verify13.mjs         # 29 PASS
node tests/verify-chassis.mjs   # 55 PASS（v11.1 底盘保留）
node tests/verify-upgrade.mjs   # 45 PASS（造 v11.1 真库 → 升级 → 逐行校验）
node scripts/doctor.mjs         # 47 项硬检查
node sea/sea-server.mjs         # 识海面板，只读，8765
```

v13 基础断言为 **286 项**。v14 全量包含 P0–P5、ima 并入专项和交叉验证专项，最终为：

- `npm test`：**16 套件 663 / 663 通过**（572 + ima 的 p4 37 条 + p5 54 条）；
- 模块图：**52 模块 / 127 依赖边 / 0 循环 / 0 孤儿 / 0 缺失导入**；
- 隐私扫描：PASS；
- 中文评测：6 例全 Recall=1.0、MRR=1.0、leakage=0；
- 沙盒：**47 场景 / 315 断言 / 0 失败 / 0 错误**（116s）；
- **真库副本实测**（13.3MB，340 记忆 / 1074 事件 / 735 提案）：ensureSchema 678ms，
  6 张表全部宽松化且行数一行不少、写入全部从 FAIL 转 OK、722 条过期提案清零、
  二次启动 `upgraded=false` 不备份；链路测试 22/22、安装自检 27/27、插件装配 16/16。

---

## 五、代码阅读顺序（给要接手的人）

1. `kit/config.mjs` → 所有参数在这里，先知道有哪些旋钮
2. `kit/` 的 `ids/scope/time/units` → 四个适配层，决定旧库怎么被读
3. `memory/text.mjs` + `memory/weight.mjs` → 评分的地基（纯函数，无副作用）
4. `memory/engine.mjs` → 一条记忆怎么被写进来（15 步）
5. `memory/search.mjs` → 一条记忆怎么被想起来（4 段召回）
6. `reflex/activation.mjs` + `life/life-state.mjs` → 她的状态怎么动
7. `session/lifecycle.mjs` + `prompt/composer.mjs` → 上下文怎么拼、怎么清
8. `outlet/cleaner.mjs` → 最后一道门
9. `index.mjs` → 以上全部怎么串起来

前 5 步都是纯函数，可以脱离 DSH 单独跑测试；第 9 步才依赖宿主。
