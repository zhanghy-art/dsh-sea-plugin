# ArcDream Hub 交叉验证

> 目标仓库：`499596849-jpg/arcdream-hub`  
> 插件仓库：`499596849-jpg/dsh-arc-hub`  
> 最新公开 Release：`v0.1.2`（2026-10-31）  
> 审计日期：2026-11-04  
> 结论：可以借架构件，不可直接并入 v14 核心；当前 HTTP 安全边界不合格。

---

## 1. 它实际是什么

ArcDream Hub 是一个与本机 sidecar、文件索引、聊天 UI、H5 和 DSH Host/Client 插件组成的数字中枢。

公开 Release `v0.1.2` 实际能力：

- `127.0.0.1:8799` 本地 HTTP 服务；
- 工作区文件索引，SQLite `files(path,name,dir,ext,size,mtime,root,project)`；
- 索引只搜文件名/路径，不搜正文；
- `/api/chat` 调用户配置的 OpenAI 兼容模型；
- Windows DPAPI 保护模型 Key；
- 人设卡可明文或 AES-256-GCM + DPAPI 密钥；
- DSH 插件提供状态、人设摘要、模式、打开目录；
- 常驻锚点卡 `order=860`；
- 客户端设置页和右下角中枢圆。

---

## 2. 值得借鉴

### 2.1 sidecar 边界清楚

数字中枢、索引、UI 和 DSH 插件分开：

```text
DSH plugin -> localhost sidecar -> local data/index
```

v14 可以保留这个原则：外部文件索引/浏览器/生图/模型不是核心依赖，而是可选 Provider。

### 2.2 真实文件索引

它不是把目录伪装成“搜索”，而是真的扫描工作区并落 SQLite 索引。

v14 可借的是：

- 只读索引；
- 文件名、路径、项目、mtime 作为结构化数据；
- 显式工作区 allowlist；
- 索引重建有状态。

v14 不借它当前的路径校验实现。

### 2.3 人设摘要暴露

DSH Host 工具只返回人设摘要，不返回完整人设卡。这个方向正确。

v14 后续若接入 persona card，应区分：

- L1 完整人格只进受控 system prompt；
- 工具只返回摘要；
- HTTP/外部 API 永不默认返回全文。

### 2.4 Key 不通过 GET 回显

模型设置接口只返回 `hasKey`，不回显 secret。这是正确的机密处理方向。

### 2.5 运行模式

`single` 与 `multimodal` 将陪伴形态和桌面中枢形态分开，值得借鉴为可选 host profile，而不是改记忆真值。

---

## 3. 实测安全缺陷

以下问题不是文档推测，是在隔离数据目录中启动 `v0.1.2 server.mjs` 后实测。

### S1 全接口 CORS 通配

`server.mjs` 对所有响应设置：

```http
Access-Control-Allow-Origin: *
```

任意网页都能跨域读取：

- `/api/config`
- `/api/status`
- `/api/persona`
- `/api/search`
- `/api/file`

### S2 工作区路径前缀绕过

`readIndexedFile()` 只做：

```js
abs.toLowerCase().startsWith(path.resolve(root).toLowerCase())
```

实测 allowlist 为 `...\ws` 时，读取 `...\ws2\outside.txt` 返回：

```json
{"ok":true,"text":"outside-workspace-secret"}
```

原因是 `ws2` 以 `ws` 开头。必须按路径分隔符或 `path.relative()` 校验，并处理 symlink/realpath。

### S3 任意路径打开

`/api/open` 与 `/api/reveal` 只要求路径存在，没有限制在已登记工作区内。

结合 CORS `*`，任意网页可以让本机弹出任意已存在路径。

### S4 人设全文可跨域读取

`/api/persona` 在存在明文人设卡时直接返回全文。实测响应带：

```http
Access-Control-Allow-Origin: *
```

这与插件文档声称“完整人设只在内存、工具只给摘要”不一致，因为 HTTP 端仍可读全文。

### S5 模型配置和额度可被跨域操纵

`/api/model` 可跨域修改 Base URL，`/api/chat` 可跨域发起模型请求。

恶意网页可以：

1. 将 Base URL 改成攻击者控制的 OpenAI 兼容端点；
2. 保持原 Key 不变；
3. 调用 `/api/chat`；
4. 服务将原 Key 放进 Authorization 发往攻击者 Base URL。

DPAPI 只保护静态存储，防不了这个问题。

### S6 声明工具与源码不一致

README 声明存在 `arc_hub_search`，但 Host `index.js` 只注册：

- `arc_hub_status`
- `arc_hub_persona`
- `arc_hub_mode`
- `arc_hub_open_dir`

源码中没有 `arc_hub_search`。

### S7 8795 helper 不在公开仓库

插件调用：

```text
http://127.0.0.1:8795/open
http://127.0.0.1:8795/hub/start
```

但主服务监听 8799，公开仓库没有 8795 helper 代码。`arc_hub_open_dir` 与中枢圆“启动服务”在纯仓库安装下可能不可用。

### S8 数据路径约定不一致

- server 默认数据目录：`~/ArcDreamHub`；
- plugin 默认根：`%LOCALAPPDATA%/ArcDreamHub`；
- plugin 读 `data/config.json` 与 `data/persona/...`；
- server 写 `config.json` 与 `persona/...`。

默认安装下 Host 工具很可能找不到 server 写入的配置和人设。

### S9 索引只到名字级

Release notes 已诚实标注：不搜正文，FTS5 在 Roadmap。

因此它不能替代 v14 的 `memories`/FTS/BM25/向量检索。

---

## 4. 采用决定

| 项目 | 决定 |
|---|---|
| sidecar 作为可选 Provider | 采纳原则 |
| 文件索引作为外部只读源 | 采纳原则，需重做安全边界 |
| 人设摘要工具 | 采纳原则 |
| DPAPI + AES 静态保护 | 仅借设计，不在 v14 核心强依赖 Windows |
| single/multimodal 模式 | 可作 host profile |
| 当前 HTTP 服务直接接入 | 不采纳 |
| 全开放 CORS | 禁止 |
| 任意路径 `/open` | 禁止 |
| HTTP 返回完整人设 | 禁止 |
| 未鉴权改模型配置/发模型请求 | 禁止 |
| 整个 UI/星图/启动圆 | 不进 v14 核心 |

---

## 5. 未来安全接口契约

若 v14 后续接 ArcDream Hub，必须先满足：

1. 只监听 `127.0.0.1`；
2. 随机 bearer token；
3. 严格 Origin allowlist，不用 `*`；
4. 工作区 `realpath` + `path.relative` 校验；
5. 所有读文件、打开目录都只在 allowlist；
6. persona API 只出摘要；
7. 修改模型配置要求二次确认/管理端权限；
8. 模型 Base URL 变更时清除旧 Key，禁止带旧 Key 发往新域名；
9. 8795 helper 代码进入仓库、版本化和健康检查；
10. Host 和 server 使用同一数据根与路径约定。

---

## 6. 本轮对 v14 的实际改动

ArcDream Hub 与 IMA 对“长期可回放”的要求共同促成了以下改动：

- `life_events` 增加 `(event_type, created_at DESC)` 索引；
- 普通运行事件仍 90 天 / 20,000 条；
- `appraisal/dream/imprint/conflict/negative-alert` 单独保留 730 天 / 100,000 条；
- appraisal 日志记录实际生效结果 `applied`；
- `life_status` 可列出最近梦和评价；
- 不新增 `dreams/appraisal_events` 表，也不改 `memories` 列。

这样保留 IMA R1 的“可回放”目标，同时维持当前零新表/零新列的回滚边界。
