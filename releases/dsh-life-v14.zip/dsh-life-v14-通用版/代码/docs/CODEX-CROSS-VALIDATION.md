# Codex 三方交叉验证记录（第三轮）

> 日期：2026-11-05  
> 基座：dsh-life v13  
> 对照：IMA merged、WorkBuddy v14、ArcDream Hub v0.1.2  
> 本候选：`14.1.0`，能力版本 `14.1`，数据库结构版本 `13`

---

## 0. 先给结论

### 0.1 采用结果

当前候选以 v13 为唯一底座，保留原有写入管线、scope、四级保护、治理、出口清洗和迁移路径。

本轮实际验证后采用：

1. IMA 的 72 小时追赶上限、180 天盖章保留期、三态 `off/shadow/on`、打包期隐私扫描；
2. WorkBuddy 的旧库 `invalid_reason` 白名单修复、真实 FTS5 候选、长句门槛前 BM25、真实 elapsed；
3. Codex 原有的睡眠队列、结构化评价、长期审计保留、生活簿、分层召回和 5 万行性能修复；
4. ArcDream Hub 的 sidecar、只读索引、摘要式人设、静态加密方向；
5. 本轮新发现并修复的 scope 越权、梦素材串会话、旧库回退丢原因。

不采用：

1. 直接把 ArcDream Hub 的 HTTP 服务、全屏 UI、任意路径打开和全文 persona API 并入核心；
2. 把 RRF 直接替换 v13 主公式；
3. 在没有正式迁移资产时直接加入大量事实列；
4. 让模型直接改写激素真值、人格正文或不可逆印记；
5. 用插件内部代码假装完成真实 QQ/微信投递。

### 0.2 可复现数字

| 候选 | 单测 | 沙盒 | 模块图 | 结论 |
|---|---:|---:|---:|---|
| IMA merged 14.1 | 559 / 559 | 47 场景 / 315 断言 / 0 失败 | 46 / 112 / 0 循环 / 0 孤儿 | 可运行 |
| WorkBuddy 最新版 | 523 / 523 | 47 场景 / 315 断言 / 0 失败 | 39 / 96 / 0 循环 / 0 孤儿 | 可运行 |
| Codex 本轮候选 | 571 / 571 | 47 场景 / 315 断言 / 0 失败 | 49 / 120 / 0 循环 / 0 孤儿 | 本轮推荐融合参考 |

补充门禁：

- IMA 隐私扫描：PASS；
- Codex 隐私扫描：PASS；
- WorkBuddy 最新文档所述修复均已从文档重建后实跑，不再按“自述数字”计分；
- 三方均坚持零第三方运行依赖，Node 22.5+ 的 `node:sqlite` 是共同运行前提。

---

## 1. 哪些需要，哪些不需要

### 1.1 必须进入融合基线

| 能力 | 原因 | 当前落点 |
|---|---|---|
| v13 的 15 步写入管线 | 记忆质量、证据、去重、候选、scope 的底盘 | `src/memory/engine.mjs` |
| 真实经过时间 | 固定 15 分钟会丢掉合盖、关机、周末离线 | `src/life/clock.mjs` |
| 单一 energy 写入口 | v13 回血、阶段回血、相位收敛会同 tick 对冲 | `src/life/sleep-stage.mjs` |
| 夜间不物理删除盖章行 | 翻案、审计、可解释性都依赖历史 | `src/maintenance/nightly.mjs` |
| FTS5 + BM25 + LIKE 并集 | 中文长问句不能被 dice 先在门槛处筛掉 | `src/memory/bm25.mjs`、`search.mjs` |
| 候选审核与五档来源 | 低置信内容和推断内容不能直写事实库 | `governance.mjs`、`candidates.mjs` |
| 睡眠阶段、梦、睡眠债 | 用户要求的是完整生活感，不只是回血数值 | `sleep-stage.mjs` |
| 睡眠投递队列契约 | 睡着时不能伪造“已经发出” | `delivery.mjs` |
| 结构化事件评价 | 情绪变化必须可归因，PAD 只能是派生状态 | `appraisal.mjs` |
| 证据原话与消息 id | 记忆必须能回到来源，不接受无证据自造 | `engine.mjs`、`evidence.mjs` |
| scope 前置隔离 | 群聊、私聊、shared 不可串读或串改 | `scope.mjs` 与各工具入口 |
| 旧库原地迁移与回滚 | v13 真实用户已有数据，不能要求重建库 | `kit/db.mjs`、`scripts/migrate.mjs` |
| 隐私扫描 | 打包前必须拦住真实路径、密钥和长 token | `scripts/privacy-scan.mjs` |

### 1.2 可以作为可选增强

| 能力 | 处理 |
|---|---|
| rerank 外部模型 | 默认 off 或 on 的低风险纯函数版；外挂模型走 500ms 超时和无损回落 |
| autoExtract | 默认 off；需要时先用 `shadow` 观察 |
| beliefPool | 默认关；冲突只隔离，不自动删记忆 |
| imprint | 默认关；调度层硬闸，模型无权直接写 |
| RRF | 保持可选，不替换 v13 主公式 |
| GPU / ONNX / cross-encoder | 只做宿主回调，不影响无 GPU 环境 |
| ArcDream 文件索引 | 作为外部只读 provider，不进入核心记忆库 |
| single / multimodal profile | 作为宿主形态配置，不改变记忆真值 |

### 1.3 本轮明确不做

| 内容 | 原因 |
|---|---|
| 全屏星图、街景、NPC、常驻桌面圆 | 用户已明确“识海可以不管”，且会扩大宿主面 |
| 未鉴权 localhost HTTP 服务 | 当前 ArcDream Hub 有 CORS、路径和模型 Key 安全问题 |
| 把完整 persona 通过工具或 HTTP 返回 | 人设全文只应进入受控 system prompt |
| 让模型直接写 `cortisol=0.63` 一类真值 | 数值必须由统一写入口限幅 |
| 把梦境写回事实记忆 | 梦是体验和素材，不是证据事实 |
| 在插件内假装完成真实 IM 发送 | 发送成功必须由宿主回执，插件只维护 queued/sent/deferred |

---

## 2. IMA merged 验证

### 2.1 实际结果

从独立目录复跑，不依赖 IMA 作者的机器：

- `npm test`：559 / 559 通过；
- 模块：46 / 112 / 0 循环 / 0 孤儿；
- 隐私扫描：PASS；
- 沙盒：47 场景 / 315 断言 / 315 PASS / 0 FAIL；
- 沙盒耗时：约 192.3 秒；
- 当前文件：106 个、完整 `src/tests/sandbox`，包版本 `14.1.0`；
- 实际新增表：0；
- 实际新增事实列：0；
- `SCHEMA_VERSION=13`，`VERSION=14.0`。

IMA 新版文档里的自述未复跑问题，本轮已经由独立环境完整复现为 559 条，不把“作者未复跑”继续当作当前缺陷。

### 2.2 采纳点

1. `off / shadow / on` 三态；
2. savepoint 里跑真实路径再回滚；
3. 72 小时追赶上限；
4. 盖章主行保留 180 天，归档副本继续保留；
5. 打包期隐私扫描；
6. 审计事件和普通运行事件分开保留。

### 2.3 修正点

1. IMA 的夜间任务仍会把所有 `life_events` 按 90 天 / 2 万条清理，连 `shadow:*` 和长期审计类型也不区分；
2. IMA 的 P4 主要是纯函数和配置断言，缺少足够的真实数据库 shadow 回滚和插件端到端测试；
3. IMA 基于较早的 Codex 515 版，没有本轮新增的 appraisal `applied`、审计保留、旧库回退和 scope 工具校验。

Codex 候选保留 IMA 的三态语义，但补上审计类型保留和真实 DB/plugin 测试。

WorkBuddy 在 00:22 的三版报告审查的是更早的 43 文件 IMA delta；本轮 00:41 的 IMA 文件是 106 文件完整包，SHA256 前 32 位为 `823930A4262E438CD9C87BC067FAB7F0`。因此“IMA 无 src、无法跑”必须作为历史结论标注。

---

## 3. WorkBuddy 验证

### 3.1 实际重建结果

从最新单文件交付重建到独立目录，并使用临时 HOME：

- `npm test`：523 / 523 通过；
- 分项：原底盘 286 + 通用版 19 + P0–P3 177 + P4 41 = 523；
- 模块：39 / 96 / 0 循环 / 0 孤儿；
- 沙盒：47 场景 / 315 断言 / 315 PASS / 0 FAIL / 0 ERR；
- 沙盒耗时：约 150.5 秒；
- 5 万行检索和写入门禁通过。

这不是只读文档推测，而是把文档中的 18 个完整文件和 11 个差异补丁重新落盘后的实跑结果。

### 3.2 已吸收

1. 旧库 `invalid_reason` CHECK 白名单：`retract()` 改用 `manual`，具体原因写 `anchor_ground.retractNote`；
2. FTS5 真实候选，不再只是读一个 flag；
3. 长问句让 BM25 在 `passesGate()` 前参与字面分；
4. 真实 elapsed 和 `lastTickAt`；
5. 单 energy 写入口和 `Object.assign` 修复；
6. Windows `os.homedir()`；
7. 5 万行写入门禁。

### 3.3 不整包替换的原因

1. WorkBuddy 仍没有本候选的四项三态 shadow；
2. 审计事件没有独立长期保留；
3. 追赶上限是 12 小时，Codex/IMA 采用 72 小时；
4. 盖章行没有 180 天分阶段剪枝和归档契约；
5. 模块数与工具面小于当前候选；
6. 本轮额外发现并修复了 WorkBuddy 旧库回退路径同样会丢 `retractNote` 的问题；
7. WorkBuddy 报告没有包含本轮新增的提示词包、中文评测和 DSH 适配报告。

---

## 3.5 三个指定 GitHub 参考库

### 3.5.1 `wumingzhiren-lab/dsh-identity-relay`

参考版本：公开仓与讨论页的 v0.3 系列。

采纳：

- 来源信任分级；
- 证据与断言分离；
- 冲突只隔离，不删除正文；
- 作废、替代、有效期和翻案记录；
- 人格卡全文只进受控 prompt；
- 凭据与注入内容的写入闸门。

不采纳：

- 用独立 `facts.jsonl` 替代或并行于 v13 的 `memories`；
- 让模型通过工具直接改人格正文；
- 把讨论页里未落到源码的说法当作已验证能力。

### 3.5.2 `xsy822/dsh-emotion-memory`

参考版本：0.1.x 公开仓。

采纳：

- PAD 作为派生三维场，不作为第二套独立真值；
- 事件评价变量先于情绪标签；
- 情感指纹附在记忆条目上；
- 想起时以 0.15 系数做再巩固；
- 心境一致度只在 rerank 中占小权重。

不采纳：

- 另起一套 PAD/四激素状态与 v13 LifeState 并行演化；
- 把 14 通道全部立即做成硬依赖；
- 用 RRF 直接替换 v13 检索主公式。

### 3.5.3 `499596849-jpg/arcdream-hub`

结论见第 5 节：只借 sidecar、只读索引、摘要式人设和静态加密方向，不接当前不安全的 HTTP/UI。

---

## 4. 死链 D1–D14 对照

| 死链 | 当前状态 | 证据或剩余边界 |
|---|---|---|
| D1 四激素 delta 恒空 | 已修 | 目标值、basis、限幅、数据驱动/回退测试 |
| D2 social 时间戳不写 | 已修 | user/bot 轮次写时间 |
| D3 edges 只有表没有写方 | 已修 | 四类真实来源、幂等；`basis` 仍是运行时自愈列 |
| D4 vec 从不产出 | 已修 | hash384 本地向量 + 可选宿主 embed |
| D5 无真实 BM25/FTS | 已修 | FTS5 候选 + BM25 + LIKE 并集 |
| D6 睡眠只是数值回血 | 核心已修 | 阶段、债、梦、醒转；真实发送仍归宿主 |
| D7 gaps/REM 未接线 | 部分修 | 梦、decay、life_gap、epiphany 工具已接；自动顿悟触发仍可增强 |
| D8 候选无审核入口 | 已修 | accept/reject/defer/conflict resolve |
| D9 evidence 未调用 | 部分修 | 写入 quote/message id，夜间 promoteTier；完整批量审计仍可选 |
| D10 死 flag | 部分修 | 关键 flag 均有读取点；presets 自动加载未做 |
| D11 主动闭环 | 部分修 | 硬闸、utility、持久队列、ack 有；意图生成和真实发送归宿主 |
| D12 空壳表 | 部分修 | promises/milestones/narratives/relationships 已接生活簿 |
| D13 v11 状态不接管 | 已修 | `adoptLegacyState` 启动时幂等接管 |
| D14 generic 漏测 | 已修 | `npm test` 包含通用宿主测试 |

“部分修”是明确边界，不是把宿主职责伪装成插件已完成。

---

## 5. ArcDream Hub 审计

正确公开仓库：

- `499596849-jpg/arcdream-hub`
- `499596849-jpg/dsh-arc-hub`
- 最新公开 Release：`v0.1.2`

用户给出的 `arcdream-hubreleases/atest` 路径返回 404，实际应查看 `arcdream-hub/releases/latest`。

### 5.1 可借鉴

1. sidecar 与 DSH 插件分离；
2. 真实工作区文件索引；
3. 工具只返回 persona 摘要；
4. DPAPI + AES-GCM 的静态保护方向；
5. `single / multimodal` 宿主形态；
6. 常驻锚点卡的内容组织。

### 5.2 实测安全问题

| 编号 | 问题 |
|---|---|
| S1 | 所有 API 返回 `Access-Control-Allow-Origin: *` |
| S2 | 工作区前缀校验可被 `ws` → `ws2` 绕过 |
| S3 | `/api/open` 与 `/api/reveal` 接受任意存在路径 |
| S4 | `/api/persona` 可跨域读取完整明文 persona |
| S5 | `/api/model` 与 `/api/chat` 未鉴权，可被恶意页面改 Base URL 并带走旧 Key |
| S6 | README 声称 `arc_hub_search`，Host 源码未注册 |
| S7 | 插件调用 8795 helper，但公开仓库没有 helper 代码；server 使用 8799 |
| S8 | Host 与 server 默认数据根、persona 路径不一致 |
| S9 | 当前索引只到文件名/路径，不搜正文 |

### 5.3 接入结论

ArcDream Hub 只能作为可选外部 provider，且接入前必须满足：

1. 只监听 `127.0.0.1`；
2. 随机 bearer token；
3. Origin allowlist；
4. `realpath + path.relative` 校验；
5. 所有 open/reveal 受 allowlist 限制；
6. persona 只出摘要；
7. 模型配置修改需管理权限；
8. Base URL 变更时清除旧 Key；
9. helper 进仓库、版本化、健康检查；
10. Host/server 共用一个数据根。

当前不把它的 HTTP、UI、启动圆或任意路径能力并入 v14 核心。

---

## 6. 本轮新发现并修复的真实问题

### 6.1 旧库盖章兼容

问题：

- v11.1 的 `invalid_reason` CHECK 只允许 `conflict/superseded/expired/manual/audit`；
- 旧代码写 `retracted` 会直接失败；
- 即使改用 `manual`，旧库缺少 `valid_to_ms` 时第二级回退也可能丢失具体原因。

修复：

- 统一 `STAMP_REASON='manual'`；
- 具体原因写 `anchor_ground.retractNote`；
- 三级回退依次保留完整列、保留原因、最后兼容更老库。

证据：`AD1–AD3`。

### 6.2 工具 id 跨 scope

问题：

- `life_gap` 可列全库缺口；
- `life_memory_review` 可列全库候选和冲突；
- `life_forget` 可按 id 操作其他 scope 记忆；
- resolve conflict 也没有 scope 校验。

修复：

- 缺口列表、候选列表、冲突列表按当前 scope 过滤；
- close/epiphany/review/resolve/forget 先查记录 scope；
- 不匹配统一返回 `scope-denied`。

证据：`AF1–AF4`。

### 6.3 梦素材串会话

问题：

- `remFromGaps()` 全库取最高张力缺口；
- 高情绪记忆和注入日志也没有 scope 约束；
- 私聊 A 的内容可能进入私聊 B 或群聊的梦。

修复：

- 梦生成只吃当前可见 scope；
- 缺口上限淘汰只在本 scope 内执行；
- 梦事件写入 scope；
- `life_status` 的历史梦和一致性抽样按当前 scope 过滤。

证据：`AE1–AE3`。

### 6.4 5 万行写入退化

处理：

- 把 tier 配额全表扫描从每次写入移到夜间维护；
- 增加 `(scope, created_at_ms)` 与 `(scope, cold, invalid_reason)` 复合索引；
- 保留原有写入管线，不通过跳过治理来换性能；
- 沙盒的 1 万 / 3 万 / 5 万行检索与写入门禁通过。

### 6.5 隐私扫描

扫描：

- `C:\Users\...` 一类真实路径；
- `/home/<user>/...`；
- `sk-`、`api_key=`、`password:`、PEM；
- 长 token。

测试中的假凭据使用显式夹具白名单，不通过放宽规则绕过。

---

## 7. 数据与迁移裁决

### 7.1 当前候选

- 新增事实表：0；
- 新增事实列：0；
- 新增可重复执行索引：2；
- `SCHEMA_VERSION=13`；
- `VERSION=14.0`；
- 睡眠、梦、评价、审计使用 `state_json` 和 `life_events`；
- `edges.basis` 是运行时幂等自愈列，融合时必须决定是否转正式迁移。

### 7.2 给 DSH 的裁决

如果 DSH 融合时新增任何正式表或列，必须同时：

1. 修改 `schema.sql`；
2. 修改 `migrations/tables.sql`；
3. 修改 `migrations/columns.json`；
4. 升 `SCHEMA_VERSION`；
5. 加旧库升级、重复执行、失败恢复测试。

没有完成以上五步，不得维持 `SCHEMA_VERSION=13` 同时又声称 schema 变了。

---

## 8. 睡眠与投递边界

当前实现：

- 默认 72 小时追赶上限；
- 30 分钟一段推进；
- 白天空闲不算睡眠；
- 睡眠债醒着累积、睡着下降；
- 深睡被叫醒升皮质醇并降低本次恢复；
- 梦只在 REM 且有 20 小时冷却；
- 普通回复可返回 `delivery='deferred'`；
- 宿主通过 `life_delivery_poll` 取队列，成功发送后用 `life_delivery_ack` 删除。

真实发送仍归宿主。插件不伪造 `sent`，不直接调用 QQ/微信协议。

---

## 9. 检索结论

融合基线采用：

```text
v13 主公式不变
+ FTS5 长词候选
+ BM25 门槛前字面分
+ LIKE 兜底
+ 可选 rerank
+ 一跳 edges 扩展
```

不采用：

- BM25 替换 LIKE；
- 直接把 RRF 写成唯一主链；
- 跨 scope 边扩展；
- 外部 rerank 失败时丢结果。

---

## 10. 最终融合建议

建议顺序：

1. 以当前 Codex 候选作为代码对照，不是让其他两份整包覆盖；
2. 先冻结 schema 和迁移资产；
3. 合入旧库盖章、72 小时、180 天、审计保留、scope 工具校验；
4. 合入 WorkBuddy 的 FTS 与性能门禁测试；
5. 对四项高风险能力先设 `shadow`，观察 `shadow:*` 事件；
6. 睡眠投递只接宿主契约，不把真实 IM 发送塞进核心；
7. ArcDream Hub 保持 sidecar 安全改造后再接；
8. 保留提示词包加载和 12 例中文 Recall@K / MRR 门禁，再用真实脱敏样本扩容；
9. `edges.basis` 默认保持 dry-run，DSH 明确升 schema 后才执行 `--apply`。

当前候选不是“只有方案”，而是包含源码、迁移、配置、测试、沙盒场景和实跑结果的完整可重建交付。
