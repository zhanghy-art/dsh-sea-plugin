# DSH-Life v14.1 适配融合报告

> 日期：2026-11-05  
> 候选：`dsh-life 14.1.0`  
> 能力版本：`14.1`  
> 数据库结构版本：默认 `13`  
> 用途：交给 DSH 做最终裁决、适配和融合

---

## 1. 结论

### 1.1 推荐基线

推荐以本包为全量代码基线。理由不是“断言数最多”，而是：

1. 当前交付目录含完整 `src/`、`tests/`、`sandbox/`、`prompts/`、`eval/` 和文档；
2. v13 原有写入、scope、保护层级、迁移和出口清洗未被换底盘；
3. 同时吸收了 IMA 14.1 的 72h、180 天、三态、审计保留与 WorkBuddy 的真实 FTS、旧库 CHECK 修复；
4. 额外修复了旧库回退、工具跨 scope、梦素材串会话和 FTS 分数未过门槛；
5. 提示词、中文检索评测和可选 schema 迁移都已成为可运行文件。

### 1.2 重要版本订正

WorkBuddy 的《三版交叉验证报告》在 2026-11-05 00:22 完成，当时看到的 IMA 文件是 43 文件的 delta。

本轮桌面上的 IMA 文件时间为 00:41，SHA256：

```text
823930A4262E438CD9C87BC067FAB7F0
63D00569D63EF9E6AF27DB571EA650F3
```

当前文件实际包含 106 个文件和完整 `src/`，因此：

- “IMA 缺 src、无法独立跑”对当前文件不再成立；
- 本轮完整复跑 IMA 后，559 项单测、47/315 沙盒、隐私扫描均通过；
- WorkBuddy 的结论应作为“对旧靶子的历史记录”，不能直接用于裁决当前 IMA。

同样，WorkBuddy 审查的 Codex 单文件是旧版 25045 行；当前终稿已重新组装、在独立目录跑过单测和沙盒，不再只是代码内嵌文档。

---

## 2. 三方最终实测

| 候选 | 包版本 | 单测 | 沙盒 | 模块 | 可独立运行 |
|---|---:|---:|---:|---:|---|
| IMA 新版 | 14.1.0 | 559 / 559 | 47 / 315 / 0 失败 | 46 / 112 | 是 |
| WorkBuddy | 14.0 系列 | 523 / 523 | 47 / 315 / 0 失败 | 39 / 96 | 是 |
| Codex 本包 | 14.1.0 | 571 / 571 | 47 / 315 / 0 失败 | 49 / 120 | 是 |

三方共同点：

- v13 为底座；
- 0 新增事实表；
- 0 新增 `memories` 事实列；
- `SCHEMA_VERSION=13`；
- `edges.basis` 仍存在“运行时自愈还是正式迁移”的裁决；
- 零第三方运行依赖；
- 单测不能替代真实 IM 桥接，发送必须由宿主回执。

---

## 3. 本包新增的完整交付件

### 3.1 提示词包

| 文件 | 用途 | 注入时机 |
|---|---|---|
| `prompts/system-core.zh.md` | 身份、事实、scope、安全和表达边界 | 常驻 system |
| `prompts/tool-policy.zh.md` | 工具选择、失败降级、禁止伪造发送 | 常驻 system |
| `prompts/memory-write.zh.md` | 直接写入、候选、禁止写入的判定 | 常驻 system |
| `prompts/nightly-audit.zh.md` | 离线候选审计的 JSON 协议 | 夜间任务 |
| `prompts/handoff.zh.md` | 三行会话交接格式 | 交接任务 |
| `prompts/manifest.json` | 顺序、scope、字符上限 | 加载时 |
| `src/prompt/pack.mjs` | 路径校验、大小校验、合并加载 | 启动/任务 |

插件启动时只注入前三段到 `dsh-life.policy`，总字符约 1700，不占 900/700 记忆预算。夜间审计和 handoff 不常驻。

### 3.2 中文检索评测

| 文件 | 用途 |
|---|---|
| `eval/zh-retrieval.json` | 12 个中文场景，含长问句、生日、偏好、约定、情感、group 和私聊隔离 |
| `src/eval/retrieval-eval.mjs` | 真实 SQLite + FTS/BM25 的 Recall@K / MRR / leakage |
| `scripts/eval-retrieval.mjs` | CLI，支持 `--json`、`--dataset=` |
| `tests/verify-prompt-eval.mjs` | 提示词与中文评测的自动门禁 |

当前固定集结果：

- Recall@5：1.0；
- MRR：1.0；
- forbiddenLeaks：0。

这是小型回归集，不是长期质量上限。DSH 后续应扩充真实脱敏样本，但不应删掉现有门禁。

### 3.3 可选 schema 迁移

| 文件 | 作用 |
|---|---|
| `src/kit/optional-migrations.mjs` | 检查 `edges.basis`，dry-run 默认不改库 |
| `scripts/migrate-edges-basis.mjs` | `--db` 只检查，`--apply` 才执行 |
| `tests/verify-final-gates.mjs` | 验证 dry-run、apply、幂等和版本声明 |

默认操作：

```bash
node scripts/migrate-edges-basis.mjs --db <mind.db>
```

只有 DSH 明确决定把 `edges.basis` 写入正式 schema 后，才执行：

```bash
node scripts/migrate-edges-basis.mjs --db <mind.db> --apply
```

一旦执行，DSH 必须同步更新：

1. `schema.sql`；
2. `migrations/tables.sql`；
3. `migrations/columns.json`；
4. `SCHEMA_VERSION`；
5. 备份与回滚验收。

---

## 4. DSH 适配接口

### 4.1 Host 最小接口

| 能力 | 调用 |
|---|---|
| 数据库位置 | `dbPath` 或 `DSH_LIFE_DB` |
| 启动 | `ctx.lifecycle.onReady(fn)` |
| 用户输入 | `ctx.lifecycle.onPreStep(ev)` |
| 回复完成 | `ctx.lifecycle.onTurnStopping(ev)` |
| 定时器 | `ctx.timer.every(15min, fn)` 或宿主自己的调度器 |
| 人格段 | `ctx.systemPrompt.persona()` |
| 策略段 | `ctx.systemPrompt.section('dsh-life.policy', text)` |
| 向量 | `ctx.embed(text)`，无则本地 hash384 |
| 工具 | `ctx.tools.register(tool)` |

### 4.2 工具契约

| 工具 | 必要参数 | 返回边界 |
|---|---|---|
| `life_recall` | `query` 或 `memory_id` | 卡片/详情受 scope 限制 |
| `life_remember` | `fact` | 低置信进候选，不直写 |
| `life_forget` | `memory_id` + `reason` | 盖章不删，绑定当前 scope |
| `life_memory_review` | action/decision | 候选与冲突绑定当前 scope |
| `life_gap` | action | 缺口绑定当前 scope |
| `life_lifebook` | action | 生活簿绑定当前 scope |
| `life_sleep` | mode | auto/sleep/awake |
| `life_delivery_poll` | limit | 只出当前持久队列 |
| `life_delivery_ack` | ids | 只在宿主发送成功后调用 |
| `life_status` | 无 | 只给受控摘要，不给内部路径 |

### 4.3 睡眠投递

插件负责：

- 维护 `state.sleep.pendingDeliveries`；
- 睡眠时返回 `delivery='deferred'`；
- 提供 poll / ack；
- 保证重复 poll 不丢项。

宿主负责：

- 真正发送；
- 返回成功回执；
- 对超时、断网和平台限流重试；
- 不把 queued 当成 sent。

### 4.4 主动行为

插件已有 utility、硬闸、持久提案和发送确认。宿主仍需提供：

- 何时允许主动开口；
- 真正发送通道；
- 用户回复后关闭追话；
- 平台级频率限制。

---

## 5. 数据与迁移

### 5.1 默认结构

- `memories` 仍是唯一长期事实源；
- 睡眠、梦、评价和标记继续走 `state_json` / `life_events`；
- 新增 `idx_mem_scope_recent`、`idx_mem_visible_recent`；
- 普通事件 90 天 / 20k；
- 审计事件 730 天 / 100k；
- 盖章主行默认保留 180 天，归档副本先写再考虑删主行。

### 5.2 回滚

```yaml
capabilities:
  v14: false
  prompts: false
```

关闭总闸后：

- 不执行 v14 状态推进；
- 不写睡眠/梦/评价审计；
- 不补向量；
- 不注入提示词包；
- 原有 v13 检索和回复仍可用。

数据库层默认 0 新表、0 新事实列，回滚不需要反向迁移。

---

## 6. 文件级融合顺序

1. `src/kit/config.mjs`：14.1 能力开关、72h、180 天、prompts；
2. `src/index.mjs`：启动、工具、睡眠、评价、scope、提示词注入；
3. `src/life/*`：真实时间、阶段机、梦、情绪、投递；
4. `src/memory/*`：FTS/BM25、rerank、治理、证据、生活簿、scope；
5. `src/maintenance/nightly.mjs`：盖章保留、审计保留；
6. `src/prompt/pack.mjs` + `prompts/*`：提示词；
7. `src/eval/*` + `eval/*`：中文评测；
8. `src/kit/optional-migrations.mjs`：由 DSH 决定是否启用；
9. `schema.sql` / `migrations/*`：只在正式 schema 裁决后改；
10. `tests/*`：任何融合都必须保留旧库、scope、总闸、FTS、审计和提示词门禁。

---

## 7. 最终验收

```bash
npm test
npm run modules
npm run privacy:scan
npm run eval:zh
node sandbox/run.mjs
node scripts/migrate-edges-basis.mjs --db <mind.db>
```

必须同时满足：

- 单测全绿；
- 模块 0 循环、0 孤儿、0 缺失导入；
- 隐私扫描 PASS；
- 中文评测达到阈值且跨 scope 泄漏为 0；
- 沙盒 47/315 全绿；
- 旧库 dry-run 不改结构；
- 真实 IM 只用宿主回执确认发送。

---

## 8. 仍需 DSH 拍板

| # | 议题 | 本包建议 |
|---|---|---|
| D1 | `edges.basis` 是否正式进 schema | 若 DSH 愿意统一升 14，执行可选迁移；否则保持运行时自愈并保留告警 |
| D2 | 群聊是否允许 shared raw | 默认只给卡片，raw 仅 owner 私聊 |
| D3 | 睡眠中普通回复 | 建议 deferred；宿主可选择简短回复 |
| D4 | 主动意图生成 | 建议放宿主调度，插件只负责提案、硬闸和队列 |
| D5 | 中文评测扩充 | 保留 12 例门禁，再用真实脱敏数据扩展 |
| D6 | 提示词注入长度 | 当前三段约 1700 字，若宿主预算不足可按 manifest 精简，不删安全边界 |

以上是真正需要 DSH 裁决的产品/宿主问题，不是代码缺口。

---

## 9. 一句话交付

本包已经把“能运行的核心、完整提示词、中文评测、旧库兼容、可选迁移、宿主接口和验收门禁”放在同一份可重建交付中。DSH 拿到后需要做的是选择产品旋钮、接宿主发送和决定是否正式升 schema，而不是再从三份候选里手工拼代码。
