# 给 DSH 的实现说明（v13.0）

> 这份文件是《DSH 双层一生感架构 v13.0》的配套施工单。
> 文档讲为什么，这里讲写在哪、按什么顺序写、怎么验证。
> 逐段出处见 [`逐段对照-融合说明书.md`](逐段对照-融合说明书.md)；通用宿主接入见 [`通用版-移植指南.md`](通用版-移植指南.md)。

## 一、先读哪几节

| 要做什么 | 看代码 |
|---|---|
| 搞清楚参数 | `src/kit/config.mjs`（唯一来源，含 `VERSION`/`SCHEMA_VERSION`） |
| 旧库怎么被读 | `src/kit/{ids,scope,time,units}.mjs`（四个适配层，先读这四个） |
| 写记忆写入 | `src/memory/{text,weight,engine,candidates,evidence}.mjs` |
| 写记忆检索 | `src/memory/{search,region-router,embedding-cache,fsrs,gaps}.mjs` |
| 写反射 | `src/reflex/activation.mjs` |
| 写状态 | `src/life/{life-state,attention,sleep}.mjs` |
| 写上下文与归档 | `src/session/lifecycle.mjs`、`src/prompt/composer.mjs` |
| 写出口治理 | `src/outlet/cleaner.mjs` |
| 写治理与闸门 | `src/govern/constitution.mjs`、`src/action/speak.mjs` |
| 写长期维护 | `src/maintenance/nightly.mjs` |
| 串起来 | `src/index.mjs` |
| 换宿主 | `src/host/generic.mjs` |

## 二、施工顺序（不要跳）

1. **schema**：先跑 `schema.sql`（或直接 `ensureSchema`），确认 11 张表 + FTS 触发器都在、`memories.id` 是 INTEGER。
2. **四个适配层**：`ids.mjs` → `scope.mjs` → `time.mjs` → `units.mjs`。
   它们决定「旧库能不能被新代码读」，写错会在运行时以 datatype mismatch / 查不到行 / NaN 的形式爆炸。
3. **纯函数层**：`text.mjs` → `weight.mjs` → `region-router.mjs`。
   这三个文件不碰数据库、不发网络、不读系统时间（时间从入参传），写完立刻跑 `node tests/verify.mjs`。
4. **写入管线**：`engine.mjs` 15 步 + 读回三态；`candidates.mjs` 的 accept 必须回调 `writeMemory`，不能只改状态。
5. **检索**：`search.mjs` 四段召回，每段 SQL 都必须带 `scopeClause`（D2）。
6. **状态层**：`life-state.mjs`（四激素 0–1、六维惯性、快照双列）→ `attention.mjs` → `sleep.mjs`。
7. **出口**：`cleaner.mjs` 在发送前跑；`stripFrames` → `isEcho` → `cleanOutgoing` 顺序不能换。
8. **装配**：`index.mjs` 四个钩子；换宿主只换 `src/host/generic.mjs`。

## 三、验证（每步都要跑）

```bash
node tests/verify.mjs           # 75 项：基线纯函数与写入检索
node tests/verify12.mjs         # 82 项：四轴/准入/FSRS/缺口/倾斜/睡眠/主动/上下文
node tests/verify13.mjs         # 29 项：v13.0 收敛（幂等、单调、上限）
node tests/verify-chassis.mjs   # 55 项：v11.1 八项底盘 + 出口 E-1~E-4 + R/M 改动
node tests/verify-upgrade.mjs   # 45 项：造 v11.1 真库 → 直升级 → 逐行校验
node tests/verify-generic.mjs   # 19 项：无 DSH 环境下跑通一轮（通用版验收基线）
node scripts/doctor.mjs         # 47 项：环境/文件/库结构/治理/维护
```

## 四、失败模式清单（这套系统的坑都在这）

1. **悄悄不说话了**，而不是报错 → 每条新逻辑都要跑 chassis 断言。
2. **旧库首次 UPDATE 报 `database disk image is malformed`** → FTS 重建顺序错；必须「摘触发器 → rebuild → 回填 → 装回 → 再 rebuild」。
3. **查不到旧记忆** → scope 默认值写成了 `chat:private`；旧库是 `private:<qq>`。
4. **主键 datatype mismatch** → 写入用 TEXT id 插 INTEGER 主键表；统一走 `kit/ids.mjs`。
5. **激素/情绪全顶满** → 0–100 与 0–1 混用；统一走 `kit/units.mjs`。
6. **数值 NaN 后静默降级** → 旧时间列是 TEXT；统一走 `kit/time.mjs`。

## 五、从 11.1 升级时特别提醒

- 默认 `route=false`、`autoArchive=false`、`speak.hardGate=false`，升级后行为与 11.1 基本一致；这三项是「想用了再开」。
- 唯一默认生效的改动：注入冷却 6 小时（`memory.injectionCooldownHours`，设 0 可关）。
- 升级会自动备份（`mind.db.v13.bak.*`）、写 `legacy_rows` 快照、记 `upgrade_manifest`；
  指纹校验失败会**拒绝启动**而不是带着坏数据跑（`upgrade.rollbackOnMismatch`）。
- 回滚：停插件 → 备份覆盖回原路径 → 换回 11.1 代码。
