# dsh-life v14.1.1 通用版 · 完整报告与总结

> 交付日期：2026-11-05
> 基线包：codex 14.1.0（571 断言全绿）
> 产物：`dsh-life-v14.zip`（123 文件 / 420,076 字节 / UTF-8 文件名）
> 验证机：Windows / Node v24.22.1 / 零第三方依赖

---

## 〇、一句话结论

v14 不是"第四个人又写了一版"，而是**把 v13 的代码当底座、用本机真库当试金石**，从三份材料里挑出真正经得起检验的部分合进来。
代码量最大的一处改动，不是加功能，而是修一个**三份材料全都没发现的致命 bug**：v13 装在本机后根本没写进过一条新记忆——因为真库的表结构还是 v11.1 的，而三版 v14 的 `schema.sql` 写的是 v12+ 的新结构，`CREATE TABLE IF NOT EXISTS` 对已存在的表什么都不做，于是所有 `INSERT` 全部报错、被上层 `catch` 吞掉。**它们都只用新建的空库测过，从没在老库上跑过。**

修完这一条，`life_events` 的事件流、`action_proposals` 的队列、`memories_archive` 的归档、生活簿的三张表才第一次真的能写进去。

---

## 一、本机 v13 现状清点（真库实measure）

### 1.1 位置与规模

| 项 | 值 |
|---|---|
| 插件目录 | `<插件根>/dsh-life-v13` |
| 数据库 | `<数据根>/外置记忆库/data/brain.sqlite`（**不是** 默认的 `mind.db`） |
| 主库体积 | 13,905,920 字节 + WAL 4,185,952 字节 |
| profile 注册 | `<用户目录>/.dsh/profiles/desktop/package.json` + `cordis.patch.yml`（insert 段 `id=life-v13`） |
| 插件入口 | `main: ./src/host/dsh.mjs`（**不能是** `src/index.mjs`，那是 factory，cordis 拿不到 apply） |
| 健康度 | `PRAGMA user_version=13`、`journal_mode=wal`、`integrity_check=ok`、36 张表 |

### 1.2 数据分布

- **memories 340 行**：active 338 / invalid 2；archive 6；legacy_rows 340。
- **scope**：`solo` 339 + `private:owner` 1 —— 注意 `owner` 是字面量字符串，不是 QQ 号。
- **category**：episode 159 / promise 76 / fact 76 / person 23 / preference 6。
- **protection_tier**：normal 278 / stable 52 / core 10（core 占 2.9%，已收敛到 3% 配额内）。
- **importance**：≥0.95 共 49、0.9–0.95 共 27、0.8–0.9 共 24 → **≥0.9 占 22%，超 doctor 的 8% 水位线**（这是历史批量导入的遗留，v14 不强行压，夜间巩固会慢慢摊平）。
- **belief**：0.7 有 339 行、0.9 有 1 行 → 从未演化，是常量。
- **向量**：240/340 有 vec，`vec_model='bge-m3:1024'`（100 行 null）——外部 bge-m3 写过，v14 的本地 hash384 会与之并存（靠 `vec_model` 区分，不覆盖）。
- **写入节奏**：10-26 有 328 条（批量导入），之后 10-27 九条、10-28 一条、10-29 一条、11-01 一条 → **v13 装上后基本停摆**。

### 1.3 六类脏数据（v14 必须能治）

1. `memories` 表有一个名为 **`undefined`** 的 TEXT 列（运行时 ALTER 拼错的产物）。
2. `life_state` 有 2 行：`id='1'`（revision 301，state_json 正常）与 `id='singleton'`（revision 0，state_json 为 NULL）——残壳。
3. 时间列是 `'1793539724176.0'` 这种"毫秒数带 .0 尾巴的字符串"（`life_state.updated_at`、`injection_log.created_at`）。
4. `action_proposals` 735 条里 722 条是 `pending` 且 `expires_at` 全在 2026-11-02 已过期 → 队列只进不出。
5. 三个高度疑似重复的索引：`idx_mem_scope_cat` / `idx_mem_scope_inj` / `idx_mem_scope_inject`。
6. `life_events` 1074 行的 **`type` 列全为 NULL**（真凶见下文 P0）。

### 1.4 死链路（v13 的真实故障）

| 链路 | 症状 | 真因 |
|---|---|---|
| 建边 D3 | `edges` 0 行 | 写入被吞（本轮已修，实测可产出） |
| 缺口 D7 | `gaps` 0 行 | 同上 |
| 候选 | `candidates` 0 行 | 与 `action_proposals` 语义混用 |
| 注入台账 | `injection_log` 仅 29 行、`used_chars` 全为 0 | 预算统计没写值 |
| 事件流 | `life_events` 1074 行但 `type` 全 NULL | **表结构错位，写入整体失败** |
| 提案队列 | 735 条 722 条 pending 全过期 | 缺过期清理 |

---

## 二、三份材料的实跑验证（不是看它们怎么说）

三份材料都自称"全绿"。本机逐个跑了一遍，结论如下。

| 材料 | 文件数 | 自报 | **本机实跑** | 结论 |
|---|---|---|---|---|
| WorkBuddy | 说明+报告+CHANGELOG（无完整 src） | 540 断言全绿 | 无法独立复跑 | 只有文档，标题党 |
| ima | 110 文件 | 全绿 | **289 PASS / 7 FAIL** | 断言没跟上自己的实现 |
| codex | 118 文件 | 全绿 | **571 PASS / 0 FAIL** ✅ | 唯一全绿、修复最全 |

### ima 的 7 条失败（都是实现改了、断言没改）

- `tests/verify-upgrade.mjs:262` `U3-e user_version = 13` → got `undefined`；`:263` `U3-f kv schema_version = 13` → 同。
- `tests/verify-generic.mjs` G1-c / G6-b：期望 13，实得 14。
- `tests/verify-v14-p0.mjs` A4 `高风险能力默认关`、C2 `basis 列自愈` → got `undefined`。

**对照**：v13 自己跑 `verify-upgrade` 是 45 PASS / 0 FAIL。所以这不是逻辑 bug，是 ima 把 `SCHEMA_VERSION` 升到 14 之后没同步改断言。**这正好说明它自称的"全绿"没在本机跑过。**

### 一个必须记住的坑：行数会骗人

`ima/src/memory/engine.mjs` 与 `codex/src/memory/engine.mjs` **字节完全相同（21412）**，但 ima 是 717 行、codex 是 369 行——**ima 的包被"单空行化"过（LF，每行之间插一个空行）**，codex 是 CRLF。

同现象：`life-state.mjs` 576 vs 304 行（同为 14372 字节）、`rerank.mjs` 311 vs 156 行（去空行后完全一致）。

> **教训：跨包比文件必须比字节或去空行后的内容，绝对不能信 `wc -l`。** 这一条如果没识破，会得出"ima 实现更完整"的完全错误结论。

---

## 三、逐模块选型决策表

裁定原则：**能跑通的 > 说得好的；本机验证过的 > 自报的；修得深的 > 功能多的。**

| 模块 | 选谁 | 理由 |
|---|---|---|
| 总体底座 | **codex** | 唯一 571 断言全绿；`STAMP` 白名单为它独占 |
| `memory/bm25.mjs` | **codex** | 它用 `bm25(mem_fts) AS _fts_rank` + `1/(1+exp(rank))` sigmoid；ima 两者都没有 |
| `memory/search.mjs` | **codex** | 有 `ftsScores` Map 与 `max(lexical, fts)` 融合、`rerankMode` 三态 + `shadowLog` |
| `memory/governance.mjs` | **codex** | 它写 `STAMP_REASON='manual'`；ima 写 `'retracted'` 会撞 v11.1 的 CHECK 白名单 |
| `memory/belief-pool.mjs` | **codex** | `listConflicts` / `consistencySample` 都带 scope 过滤 |
| `memory/recall-card.mjs` | **ima** | 多 `allowRaw` 参数与 `rawDenied`，raw 原文只给 owner 私聊 |
| `life/delivery.mjs` | **ima** | 多 `classifySleepReply`（reply-short / queue / drop）三级睡眠投递 |
| `life/sleep-stage.mjs` | **两者合并** | ima 的睡眠窗口（`sleepWindow`/`inSleepWindow`）+ codex 的 scope 隔离 |
| `life/persona-drift.mjs` | **ima**（独占） | codex 完全没有；人格只出 diff、owner 终审才落快照 |
| `maintenance/nightly.mjs` | **钩子取 ima、剪除取 codex** | ima 有 `archiveDreams`/`personaDiff` 钩子；codex 的剪除条件更严（`archiveExists` + `retainDays>0` + `cold_at_ms` 兜底） |
| `index.mjs` | **合并** | ima 的 persona 工具 + 三级睡眠回复；codex 的 prompt pack、edges basis 自检 |
| `SCHEMA_VERSION` | **14**（ima 的路线） | codex 自己内部矛盾：`verify-final-gates.mjs:27` 早就断言 14，其余四处断言 13。而 `edges.basis` 确实是 schema 变更 |
| `kit/shadow.mjs` | **ima 的 `inShadow`** | SAVEPOINT→ROLLBACK→写 life_events，三态观测必需 |
| 包名 | 统一 `dsh-life-v14` | install-log 记过的"装了不跑"三根因之一 |

---

## 四、v14 实际改了什么

### P0 · 老库表结构错位（最严重，三版都没修）

**症状链**：真库 `life_events` 仍是 v11.1 的 DDL（`seq/at/kind/payload/delta/revision/applied_at/type/event_id/created_at`），而代码按 v12+ 新结构写（`event_id/event_type/event_json/...`）。

```sql
-- 实测报错（被上层 catch 吞掉，所以表现为"静默失败"）
table life_events has no column named event_type
NOT NULL constraint failed: life_events.at
```

**影响面**：不止 `life_events`，实测有 **6 张表**写入全 FAIL：

| 表 | 报错 | 写入点 |
|---|---|---|
| `life_events` | 缺 NOT NULL 列 `at, kind` | `src/kit/shadow.mjs:8`、`src/life/appraisal.mjs:164`、`src/life/sleep-stage.mjs:120`、`src/memory/belief-pool.mjs:13` |
| `action_proposals` | `NOT NULL constraint failed: at` | `src/index.mjs:488` |
| `memories_archive` | `NOT NULL constraint failed: row_json` | `src/maintenance/nightly.mjs:151` |
| `milestones` | `no column named scope` | `src/memory/lifebook.mjs:43` |
| `promises` | `no column named scope` | `src/memory/lifebook.mjs:14` |
| `narratives` | `datatype mismatch` | `src/memory/lifebook.mjs:55` |

**修法**：新增 `src/kit/legacy-shape.mjs`（约 280 行）。

- `RECIPES` 覆盖 6 张表，每张给 `{cols, keep, copy(has), verify}`。
- **`copy` 返回「列名→SQL 表达式」的对象映射，不是数组**——数组按位置对齐极易错位（实测报过 `copy-arity-mismatch 12!=8`、`17!=15`、`9!=8`）。
- 安全：`BEGIN IMMEDIATE` 单事务 → 建 `_relax_<table>` → `INSERT...SELECT` → **行数校验（不等就抛）** → `DROP TABLE 原表` → `ALTER TABLE tmp RENAME` → COMMIT；异常 ROLLBACK + `DROP TABLE IF EXISTS tmp`，原表毫发无伤。
- 老表独有的列全部当作可空列保留（`keep`），不丢任何字段。
- 语义映射：`at → created_at`、`kind → event_type`、`title → text`、`row_json → payload`。
- `event_type` 优先级必须是 `pick(event_type, type, kind)`——真库 `type` 列存在但 1074 行全 NULL，直接取会把 `event_type` 也写成 NULL。
- 时间换算用 `typeof` 判断，已回填的整数不会被二次乘 1000。

**验证（真库副本 13.3MB）**：6 张表全部宽松化、**行数一行不少**、6 张表写入全部从 FAIL 转 OK、`life_events.kind` 分布原样保留（proposal:735 / offline_catchup:166 / recall:148 / affect:11 / reflex:9 / outbound:4 / audit:1）、`created_at` 空值 0、二次 `ensureSchema` 幂等。

### P1 · 版本号统一 13 → 14

- `src/kit/config.mjs:8` → `SCHEMA_VERSION = 14`。
- `src/kit/optional-migrations.mjs` 去掉硬编码，改 import `SCHEMA_VERSION`。
- `migrations/columns.json` → `target_version=14`，补 `edges.basis` 列定义。
- `schema.sql` / `migrations/tables.sql` 的 `edges` 表加 `basis TEXT`。
- 五处测试断言 + 沙盒 6 处 + `scripts/verify-install.mjs` / `verify-plugin.mjs` 全部同步。
- `tests/verify-v14-p0.mjs` C2 断言重写（新 schema 自带 basis，原来的"第一次必须 true"已互斥），拆成 C2-a 幂等 + C2-b 老表补列两条，更严。

### P2 · 版本戳不推进（真漏洞）

v13 自己建的库列齐、索引齐、结构也对 → `ensureSchema` 判 `upgraded:false` 直接返回 → `user_version` 永远停在 13。

修法：`const versionStale = Number(PRAGMA user_version) < SCHEMA_VERSION;` 参与 `needUpgrade` 判定。

### P3 · ima 独有能力合并

| 新增 | 说明 |
|---|---|
| `src/life/persona-drift.mjs` | 人格慢漂移。只写 `life_events(type='persona:diff')`，owner 终审 `apply` 才落 `kv('persona:snapshot')`。`TIER_OK` 只认 user/owner/self/manual 来源——**模型永远不能自己改人格** |
| `life_persona_review` 工具 | action: list / build / apply |
| `sleepWindow` / `inSleepWindow` | 支持 `cfg.sleep.window = 'auto' \| {start,end}`，跨零点正确 |
| `classifySleepReply` / `sleepShortReply` | 睡着时三级：主人私聊命中紧急词回一句极短 / 主人私聊普通消息排队 / 群聊直接丢 |
| `archiveDreams` / `dreamsByNight` + `dreams` 表 | dreamLog 超 `softLimit=30` 才归档，**梦永远不进 memories** |
| `recall-card` 的 `allowRaw` | raw 原文只给 owner 私聊 |

夜间钩子 `archiveDreams` / `personaDiff`（每 14 天）接进 `nightlyOpts`。

### P4 · 脏数据治理

新增 `src/kit/dirty-data.mjs`（约 330 行），治六类：

| 治理项 | 做法 |
|---|---|
| 脏列 | 删 `undefined` / `null` / `NULL` / `''` 这类非法列名（`JUNK_COLUMNS`） |
| 残行 | `life_state` 里 `state_json` 为空且 `revision=0` 的空壳删掉 |
| 时间尾巴 | `'1793539724176.0'` → 纯数字；判定口径 `dirty = dotZero + iso` |
| 过期提案 | `pending`/`allowed` 且已过期的改 `status='expired'` + `drop_reason='v14-stale-cleanup'`（**不删行**） |
| 重复索引 | 按「表+列序列」归一化判重，保留名字最短的 |
| 多向量模型 | 只报告不处理（靠 `vec_model` 字段并存） |

设计要点：
- 总入口 `runDirtyCleanup` 靠 `kv('dirty:v14')` 打戳，**重复启动是 no-op**；单事务；每步失败只 warn 不阻断；报告另存 `kv('dirty:v14:report')`。
- **绝不 import `./db.mjs`**——会成环，`tests/verify-v14-p3.mjs` E1/E2 会直接判死。改为就地写 `kvRead` / `kvWrite`。
- 治理放在**指纹校验之后、版本戳之前**。

### 其它修复

| 项 | 问题 | 修法 |
|---|---|---|
| 时间尾巴 | TEXT 亲和性列写 JS number，SQLite 先当 REAL 再转 TEXT，落库变 `'1793824621501.0'`，每次写都留一条 | `saveState` 直接传**字符串** |
| `doctor.mjs:10` | `process.env.HOME` 在 Windows 为空 → 相对路径 `./.dsh/...` → 永远报"库文件不存在" | 改 `os.homedir()` |
| `doctor.mjs:61` | 版本检查写死"必须 13.x" | 改 `>= 13` |
| 重复索引自造 | `post_migrate_sql` 里的 `idx_*2` 与 schema 的 `idx_*` 完全同列，治理删了又建 | 从 `post_migrate_sql` 移除（18 条 → 14 条） |
| 包名三处不一致 | `package.json` / `host/dsh.mjs` / `cordis.patch.yml` | 统一 `dsh-life-v14` |
| 高风险能力默认 | 默认 `false`，等于没开也看不见 | 改 `'shadow'`：算完回滚、只留审计，默认不生效但可观测 |

---

## 五、验证矩阵（全部本机实跑，不是自报）

| 项目 | 命令 | 结果 |
|---|---|---|
| 全量单测 | `npm test` | **16 套件 663 / 663 PASS**，exit=0 |
| 沙盒 | `node sandbox/run.mjs` | **47 场景 / 315 断言 / PASS 315 / FAIL 0 / ERR 0**，117s |
| 模块图 | `node scripts/check-modules.mjs` | 52 模块 / 127 依赖边 / **0 循环 / 0 孤儿** |
| 隐私扫描 | `node scripts/privacy-scan.mjs .` | PASS |
| 中文检索 | `node scripts/eval-retrieval.mjs` | 6 例全 Recall=1.00 / MRR=1.00 / leakage=0 |
| 真库链路 | `materials/live-chain-test.mjs`（13.3MB 副本） | **22 / 22 PASS** |
| 安装自检 | `node scripts/verify-install.mjs` | **27 PASS / 0 FAIL** |
| 插件装配 | `node scripts/verify-plugin.mjs` | **16 ok / 0 false** |
| 编译检查 | `node --check` 全量 | 通过 |
| 打包后复跑 | 解压 zip → `npm test` + 沙盒 | 663 全绿 / 315 全绿 |

### 16 套件明细

```
verify                    75    verify-v14-p0        44
verify12                  82    verify-v14-p1        59
verify13                  29    verify-v14-p2        42
verify-chassis            55    verify-v14-p3        33
verify-upgrade            45    verify-v14-p4        37  (ima 并入)
verify-generic            19    verify-v14-p5        54  (ima 并入)
verify-v14-codex          40    verify-prompt-eval   13
verify-v14-cross2         31    verify-final-gates    5
                                                ─────────
                                              总计 663
```

### 真库链路 22 条覆盖

L1 基本盘 → L2 写入可写 → L3 刚写可立刻搜到 → L4 跨 scope 不泄漏 → L5 建边真产出（`readGraph.real=true`）→ L6 每条边有 basis → L7 重复建边幂等 → L8 缺口落库带 scope → L9 过期提案 722 → 0 → L10 二次启动 `upgraded=false` 不备份。

---

## 六、安装与升级（通用）

### 6.1 从 v11.1 / v13 原地升级

```bash
# 1) 覆盖代码（只增文件，不动你的 self-made/）
#    解开 dsh-life-v14.zip，整体同步到插件目录，例如
#    Windows: <插件目录>/dsh-life-v14
#    其它:    ~/.dsh/plugins/dsh-life-v14

# 2) 先看它会改什么（不写库）
node scripts/migrate.mjs --db <你的库绝对路径> --dry-run

# 3) 就地升级（自动备份 + 只加列/表 + 修老表结构 + 治脏数据）
node scripts/migrate.mjs --db <你的库绝对路径>

# 4) 注册到 profile
#    package.json 的 dependencies 加 "dsh-life-v14": "link:<包绝对路径>"
#    dsh.profile.bundles 包含 "dsh-life-v14"
#    cordis.patch.yml 里 dbPath 指向旧库（同一个文件，原地接管，不复制不迁移）

# 5) 重启 DSH
```

**必须把 `dbPath` 指到旧库**，否则 v14 会去 `~/.dsh/dsh-life/mind.db` 新建一个空库，看起来"装好了但什么都没有"。

### 6.2 全新安装

```bash
cp config.example.yml ~/.dsh/dsh-life/config.yml
dsh plugin add file:///<包绝对路径>/dsh-life-v14
```

### 6.3 升级后默认行为

| 能力 | 默认 | 说明 |
|---|---|---|
| `capabilities.v14` | `false` | 总闸，关着就是 v13 行为 |
| `route`（分舱路由） | `false` | 兼容模式 |
| `autoArchive` | `false` | 自动归档，想省钱再开 |
| `autoExtract` / `beliefPool` / `imprint` / `rerank` | `'shadow'` | 算完回滚，只留审计 |
| 注入冷却 | 6 小时 | 唯一默认生效的改动，可设 0 关 |
| 激素标度 | 0–1 | 旧 0–100 值启动时自动归一 |

### 6.4 回滚

```bash
# 停插件 → 把 <库>.v13.bak.<时间戳> 覆盖回原路径 → 换回 v13 代码
```

**数据零丢失**：所有重建都是"建新表 → 搬数据 → 校验行数 → 才删旧表"，且全程单事务。

---

## 七、这个版本的四条底线

1. **状态数值写入口唯一**：模型只产 delta 提案，由 `life-state.mjs` / `sleep-stage.mjs` 限幅回写。人格同理——`persona-drift` 只出 diff，owner 点了 `apply` 才落快照。
2. **情绪 / rerank / 梦境 / 印记不写 memories 正文、不进 effWeight、不改 belief**。梦只在 `dreams` 表。
3. **零第三方依赖**：只用 `node:` 内置 + `node:sqlite`。模型能力全是可选回调，失败降级，**永不阻断回复**。
4. **不确定就 shadow**：高风险能力先算后回滚，跑一段时间看审计日志，确认无副作用再开正。

---

## 八、已知限制（不藏）

1. **本机无 embed 能力**（`.boot.log` 里 `caps.embed=false`，`probe-fail=cannot get property "embed" without inject`）→ 向量通道降级，只剩 BM25 + 字面 + 中文 LIKE 兜底。这是宿主限制，不是插件 bug。
2. **importance ≥0.9 占 22%**，仍高于 doctor 的 8% 水位线。v14 不强行压（会伤到真重要的记忆），靠夜间巩固慢慢摊平。
3. **多套向量模型并存**：真库有 240 条 `bge-m3:1024`，v14 本地是 hash384。靠 `vec_model` 区分，互不覆盖，但混合检索时的可比性有限。
4. **`life_events` 有 1 行 `kind` 为 NULL**（历史残留），v14 原样保留，不伪造。
5. **沙盒是模拟环境**，不等于真机跑够久。真机长期表现要靠运行观察——这正是 v13 缺的那一环。
6. **未做的事**：没动 QQ 桥接侧的出口改写（`outbound-clean.js`），那是另一个仓库；没给 v13 的 4 个历史产物（`sandbox-log-2026-10-31.md` 等）补齐，它们是当时的运行记录，v14 的对应记录在 `docs/` 里。

---

## 九、总结

### 9.1 这轮真正学到的东西

**"测试全绿"和"在你机器上能用"是两件事。**
三份材料都全绿，但它们全部用**新建的空库**做测试。真机上那个从 v11.1 一路升上来的库，表结构是旧的、有脏列、有时间尾巴、有 722 条过期提案——**没有一份材料的测试碰过这个场景**。而恰恰是这个场景，解释了 v13 装上后为什么"记忆不进、事件流空、队列只进不出"。

所以这一版最值钱的不是加了什么功能，而是**把真库复制了一份，逼着 v14 在它上面跑一遍**。跑出来的 6 张表写入失败，是三份材料加起来 100 多个测试文件里一条都没覆盖的。

### 9.2 数字对照

| 维度 | v13 | codex 14.1.0 | **v14.1.1** |
|---|---|---|---|
| 断言 | 286 | 571 | **663** |
| 沙盒 | — | 315 | **315** |
| 模块 | 29 | 52 | **52** |
| 真库写入 | **6 表全 FAIL** | 未测 | **6 表全 OK** |
| 脏数据治理 | 无 | 无 | **6 类** |
| 老库结构自适应 | 无 | 无 | **6 张表** |
| 人格漂移 | 无 | 无 | **有** |
| 睡眠窗口 | 无 | 无 | **有** |
| 包名一致 | 一致 | 一致 | **一致** |

### 9.3 一句话

**v14 是把 v13 从"装上了但没真的在跑"变成"装上了并且真的在跑"的那一版。**

它继承 v13 的全部记忆管线与人生状态设计，把三份材料里最能打的部分挑出来合进去，然后补上那个所有人都漏掉的、最要命的一环：**在真实的、被用过两个月的库上，把每一条写入路径真的走一遍**。

---

*文档与代码包同源。包内另有 `docs/DSH-适配融合报告-v14.1.md`（codex 原始设计报告）、`docs/逐段对照-融合说明书.md`（v13 逐段对照）、`CHANGELOG.md`（完整版本史）。*
