-- ============================================================
--  v11.1 → v13.0 升级用：表 / 索引 / 触发器（全部幂等）
--  执行顺序见 src/kit/db.mjs ensureSchema()：
--    1) 逐列 ALTER（migrations/columns.json）  2) 本文件（剔除 rebuild 与触发器）
--    3) 摘触发器 → rebuild → 回填 → 装回触发器 → 再 rebuild  4) 打戳 + 指纹校验
-- ============================================================

-- ============================================================
--  DSH 双层一生感架构 v13.0  schema
--  兼容：11.1 旧库可直接就地升级（scripts/migrate.mjs / kit/db.mjs）
--  口径：主键统一 INTEGER（旧库本来就是 INTEGER，见 v11.1 第十一章 DDL）
--        时间同时保留 TEXT 旧列与 *_ms 新列（旧值不改写，新代码只读 *_ms）
--        raw 保持 v11.1 语义（原话全文 TEXT），v12 的 0/1 标志改用 raw_kept
--  Node >= 22.5（node:sqlite 内置）
-- ============================================================

PRAGMA journal_mode = WAL;
PRAGMA synchronous = NORMAL;
PRAGMA foreign_keys = ON;

-- ---------- 记忆主表 ----------
CREATE TABLE IF NOT EXISTS memories (
  id                     INTEGER PRIMARY KEY AUTOINCREMENT,
  scope                  TEXT NOT NULL,
  subject_qq             TEXT,
  category               TEXT NOT NULL,
  fact                   TEXT NOT NULL CHECK(length(fact) <= 500),
  tags                   TEXT,
  evidence               TEXT,
  evidence_kind          TEXT,
  evidence_ref           TEXT,
  source_kind            TEXT,
  source_id              TEXT,
  raw                    TEXT,                  -- v11.1 语义：原话全文
  raw_kept               INTEGER DEFAULT 1,     -- v13：raw 是否被保留（旧库全 1）
  importance             REAL DEFAULT 0.5 CHECK(importance BETWEEN 0 AND 1),
  emotional_salience     REAL DEFAULT 0 CHECK(emotional_salience BETWEEN 0 AND 1),
  relationship_salience  REAL DEFAULT 0 CHECK(relationship_salience BETWEEN 0 AND 1),
  beta                   REAL DEFAULT 0.6 CHECK(beta BETWEEN 0 AND 1),
  beta_src               TEXT DEFAULT 'inferred',
  belief                 REAL DEFAULT 0.7 CHECK(belief BETWEEN 0 AND 1),
  novelty                REAL DEFAULT 0,
  activation             REAL DEFAULT 0,
  protection_tier        TEXT DEFAULT 'normal', -- core / stable / normal / ephemeral
  region                 TEXT DEFAULT 'daily',
  region_score           REAL DEFAULT 0,
  -- 时间：TEXT 旧列（只读不写） + INTEGER 新列（新代码唯一读取源）
  happened_at            TEXT,
  created_at             TEXT,
  confirmed_at           TEXT,
  valid_to               TEXT,
  last_recalled          TEXT,
  cold_at                TEXT,
  happened_at_ms         INTEGER,
  created_at_ms          INTEGER,
  confirmed_at_ms        INTEGER,
  valid_from_ms          INTEGER,
  valid_to_ms            INTEGER,
  last_recalled_ms       INTEGER,
  cold_at_ms             INTEGER,
  time_granularity       TEXT DEFAULT 'point',
  emotion                TEXT,
  emotion_intensity      REAL DEFAULT 0,
  bot_feeling            TEXT,
  bot_feeling_intensity  REAL DEFAULT 0,
  perspective            TEXT,
  attr_key               TEXT,
  attr_value             TEXT,
  supersedes             INTEGER,
  invalid_reason         TEXT,
  superseded_by          INTEGER,
  review_stability       REAL DEFAULT 1,
  review_due_at          INTEGER,
  evidence_count         INTEGER DEFAULT 1,
  confirm_count          INTEGER DEFAULT 0,
  content_hash           TEXT,
  origin_key             TEXT,
  anchor_place           TEXT,
  anchor_ground          TEXT,
  last_injected_at       INTEGER,
  recall_count           INTEGER DEFAULT 0,
  uses                   INTEGER DEFAULT 0,
  cold                   INTEGER DEFAULT 0,
  cold_reason            TEXT,
  audit_status           TEXT DEFAULT 'ok',
  vec                    BLOB,
  vec_model              TEXT
);

CREATE INDEX IF NOT EXISTS idx_mem_scope_cat ON memories(scope, category, cold);
CREATE INDEX IF NOT EXISTS idx_mem_scope_inj ON memories(scope, cold, invalid_reason);
CREATE INDEX IF NOT EXISTS idx_mem_subject   ON memories(subject_qq);
CREATE INDEX IF NOT EXISTS idx_mem_attr      ON memories(attr_key);
CREATE INDEX IF NOT EXISTS idx_mem_region    ON memories(region, cold);
CREATE INDEX IF NOT EXISTS idx_mem_tier      ON memories(protection_tier, invalid_reason);
CREATE INDEX IF NOT EXISTS idx_mem_belief    ON memories(belief);
CREATE INDEX IF NOT EXISTS idx_mem_review    ON memories(review_due_at);
CREATE INDEX IF NOT EXISTS idx_mem_origin    ON memories(origin_key);
CREATE INDEX IF NOT EXISTS idx_mem_hash      ON memories(content_hash);
CREATE INDEX IF NOT EXISTS idx_mem_scope_recent
  ON memories(scope, created_at_ms DESC, created_at DESC)
  WHERE invalid_reason IS NULL;
CREATE INDEX IF NOT EXISTS idx_mem_visible_recent
  ON memories(invalid_reason, cold, created_at_ms DESC, created_at DESC);

CREATE VIRTUAL TABLE IF NOT EXISTS mem_fts
  USING fts5(fact, tags, content='memories', content_rowid='rowid', tokenize='trigram');

CREATE TRIGGER IF NOT EXISTS mem_ai AFTER INSERT ON memories BEGIN
  INSERT INTO mem_fts(rowid, fact, tags) VALUES (new.rowid, new.fact, new.tags);
END;
CREATE TRIGGER IF NOT EXISTS mem_ad AFTER DELETE ON memories BEGIN
  INSERT INTO mem_fts(mem_fts, rowid, fact, tags) VALUES ('delete', old.rowid, old.fact, old.tags);
END;
CREATE TRIGGER IF NOT EXISTS mem_au AFTER UPDATE ON memories BEGIN
  INSERT INTO mem_fts(mem_fts, rowid, fact, tags) VALUES ('delete', old.rowid, old.fact, old.tags);
  INSERT INTO mem_fts(rowid, fact, tags) VALUES (new.rowid, new.fact, new.tags);
END;

-- ---------- 辅助表 ----------
CREATE TABLE IF NOT EXISTS narratives (
  id INTEGER PRIMARY KEY AUTOINCREMENT, scope TEXT NOT NULL, period TEXT NOT NULL,
  period_start INTEGER, text TEXT, chars INTEGER,
  audit_status TEXT DEFAULT 'ok', created_at INTEGER, injected_at INTEGER
);

CREATE TABLE IF NOT EXISTS candidates (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  scope TEXT NOT NULL, subject_qq TEXT,
  text TEXT, kind TEXT, payload TEXT, category TEXT,
  evidence TEXT, evidence_kind TEXT, evidence_ref TEXT, msg_ids TEXT,
  source_kind TEXT, source_id TEXT, confidence REAL DEFAULT 0,
  status TEXT DEFAULT 'pending',
  memory_id INTEGER, created_at INTEGER, expires_at INTEGER,
  fingerprint TEXT, origin_key TEXT, status_reason TEXT,
  review_after INTEGER, reviewed_at INTEGER, raw_text TEXT
);
CREATE INDEX IF NOT EXISTS idx_cand_status ON candidates(status, review_after);

CREATE TABLE IF NOT EXISTS relationships (
  scope TEXT PRIMARY KEY, closeness REAL DEFAULT 0.5, trust REAL DEFAULT 0.5,
  stage TEXT DEFAULT 'normal', updated_at INTEGER
);

CREATE TABLE IF NOT EXISTS promises (
  id INTEGER PRIMARY KEY AUTOINCREMENT, scope TEXT NOT NULL, text TEXT,
  due_at INTEGER, status TEXT DEFAULT 'pending',
  created_at INTEGER, last_notified_at INTEGER
);

CREATE TABLE IF NOT EXISTS milestones (
  id INTEGER PRIMARY KEY AUTOINCREMENT, scope TEXT NOT NULL, text TEXT, happened_at INTEGER, created_at INTEGER
);

CREATE TABLE IF NOT EXISTS memories_archive (
  id INTEGER, archived_at INTEGER, reason TEXT, payload TEXT
);

CREATE TABLE IF NOT EXISTS reflexes (
  id INTEGER PRIMARY KEY AUTOINCREMENT, scope TEXT NOT NULL, subject_qq TEXT,
  trigger TEXT NOT NULL, response TEXT,
  pain_level REAL DEFAULT 0.5,
  activation REAL DEFAULT 0,
  last_fired_at INTEGER, fire_count INTEGER DEFAULT 0,
  created_at INTEGER
);

CREATE TABLE IF NOT EXISTS injection_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  memory_id INTEGER NOT NULL, scope TEXT, kind TEXT,
  injected_at INTEGER NOT NULL, turn_id TEXT
);
CREATE INDEX IF NOT EXISTS idx_inj_mem_time ON injection_log(memory_id, injected_at);

CREATE TABLE IF NOT EXISTS edges (
  from_id INTEGER NOT NULL, to_id INTEGER NOT NULL,
  type TEXT NOT NULL,
  weight REAL DEFAULT 0.5, created_at INTEGER NOT NULL,
  basis TEXT,                       -- v14：这条边是怎么来的（模型侧可答「为什么连」）
  PRIMARY KEY (from_id, to_id, type)
);
CREATE INDEX IF NOT EXISTS idx_edges_from ON edges(from_id, type);

-- ---------- 状态核 ----------
CREATE TABLE IF NOT EXISTS life_state (
  id INTEGER PRIMARY KEY CHECK(id = 1),
  revision INTEGER NOT NULL DEFAULT 0,
  schema_version INTEGER NOT NULL DEFAULT 13,
  state_json TEXT NOT NULL,
  updated_at INTEGER NOT NULL
);

-- 兼容两套列名：v11.1 用 event_type/event_json，v12+ 用 type/payload；双写
CREATE TABLE IF NOT EXISTS life_events (
  event_id TEXT PRIMARY KEY,
  revision INTEGER,
  event_type TEXT,
  event_json TEXT,
  type TEXT,
  payload TEXT,
  created_at INTEGER NOT NULL,
  applied_at INTEGER
);
CREATE INDEX IF NOT EXISTS idx_events_time ON life_events(created_at);
CREATE INDEX IF NOT EXISTS idx_events_pending ON life_events(applied_at) WHERE applied_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_events_type_time ON life_events(event_type, created_at DESC);

-- 兼容两套列名：v11.1 是 snapshot_json（NOT NULL），v12+ 用 state_json
CREATE TABLE IF NOT EXISTS life_snapshots (
  revision INTEGER PRIMARY KEY,
  state_hash TEXT,
  snapshot_json TEXT,
  state_json TEXT,
  size_bytes INTEGER,
  created_at INTEGER
);

CREATE TABLE IF NOT EXISTS action_proposals (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  intent TEXT, say TEXT, why TEXT,
  evidence_id INTEGER, expected_effect TEXT, risk TEXT DEFAULT 'low',
  status TEXT DEFAULT 'queued',          -- queued / sent / dropped / expired
  created_at INTEGER, sent_at INTEGER, drop_reason TEXT
);

CREATE TABLE IF NOT EXISTS kv (k TEXT PRIMARY KEY, v TEXT, updated_at INTEGER);

-- ---------- v12.1 表 ----------
CREATE TABLE IF NOT EXISTS memory_evidence (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  memory_id INTEGER NOT NULL,
  independent_key TEXT NOT NULL,
  source_kind TEXT, source_id TEXT, ref TEXT,
  quote TEXT, message_ids TEXT, asserted_at INTEGER,
  created_at INTEGER NOT NULL,
  UNIQUE(memory_id, independent_key)
);
CREATE INDEX IF NOT EXISTS idx_ev_mem ON memory_evidence(memory_id);

CREATE TABLE IF NOT EXISTS memory_cells (
  cell_id INTEGER PRIMARY KEY,
  centroid BLOB,
  summary TEXT,
  member_count INTEGER DEFAULT 0,
  updated_at INTEGER
);

CREATE TABLE IF NOT EXISTS gaps (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  scope TEXT,
  question TEXT NOT NULL,
  tension REAL DEFAULT 0,
  evidence_count INTEGER DEFAULT 0,
  coverage REAL DEFAULT 0,
  created_at INTEGER NOT NULL,
  resolved INTEGER DEFAULT 0,
  closed_by TEXT,
  closed_at INTEGER
);
CREATE INDEX IF NOT EXISTS idx_gaps_open ON gaps(resolved, tension DESC);

CREATE TABLE IF NOT EXISTS context_checkpoints (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  scope TEXT NOT NULL,
  session_id TEXT,
  revision INTEGER,
  handoff TEXT,
  summary TEXT,
  boundary TEXT,
  msg_ids TEXT,
  created_at INTEGER
);
CREATE INDEX IF NOT EXISTS idx_ckpt_scope ON context_checkpoints(scope, created_at DESC);

-- ---------- v14 / Q5：梦的长期回放（表先建，只有溢出或按夜查询才写入）----------
CREATE TABLE IF NOT EXISTS dreams (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  night TEXT NOT NULL,
  stage TEXT,
  level INTEGER DEFAULT 1,
  text TEXT,
  from_ids TEXT,
  gap_ids TEXT,
  mood_json TEXT,
  clarity REAL DEFAULT 1,
  created_at INTEGER NOT NULL,
  archived_from TEXT DEFAULT 'dreamLog'
);
CREATE INDEX IF NOT EXISTS idx_dreams_night ON dreams(night, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_dreams_created ON dreams(created_at DESC);

-- ---------- v13.0 升级安全表 ----------
CREATE TABLE IF NOT EXISTS schema_migrations (
  version INTEGER PRIMARY KEY,
  label TEXT,
  applied_at INTEGER NOT NULL,
  note TEXT
);

CREATE TABLE IF NOT EXISTS legacy_rows (
  table_name TEXT NOT NULL,
  row_key TEXT NOT NULL,
  legacy_json TEXT NOT NULL,
  fingerprint TEXT NOT NULL,
  captured_at INTEGER NOT NULL,
  PRIMARY KEY (table_name, row_key)
);

CREATE TABLE IF NOT EXISTS upgrade_manifest (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  from_version TEXT, to_version TEXT, applied_at INTEGER NOT NULL,
  added_columns INTEGER, rebuilt_fts INTEGER,
  legacy_fingerprint TEXT, legacy_rows_count INTEGER,
  post_fingerprint TEXT, verify_ok INTEGER,
  backup_path TEXT, note TEXT
);

-- 新建库也执行一次 rebuild（空表时无副作用；统一路径，避免升级/新装两套逻辑）
INSERT INTO mem_fts(mem_fts) VALUES('rebuild');
