# DSH-Life v14 Prompt Pack

该目录是 DSH 适配层的提示词真源。`manifest.json` 定义加载顺序和字符上限，
`src/prompt/pack.mjs` 负责安全加载、校验和合并。

## 使用边界

1. `system-core`、`tool-policy`、`memory-write` 属于常驻 system 指令；
2. `nightly-audit` 只在离线审计任务使用；
3. `handoff` 只在会话交接任务使用；
4. 人格正文由 DSH 的 L1 配置单独提供，不塞进这些文件；
5. 提示词不能替代代码闸门，scope、候选、证据和发送回执仍由代码强制。

## 校验

```bash
node tests/verify-prompt-eval.mjs
```
