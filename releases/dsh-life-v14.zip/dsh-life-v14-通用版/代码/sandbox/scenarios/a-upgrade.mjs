// sandbox/scenarios/a-upgrade.mjs — A 组：升级路径（数据侧）
import { join } from 'node:path';
import { existsSync, readdirSync, statSync, readFileSync } from 'node:fs';
import { ensureSchema, openDb, legacyFingerprint, kvGet } from '../../src/kit/db.mjs';
import { enforceTierQuota } from '../../src/memory/engine.mjs';
import { searchMemory, logInjection } from '../../src/memory/search.mjs';
import { recover, saveState } from '../../src/life/life-state.mjs';
import { DEFAULTS, SCHEMA_VERSION } from '../../src/kit/config.mjs';
import { V11_DDL, makeV11, openRaw, colsOf, fileSize, OWNER, SCOPE } from '../lib.mjs';

const bakCount = (dir, base = 'mind.db.v13.bak.') =>
  readdirSync(dir).filter(f => f.startsWith(base)).length;

export async function runA(rec, work) {
  // ---------------- A1 全新库 ----------------
  {
    rec.begin('A1', '全新空库（fresh）', '库文件不存在时，schema.sql 一次建好，版本戳与台账就位');
    const dir = work('A1'); const p = join(dir, 'mind.db');
    try {
      const db = await openDb(p);
      const r = await ensureSchema(db, { dbPath: p });
      rec.ok('fresh=true', r.fresh === true, r);
      rec.ok('user_version=14', db.prepare('PRAGMA user_version').get().user_version === SCHEMA_VERSION);
      rec.ok('kv schema_version=14', kvGet(db, 'schema_version') === String(SCHEMA_VERSION), kvGet(db, 'schema_version'));
      const tables = db.prepare("SELECT count(*) n FROM sqlite_master WHERE type='table'").get().n;
      rec.ok('表数量 ≥ 20', tables >= 20, tables);
      const cols = colsOf(db, 'memories');
      rec.ok('memories 含 _ms 列', cols.includes('created_at_ms') && cols.includes('valid_from_ms'), cols.length);
      rec.ok('manifest 有 fresh 记录', db.prepare("SELECT note FROM upgrade_manifest WHERE note='new database'").get()?.note === 'new database');
      rec.ok('无备份文件（新建库不该备份）', bakCount(dir) === 0, bakCount(dir));
      rec.note('db_size', fileSize(p));
      db.close();
    } catch (e) { rec.fail(e); }
    rec.end();
  }

  // ---------------- A2 v11.1 标准库直升级 ----------------
  {
    rec.begin('A2', 'v11.1 真实 DDL 库直升级（30 行）', '旧数据一行不改、新能力长出来、FTS 不炸');
    const dir = work('A2'); const p = join(dir, 'mind.db');
    try {
      makeV11(p, { rows: 30 });
      const raw = openRaw(p);
      const beforeCols = colsOf(raw, 'memories');
      const fpBefore = legacyFingerprint(raw, 'memories', beforeCols, 'id');
      const oldRow5 = raw.prepare('SELECT * FROM memories WHERE id=5').get();
      raw.close();

      const db = await openDb(p);
      const t0 = Date.now();
      const r = await ensureSchema(db, { dbPath: p });
      const ms = Date.now() - t0;
      const afterCols = colsOf(db, 'memories');
      const fpAfter = legacyFingerprint(db, 'memories', beforeCols, 'id');

      rec.ok('识别为老库并升级', r.upgraded === true && r.fresh === false, r);
      rec.ok('新增列 ≥ 25', afterCols.length - beforeCols.length >= 25, { before: beforeCols.length, after: afterCols.length });
      rec.ok('指纹一致（旧列逐行未改）', fpAfter.hash === fpBefore.hash && fpAfter.count === 30, { fpBefore: fpBefore.count, fpAfter: fpAfter.count });
      rec.ok('fingerprintOk 标记为真', r.fingerprintOk === true);
      rec.ok('legacy_rows 30 行', db.prepare('SELECT count(*) n FROM legacy_rows').get().n === 30);
      rec.ok('manifest verify_ok=1', db.prepare('SELECT verify_ok v FROM upgrade_manifest ORDER BY id DESC LIMIT 1').get()?.v === 1);
      rec.ok('user_version=14', db.prepare('PRAGMA user_version').get().user_version === SCHEMA_VERSION);
      rec.ok('备份文件生成 1 份', bakCount(dir) === 1, bakCount(dir));

      const row5 = db.prepare('SELECT * FROM memories WHERE id=5').get();
      rec.ok('raw 原话保留', row5.raw === oldRow5.raw);
      rec.ok('fact 未被改写', row5.fact === oldRow5.fact);
      rec.ok('TEXT 时间仍是旧格式（无 T）', !String(row5.created_at).includes('T'), row5.created_at);
      rec.ok('created_at_ms 已回填', Number(row5.created_at_ms) > 0, row5.created_at_ms);
      rec.ok('CONFIRMED 时间毫秒换算一致',
        Math.abs(Number(row5.confirmed_at_ms) - Date.parse(row5.confirmed_at.replace(' ', 'T') + 'Z')) < 2000,
        { ms: row5.confirmed_at_ms, txt: row5.confirmed_at });

      const dep = db.prepare('SELECT invalid_reason, valid_to FROM memories WHERE id=2').get();
      rec.ok('废弃行状态未被改写', dep.invalid_reason === 'superseded' && !!dep.valid_to, dep);
      const cold = db.prepare('SELECT cold, cold_reason FROM memories WHERE id=3').get();
      rec.ok('冷行状态未被改写', cold.cold === 1 && cold.cold_reason === 'age', cold);
      rec.ok('scope 编码未被改写', db.prepare("SELECT count(*) n FROM memories WHERE scope LIKE 'private:%'").get().n === 30);
      rec.ok('id 仍为 INTEGER 自增', db.prepare("SELECT count(*) n FROM memories WHERE typeof(id)='integer'").get().n === 30);

      const hits = searchMemory(db, '旧库第5条', { scope: SCOPE, topK: 5 }).items;
      rec.ok('升级后检索命中旧数据', hits.length > 0 && hits.some(h => /旧库第/.test(h.mem.fact)), hits.length);

      // 注入日志：v11.1 的 injection_log 是 (id,turn_id,used_chars,dropped,by_kind,created_at)，
      // 既没有 scope/kind，created_at 还是 NOT NULL 无默认值。若按 v13 列名硬写会抛
      // 「no such column: scope」/「NOT NULL constraint failed」，异常被上层 catch 吞掉，
      // 线上表现就是 injection_log 永远 0 条、看着像「记忆根本没注入」。
      let injErr = null;
      const injBefore = db.prepare('SELECT count(*) n FROM injection_log').get().n;
      try { logInjection(db, hits, Date.now(), 'turn-a2'); } catch (e) { injErr = e.message; }
      const injN = db.prepare('SELECT count(*) n FROM injection_log').get().n;
      rec.ok('升级后注入日志能写入（旧库列不同也不炸）', injErr === null && injN === injBefore + hits.length, { injErr, injBefore, injN, hits: hits.length });
      rec.note('upgrade_ms', ms);
      rec.note('db_size_after', fileSize(p));
      rec.note('backup_size', fileSize(join(dir, readdirSync(dir).find(f => f.startsWith('mind.db.v13.bak.')))));
      db.close();
    } catch (e) { rec.fail(e); }
    rec.end();
  }

  // ---------------- A3 零行旧库 ----------------
  {
    rec.begin('A3', 'v11.1 空库（0 行）', '边界：没有数据也要能升级，且不误报指纹差异');
    const dir = work('A3'); const p = join(dir, 'mind.db');
    try {
      makeV11(p, { rows: 0 });
      const db = await openDb(p);
      const r = await ensureSchema(db, { dbPath: p });
      rec.ok('升级成功', r.upgraded === true, r);
      rec.ok('指纹一致（空表）', r.fingerprintOk === true);
      rec.ok('legacy_rows 0 行', db.prepare('SELECT count(*) n FROM legacy_rows').get().n === 0);
      rec.ok('user_version=14', db.prepare('PRAGMA user_version').get().user_version === SCHEMA_VERSION);
      db.close();
    } catch (e) { rec.fail(e); }
    rec.end();
  }

  // ---------------- A4 大型旧库 3000 行 ----------------
  {
    rec.begin('A4', '大型旧库直升级（3000 行）', '规模下的耗时、指纹与快照完整性');
    const dir = work('A4'); const p = join(dir, 'mind.db');
    try {
      makeV11(p, { rows: 3000 });
      rec.note('db_size_before', fileSize(p));
      const db = await openDb(p);
      const t0 = Date.now();
      const r = await ensureSchema(db, { dbPath: p });
      const ms = Date.now() - t0;
      rec.ok('升级成功且指纹一致', r.upgraded && r.fingerprintOk, { added: r.added });
      rec.ok('3000 行全部保留', db.prepare('SELECT count(*) n FROM memories').get().n === 3000);
      rec.ok('legacy_rows 3000 行', db.prepare('SELECT count(*) n FROM legacy_rows').get().n === 3000);
      rec.ok('耗时 < 60s', ms < 60000, ms);
      const hits = searchMemory(db, '旧库第2999条记忆', { scope: SCOPE, topK: 3 }).items;
      rec.ok('大库检索命中', hits.length > 0, hits.length);
      rec.note('upgrade_ms', ms);
      rec.note('db_size_after', fileSize(p));
      rec.note('ms_per_1000_rows', Math.round(ms / 3));
      db.close();
    } catch (e) { rec.fail(e); }
    rec.end();
  }

  // ---------------- A5 脏库 ----------------
  {
    rec.begin('A5', '脏数据旧库（NULL 时间/超长/emoji/audit=suspect）', '真实世界的脏数据不能让升级崩掉');
    const dir = work('A5'); const p = join(dir, 'mind.db');
    try {
      makeV11(p, { rows: 30, dirty: true });
      const raw = openRaw(p);
      const nBefore = raw.prepare('SELECT count(*) n FROM memories').get().n;
      const longLen = raw.prepare("SELECT length(fact) l FROM memories WHERE fact LIKE '超长记忆%'").get().l;
      raw.close();
      const db = await openDb(p);
      const r = await ensureSchema(db, { dbPath: p });
      rec.ok('脏库升级成功', r.upgraded && r.fingerprintOk, { added: r.added, fp: r.fingerprintOk });
      rec.eq('行数不变', db.prepare('SELECT count(*) n FROM memories').get().n, nBefore);
      const nullTime = db.prepare("SELECT happened_at, created_at_ms FROM memories WHERE fact='NULL 时间的记忆'").get();
      rec.ok('NULL 发生时间不炸（happened 为空、created 毫秒已回填）', nullTime && nullTime.happened_at === null && Number(nullTime.created_at_ms) > 0, nullTime);
      const longRow = db.prepare("SELECT length(fact) l FROM memories WHERE fact LIKE '超长记忆%'").get();
      rec.ok('超长 fact 未被截断', longRow.l === longLen, { before: longLen, after: longRow.l });
      const emoji = db.prepare("SELECT fact FROM memories WHERE fact LIKE '%🐋%'").get();
      rec.ok('emoji 内容原样保留', !!emoji && emoji.fact.includes('🐋'));
      const sus = db.prepare("SELECT audit_status FROM memories WHERE fact='audit 可疑的一条'").get();
      rec.ok('audit_status=suspect 未被改写', sus.audit_status === 'suspect', sus);
      db.close();
    } catch (e) { rec.fail(e); }
    rec.end();
  }

  // ---------------- A6 幂等 ----------------
  {
    rec.begin('A6', '重复升级 3 次（幂等）', '第二次起不应再改库、不应再备份');
    const dir = work('A6'); const p = join(dir, 'mind.db');
    try {
      makeV11(p, { rows: 30 });
      const db = await openDb(p);
      const r1 = await ensureSchema(db, { dbPath: p });
      const bak1 = bakCount(dir);
      const r2 = await ensureSchema(db, { dbPath: p });
      const r3 = await ensureSchema(db, { dbPath: p });
      const bak3 = bakCount(dir);
      rec.ok('第一次: 升级', r1.upgraded === true);
      rec.ok('第三次: 无改动', r3.upgraded === false && r3.added === 0, r3);
      rec.ok('第三次: 不再备份', bak3 === bak1, { bak1, bak3 });
      rec.ok('第三次: 指纹仍一致', r3.fingerprintOk === true);
      rec.ok('memories 行数仍 30', db.prepare('SELECT count(*) n FROM memories').get().n === 30);
      db.close();
    } catch (e) { rec.fail(e); }
    rec.end();
  }

  // ---------------- A7 半途中断后续跑 ----------------
  {
    rec.begin('A7', '模拟上次升级中断（已补 2 列、触发器缺失）', '中断后半途库必须能续跑完成');
    const dir = work('A7'); const p = join(dir, 'mind.db');
    try {
      makeV11(p, { rows: 30 });
      // 手工制造「上次跑到一半」：补了 2 个新列，但触发器没装回
      const raw = openRaw(p);
      raw.exec('ALTER TABLE memories ADD COLUMN protection_tier TEXT DEFAULT \'normal\';');
      raw.exec('ALTER TABLE memories ADD COLUMN content_hash TEXT;');
      raw.close();

      const db = await openDb(p);
      const r = await ensureSchema(db, { dbPath: p });
      rec.ok('续跑完成', r.upgraded === true, r);
      rec.ok('指纹一致', r.fingerprintOk === true);
      rec.ok('补列数量少于全量（已存在 2 列）', r.added < 60, r.added);
      const trigs = db.prepare("SELECT name FROM sqlite_master WHERE type='trigger' AND name LIKE 'mem_a%'").all().map(x => x.name);
      rec.ok('三个 FTS 触发器装回', trigs.length === 3, trigs);
      const upd = db.prepare("UPDATE memories SET fact = fact WHERE id = 1").run();
      rec.ok('升级后首次 UPDATE 不报 malformed', !!upd, upd);
      rec.ok('content_hash 已回填', db.prepare("SELECT count(*) n FROM memories WHERE content_hash IS NOT NULL AND content_hash<>''").get().n === 30);
      db.close();
    } catch (e) { rec.fail(e); }
    rec.end();
  }

  // ---------------- A8 FTS 三字中文与重建 ----------------
  {
    rec.begin('A8', 'FTS5 中文三字检索 + 首次 UPDATE', 'trigram 分词下限与 rebuild 顺序');
    const dir = work('A8'); const p = join(dir, 'mind.db');
    try {
      makeV11(p, { rows: 30 });
      const db = await openDb(p);
      await ensureSchema(db, { dbPath: p });
      const two = db.prepare("SELECT count(*) n FROM mem_fts WHERE mem_fts MATCH '习惯'").get();
      const three = db.prepare("SELECT count(*) n FROM mem_fts WHERE mem_fts MATCH '习惯条'").get();
      rec.ok('两字 MATCH 不报错（可能 0 行）', Number.isInteger(two.n), two);
      rec.ok('三字 MATCH 命中', three.n > 0, three);
      db.prepare("INSERT INTO memories(scope,category,fact,created_at,importance,audit_status) VALUES(?,?,?,?,?,?)")
        .run(SCOPE, 'fact', '新增的一条用于触发器测试', new Date().toISOString(), 0.5, 'ok');
      const ins = db.prepare("SELECT count(*) n FROM mem_fts WHERE mem_fts MATCH '触发器测试'").get();
      rec.ok('INSERT 后触发器同步到 FTS', ins.n > 0, ins);
      db.prepare("UPDATE memories SET fact='改成新的内容用于更新测试' WHERE fact='新增的一条用于触发器测试'").run();
      const upd = db.prepare("SELECT count(*) n FROM mem_fts WHERE mem_fts MATCH '更新测试'").get();
      rec.ok('UPDATE 后触发器同步到 FTS', upd.n > 0, upd);
      db.prepare("DELETE FROM memories WHERE fact='改成新的内容用于更新测试'").run();
      const del = db.prepare("SELECT count(*) n FROM mem_fts WHERE mem_fts MATCH '更新测试'").get();
      rec.ok('DELETE 后触发器同步到 FTS', del.n === 0, del);
      db.close();
    } catch (e) { rec.fail(e); }
    rec.end();
  }

  // ---------------- A9 保护层级配额驱逐 ----------------
  {
    rec.begin('A9', 'core 配额 3% 驱逐（1000 行 / 200 条 core）', '配额超限时按 effWeight 驱逐，不炸库');
    const dir = work('A9'); const p = join(dir, 'mind.db');
    try {
      makeV11(p, { rows: 1000 });
      const db = await openDb(p);
      await ensureSchema(db, { dbPath: p });
      db.exec("UPDATE memories SET protection_tier='core' WHERE id <= 200");
      const r = enforceTierQuota(db, Date.now(), DEFAULTS);
      const n = db.prepare("SELECT count(*) n FROM memories WHERE protection_tier='core'").get().n;
      rec.ok('core 数量降到 3% 以内', n <= Math.ceil(1000 * 0.03), { left: n, quota: Math.ceil(1000 * 0.03) });
      rec.note('demoted', r);
      rec.ok('被驱逐的行仍有保护层级值', db.prepare("SELECT count(*) n FROM memories WHERE protection_tier IS NULL").get().n === 0);
      db.close();
    } catch (e) { rec.fail(e); }
    rec.end();
  }

  // ---------------- A10 旧状态归一 / 双写 ----------------
  {
    rec.begin('A10', '旧 0–100 激素状态恢复 + 快照/事件双写', '状态层标度迁移不能改坏已有值');
    const dir = work('A10'); const p = join(dir, 'mind.db');
    try {
      makeV11(p, { rows: 30 });
      const db = await openDb(p);
      await ensureSchema(db, { dbPath: p });
      const st = recover(db).state;
      rec.ok('激素归一到 0–1', st.hormones.cortisol === 0.30 && st.hormones.dopamine === 0.50 && st.hormones.oxytocin === 0.40 && st.hormones.serotonin === 0.60, st.hormones);
      rec.ok('needs 未被破坏', Math.abs(st.needs.social - 0.44) < 1e-9, st.needs);
      rec.ok('revision ≥ 41（事件表无 revision 时为 max(41)）', st.revision >= 41, st.revision);
      saveState(db, st);
      const snap = db.prepare('SELECT snapshot_json, state_json, size_bytes FROM life_snapshots ORDER BY revision DESC LIMIT 1').get();
      rec.ok('快照双列都有值', !!snap && !!snap.snapshot_json && !!snap.state_json, snap ? Object.keys(snap) : null);
      rec.ok('快照 state_json 与 snapshot_json 同值', snap.snapshot_json === snap.state_json);
      const ev = db.prepare("SELECT event_type, type, event_json, payload, applied_at FROM life_events WHERE event_id='ev1'").get();
      rec.ok('旧事件 event_type 未被改写', ev.event_type === 'tick', ev);
      rec.ok('事件 payload 已补齐（与 event_json 同值）', ev.payload === ev.event_json, { p: ev.payload, j: ev.event_json });
      db.close();
    } catch (e) { rec.fail(e); }
    rec.end();
  }
}
