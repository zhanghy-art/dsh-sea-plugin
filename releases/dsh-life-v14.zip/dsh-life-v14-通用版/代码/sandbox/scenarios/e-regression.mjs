// sandbox/scenarios/e-regression.mjs — E 组：回归（跑交付包自带测试）
import { execFileSync } from 'node:child_process';
import { join } from 'node:path';
import { PKG } from '../lib.mjs';

const NODE = process.execPath;

const SUITES = [
  ['verify.mjs', 75],
  ['verify12.mjs', 82],
  ['verify13.mjs', 29],
  ['verify-chassis.mjs', 55],
  ['verify-upgrade.mjs', 45],
  ['verify-generic.mjs', 19],
];

const parse = (out) => {
  const p = /PASS (\d+)/.exec(out);
  const f = /FAIL (\d+)/.exec(out);
  return { pass: p ? +p[1] : -1, fail: f ? +f[1] : -1 };
};

export async function runE(rec) {
  rec.begin('E1', '交付包自带 6 套测试（在 sandbox 进程内复跑）', '确认被测包与交付时一致，没有本地漂移');
  let sum = 0, bad = 0;
  for (const [file, expect] of SUITES) {
    const t0 = Date.now();
    let out = '', code = 0;
    try {
      out = execFileSync(NODE, [join(PKG, 'tests', file)], { encoding: 'utf8', timeout: 180000, stdio: ['ignore', 'pipe', 'pipe'] });
    } catch (e) {
      code = e.status ?? -1;
      out = String(e.stdout || '') + String(e.stderr || '');
    }
    const r = parse(out);
    const ms = Date.now() - t0;
    const pass = r.pass === expect && r.fail === 0 && code === 0;
    rec.ok(`${file} = ${expect}`, pass, { ...r, code, expect, ms });
    rec.note(file, { pass: r.pass, fail: r.fail, ms });
    sum += Math.max(0, r.pass);
    if (!pass) bad++;
  }
  rec.note('total_pass', sum);
  rec.ok('六套合计 305', sum === 305, sum);
  rec.ok('无失败套件', bad === 0, bad);
  rec.end();

  rec.begin('E2', 'doctor 结构自检（47 项，指向沙盒新建库）', '包结构、schema、版本戳、模块可加载');
  try {
    const { mkdtempSync } = await import('node:fs');
    const { tmpdir } = await import('node:os');
    const { openDb, ensureSchema } = await import('../../src/kit/db.mjs');
    const dir = mkdtempSync(join(tmpdir(), 'dsh13-doctor-'));
    const dbPath = join(dir, 'mind.db');
    const db = await openDb(dbPath);
    await ensureSchema(db, { dbPath });
    db.close();
    let out = '', code = 0;
    try {
      out = execFileSync(NODE, [join(PKG, 'scripts', 'doctor.mjs'), '--db', dbPath], { encoding: 'utf8', timeout: 120000, stdio: ['ignore', 'pipe', 'pipe'] });
    } catch (e) { code = e.status ?? -1; out = String(e.stdout || '') + String(e.stderr || ''); }
    const m = /PASS (\d+) \/ FAIL (\d+)/.exec(out);
    const p = m ? +m[1] : -1, f = m ? +m[2] : -1;
    rec.ok('doctor 无失败（空库环境 43 项，有数据环境 47 项）', f === 0 && p >= 43, { p, f, code });
    rec.note('doctor', { pass: p, fail: f });
    if (f > 0) rec.note('doctor_tail', out.split('\n').filter(l => l.includes('FAIL')).slice(0, 8));
  } catch (e) { rec.fail(e); }
  rec.end();
}
