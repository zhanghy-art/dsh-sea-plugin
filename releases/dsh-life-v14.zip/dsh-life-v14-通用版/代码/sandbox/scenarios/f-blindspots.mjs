// sandbox/scenarios/f-blindspots.mjs — 豆包点名的 7 个盲区
//
// 对应关系：
//   F1 长时间运行稳定性（1000 写 + 反复检索 + 夜间巩固，采样内存曲线）
//   F2 夜间巩固完整流程（反射衰减 + 转冷 + FSRS + core 驱逐 + 次日恢复）
//   F3 端到端对话闭环（连续 16 轮：写 → 检索 → 组装 → 回复 → 再写）
//   F4 QQ 桥接边界（宿主适配层：私聊/群聊/@/欢迎语/多群隔离；不含 QQ 协议与网关）
//   F5 主动行为完整链路（想不想 → 该不该 → 能不能 → queued → sent → 追话）
//   F6 升级后「还是不是原来那个她」（v11.1 真库升级 → 真聊几句 → 旧事能召回）
//   F7 配置兼容（旧 config 直接用、新增项默认值、深合并、不污染入参）
import { mkdirSync, rmSync, existsSync } from 'node:fs';
import { join } from 'node:path';
import { Recorder, PKG, OWNER, SCOPE, DAY, iso, makeV11 } from '../lib.mjs';
import { openDb, ensureSchema } from '../../src/kit/db.mjs';
import { DEFAULTS, mergeConfig, SCHEMA_VERSION } from '../../src/kit/config.mjs';
import { writeMemory, scanCold, enforceTierQuota } from '../../src/memory/engine.mjs';
import { searchMemory } from '../../src/memory/search.mjs';
import { recover, saveState, defaultState, lifeTick } from '../../src/life/life-state.mjs';
import { ActivationBook } from '../../src/reflex/activation.mjs';
import { runNightly, capacityReport } from '../../src/maintenance/nightly.mjs';
import { decideProactive, planFollowup, canSpeak, hardGates } from '../../src/action/speak.mjs';
import { pickReviewCard, markFloated } from '../../src/memory/fsrs.mjs';
import { SessionLifecycle, buildHandoffPrompt, validateHandoff } from '../../src/session/lifecycle.mjs';
import { coreEligible, coreExit } from '../../src/memory/weight.mjs';
import { createGenericHost } from '../../src/host/generic.mjs';
import { cleanOutgoing } from '../../src/outlet/cleaner.mjs';
import createPlugin from '../../src/index.mjs';

const quietLog = { info() {}, warn() {}, error() {} };
const mkV11 = (dir, name = 'mind.db') => join(dir, name);

// 把 HOME 指到沙盒目录：插件内部的 embed-cache / cold 目录都落在沙盒里，不碰真实家目录
function withHome(dir, fn) {
  const old = process.env.HOME;
  process.env.HOME = dir;
  mkdirSync(join(dir, '.dsh', 'dsh-life', 'cold'), { recursive: true });
  return Promise.resolve()
    .then(fn)
    .finally(() => { if (old === undefined) delete process.env.HOME; else process.env.HOME = old; });
}

const avg = (a) => (a.length ? a.reduce((x, y) => x + y, 0) / a.length : 0);
const mb = (n) => Math.round(n / 1048576 * 10) / 10;

// ---------------------------------------------------------------- F1
async function f1(rec, work) {
  rec.begin('F1', '长时间运行稳定性（1000 写 + 1000 检索 + 4 次夜间巩固）',
    '模拟连续跑几个小时：内存会不会单调涨、库会不会卡住、功能会不会在半程后失效');
  const dir = work('F1');
  const dbPath = join(dir, 'mind.db');
  const cfg = mergeConfig(DEFAULTS, { memory: { dailyQuotaGlobal: 100000, dailyQuotaPerGroup: 100000 } });
  const db = await openDb(dbPath);
  await ensureSchema(db, { dbPath, cfg, log: quietLog });
  const dbSize0 = 0;

  const TOPICS = ['咖啡', '跑步', '猫', '代码', '做饭', '电影', '天气', '游戏', '读书', '旅行'];
  const samples = [];
  const t0 = Date.now();
  let writeOk = 0, writeRejected = 0;
  for (let r = 0; r < 20; r++) {
    for (let i = 0; i < 50; i++) {
      const n = r * 50 + i;
      const res = await writeMemory(db, {
        fact: `第${n}号观察：主人聊到${TOPICS[n % 10]}的第${n}次记录，细节编号${n}`,
        category: n % 7 === 0 ? 'person' : 'fact',
        scope: SCOPE, subject_qq: OWNER,
        source_kind: 'owner', source_id: OWNER,
        evidence_kind: 'user_sentence', evidence_ref: `f1-${n}`,
        raw: `原话第${n}条：今天又说到${TOPICS[n % 10]}`,
        importance: 0.5 + (n % 3) * 0.05,
      }, { cfg, now: Date.now() - (1000 - n) * 60000 });
      if (res.action === 'insert' || res.action === 'superseded') writeOk++; else writeRejected++;
      searchMemory(db, TOPICS[n % 10], { cfg, scope: SCOPE, topK: 6, now: Date.now() });
    }
    if (r % 5 === 4) runNightly(db, { now: Date.now(), cfg, force: true });
    const mu = process.memoryUsage();
    samples.push({ round: r, heap: mu.heapUsed, rss: mu.rss, rows: db.prepare('SELECT COUNT(*) AS n FROM memories').get().n });
  }
  const elapsed = Date.now() - t0;

  const early = samples.filter(s => s.round < 7);
  const late = samples.filter(s => s.round >= 13);
  const heapEarly = avg(early.map(s => s.heap));
  const heapLate = avg(late.map(s => s.heap));
  const rssEarly = avg(early.map(s => s.rss));
  const rssLate = avg(late.map(s => s.rss));
  const rows = db.prepare('SELECT COUNT(*) AS n FROM memories').get().n;

  rec.ok('1000 次写入无异常', writeOk + writeRejected === 1000, { writeOk, writeRejected });
  rec.ok('写入绝大多数被接受（≥95%）', writeOk >= 950, writeOk);
  rec.ok('库内行数随写入增长（≥900）', rows >= 900, rows);
  rec.ok('堆增长受控（未强制 GC，< 前段 ×5）', heapLate < heapEarly * 5,
    { early: mb(heapEarly), late: mb(heapLate) });
  rec.ok('RSS 后段受控（页缓存增长，< 前段 ×3 + 100MB）', rssLate < rssEarly * 3 + 100 * 1048576,
    { early: mb(rssEarly), late: mb(rssLate) });
  const last = samples[samples.length - 1];
  rec.ok('末轮仍可正常写入检索（行数 > 前轮）', last.rows > samples[0].rows, { first: samples[0].rows, last: last.rows });
  const tail = searchMemory(db, '咖啡', { cfg, scope: SCOPE, topK: 6 });
  rec.ok('1000 条之后仍能检索到早期内容', tail.items.length > 0, tail.items.length);
  rec.note('total_ms', elapsed);
  // 强制 GC 对照（sandbox/_mem.mjs，--expose-gc）：heap 稳定在 5.5–5.7MB，RSS 涨到 ~195MB 后平台化 = SQLite 页缓存，非泄漏
  rec.note('gc_control', { note: 'heap 平稳 5.5→5.7MB / RSS 56→195MB 后平台化', leak: false });
  rec.note('rows_final', rows);
  rec.note('heap_early_mb', mb(heapEarly));
  rec.note('heap_late_mb', mb(heapLate));
  rec.note('rss_early_mb', mb(rssEarly));
  rec.note('rss_late_mb', mb(rssLate));
  rec.note('heap_curve', samples.map(s => `${s.round}:${mb(s.heap)}`).join(' '));
  rec.note('db_size_kb', Math.round(dbSize0 / 1024) || Math.round((await import('node:fs')).statSync(dbPath).size / 1024));
  db.close();
  rec.end();
}

// ---------------------------------------------------------------- F2
async function f2(rec, work) {
  rec.begin('F2', '夜间巩固完整流程（衰减/转冷/FSRS/驱逐/次日恢复）',
    '几个维护动作串起来跑会不会互相干扰，跑完后第二天还能不能正常起来');
  const dir = work('F2');
  const dbPath = join(dir, 'mind.db');
  const cfg = DEFAULTS;
  const db = await openDb(dbPath);
  await ensureSchema(db, { dbPath, cfg, log: quietLog });
  const now = Date.now();

  // 60 条正常记忆（其中 3 条很老且低权重 → 应被转冷）
  for (let i = 0; i < 60; i++) {
    const old = i < 3;
    await writeMemory(db, {
      fact: `巩固测试第${i}条：${['事实', '偏好', '约定'][i % 3]}内容编号${i}`,
      category: i % 9 === 0 ? 'person' : i % 5 === 0 ? 'promise' : 'fact',
      scope: SCOPE, subject_qq: OWNER,
      source_kind: old ? 'model_inference' : 'owner', source_id: OWNER,
      evidence_kind: 'user_sentence', evidence_ref: `f2-${i}`,
      raw: `原话${i}`, importance: old ? 0.2 : 0.6,
    }, { cfg, now: now - (old ? 400 : i) * DAY });
  }
  // 待归档的失效记录
  db.prepare("INSERT INTO memories(scope,category,fact,importance,created_at,created_at_ms,invalid_reason) VALUES(?,?,?,?,?,?,?)")
    .run(SCOPE, 'fact', '这条已被证伪，应归档', 0.4, iso(now - 40 * DAY), now - 40 * DAY, 'contradicted');

  // 10 条候选：5 条过期
  for (let i = 0; i < 10; i++) {
    db.prepare('INSERT INTO candidates(scope,text,kind,category,status,confidence,created_at,expires_at) VALUES(?,?,?,?,?,?,?,?)')
      .run(SCOPE, `候选内容${i}`, 'fact', 'fact', 'pending', 0.5, now - (i + 1) * DAY, i < 5 ? now - DAY : now + 7 * DAY);
  }
  // 事件：120 条，其中 20 条超 90 天
  const insEv = db.prepare('INSERT INTO life_events(event_id,event_type,event_json,created_at) VALUES(?,?,?,?)');
  for (let i = 0; i < 120; i++) insEv.run(`ev${i}`, 'tick', JSON.stringify({ i }), now - (i < 20 ? 120 : i) * DAY);
  // 注入日志：50 条，其中 30 条超 30 天
  const insInj = db.prepare('INSERT INTO injection_log(memory_id,scope,kind,injected_at) VALUES(?,?,?,?)');
  for (let i = 0; i < 50; i++) insInj.run(1, SCOPE, 'auto', i < 30 ? now - 40 * DAY : now - DAY);
  // 反射：activation 0.8
  db.prepare('INSERT INTO reflexes(id,scope,trigger,response,activation,pain_level,created_at) VALUES(?,?,?,?,?,?,?)')
    .run(1, SCOPE, '累', '你听起来很累，先歇会儿', 0.8, 0.5, now);
  db.prepare('INSERT INTO reflexes(id,scope,trigger,response,activation,pain_level,created_at) VALUES(?,?,?,?,?,?,?)')
    .run(2, SCOPE, '饿', '记得吃饭', 0.8, 0.4, now);

  const book = new ActivationBook(cfg);
  book.load(db.prepare('SELECT * FROM reflexes').all());
  book.decayAll(120);          // 2 小时
  book.persist(db);
  const actAfter = db.prepare('SELECT activation FROM reflexes WHERE id = 1').get().activation;

  // core 驱逐：把 10 条标成 core（60 条的 3% = 1，应降到只剩 1 条）
  db.prepare("UPDATE memories SET protection_tier='core' WHERE id IN (SELECT id FROM memories WHERE invalid_reason IS NULL ORDER BY id LIMIT 10)").run();
  enforceTierQuota(db, now, cfg);
  const coreN = db.prepare("SELECT COUNT(*) AS n FROM memories WHERE protection_tier='core' AND invalid_reason IS NULL").get().n;
  const totalN = db.prepare('SELECT COUNT(*) AS n FROM memories WHERE invalid_reason IS NULL').get().n;

  // FSRS：设一条到期复习
  db.prepare("UPDATE memories SET protection_tier='stable', review_stability=1, recall_count=1, review_due_at=? WHERE id = 5").run(Date.now() - DAY);
  const card = pickReviewCard(db, { cfg, now, scoreOf: () => 0.6 });
  if (card) markFloated(db, card.mem.id, now);
  const dueAfter = db.prepare('SELECT review_due_at FROM memories WHERE id = ?').get(card?.mem?.id ?? 5)?.review_due_at ?? null;

  // 串跑夜间
  const rep = runNightly(db, { now, cfg });
  const cap = capacityReport(db);
  const again = runNightly(db, { now, cfg });   // 同日第二次

  rec.ok('反射衰减生效（0.8 → 明显下降）', actAfter < 0.35, actAfter);
  rec.ok('core 被压回配额（≤3%）', coreN <= Math.max(1, Math.floor(totalN * 0.03)), { coreN, totalN });
  rec.ok('FSRS 浮出 1 张卡', !!card, card ? card.mem.id : null);
  rec.ok('浮出后复习时间被推后', dueAfter && dueAfter > now, dueAfter);
  rec.ok('转冷 ≥1 条', rep.cold >= 1, rep.cold);
  rec.ok('过期候选被清理（本轮置 expired ≥5 条）', rep.candidates >= 5, rep.candidates);
  rec.ok('失效记录被归档（≥1 条）', rep.archive >= 1, rep.archive);
  rec.ok('事件按 90 天裁剪（120 条中 49 条超期 → 71）', cap.events === 71, cap.events);
  rec.ok('WAL checkpoint 正常', rep.wal === 'ok', rep.wal);
  rec.ok('同日第二次夜间被跳过（幂等）', again.skipped === true, again);
  rec.ok('夜间后仍有可检索记忆', searchMemory(db, '巩固测试', { cfg, scope: SCOPE, topK: 6 }).items.length > 0, null);

  // 次日启动：关库 → 重开 → 检查结构不重建、状态可恢复
  saveState(db, recover(db, cfg).state, now, cfg);
  db.close();
  const db2 = await openDb(dbPath);
  const info = await ensureSchema(db2, { dbPath, cfg, log: quietLog });
  const st = recover(db2, cfg).state;
  const hits2 = searchMemory(db2, '巩固测试', { cfg, scope: SCOPE, topK: 6 }).items.length;
  rec.ok('次日重启不重新迁移（added=0）', info.fresh === false && info.added === 0, { fresh: info.fresh, added: info.added });
  rec.ok('次日状态可恢复（revision 为数字且状态可读）', typeof st.revision === 'number', st.revision);
  rec.ok('次日检索仍命中', hits2 > 0, hits2);
  rec.note('nightly', rep);
  rec.note('capacity', cap);
  rec.note('reflex_activation_after', actAfter);
  db2.close();
  rec.end();
}

// ---------------------------------------------------------------- F3
async function f3(rec, work) {
  rec.begin('F3', '端到端对话闭环（连续 16 轮：写 → 检索 → 组装 → 回复 → 再写）',
    '一轮对话能跑通不代表十轮能接上；这里看第 N 轮还记不记得第 1 轮，以及压缩点之后接不接得上');
  const dir = work('F3');
  const dbPath = join(dir, 'mind.db');
  await withHome(dir, async () => {
    const events = [];
    const host = createGenericHost({
      log: quietLog,
      persona: () => '你叫小鱼，是一只住在主人电脑里的鲸鱼。',
      embed: async () => null,
      emit: (name, payload) => events.push({ name, payload }),
    });
    const plugin = createPlugin(host.ctx, { dbPath, ownerQq: OWNER });
    await host.start();

    const LINES = [
      ['我叫张含瑜，你叫我主人就行', '好，主人。'],
      ['我最喜欢喝冰美式，不加糖', '记住了，冰美式不加糖。'],
      ['我养了一只橘猫叫团子', '团子这名字好。'],
      ['我周三早上八点有课', '周三早八，我记着。'],
      ['我最近在健身，练完想吃饼干', '练完给你记一块饼干。'],
      ['我不吃香菜', '香菜不加。'],
      ['我晚上一般十一点睡', '十一点，那我早点催你。'],
      ['我电脑是 3060 的笔记本', '3060，够用了。'],
      ['我不喜欢别人叫我全名', '好，只叫主人。'],
      ['我周末喜欢睡到自然醒', '周末不吵你。'],
      ['我怕你突然不见了', '我不会突然不见。'],
      ['我生日是三月十二号', '三月十二，记下了。'],
      ['我讨厌下雨天出门', '下雨就在家待着。'],
      ['我最近在学做饭', '做饭我可以陪你聊。'],
      ['我不喝牛奶，乳糖不耐', '牛奶换成豆浆。'],
      ['今天先聊到这，晚安', '晚安，主人。'],
    ];

    const memTexts = [];
    let err = null;
    try {
      for (let i = 0; i < LINES.length; i++) {
        const [q, a] = LINES[i];
        const sections = await host.userMessage({ text: q, scope: SCOPE, ownerQq: OWNER });
        memTexts.push(sections.get('dsh-life.memory') || '');
        // 模拟模型侧：读到注入段就顺着说，同时把用户这句写成记忆（真实链路里由模型调工具完成）
        await writeMemory(plugin.db, {
          fact: q, category: i % 4 === 0 ? 'person' : 'fact',
          scope: SCOPE, subject_qq: OWNER,
          source_kind: 'owner', source_id: OWNER,
          evidence_kind: 'user_sentence', evidence_ref: `f3-${i}`,
          raw: q,
        }, { cfg: DEFAULTS, now: Date.now() + i * 1000 });
        await host.reply({ text: a, message: { scope: SCOPE, ownerQq: OWNER } });
      }
    } catch (e) { err = e; }

    const rows = plugin.db.prepare('SELECT COUNT(*) AS n FROM memories').get().n;
    const lastSections = memTexts[memTexts.length - 1] || '';
    // Explicit recall is allowed to bypass the automatic-injection cooldown.
    // Automatic injection still honors 6h cooldown; B5 guards that behavior.
    const tailHit = searchMemory(plugin.db, '冰美式', { cfg: DEFAULTS, scope: SCOPE, topK: 6, ignoreCooldown: true }).items;
    const summarizeEv = events.filter(e => e.name === 'dsh-life:summarize');

    rec.ok('16 轮无异常', !err, err && err.message);
    rec.ok('记忆累计 16 条', rows === 16, rows);
    rec.ok('第 1 轮无记忆可注入（空库）', memTexts[0].includes('(无记忆)') || memTexts[0].length < 80, memTexts[0].slice(0, 60));
    rec.ok('第 5 轮起能注入到前几轮的事', memTexts[4].includes('美式') || memTexts[4].includes('团子') || memTexts[4].includes('主人'), memTexts[4].slice(0, 120));
    rec.ok('第 16 轮仍记得第 2 轮的冰美式', tailHit.length > 0, tailHit.length);
    rec.ok('第 16 轮注入段非空', lastSections.length > 0, lastSections.length);
    rec.ok('触发过摘要事件（≥15 轮）', summarizeEv.length >= 1, summarizeEv.length);

    // 压缩后接续：写纪要 → 新会话首轮读得到
    const sess = new SessionLifecycle(plugin.db, { cfg: DEFAULTS, root: join(dir, 'cold') });
    const handoff = '刚才在聊主人的饮食习惯（冰美式不加糖、不吃香菜、乳糖不耐）和周三早八的课，说到一半。';
    sess.saveHandoff(SCOPE, handoff, Date.now());
    const sess2 = new SessionLifecycle(plugin.db, { cfg: DEFAULTS, root: join(dir, 'cold') });
    const back = sess2.readHandoff(SCOPE, Date.now());
    rec.ok('纪要可跨实例读回', back && back.includes('冰美式'), back ? back.slice(0, 40) : null);
    rec.ok('纪要通过格式校验', validateHandoff(handoff, ['聊吃的', '聊课']).ok !== false, validateHandoff(handoff, ['聊吃的', '聊课']));
    const checks = sess2.preResetChecks({ handoffText: handoff });
    rec.ok('重置五项检查全部可判定', checks && checks.ok === true && Array.isArray(checks.failed) && checks.failed.length === 0, checks);

    // 回声窗：同一句连发两次
    await host.reply({ text: '晚安，主人。', message: { scope: SCOPE, ownerQq: OWNER } });
    const echoRes = await host.reply({ text: '晚安，主人。', message: { scope: SCOPE, ownerQq: OWNER } });
    rec.ok('重复自己会被标记 rewrite', echoRes.rewrite === true, echoRes.rewrite);

    host.stop();
    rec.note('turns', LINES.length);
    rec.note('memories', rows);
    rec.note('summarize_events', summarizeEv.length);
  });
  rec.end();
}

// ---------------------------------------------------------------- F4
async function f4(rec, work) {
  rec.begin('F4', 'QQ 桥接边界（宿主适配层：私聊/群聊/@/欢迎语/多群隔离）',
    '真实 QQ 网关不在沙盒范围内；这里测到「消息事件进来 → 段落 → 清洗 → 写记忆」这一层，边界如实标注');
  const dir = work('F4');
  const dbPath = join(dir, 'mind.db');
  await withHome(dir, async () => {
    const host = createGenericHost({ log: quietLog, persona: () => '你叫小鱼。', embed: async () => null });
    const plugin = createPlugin(host.ctx, { dbPath, ownerQq: OWNER });
    await host.start();

    // 私聊：写一条，检查段落与预算
    await host.userMessage({ text: '我最喜欢喝冰美式', scope: `private:${OWNER}`, ownerQq: OWNER });
    await writeMemory(plugin.db, {
      fact: '主人最喜欢喝冰美式', category: 'preference', scope: `private:${OWNER}`,
      subject_qq: OWNER, source_kind: 'owner', source_id: OWNER,
      evidence_kind: 'user_sentence', evidence_ref: 'q1', raw: '我最喜欢喝冰美式',
    }, { cfg: DEFAULTS });
    const priv = await host.userMessage({ text: '还记得冰美式吗', scope: `private:${OWNER}`, ownerQq: OWNER });
    const privText = priv.get('dsh-life.memory') || '';

    // 群聊：同一句在群里问，只应看到群内/共享内容
    const grp = await host.userMessage({ text: '还记得冰美式吗', scope: 'group:777000111', groupId: '777000111' });
    const grpText = grp.get('dsh-life.memory') || '';

    // 群 A 写一条，群 B 不应看到
    await writeMemory(plugin.db, {
      fact: '群A定的团建时间是周五下午', category: 'fact', scope: 'group:777000111',
      source_kind: 'owner', source_id: OWNER, evidence_kind: 'user_sentence', evidence_ref: 'g1', raw: '周五下午团建',
    }, { cfg: DEFAULTS });
    rec.note('f4_rows', plugin.db.prepare('SELECT id,scope,category,fact FROM memories').all());
    rec.note('f4_direct', (() => { const r = searchMemory(plugin.db, '团建时间', { cfg: DEFAULTS, scope: 'group:777000111', topK: 6 }); return { hits: r.items.length, debug: r.debug }; })());
    const gA = await host.userMessage({ text: '团建时间', scope: 'group:777000111', groupId: '777000111' });
    const gB = await host.userMessage({ text: '团建时间', scope: 'group:888000222', groupId: '888000222' });

    // 唤醒类别：@ 与欢迎语在配置里存在，但 solo 默认不按它们主动开口
    const w = DEFAULTS.wake;
    rec.ok('私聊段落能注入偏好', privText.includes('冰美式'), privText.slice(0, 80));
    rec.ok('私聊预算 900 字内', privText.length <= 900, privText.length);
    rec.ok('群聊预算 700 字内', grpText.length <= 700, grpText.length);
    rec.ok('群聊看不到私聊内容', !grpText.includes('冰美式'), grpText.slice(0, 80));
    rec.ok('群 A 能看到自己的团建记忆', (gA.get('dsh-life.memory') || '').includes('团建'), (gA.get('dsh-life.memory') || '').slice(0, 60));
    rec.ok('群 B 看不到群 A 的记忆', !(gB.get('dsh-life.memory') || '').includes('团建'), (gB.get('dsh-life.memory') || '').slice(0, 60));
    rec.ok('九类唤醒含 at / welcome', w.classes.includes('at') && w.classes.includes('welcome'), w.classes.length);
    rec.ok('solo 模式不按 @ 主动开口', !w.soloEnabled.includes('at'), w.soloEnabled);

    // 出口清洗：QQ 侧最常见的两类脏输出
    const c1 = cleanOutgoing('查了一下：{"a":1,"b":2,"c":3}');
    const c2 = cleanOutgoing('{"result":"ok","n":12,"list":[1,2,3]}');
    rec.ok('带前缀的 JSON 不被整条吞掉', c1.text.includes('查了一下'), c1.text);
    rec.ok('纯 JSON 被折叠', c2.text === '[已获取信息]', c2.text);

    host.stop();
    rec.note('note', '本场景覆盖到宿主适配层（generic host），不含 QQ 协议/网关/OneBot 事件');
  });
  rec.end();
}

// ---------------------------------------------------------------- F5
async function f5(rec, work) {
  rec.begin('F5', '主动行为完整链路（想不想 → 该不该 → 能不能 → queued → sent → 追话）',
    '硬闸单测通过 ≠ 整条链能发出；这里从 utility 一路走到 queued/sent，再看追话的时机');
  const dir = work('F5');
  const dbPath = join(dir, 'mind.db');
  const cfg = DEFAULTS;

  // 下午两点，社交需求高、刚说完话
  const now = new Date('2026-10-31T14:00:00+08:00').getTime();
  const state = defaultState(now);
  state.needs.social = 0.9;
  state.needs.curiosity = 0.6;
  state.needs.rest = 0.7;
  state.needs.energy = 0.75;
  state.hormones = { cortisol: 0.3, dopamine: 0.6, oxytocin: 0.55, serotonin: 0.6 };
  state.social.lastUserAt = now - 40 * 60000;
  state.social.lastBotAt = now - 40 * 60000;
  state.social.lastProactiveAt = 0;
  state.counters.proactiveToday = 0;
  state.counters.proactiveThisHour = 0;

  const features = {
    explicit: false, relevance: 0.7, commitment: 0.6, relationship: 0.7, socialNeed: 0.9,
    curiosity: 0.5, contextualFit: 0.7, intrusionRisk: 0.2, repetitionRisk: 0.1, recentPenalty: 0.05,
  };
  const d = decideProactive({ needs: state.needs, features, state, now, wasOpen: false, preset: {}, cfg });
  const sp = canSpeak(state.needs, cfg);
  const gate = hardGates(state, now, cfg, { preset: cfg.preset });

  // 静默时段：同一状态放到凌晨三点
  const night = new Date('2026-10-31T03:00:00+08:00').getTime();
  const gateNight = hardGates(state, night, cfg, { preset: cfg.preset });

  // 追话时机
  const fu = planFollowup({ lastUserAt: now - 20000, lastBotAt: now - 90000, followupCountThisHour: 0, isPrivate: true, now }, cfg);
  const fuGroup = planFollowup({ lastUserAt: now - 20000, lastBotAt: now - 90000, followupCountThisHour: 0, isPrivate: false, now }, cfg);
  const fuBusy = planFollowup({ lastUserAt: now - 20000, lastBotAt: now - 90000, followupCountThisHour: 2, isPrivate: true, now }, cfg);

  // 走插件工具：queued → sent
  await withHome(dir, async () => {
    const host = createGenericHost({ log: quietLog, persona: () => '你叫小鱼。', embed: async () => null });
    // 25–26 点不存在 = 永不静默：否则晚上 11 点后跑沙盒，life_propose 会被 quiet 闸正常拦下，断言半夜红
    const plugin = createPlugin(host.ctx, { dbPath, ownerQq: OWNER, quietHours: [25, 26] });
    await host.start();
    // 让插件的运行时状态也处在这个时间点
    plugin.state.needs.social = 0.9;
    plugin.state.needs.rest = 0.7;
    plugin.state.social.lastBotAt = Date.now() - 40 * 60000;
    plugin.state.social.lastProactiveAt = 0;
    plugin.state.counters.proactiveToday = 0;

    const propose = host.tools.find(t => t.name === 'life_propose');
    const markSent = host.tools.find(t => t.name === 'life_mark_sent');
    let q1 = null, m1 = null;
    try {
      const em = await writeMemory(plugin.db, { fact: '主人喜欢橘猫', category: 'preference', scope: `private:${OWNER}`, subject_qq: OWNER, source_kind: 'owner', source_id: OWNER, evidence_kind: 'user_sentence', evidence_ref: 'p1', raw: '我喜欢橘猫' }, { cfg });
      q1 = await propose.run({ intent: 'mingle', say: '刚看到一只很像团子的橘猫', why: '主人喜欢猫', evidence_id: em.id, expected_effect: '换来一句回应' });
      if (q1 && q1.proposalId) m1 = await markSent.run({ proposal_id: q1.proposalId, host_message_id: 'host-1' });
    } catch (e) { rec.fail(e); }

    const row = plugin.db.prepare('SELECT status, sent_at FROM action_proposals ORDER BY id DESC LIMIT 1').get();
    rec.ok('整条链能走到 queued', q1 && q1.queued === true, q1);
    rec.ok('宿主回执后变 sent', m1 && m1.ok === true, m1);
    rec.ok('库内状态确实是 sent 且有发送时间', row && row.status === 'sent' && row.sent_at > 0, row);
    rec.ok('发送后计数 +1', plugin.state.counters.proactiveToday === 1, plugin.state.counters.proactiveToday);
    host.stop();
  });

  rec.ok('想不想：speakWeight 过线', sp.ok === true, sp);
  rec.ok('该不该：utility 过滞回线', d.utility >= 0.45, d.utility);
  rec.ok('能不能：硬闸放行', gate.ok === true, gate.failed);
  rec.ok('凌晨静默时段被硬闸拦下', gateNight.ok === false && gateNight.failed.includes('quiet'), gateNight.failed);
  rec.ok('追话：私聊 30–180 秒后', !!fu && fu.ok === true && fu.delayMs >= 30000 && fu.delayMs <= 180000 && fu.maxBubbles === 3, fu);
  rec.ok('追话：群聊不追', !!fuGroup && fuGroup.ok === false && fuGroup.reason === 'group', fuGroup);
  rec.ok('追话：一小时内第 3 次不再追', !!fuBusy && fuBusy.ok === false && fuBusy.reason === 'hourly', fuBusy);
  rec.note('decide', { send: d.send, stage: d.stage, utility: Math.round(d.utility * 1000) / 1000 });
  rec.note('followup', fu);
  rec.end();
}

// ---------------------------------------------------------------- F6
async function f6(rec, work) {
  rec.begin('F6', '升级后「还是不是原来那个她」（v11.1 真库 → 升级 → 真聊几句）',
    '数据一行没丢不等于她还是原来的她；这里拿旧库升级完直接聊，看旧事能不能召回、状态对不对');
  const dir = work('F6');
  const dbPath = mkV11(dir);
  makeV11(dbPath, { rows: 30 });
  // 再补几条真会问到的内容，模拟 v11.1 长期使用后的库
  const raw = (await import('node:sqlite')).DatabaseSync;
  const dbA = new raw(dbPath);
  const ins = dbA.prepare(`INSERT INTO memories(scope,subject_qq,category,fact,tags,evidence_kind,evidence_ref,source_kind,source_id,raw,importance,happened_at,time_granularity,created_at,audit_status)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
  const t = Date.now();
  ins.run(SCOPE, OWNER, 'person', '主人叫张含瑜，喜欢被叫主人', '["称呼"]', 'user_sentence', 'm2001', 'user', OWNER, '你叫我主人就行', 0.9, iso(t - 200 * DAY), 'day', iso(t - 200 * DAY), 'ok');
  ins.run(SCOPE, OWNER, 'preference', '主人最喜欢喝冰美式，不加糖', '["咖啡"]', 'user_sentence', 'm2002', 'user', OWNER, '冰美式不加糖', 0.85, iso(t - 150 * DAY), 'day', iso(t - 150 * DAY), 'ok');
  ins.run(SCOPE, OWNER, 'promise', '主人答应练完健身吃一块饼干', '["约定"]', 'user_sentence', 'm2003', 'user', OWNER, '练完就有饼干', 0.9, iso(t - 100 * DAY), 'day', iso(t - 100 * DAY), 'ok');
  ins.run(SCOPE, OWNER, 'fact', '主人养了一只橘猫叫团子', '["猫"]', 'user_sentence', 'm2004', 'user', OWNER, '我家猫叫团子', 0.8, iso(t - 60 * DAY), 'day', iso(t - 60 * DAY), 'ok');
  dbA.close();

  // 升级
  const db0 = await openDb(dbPath);
  const info = await ensureSchema(db0, { dbPath, cfg: DEFAULTS, log: quietLog });
  const rowsAfter = db0.prepare("SELECT COUNT(*) AS n FROM memories WHERE invalid_reason IS NULL").get().n;
  const st = recover(db0, DEFAULTS).state;
  db0.close();

  let privText = '';
  let reply = null;
  await withHome(dir, async () => {
    const host = createGenericHost({ log: quietLog, persona: () => '你叫小鱼，住在主人的电脑里。', embed: async () => null });
    const plugin = createPlugin(host.ctx, { dbPath, ownerQq: OWNER });
    await host.start();
    // 三句真会问到的
    const asks = ['你还记得我喜欢喝什么吗', '饼干约定呢', '我养的猫叫什么'];
    const got = [];
    for (const q of asks) {
      const sections = await host.userMessage({ text: q, scope: SCOPE, ownerQq: OWNER });
      got.push(sections.get('dsh-life.memory') || '');
    }
    privText = got.join('\n---\n');
    reply = await host.reply({ text: '记得的：{"coffee":"冰美式","cat":"团子"}', message: { scope: SCOPE, ownerQq: OWNER } });
    host.stop();
  });

  const hs = st.hormones || {};
  const hormoneOk = ['cortisol', 'dopamine', 'oxytocin', 'serotonin'].every(k => typeof hs[k] === 'number' && hs[k] >= 0 && hs[k] <= 1);
  rec.ok('升级后记忆行数充足', rowsAfter >= 30, rowsAfter);
  rec.ok('升级后激素已归一到 0–1', hormoneOk, hs);
  rec.ok('旧库有数据时不算 fresh', info.fresh === false, info.fresh);
  rec.ok('问「喜欢喝什么」能召回旧偏好', privText.includes('冰美式'), privText.slice(0, 100));
  rec.ok('问「饼干约定呢」能召回旧约定', privText.includes('饼干'), privText.slice(0, 100));
  rec.ok('问「养的猫」能召回团子', privText.includes('团子'), privText.slice(0, 100));
  rec.ok('E-1 只折整条 JSON：带前缀的 JSON 保留原样（如实记录边界）', reply && reply.text.includes('coffee'), reply && reply.text);
  rec.ok('回复清洗后仍有正文', reply && reply.text.length > 0, reply && reply.text);
  rec.note('memories_visible', rowsAfter);
  rec.note('section_sample', privText.slice(0, 240));
  rec.end();
}

// ---------------------------------------------------------------- F7
async function f7(rec, work) {
  rec.begin('F7', '配置兼容（旧 config 直接用 / 默认值 / 深合并 / 不污染入参）',
    'v11.1 的配置不改直接给 v13 用，新增项有没有默认值、旧项会不会丢、会不会把宿主对象改坏');
  // 一份「v11.1 时代」的配置：少了很多新键，还带一个已废弃的键
  const legacy = {
    preset: 'solo-qq',
    dbPath: 'D:/old/mind.db',
    quietHours: [22, 7],
    memory: { maxChars: 400 },
    retrieval: { topK: 4 },
    deprecatedKey: 'v11 时代的东西',
  };
  const snap = JSON.stringify(legacy);
  const cfg = mergeConfig(DEFAULTS, legacy);

  const checks = {
    '旧项 quietHours 保留': JSON.stringify(cfg.quietHours) === '[22,7]',
    '旧项 memory.maxChars 覆盖': cfg.memory.maxChars === 400,
    '同层未覆盖项仍是默认': cfg.memory.dedupDice === DEFAULTS.memory.dedupDice,
    '旧项 retrieval.topK 覆盖': cfg.retrieval.topK === 4,
    '新增段 wake 有默认': !!cfg.wake && Array.isArray(cfg.wake.classes) && cfg.wake.classes.length === 9,
    '新增段 upgrade 有默认': cfg.upgrade && cfg.upgrade.backup === true && cfg.upgrade.backupKeep === 3,
    '新增字段 candidateAcceptRerun 默认 true': cfg.memory.candidateAcceptRerun === true,
    'profile 默认 dsh': cfg.profile === 'dsh',
    'speak.hardGate 默认 false（软加项）': cfg.speak.hardGate === false,
    '激素基线是 0–1 标度': cfg.hormone.init.cortisol <= 1 && cfg.hormone.floor.cortisol <= 1,
    '预算 900/700 未被旧配置带偏': cfg.budget.private === 900 && cfg.budget.group === 700,
    '未知键不覆盖已知项（merge 语义如实保留）': cfg.memory.maxChars === 400 && cfg.budget.private === 900,
    '入参未被就地修改': JSON.stringify(legacy) === snap,
  };
  for (const [k, v] of Object.entries(checks)) rec.ok(k, v, v ? undefined : cfg);

  // 深合并不误伤兄弟字段
  const deep = mergeConfig(DEFAULTS, { memory: { maxChars: 300 }, wake: { ack: { maxChars: 5 } } });
  rec.ok('深合并：memory 其它项保留', deep.memory.maxChars === 300 && deep.memory.dedupDice === DEFAULTS.memory.dedupDice, deep.memory.maxChars);
  rec.ok('深合并：wake.ack 其它项保留', deep.wake.ack.maxChars === 5 && deep.wake.ack.windowS === DEFAULTS.wake.ack.windowS, deep.wake.ack);

  // 两份不同配置互不影响（宿主改一个不该影响另一个）
  const a = mergeConfig(DEFAULTS, { memory: { maxChars: 111 } });
  const b = mergeConfig(DEFAULTS, { memory: { maxChars: 222 } });
  rec.ok('两份配置互相隔离', a.memory.maxChars === 111 && b.memory.maxChars === 222 && DEFAULTS.memory.maxChars === 500,
    { a: a.memory.maxChars, b: b.memory.maxChars, d: DEFAULTS.memory.maxChars });

  // 脏值：给错类型不应抛
  let threw = null;
  try {
    const bad = mergeConfig(DEFAULTS, { budget: 900, quietHours: '23-8', memory: null });
    rec.note('dirty_config_result', { budget: bad.budget, quietHours: bad.quietHours, memoryIsObject: typeof bad.memory });
  } catch (e) { threw = e; }
  rec.ok('脏配置不致抛异常', !threw, threw && threw.message);

  // 同一个旧配置连续启动两次，行为一致
  const p1 = join(work('F7'), 'a.db');
  const p2 = join(work('F7b') || work('F7'), 'b.db');
  const r1 = await openDb(p1); await ensureSchema(r1, { dbPath: p1, cfg, log: quietLog });
  const r2 = await openDb(p2); await ensureSchema(r2, { dbPath: p2, cfg, log: quietLog });
  const v1 = r1.prepare("SELECT v FROM kv WHERE k='schema_version'").get()?.v;
  const v2 = r2.prepare("SELECT v FROM kv WHERE k='schema_version'").get()?.v;
  rec.ok('旧配置下建库版本戳一致', v1 === String(SCHEMA_VERSION) && v2 === String(SCHEMA_VERSION), { v1, v2 });
  r1.close(); r2.close();
  rec.note('legacy_cfg_keys', Object.keys(legacy).join(','));
  rec.end();
}

export async function runF(rec, work) {
  await f1(rec, work);
  await f2(rec, work);
  await f3(rec, work);
  await f4(rec, work);
  await f5(rec, work);
  await f6(rec, work);
  await f7(rec, work);
}
