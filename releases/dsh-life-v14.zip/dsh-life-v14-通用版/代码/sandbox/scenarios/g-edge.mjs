// sandbox/scenarios/g-edge.mjs — 豆包「还没测到的」5 条
//
//   G1 真 QQ 网关集成 —— 真网关接不进来（需要 QQ 号、协议端、网关进程），
//      这里测「协议事件 → 插件事件」这一层的形状：OneBot v11 消息段怎么翻译成
//      { text, scope, ownerQq, groupId, userId }，@/图片/引用/纯表情/超长怎么过。
//      参考实现 onebotToLifeEvent() 一并给出，宿主照抄即可接线。
//   G2 几万条记忆后的性能衰减 —— 1 万 / 3 万 / 5 万行三档，比检索 P50/P95 与写入延迟，
//      判断「全表打分」是不是随行数线性恶化。
//   G3 多群同时在线（33 个会话）—— 33 个群轮转 165 轮，看内存/耗时/隔离。
//   G4 进程被强杀后的恢复 —— 子进程写一半被 SIGKILL，重启查完整性、有无半截行、能否继续写。
//   G5 磁盘满 —— 用 SQLite 的 `PRAGMA max_page_count` 精确模拟「盘满」，
//      看是静默失败还是抛错、事务有没有回滚、库还坏没坏。
import { spawn } from 'node:child_process';
import { writeFileSync, rmSync, mkdirSync } from 'node:fs';
import { join } from 'node:path';
import { Recorder, PKG, OWNER, SCOPE, DAY, iso, makeV11 } from '../lib.mjs';
import { openDb, ensureSchema, kvGet } from '../../src/kit/db.mjs';
import { DEFAULTS } from '../../src/kit/config.mjs';
import { writeMemory } from '../../src/memory/engine.mjs';
import { searchMemory } from '../../src/memory/search.mjs';
import { createGenericHost } from '../../src/host/generic.mjs';
import createPlugin from '../../src/index.mjs';

const quietLog = { info() {}, warn() {}, error() {} };
const ms = (t) => Math.round(t);
const pct = (arr, p) => { const a = [...arr].sort((x, y) => x - y); return a[Math.min(a.length - 1, Math.floor(a.length * p))]; };

// ============================================================ G1 适配器
/**
 * OneBot v11 消息事件 → dsh-life 的 userMessage 入参。
 * 宿主（QQ 桥接）照这个函数接线即可；它只做格式转换，不碰记忆。
 */
export function onebotToLifeEvent(ev, { selfId = null } = {}) {
  const segs = Array.isArray(ev?.message) ? ev.message : [];
  const isGroup = ev?.message_type === 'group' || (ev?.group_id != null);
  const groupId = ev?.group_id != null ? String(ev.group_id) : null;
  const userId = ev?.user_id != null ? String(ev.user_id) : (ev?.sender?.user_id != null ? String(ev.sender.user_id) : null);
  const ats = segs.filter((s) => s?.type === 'at').map((s) => String(s?.data?.qq ?? ''));
  const replyId = segs.find((s) => s?.type === 'reply')?.data?.id ?? null;
  const images = segs.filter((s) => s?.type === 'image').length;
  let text = '';
  for (const s of segs) {
    if (s?.type === 'text') text += s?.data?.text ?? '';
    else if (s?.type === 'at' || s?.type === 'image' || s?.type === 'face') text += ' ';
    else if (s?.type === 'mface' || s?.type === 'record' || s?.type === 'video' || s?.type === 'file') text += ' ';
  }
  if (!text.trim()) text = String(ev?.raw_message ?? '').replace(/\[CQ:[^\]]+\]/g, ' ').trim();
  text = text.replace(/\s+/g, ' ').trim().slice(0, 2000);
  return {
    text,
    scope: isGroup ? `group:${groupId}` : `private:${userId}`,
    groupId: isGroup ? groupId : null,
    userId,
    ownerQq: isGroup ? null : userId,
    atSelf: selfId != null && ats.includes(String(selfId)),
    atOthers: ats.filter((x) => x !== String(selfId)),
    replyId,
    images,
    isGroup,
    // 纯图片/表情、或只有 @ 没有文字：不该进记忆管线（否则会写入一条空事实）
    skipMemory: !text.trim(),
  };
}

async function g1(rec, work) {
  rec.begin('G1', '真 QQ 网关链路（协议事件 → 插件事件 → 段落 → 可发送文本）',
    '真网关（QQ 号+协议端+SnowLuma）不在沙盒内；这里测桥接适配层的形状与边界，参考实现随包给出');
  const dir = work('G1');
  const selfId = '10001';
  const ox = OWNER;

  const evGroup = {
    post_type: 'message', message_type: 'group', group_id: 777000111, user_id: Number(ox),
    raw_message: '[CQ:at,qq=10001] 团建定在周五了',
    message: [{ type: 'at', data: { qq: '10001' } }, { type: 'text', data: { text: ' 团建定在周五了' } }],
  };
  const e1 = onebotToLifeEvent(evGroup, { selfId });
  rec.ok('群消息 → scope group:<id>', e1.scope === 'group:777000111', e1.scope);
  rec.ok('@ 被剥离、不进正文', e1.text === '团建定在周五了', e1.text);
  rec.ok('识别出 @ 的是自己', e1.atSelf === true, e1.atSelf);
  rec.ok('群消息不带 ownerQq（发话人≠主人）', e1.ownerQq === null, e1.ownerQq);

  const evPrivate = {
    post_type: 'message', message_type: 'private', user_id: Number(ox), raw_message: '我喜欢冰美式',
    message: [{ type: 'text', data: { text: '我喜欢冰美式' } }],
  };
  const e2 = onebotToLifeEvent(evPrivate, { selfId });
  rec.ok('私聊 → scope private:<qq>', e2.scope === `private:${ox}`, e2.scope);
  rec.ok('私聊带 ownerQq', e2.ownerQq === ox, e2.ownerQq);

  const evImageOnly = { message_type: 'group', group_id: 7, user_id: 9, raw_message: '[CQ:image,file=a.jpg]', message: [{ type: 'image', data: { file: 'a.jpg' } }] };
  const e3 = onebotToLifeEvent(evImageOnly, { selfId });
  rec.ok('纯图片消息：正文为空', e3.text === '', JSON.stringify(e3.text));
  rec.ok('纯图片消息：skipMemory=true（不进记忆管线）', e3.skipMemory === true, e3);

  const evReply = { message_type: 'group', group_id: 7, user_id: 9, raw_message: '对', message: [{ type: 'reply', data: { id: '18446744073709551615' } }, { type: 'text', data: { text: '对' } }] };
  const e4 = onebotToLifeEvent(evReply, { selfId });
  rec.ok('引用回复：识别 replyId', e4.replyId === '18446744073709551615', e4.replyId);
  rec.ok('引用段不混进正文', e4.text === '对', e4.text);

  const long = '啊'.repeat(3000);
  const e5 = onebotToLifeEvent({ message_type: 'private', user_id: 9, message: [{ type: 'text', data: { text: long } }] }, { selfId });
  rec.ok('超长正文被截到 2000 字（不撑爆预算）', e5.text.length === 2000, e5.text.length);

  // 真跑一条：适配后的入参交给插件，看段落与可发送文本
  const dbPath = join(dir, 'mind.db');
  const host = createGenericHost({ log: quietLog, persona: () => '你叫小鱼，住在主人的电脑里。', embed: async () => null });
  const plugin = createPlugin(host.ctx, { dbPath, ownerQq: ox });
  await host.start();
  await writeMemory(plugin.db, {
    fact: '群A的团建定在周五下午', category: 'fact', scope: 'group:777000111',
    source_kind: 'owner', source_id: ox, evidence_kind: 'user_sentence', evidence_ref: 'g1', raw: '团建周五',
  }, { cfg: DEFAULTS });
  const sections = await host.userMessage({ text: e1.text, scope: e1.scope, groupId: e1.groupId, message: e1 });
  const secText = sections.get('dsh-life.memory') || '';
  rec.ok('适配事件能走完 onPreStep 并产出段落', typeof secText === 'string' && secText.length > 0, secText.slice(0, 60));
  const reply = await host.reply({ text: '好，记下了。{"ok":1}', message: { scope: e1.scope, groupId: e1.groupId } });
  rec.ok('出站文本经出口清洗（E-1 只折整条 JSON：带前缀不折，如实记录）', reply && typeof reply.text === 'string' && reply.text.includes('"ok":1'), reply && reply.text);
  rec.ok('入站 body 不含 CQ 码', !e1.text.includes('[CQ:'), e1.text);
  host.stop();
  rec.note('adapter', { group: e1.scope, private: e2.scope, imageSkip: e3.skipMemory, replyId: e4.replyId });
  rec.end();
}

// ============================================================ G2 几万条衰减
function seedRows(db, n, tag) {
  const ins = db.prepare(`INSERT INTO memories(scope,subject_qq,category,fact,raw,importance,belief,created_at,created_at_ms,region,protection_tier,cold,evidence_kind,evidence_ref,source_kind,source_id,audit_status,happened_at_ms)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
  const TOPICS = ['咖啡', '跑步', '猫', '代码', '做饭', '电影', '天气', '游戏', '读书', '旅行'];
  const now = Date.now();
  db.exec('BEGIN');
  for (let i = 0; i < n; i++) {
    const t = now - (n - i) * 60000;
    ins.run(SCOPE, OWNER, i % 9 === 0 ? 'person' : 'fact',
      `${tag}第${i}条：主人聊到${TOPICS[i % 10]}的记录${i}`, `原话${i}`, 0.5 + (i % 3) * 0.05, 0.8,
      iso(t), t, 'daily', 'normal', 0, 'user_sentence', `${tag}-${i}`, 'owner', OWNER, 'ok', t);
  }
  db.exec('COMMIT');
}

async function g2(rec, work) {
  rec.begin('G2', '几万条记忆后的性能衰减（1 万 / 3 万 / 5 万行）',
    'D2 只测了 3000 行；这里看全表打分随行数的曲线，判断会不会随使用月数越来越慢');
  const dir = work('G2');
  const TOPICS = ['咖啡', '跑步', '猫', '代码', '做饭'];
  const rows = [];
  for (const n of [10000, 30000, 50000]) {
    const dbPath = join(dir, `m${n}.db`);
    const db = await openDb(dbPath);
    await ensureSchema(db, { dbPath, cfg: DEFAULTS, log: quietLog });
    const tSeed = performance.now();
    seedRows(db, n, `s${n}`);
    const seedMs = performance.now() - tSeed;
    // 检索 50 次
    const lat = [];
    for (let i = 0; i < 50; i++) {
      const t = performance.now();
      searchMemory(db, TOPICS[i % TOPICS.length], { cfg: DEFAULTS, scope: SCOPE, topK: 6 });
      lat.push(performance.now() - t);
    }
    // 写入 50 次
    const wlat = [];
    for (let i = 0; i < 50; i++) {
      const t = performance.now();
      await writeMemory(db, {
        fact: `新写入第${i}条关于${TOPICS[i % 5]}的事`, category: 'fact', scope: SCOPE, subject_qq: OWNER,
        source_kind: 'owner', source_id: OWNER, evidence_kind: 'user_sentence', evidence_ref: `n${n}-${i}`, raw: `新${i}`,
      }, { cfg: DEFAULTS });
      wlat.push(performance.now() - t);
    }
    rows.push({ n, seedMs, p50: pct(lat, 0.5), p95: pct(lat, 0.95), max: Math.max(...lat), w50: pct(wlat, 0.5), w95: pct(wlat, 0.95) });
    db.close();
  }
  rec.note('curve', rows.map((r) => ({ n: r.n, searchP50: ms(r.p50), searchP95: ms(r.p95), writeP50: ms(r.w50) })));
  const [r1, r2, r3] = rows;
  rec.ok('检索不随行数爆炸（5 万行的 P95 < 1 万行的 10 倍）', r3.p95 < r1.p95 * 10, { p95_10k: ms(r1.p95), p95_50k: ms(r3.p95) });
  rec.ok('5 万行检索 P95 仍在可交互范围（< 500ms）', r3.p95 < 500, ms(r3.p95));
  rec.ok('写入延迟不随行数爆炸（5 万 vs 1 万 < 5 倍）', r3.w95 < Math.max(50, r1.w95 * 5), { w95_10k: ms(r1.w95), w95_50k: ms(r3.w95) });
  rec.ok('写入仍在可接受范围（5 万行 P50 < 150ms）', r3.w50 < 150, ms(r3.w50));
  rec.ok('写入随行数增长但不失控（5 万 vs 1 万 P50 < 5 倍）', r3.w50 < Math.max(20, r1.w50 * 5), { w50_10k: ms(r1.w50), w50_50k: ms(r3.w50) });
  rec.ok('5 万行仍能召回（不是只快不准）', searchMemory((await (async () => { const db = await openDb(join(dir, 'm50000.db')); return db; })()), '咖啡', { cfg: DEFAULTS, scope: SCOPE, topK: 6 }).items.length > 0, null);
  rec.end();
}

// ============================================================ G3 多群并发
async function g3(rec, work) {
  rec.begin('G3', '多群同时在线（33 个会话轮转 165 轮）',
    '你平时挂着 33 个会话；这里测 33 个群轮流说话时内存、耗时、互相隔离');
  const dir = work('G3');
  const dbPath = join(dir, 'mind.db');
  const host = createGenericHost({ log: quietLog, persona: () => '你叫小鱼。', embed: async () => null });
  const plugin = createPlugin(host.ctx, { dbPath, ownerQq: OWNER });
  await host.start();
  const db = plugin.db;

  const GROUPS = 33;
  const base = Date.now();
  // 每群写一条自己的暗号
  for (let g = 0; g < GROUPS; g++) {
    await writeMemory(db, {
      fact: `群${g}的暗号是海豚#${g}#`, category: 'fact', scope: `group:${700000000 + g}`,
      source_kind: 'owner', source_id: OWNER, evidence_kind: 'user_sentence', evidence_ref: `g${g}`, raw: `海豚#${g}#`,
    }, { cfg: DEFAULTS });
  }
  const mu0 = process.memoryUsage();
  const lat = [];
  let leak = 0;       // cross-group leakage: always forbidden
  let missingSelf = 0; // first turn of each group must hit its own anchor
  for (let r = 0; r < 5; r++) {
    for (let g = 0; g < GROUPS; g++) {
      const t = performance.now();
      const sec = await host.userMessage({ text: `海豚#${g}#`, scope: `group:${700000000 + g}`, groupId: String(700000000 + g) });
      lat.push(performance.now() - t);
      const txt = sec.get('dsh-life.memory') || '';
      const hitSelf = txt.includes(`海豚#${g}#`);
      const others = Array.from({ length: GROUPS }, (_, k) => k).filter((k) => k !== g && txt.includes(`海豚#${k}#`));
      if (others.length) leak++;
      if (r === 0 && !hitSelf) missingSelf++;
    }
  }
  const mu1 = process.memoryUsage();
  rec.ok('33 群 × 5 轮 = 165 轮无异常且首轮各自命中自己', leak === 0 && missingSelf === 0, { leak, missingSelf });
  rec.ok('群之间零串味（165 轮内没有一次读到别的群暗号）', leak === 0, { leak });
  rec.ok('每轮耗时 P95 < 100ms（33 会话轮转仍可交互）', pct(lat, 0.95) < 100, ms(pct(lat, 0.95)));
  rec.ok('内存没有随会话数线性膨胀（heap 增量 < 160MB）', mu1.heapUsed - mu0.heapUsed < 160 * 1048576, {
    heapMB: +((mu1.heapUsed - mu0.heapUsed) / 1048576).toFixed(1),
    rssMB: +((mu1.rss - mu0.rss) / 1048576).toFixed(1),
  });
  rec.ok('总行数 = 33 条（没有跨群重复写入）', db.prepare('SELECT COUNT(*) AS n FROM memories').get().n === GROUPS, db.prepare('SELECT COUNT(*) AS n FROM memories').get().n);
  rec.note('latency', { p50: ms(pct(lat, 0.5)), p95: ms(pct(lat, 0.95)), max: ms(Math.max(...lat)) });
  host.stop();
  rec.end();
}

// ============================================================ G4 强杀恢复
async function g4(rec, work) {
  rec.begin('G4', '进程被强杀后的恢复（SIGKILL → 重启）',
    '正常关闭测过，直接 kill 没测；这里在写入中途强杀子进程，再看库能不能开、有没有半截行');
  const dir = work('G4');
  const dbPath = join(dir, 'mind.db');
  const db0 = await openDb(dbPath);
  await ensureSchema(db0, { dbPath, cfg: DEFAULTS, log: quietLog });
  db0.close();

  const writer = join(dir, 'writer.mjs');
  writeFileSync(writer, `
import { openDb } from ${JSON.stringify(new URL('../../src/kit/db.mjs', import.meta.url).href)};
import { DEFAULTS } from ${JSON.stringify(new URL('../../src/kit/config.mjs', import.meta.url).href)};
import { writeMemory } from ${JSON.stringify(new URL('../../src/memory/engine.mjs', import.meta.url).href)};
const dbPath = process.argv[2];
const db = await openDb(dbPath);
let n = 0;
process.stdout.write('ready\\n');
for (let i = 0; i < 5000; i++) {
  await writeMemory(db, {
    fact: '强杀测试第' + i + '条：写一半就断电', category: 'fact', scope: 'private:${OWNER}',
    subject_qq: '${OWNER}', source_kind: 'owner', source_id: '${OWNER}',
    evidence_kind: 'user_sentence', evidence_ref: 'k' + i, raw: 'k' + i,
  }, { cfg: DEFAULTS });
  n++;
  if (n % 20 === 0) process.stdout.write('n=' + n + '\\n');
}
db.close();
`, 'utf8');

  const child = spawn(process.execPath, [writer, dbPath], { stdio: ['ignore', 'pipe', 'pipe'] });
  let wrote = 0;
  const killed = await new Promise((resolve) => {
    const onData = (buf) => {
      const s = String(buf);
      const m = s.match(/n=(\d+)/);
      if (m) wrote = Number(m[1]);
      if (wrote >= 60) {
        child.kill('SIGKILL');
        resolve({ at: wrote });
      }
    };
    child.stdout.on('data', onData);
    child.stderr.on('data', () => {});
    child.on('exit', () => resolve({ at: wrote, exited: true }));
    setTimeout(() => { try { child.kill('SIGKILL'); } catch { /* 已经没了 */ } resolve({ at: wrote, timeout: true }); }, 8000);
  });

  const db = await openDb(dbPath);
  const integ = db.prepare('PRAGMA integrity_check').get();
  const n = db.prepare('SELECT COUNT(*) AS n FROM memories').get().n;
  const half = db.prepare("SELECT COUNT(*) AS n FROM memories WHERE fact IS NULL OR fact = ''").get().n;
  const ver = db.prepare("SELECT COUNT(*) AS n FROM memories WHERE evidence_ref IS NULL").get().n;
  rec.ok('强杀发生在写入中途（不是写完才杀）', killed.at >= 60, killed);
  rec.ok('强杀后库仍能打开', !!integ, integ);
  rec.ok('integrity_check = ok', String(integ?.integrity_check).toLowerCase() === 'ok', integ);
  rec.ok('已提交的行还在（≥60 条）', n >= 60, n);
  rec.ok('没有半截行（fact 空 / evidence_ref 空 均为 0）', half === 0 && ver === 0, { half, ver });
  // 还能继续写 + 读
  const w = await writeMemory(db, {
    fact: '强杀恢复后的第一条', category: 'fact', scope: SCOPE, subject_qq: OWNER,
    source_kind: 'owner', source_id: OWNER, evidence_kind: 'user_sentence', evidence_ref: 'post-kill', raw: '恢复',
  }, { cfg: DEFAULTS });
  const hit = searchMemory(db, '强杀恢复', { cfg: DEFAULTS, scope: SCOPE, topK: 6 })
    .items.some((x) => String(x.mem.fact).includes('强杀恢复'));
  rec.ok('强杀后还能继续写（返回 verified）', w.verify === 'verified', w);
  rec.ok('强杀后新写的能立刻检索到', hit, hit);
  rec.ok('WAL 没留下未提交的中间态（行数 = 提交数）', n >= 60 && half === 0, { n });
  rec.note('kill', { wroteAtKill: killed.at, rowsAfter: n });
  db.close();
  rec.end();
}

// ============================================================ G5 磁盘满
async function g5(rec, work) {
  rec.begin('G5', '磁盘满的行为（SQLITE_FULL）',
    '用 PRAGMA max_page_count 精确模拟盘满：看写入是静默失败还是抛错、事务回不回滚、库坏不坏');
  const dir = work('G5');
  const dbPath = join(dir, 'mind.db');
  const db = await openDb(dbPath);
  await ensureSchema(db, { dbPath, cfg: DEFAULTS, log: quietLog });
  // 先写 5 条正常数据
  for (let i = 0; i < 5; i++) {
    await writeMemory(db, { fact: `盘满前的第${i}条`, category: 'fact', scope: SCOPE, subject_qq: OWNER, source_kind: 'owner', source_id: OWNER, evidence_kind: 'user_sentence', evidence_ref: `p${i}`, raw: `p${i}` }, { cfg: DEFAULTS });
  }
  const before = db.prepare('SELECT COUNT(*) AS n FROM memories').get().n;
  const pageCount = db.prepare('PRAGMA page_count').get().page_count;
  db.exec(`PRAGMA max_page_count = ${pageCount + 2}`);   // 只留 2 页余量（约 8KB）

  let err = null;
  let silent = 0;
  let written = 0;
  let i = 0;
  for (; i < 400; i++) {
    try {
      const r = await writeMemory(db, {
        fact: `盘满测试第${i}条：这条应该写不进去了，长度拉长到 3KB 让它几轮就撑满 ${'x'.repeat(3000)}`,
        category: 'fact', scope: SCOPE, subject_qq: OWNER, source_kind: 'owner', source_id: OWNER,
        evidence_kind: 'user_sentence', evidence_ref: `full${i}`, raw: `full${i}`,
      }, { cfg: DEFAULTS });
      // 引擎返回 failed/unknown 但没抛 —— 也算「没静默」需要有明确信号
      written++;
      if (r && (r.verify === 'failed' || r.action === 'rejected')) silent++;
    } catch (e) {
      err = e;
      break;
    }
  }
  const after = db.prepare('SELECT COUNT(*) AS n FROM memories').get().n;
  // 实测：node:sqlite 在 SQLITE_FULL 时抛出，但引擎 writeMemory 捕获后返回 { verify:'failed' }。
  // 两种都算“有信号”；真正危险的是“调用方以为成功”。
  const signaled = !!err || silent > 0;
  rec.ok('盘满有明确信号（抛错或返回 failed，不静默吞掉）', signaled, { err: err && String(err.message).slice(0, 80), silentFailed: silent });
  rec.ok('信号能区分「写失败」与「写成功」（失败条数 > 0 且不记为 insert）', silent > 0 || !!err, { silentFailed: silent });
  rec.ok('盘满之前的行一条不少', before >= 5, { before, after });
  rec.ok('至少写成功过几条（说明不是一上来就满）', written >= 1, { written });
  rec.ok('失败写入没有留下半截行（成功的盘满行 + 盘满前 5 条 = 总行数）', after === 5 + db.prepare("SELECT COUNT(*) AS n FROM memories WHERE fact LIKE '盘满测试%'").get().n, {
    total: after, partial: db.prepare("SELECT COUNT(*) AS n FROM memories WHERE fact LIKE '盘满测试%'").get().n,
  });
  // 解除限制 → 还能写（没被永久卡死）
  db.exec('PRAGMA max_page_count = 1073741823');
  const ok2 = await writeMemory(db, { fact: '盘满恢复后写入成功', category: 'fact', scope: SCOPE, subject_qq: OWNER, source_kind: 'owner', source_id: OWNER, evidence_kind: 'user_sentence', evidence_ref: 'full-ok', raw: 'ok' }, { cfg: DEFAULTS });
  rec.ok('空间恢复后能继续写（库没被卡死）', ok2.verify === 'verified', ok2);
  rec.ok('库仍可读（integrity ok）', String(db.prepare('PRAGMA integrity_check').get().integrity_check).toLowerCase() === 'ok', null);
  rec.note('full', { at: i, before, after, silentSignal: silent, err: err && String(err.message).slice(0, 160) });
  db.close();
  rec.end();
}

export async function runG(rec, work) {
  await g1(rec, work);
  await g2(rec, work);
  await g3(rec, work);
  await g4(rec, work);
  await g5(rec, work);
}
