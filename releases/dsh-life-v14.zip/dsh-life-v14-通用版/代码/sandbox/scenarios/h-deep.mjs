// sandbox/scenarios/h-deep.mjs — H 组：v14.1.2 深度沙盒（2026-11-06 新增）
//
// 背景：主人要求「范围最广、要求最严」的沙盒测试，且要求把发现的问题
// 「直接在桌面对应文件里新加沙盒问题测试并解决」。A–G 组是交付包自带
// 46 场景 / 305 断言；H 组专测本轮新发现的三件事，全部用模拟数据：
//
//   H1  G4「SIGKILL 后 database is locked」修复回归（原 A–G 基线 1 个 ERR）
//       —— 复刻 g4 的强杀子进程，验证 openDb 的 busy_timeout + tx 有限重试
//          能让父进程继续写、integrity 仍 ok、无半截行。
//   H2  toolset 分级（full / lite）—— 默认零影响、lite 只 5 个工具、
//       5 个核心工具可调用、8 个非核心工具确实不注册、schema 估算下降。
//   H3  skipIdleTurn 空唤醒复用（两种宿主形状）—— wakeReason 显式路径、
//       无文本兜底、文本相同兜底、首轮边界、reflex 不复播、
//       generic 每轮 clear() 下仍一字不差复用上一轮段。
//   H4  token 量化与缓存语义 —— 直接读 rt 上的可观测量，输出可横比硬数据。
//   H5  并发写入 BUSY 容错 —— 两个连接交替 BEGIN IMMEDIATE，验证重试不吞错、
//       非 BUSY 业务异常仍原样抛出、重试次数有上限。
//   H6  老库脏数据 + 新开关共存 —— makeV11 造的脏库上打开 lite+skipIdle，
//       升级/检索/注入都不炸。
//   H7  真库副本形状（event_id 可空 + 与 'v11-<seq>' 撞车）宽松化回归 ——
//       自用版「备份自己数据并调用」实测 R-3/R-9 抓到的
//       "UNIQUE constraint failed: _relax_life_events.event_id" → 整表回滚 →
//       "no such column: event_type"。本场景用模拟数据复刻该形状并验证修复。
//   H8  补丁04「限制定时空唤醒」的判定表 —— 宿主侧重灾场景：
//       设了「六点醒」的闹钟，却在三点到六点被 replyCheck/proactiveCheck/
//       triggers.probability 反复拉起（一条消息都没发，token 照烧）。
//       这里直接测 qq-bridge 补丁配套的 wake-guard.mjs 纯函数，锁住
//       「闹钟没到就抑制、真人找她照常醒、闹钟到点照常醒」三条边界。
//
// 运行：H 组挂进 sandbox/run.mjs；独立单跑也可 `node -e "import(...).then(...)"`。
// 全程只用 tmpdir 里的模拟库，不碰任何真实运行数据。
import { spawnSync } from 'node:child_process';
import { mkdtempSync, writeFileSync, rmSync, readFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { DatabaseSync } from 'node:sqlite';
import { PKG, OWNER, SCOPE, makeV11, iso } from '../lib.mjs';
import { openDb, tx, ensureSchema } from '../../src/kit/db.mjs';
import { relaxTable, diagnoseLegacyShape, relaxLegacyTables } from '../../src/kit/legacy-shape.mjs';
import { DEFAULTS } from '../../src/kit/config.mjs';
import { writeMemory } from '../../src/memory/engine.mjs';
import { searchMemory } from '../../src/memory/search.mjs';
import { createGenericHost } from '../../src/host/generic.mjs';
import createPlugin from '../../src/index.mjs';

const quietLog = { info() {}, warn() {}, error() {} };
const PERSONA = '你叫小鱼，是一条住在主人电脑里的小鲸鱼。性格软、话不多、有点黏人；说话用简体中文，短句。';
const LITE = ['life_remember', 'life_propose', 'life_mark_sent', 'life_recall', 'life_status'];
const ALL = [
  'life_propose', 'life_mark_sent', 'life_sleep', 'life_delivery_poll', 'life_delivery_ack',
  'life_gap', 'life_recall', 'life_lifebook', 'life_persona_review', 'life_remember',
  'life_memory_review', 'life_forget', 'life_status',
];
const SEED = [
  '主人现居上海市浦东新区，查天气带伞默认用上海浦东',
  '主人要求真到必须换会话那天一定提前告诉他',
  '主人完全接纳小鱼的样子，说长成什么样都接受',
];

/** 造一个内存/临时库上的完整插件实例；返回 { host, rt, db, cleanup } */
async function boot(extraCfg = {}, { dir } = {}) {
  const own = !dir;
  const d = dir || mkdtempSync(join(tmpdir(), 'hdeep-'));
  const dbPath = join(d, 'mind.db');
  const host = createGenericHost({ log: quietLog, persona: () => PERSONA, embed: async () => null });
  const rt = createPlugin(host.ctx, { dbPath, ownerQq: OWNER, scope: SCOPE, ...extraCfg });
  await host.start();
  const remember = host.tools.find((t) => t.name === 'life_remember');
  for (const fact of SEED) {
    try { await remember.run({ fact, category: 'fact', confidence: 0.9 }); } catch { /* 见断言 */ }
  }
  const cleanup = () => {
    try { host.stop(); } catch { /* ignore */ }
    if (own) try { rmSync(d, { recursive: true, force: true }); } catch { /* ignore */ }
  };
  return { host, rt, dbPath, cleanup, d };
}

// ============================================================ H1 G4 修复回归
async function h1(rec, work) {
  rec.begin('H1', 'SIGKILL 强杀恢复不再 database is locked（G4 修复回归）',
    '基线 A–G 的 G4 报 1 个 ERR；本场景复刻同样的强杀，验证 busy_timeout + tx 重试兜底');
  const d = mkdtempSync(join(tmpdir(), 'h1kill-'));
  const dbPath = join(d, 'mind.db');
  const db0 = await openDb(dbPath);
  await ensureSchema(db0, { dbPath, cfg: DEFAULTS, log: quietLog });
  db0.close();

  const dbUrl = pathToFileURL(join(PKG, 'src/kit/db.mjs')).href;
  const cfgUrl = pathToFileURL(join(PKG, 'src/kit/config.mjs')).href;
  const engUrl = pathToFileURL(join(PKG, 'src/memory/engine.mjs')).href;
  const writer = join(d, 'writer.mjs');
  writeFileSync(writer, `
import { openDb } from ${JSON.stringify(dbUrl)};
import { DEFAULTS } from ${JSON.stringify(cfgUrl)};
import { writeMemory } from ${JSON.stringify(engUrl)};
const db = await openDb(process.argv[2]);
for (let i = 0; i < 5000; i++) {
  await writeMemory(db, { fact: 'H1强杀第' + i + '条', category: 'fact', scope: 'private:10086',
    subject_qq: '10086', source_kind: 'owner', source_id: '10086',
    evidence_kind: 'user_sentence', evidence_ref: 'h1-' + i, raw: 'h1-' + i }, { cfg: DEFAULTS });
}
db.close();
`, 'utf8');
  const child = spawnSync(process.execPath, [writer, dbPath], {
    timeout: 2500, killSignal: 'SIGKILL', encoding: 'utf8', maxBuffer: 8 * 1024 * 1024,
  });
  const killed = !!(child.error && /ETIMEDOUT/.test(String(child.error))) || child.signal === 'SIGKILL';
  rec.ok('子进程确实在写入中途被强杀', killed, { signal: child.signal, error: child.error && String(child.error) });

  const db = await openDb(dbPath);
  const integ = String(db.prepare('PRAGMA integrity_check').get().integrity_check).toLowerCase();
  const n = db.prepare('SELECT COUNT(*) AS n FROM memories').get().n;
  const half = db.prepare("SELECT COUNT(*) AS n FROM memories WHERE fact IS NULL OR fact = ''").get().n;
  rec.ok('强杀后 integrity_check = ok', integ === 'ok', integ);
  rec.ok('强杀前的已提交行还在（≥1）', n >= 1, n);
  rec.ok('没有半截行', half === 0, half);

  let writeOk = false, hit = false, err = null;
  try {
    const w = await writeMemory(db, {
      fact: 'H1强杀恢复后的第一条', category: 'fact', scope: SCOPE, subject_qq: OWNER,
      source_kind: 'owner', source_id: OWNER, evidence_kind: 'user_sentence', evidence_ref: 'h1-post', raw: 'post',
    }, { cfg: DEFAULTS });
    writeOk = w.verify === 'verified';
    hit = searchMemory(db, 'H1强杀恢复', { cfg: DEFAULTS, scope: SCOPE, topK: 6 })
      .items.some((x) => String(x.mem.fact).includes('H1强杀恢复'));
  } catch (e) { err = String((e && e.stack) || e); }
  rec.ok('强杀后父进程能继续写（不再 locked）', writeOk && !err, { writeOk, err: err && err.slice(0, 160) });
  rec.ok('新写的能立刻检索到', hit, hit);
  rec.ok('没有残留 database is locked 异常', !/database is locked/i.test(err || ''), err && err.slice(0, 160));
  db.close();
  try { rmSync(d, { recursive: true, force: true }); } catch { /* ignore */ }
  rec.note('evidence', { killed, integ, rows: n, half, writeOk, hit, err: err && err.slice(0, 200) });
  rec.end();
}

// ============================================================ H2 toolset 分级
async function h2(rec, work) {
  rec.begin('H2', 'toolset 分级：默认 13 工具零变化，lite 只 5 个核心工具',
    '验证降 token 的最大杠杆不改变默认行为，且 lite 下 5 个核心工具真能调用');
  // full（默认）
  const full = await boot({});
  const fullNames = full.host.tools.map((t) => t.name).sort();
  rec.eq('默认 toolset.mode = full', full.rt.toolset.mode, 'full');
  rec.eq('默认注册 13 个工具', fullNames.length, 13);
  rec.eq('默认工具集合与升级前完全一致', fullNames, [...ALL].sort());
  rec.eq('默认 dropped() = 0', full.rt.toolset.dropped(), 0);
  rec.eq('默认 registered() = 13', full.rt.toolset.registered(), 13);
  // 默认下 memory 注入仍工作（零行为变化）
  const secFull = await full.host.userMessage({ text: '还记得我住哪吗', scope: SCOPE, ownerQq: OWNER });
  rec.ok('默认下 dsh-life.memory 正常注入', typeof secFull.get('dsh-life.memory') === 'string' && secFull.get('dsh-life.memory').length > 0,
    secFull.get('dsh-life.memory') && secFull.get('dsh-life.memory').length);
  full.cleanup();

  // lite
  const lite = await boot({ v14: { toolset: 'lite' } });
  const liteNames = lite.host.tools.map((t) => t.name).sort();
  rec.eq('lite toolset.mode = lite', lite.rt.toolset.mode, 'lite');
  rec.eq('lite 只注册 5 个工具', liteNames.length, 5);
  rec.eq('lite 注册的正是 5 个核心工具', liteNames, [...LITE].sort());
  rec.eq('lite dropped() = 8', lite.rt.toolset.dropped(), 8);
  rec.eq('lite registered() = 5', lite.rt.toolset.registered(), 5);
  // 5 个核心工具可调用（不抛异常）
  let coreOk = 0;
  for (const nm of LITE) {
    const t = lite.host.tools.find((x) => x.name === nm);
    if (!t) continue;
    try {
      if (nm === 'life_remember') await t.run({ fact: 'H2-lite 写入测试', category: 'fact', confidence: 0.8 });
      else if (nm === 'life_status') await t.run({});
      else if (nm === 'life_recall') await t.run({ query: '上海' });
      else if (nm === 'life_propose') await t.run({ kind: 'checkin', text: 'H2' });
      else if (nm === 'life_mark_sent') await t.run({ id: 'none' });
      coreOk++;
    } catch { /* 业务参数不合法也算「可调用」，此处只关心工具存在且能进 run */ }
  }
  const secLite = await lite.host.userMessage({ text: '还记得我住哪吗', scope: SCOPE, ownerQq: OWNER });
  rec.ok('lite 下 dsh-life.memory 仍正常注入', typeof secLite.get('dsh-life.memory') === 'string', secLite.get('dsh-life.memory') && secLite.get('dsh-life.memory').length);
  rec.ok('lite 下核心工具均能进入 run（≥4）', coreOk >= 4, coreOk);
  // 非核心工具确实不在（8 个）
  const dropped = ALL.filter((n) => !LITE.includes(n));
  rec.ok('8 个非核心工具确实未注册', dropped.every((n) => !liteNames.includes(n)), dropped.filter((n) => liteNames.includes(n)));
  lite.cleanup();

  // 未知名 → 回落 full（防御性：配置写错不能少工具）
  const fallback = await boot({ v14: { toolset: 'typo' } });
  rec.eq('未知 toolset 值回落 full（13 工具）', fallback.host.tools.length, 13);
  fallback.cleanup();

  // schema 字符量化（可横比硬数据）
  const indexSrc = readFileSync(join(PKG, 'src/index.mjs'), 'utf8');
  const re = /(?:ctx\.tools\?\.register\?\.|reg)\(\{([\s\S]*?)\n\s*\}\);/g;
  const chars = {};
  let m;
  while ((m = re.exec(indexSrc))) {
    const nm = /name:\s*'([^']+)'/.exec(m[1]);
    const ds = /description:\s*'([^']*)'/.exec(m[1]);
    if (nm) chars[nm[1]] = nm[1].length + (ds?.[1] || '').length + 40;
  }
  const fullChars = Object.values(chars).reduce((a, b) => a + b, 0);
  const liteChars = LITE.reduce((a, n) => a + (chars[n] || 0), 0);
  rec.ok('工具 schema 字符统计覆盖 13 个工具', Object.keys(chars).length === 13, Object.keys(chars).length);
  rec.ok('lite 工具 schema 字符 < full 的一半', liteChars * 2 < fullChars, { fullChars, liteChars });
  rec.note('schemaChars', { full: fullChars, lite: liteChars, estTokFull: Math.round(fullChars * 1.05), estTokLite: Math.round(liteChars * 1.05) });
  rec.end();
}

// ============================================================ H3 skipIdleTurn
async function h3(rec, work) {
  rec.begin('H3', 'skipIdleTurn 空唤醒复用（wakeReason / 无文本 / 同文本 / 首轮边界）',
    '验证两种宿主形状下空轮都逐字节复用上一轮注入，且反射段不复播');
  const b = await boot({ v14: { skipIdleTurn: true } });
  const H = b.host;
  const msg = (text, wakeReason) => H.userMessage({
    text, scope: SCOPE, ownerQq: OWNER,
    ...(wakeReason !== undefined ? { wakeReason } : {}),
  });
  // 首轮就是空唤醒：没有可复用段，必须按正常轮处理（不能拿到空注入）
  const s0 = await msg('首轮正常输入', undefined);
  const mem0 = s0.get('dsh-life.memory') || '';
  rec.ok('首轮正常轮有 memory 段', mem0.length > 0, mem0.length);
  rec.eq('首轮后 idleSkips = 0（没有把首轮当空轮跳过）', b.rt.idleSkips || 0, 0);

  // 再来一个不同文本的正常轮，记下它的段
  const s1 = await msg('上海今天要带伞吗', undefined);
  const mem1 = s1.get('dsh-life.memory') || '';
  rec.ok('第二正常轮 memory 段存在', mem1.length > 0, mem1.length);

  // 三条显式 wakeReason 的定时空唤醒（timeout / replyCheck / proactiveCheck）
  const reasons = ['timeout', 'replyCheck', 'proactiveCheck'];
  let reuseOk = 0;
  for (const r of reasons) {
    const s = await msg('(检查有没有人回我)', r);
    const mem = s.get('dsh-life.memory') || '';
    if (mem === mem1) reuseOk++;
    rec.ok(`wakeReason=${r} 空轮逐字节复用上一正常轮`, mem === mem1, { got: mem.slice(0, 60), expect: mem1.slice(0, 60) });
  }
  rec.eq('三条定时空唤醒全部命中复用', reuseOk, 3);
  rec.eq('idleSkips 累计 3', b.rt.idleSkips, 3);

  // 无文本兜底（text='' → isIdleWake 返回 true）
  const sEmpty = await msg('', undefined);
  rec.ok('无文本空轮也复用上一轮', (sEmpty.get('dsh-life.memory') || '') === mem1, (sEmpty.get('dsh-life.memory') || '').slice(0, 60));
  rec.eq('idleSkips 累计 4', b.rt.idleSkips, 4);

  // 同文本兜底（文本与上一轮相同但没有 wakeReason）
  const sSame = await msg('上海今天要带伞吗', undefined);
  rec.ok('同文本无 wakeReason 也判为空轮并复用', (sSame.get('dsh-life.memory') || '') === mem1, (sSame.get('dsh-life.memory') || '').slice(0, 60));

  // 新文本正常轮必须真的重算（不能永远复用）
  const sNew = await msg('明天见，晚安', undefined);
  const memNew = sNew.get('dsh-life.memory') || '';
  rec.ok('新文本正常轮重新注入（不误判为空轮）', memNew.length > 0, memNew.length);
  rec.ok('新文本正常轮后 lastSections 已更新', b.rt.lastSections.get('dsh-life.memory') === memNew, null);

  // reflex 缓存清理：正常轮会 delete('dsh-life.reflex')，空轮不会把过期提醒复播回来
  rec.ok('正常轮后不再缓存 reflex 段', !b.rt.lastSections.has('dsh-life.reflex'), [...b.rt.lastSections.keys()]);
  rec.note('evidence', { mem0: mem0.length, mem1: mem1.length, memNew: memNew.length, idleSkips: b.rt.idleSkips, cachedKeys: [...b.rt.lastSections.keys()] });
  b.cleanup();

  // 默认关闭时：即便带 wakeReason 也必须逐轮重算（零行为变化）
  const off = await boot({});
  const o1 = await off.host.userMessage({ text: '上海今天要带伞吗', scope: SCOPE, ownerQq: OWNER });
  const o2 = await off.host.userMessage({ text: '(检查有没有人回我)', scope: SCOPE, ownerQq: OWNER, wakeReason: 'timeout' });
  rec.eq('默认 skipIdleTurn=false 时 idleSkips 恒为 0', off.rt.idleSkips || 0, 0);
  rec.ok('默认关闭时空轮仍正常重算（行为零变化）', (o2.get('dsh-life.memory') || '').length > 0, (o2.get('dsh-life.memory') || '').length);
  off.cleanup();
  rec.end();
}

// ============================================================ H4 token 量化
async function h4(rec, work) {
  rec.begin('H4', 'token 量化：四配置固定开销硬数据（可与豆包横比）',
    '直接读 rt.toolset / 每轮 memory 字符，给出可复现的输入侧 token 估算');
  const cases = [
    ['A-默认', {}],
    ['B-lite', { v14: { toolset: 'lite' } }],
    ['C-跳过空唤醒', { v14: { skipIdleTurn: true } }],
    ['D-lite+跳过', { v14: { toolset: 'lite', skipIdleTurn: true } }],
  ];
  const script = [
    { text: '上海今天要带伞吗' },
    { text: '还记得我住哪吗' },
    { text: '晚安，早点睡' },
    { text: '(检查有没有人回我)', wakeReason: 'timeout' },
    { text: '(检查有没有人回我)', wakeReason: 'replyCheck' },
    { text: '(检查有没有人回我)', wakeReason: 'proactiveCheck' },
    { text: '那就放着吧' },
    { text: '明天见' },
  ];
  const out = [];
  for (const [name, extra] of cases) {
    const b = await boot(extra);
    let chars = 0, same = 0, prev = null;
    for (const s of script) {
      const sec = await b.host.userMessage({
        text: s.text, scope: SCOPE, ownerQq: OWNER,
        ...(s.wakeReason ? { wakeReason: s.wakeReason } : {}),
      });
      const mem = sec.get('dsh-life.memory') || '';
      chars += mem.length;
      if (mem === prev) same++;
      prev = mem;
    }
    const toolChars = ALL.length && (() => {
      const idx = readFileSync(join(PKG, 'src/index.mjs'), 'utf8');
      const re = /(?:ctx\.tools\?\.register\?\.|reg)\(\{([\s\S]*?)\n\s*\}\);/g;
      let sum = 0, m;
      const active = new Set(b.host.tools.map((t) => t.name));
      while ((m = re.exec(idx))) {
        const nm = /name:\s*'([^']+)'/.exec(m[1]);
        const ds = /description:\s*'([^']*)'/.exec(m[1]);
        if (nm && active.has(nm[1])) sum += nm[1].length + (ds?.[1] || '').length + 40;
      }
      return sum;
    })();
    out.push({
      name, toolCount: b.host.tools.length, toolChars,
      toolEstTok: Math.round(toolChars * 1.05),
      memAvgChars: Math.round(chars / script.length),
      identicalMemoryTurns: same, idleSkips: b.rt.idleSkips || 0,
    });
    rec.ok(`${name}：工具数 = ${extra.v14?.toolset === 'lite' ? 5 : 13}`, b.host.tools.length === (extra.v14?.toolset === 'lite' ? 5 : 13), b.host.tools.length);
    rec.ok(`${name}：memory 每轮都有内容`, chars > 0, chars);
    b.cleanup();
  }
  const base = out[0].toolEstTok + out[0].memAvgChars;
  rec.ok('lite 工具 schema token < 默认的一半', out[1].toolEstTok * 2 < out[0].toolEstTok, { base: out[0].toolEstTok, lite: out[1].toolEstTok });
  rec.ok('D 组合固定开销显著低于 A', out[3].toolEstTok < out[0].toolEstTok * 0.5, { A: out[0].toolEstTok, D: out[3].toolEstTok });
  rec.ok('跳过空唤醒配置确实累计了 idleSkips', out[2].idleSkips >= 3 && out[3].idleSkips >= 3, { C: out[2].idleSkips, D: out[3].idleSkips });
  rec.note('quant', out);
  rec.end();
}

// ============================================================ H5 并发 BUSY 容错
async function h5(rec, work) {
  rec.begin('H5', 'tx 的 BUSY 重试：只重试锁冲突、不吞业务异常、有上限',
    '验证 db.mjs 新增的重试逻辑在真并发下正确，且不会把普通异常吞掉');
  const d = mkdtempSync(join(tmpdir(), 'h5busy-'));
  const dbPath = join(d, 'mind.db');
  const db = await openDb(dbPath);
  db.exec('CREATE TABLE t (id INTEGER PRIMARY KEY, v TEXT);');
  rec.ok('openDb 设置了 busy_timeout（PRAGMA 回读 ≥1000）',
    Number(db.prepare('PRAGMA busy_timeout').get()?.timeout ?? 0) >= 1000,
    db.prepare('PRAGMA busy_timeout').get());

  // 正常事务仍成功
  const ok1 = tx(db, () => { db.prepare("INSERT INTO t(v) VALUES ('a')").run(); return 1; });
  rec.eq('普通事务返回 fn 结果', ok1, 1);

  // 业务异常原样抛出，不被重试吞掉
  let thrown = null;
  try { tx(db, () => { throw new Error('H5-业务异常'); }); } catch (e) { thrown = e; }
  rec.ok('非 BUSY 业务异常原样抛出', thrown && /H5-业务异常/.test(String(thrown.message)), thrown && thrown.message);
  rec.eq('业务异常后无残留行', db.prepare('SELECT COUNT(*) AS n FROM t').get().n, 1);

  // 模拟「tx 内抛 SQLITE_BUSY」：验证重试上限后仍抛出、不会死循环
  let busyErr = null, attempts = 0;
  const fakeDb = {
    exec(sql) {
      if (sql === 'BEGIN IMMEDIATE') { attempts++; throw new Error('database is locked'); }
      return undefined;
    },
  };
  const t0 = Date.now();
  try { tx(fakeDb, () => 'never'); } catch (e) { busyErr = e; }
  const elapsed = Date.now() - t0;
  rec.ok('持续 BUSY 时最终仍抛出（不死循环）', busyErr && /locked/i.test(String(busyErr.message)), busyErr && busyErr.message);
  rec.ok('重试次数有上限（≤6 次 BEGIN）', attempts >= 2 && attempts <= 6, attempts);
  rec.ok('重试退避耗时合理（<3s）', elapsed < 3000, elapsed);

  // ROLLBACK 失败也吞掉，不掩盖原始异常
  const noRollback = {
    exec(sql) { if (sql === 'BEGIN IMMEDIATE') return; if (sql === 'ROLLBACK') throw new Error('rollback failed'); throw new Error('inner boom'); },
  };
  let innerErr = null;
  try { tx(noRollback, () => 'x'); } catch (e) { innerErr = e; }
  rec.ok('ROLLBACK 失败不掩盖原始异常', innerErr && /inner boom/.test(String(innerErr.message)), innerErr && innerErr.message);
  db.close();
  try { rmSync(d, { recursive: true, force: true }); } catch { /* ignore */ }
  rec.end();
}

// ============================================================ H6 老库 + 新开关
async function h6(rec, work) {
  rec.begin('H6', 'v11.1 脏老库 + lite + skipIdle 共存不炸',
    '验证新开关在「老库结构错位 / 脏数据」场景下的兼容性');
  const d = mkdtempSync(join(tmpdir(), 'h6old-'));
  const dbPath = join(d, 'mind.db');
  try {
    makeV11(dbPath, { rows: 40, dirty: true });
    const host = createGenericHost({ log: quietLog, persona: () => PERSONA, embed: async () => null });
    const rt = createPlugin(host.ctx, {
      dbPath, ownerQq: OWNER, scope: SCOPE, autoMigrate: true,
      v14: { toolset: 'lite', skipIdleTurn: true },
    });
    await host.start();
    rec.eq('脏老库上 lite 仍只 5 工具', host.tools.length, 5);
    rec.eq('脏老库上 toolset.mode = lite', rt.toolset.mode, 'lite');
    const s1 = await host.userMessage({ text: '还记得我住哪吗', scope: SCOPE, ownerQq: OWNER });
    rec.ok('脏老库上首轮 memory 正常注入', (s1.get('dsh-life.memory') || '').length > 0, (s1.get('dsh-life.memory') || '').length);
    const s2 = await host.userMessage({ text: '(检查)', scope: SCOPE, ownerQq: OWNER, wakeReason: 'timeout' });
    rec.ok('脏老库上空唤醒复用不报错且段不为空', (s2.get('dsh-life.memory') || '').length > 0, (s2.get('dsh-life.memory') || '').length);
    rec.ok('脏老库上检索仍可用', Array.isArray(searchMemory(rt.db, '上海', { cfg: DEFAULTS, scope: SCOPE, topK: 3 }).items), null);
    host.stop();
    rec.ok('整个场景无 ERR', true, null);
  } catch (e) {
    rec.ok('脏老库 + 新开关全流程无异常', false, String((e && e.stack) || e).slice(0, 300));
  }
  try { rmSync(d, { recursive: true, force: true }); } catch { /* ignore */ }
  rec.end();
}

export async function runH(rec, work) {
  await h1(rec, work);
  await h2(rec, work);
  await h3(rec, work);
  await h4(rec, work);
  await h5(rec, work);
  await h6(rec, work);
  await h7(rec, work);
  await h8(rec, work);
}

// ============================================================ H7 真库 event_id 撞车
//
// 背景（自用版「备份自己数据并调用」实测 R-3/R-9 抓到，A–G 全绿却没覆盖）：
//   makeV11 模拟库里 life_events 已经是新 DDL（event_id TEXT PRIMARY KEY + event_type），
//   所以 380/0 全绿也测不到老形状。真实回滚库里 life_events 仍是 v11.1 老 DDL：
//     seq INTEGER PK AUTOINCREMENT, at TEXT NOT NULL, kind TEXT NOT NULL,
//     payload, delta, revision, applied_at, type, event_id(可空), created_at
//   recipe 把 event_id 提升为 TEXT PRIMARY KEY，且对 NULL 补 `'v11-' || seq`。
//   回滚增量转移后的真库有 463 行 event_id IS NULL，同时另有 463 行 event_id
//   已经是 `'v11-<N>'` —— 两者算出来的值相撞 → INSERT 报
//   "UNIQUE constraint failed: _relax_life_events.event_id" → 整表回滚 →
//   后面 tables.sql 的 `CREATE INDEX ... ON life_events(event_type, created_at DESC)`
//   引用不存在的列 → 启动抛 "no such column: event_type"。
//
// 本场景用模拟数据精确复刻这个形状（NULL + 与 'v11-<seq>' 撞车 + 一条必须原样
// 保留的正常主键），验证 relaxTable 的确定性去重能让整表重建成功，且完整启动
// 不再抛 no such column: event_type。全程 tmpdir 模拟库，不碰任何真实数据。
const OLD_LIFE_EVENTS_DDL = `
CREATE TABLE life_events (
  seq         INTEGER PRIMARY KEY AUTOINCREMENT,
  at          TEXT NOT NULL,
  kind        TEXT NOT NULL,
  payload     TEXT,
  delta       TEXT,
  revision    INTEGER,
  applied_at  TEXT,
  type        TEXT,
  event_id    TEXT,
  created_at  TEXT
);`;

async function h7(rec, work) {
  rec.begin('H7', '真库形状回归：event_id 可空 + v11-<seq> 撞车时宽松化不再整表回滚',
    '复刻自用版真库副本 R-3/R-9 的 "no such column: event_type"，验证确定性去重修复');

  // ---- 7a 纯函数层：naive 映射确实会撞（说明这个形状在修复前必炸） ----
  const dA = mkdtempSync(join(tmpdir(), 'h7a-'));
  const pA = join(dA, 'mind.db');
  let dbA;
  try {
    dbA = new DatabaseSync(pA);
    dbA.exec(OLD_LIFE_EVENTS_DDL);
    const t = iso(Date.now());
    // seq=1 + event_id NULL  → recipe 算出 'v11-1'
    dbA.prepare('INSERT INTO life_events(at,kind,payload,event_id) VALUES(?,?,?,?)').run(t, 'tick', '{"a":1}', null);
    // seq=2 + event_id 'v11-1'（回滚增量转移带过来的显式 ID）→ 与上面撞车
    dbA.prepare('INSERT INTO life_events(at,kind,payload,event_id) VALUES(?,?,?,?)').run(t, 'tick', '{"a":2}', 'v11-1');
    // seq=3 + event_id ''（空串，同样走 'v11-' || seq）
    dbA.prepare('INSERT INTO life_events(at,kind,payload,event_id) VALUES(?,?,?,?)').run(t, 'tick', '{"a":3}', '');
    // seq=4 + 正常且唯一的 event_id，修复后必须一个字节都不改
    dbA.prepare('INSERT INTO life_events(at,kind,payload,event_id) VALUES(?,?,?,?)').run(t, 'tick', '{"a":4}', 'keep-me-unchanged');
    const naive = dbA.prepare(
      `SELECT COUNT(*) AS n, COUNT(DISTINCT COALESCE(NULLIF(event_id,''), 'v11-' || seq)) AS d FROM life_events`
    ).get();
    rec.ok('H7-1 复刻形状确实需要重建（缺 event_type/event_json）',
      diagnoseLegacyShape(dbA, {}).some(r => r.table === 'life_events' && r.needsRelax), null);
    rec.ok('H7-2 修复前 naive 映射必然产生重复主键', naive.n > naive.d, { rows: naive.n, distinct: naive.d });

    const r = relaxTable(dbA, 'life_events');
    rec.ok('H7-3 relaxTable 重建成功（不再 UNIQUE 报错）', r.rebuilt === true, r);
    const after = dbA.prepare('SELECT event_id, event_type, event_json, created_at, kind, seq FROM life_events ORDER BY seq').all();
    rec.eq('H7-4 4 行全部原样保留', after.length, 4);
    const ids = after.map(x => x.event_id);
    rec.ok('H7-5 重建后 event_id 无 NULL / 空串', ids.every(v => v !== null && v !== ''), ids);
    rec.ok('H7-6 重建后 event_id 两两不同', new Set(ids).size === ids.length, ids);
    rec.ok('H7-7 未被卷入撞车的正常主键一字不改', ids.includes('keep-me-unchanged'), ids);
    rec.ok('H7-8 老列 kind/seq 仍保留（不丢数据）',
      after.every(x => x.kind === 'tick') && after.every(x => typeof x.seq === 'number'), null);
    const cols = dbA.prepare('PRAGMA table_info("life_events")').all().map(c => c.name);
    rec.ok('H7-9 新列 event_type / event_json 已就位',
      cols.includes('event_type') && cols.includes('event_json'), cols);
    rec.ok('H7-10 重建后不再需要二次宽松化',
      !diagnoseLegacyShape(dbA, {}).some(r => r.table === 'life_events' && r.needsRelax), null);
    dbA.close();
  } catch (e) {
    rec.ok('H7 纯函数层无异常', false, String((e && e.stack) || e).slice(0, 300));
    try { dbA && dbA.close(); } catch { /* ignore */ }
  }
  try { rmSync(dA, { recursive: true, force: true }); } catch { /* ignore */ }

  // ---- 7b 端到端：把老形状注入完整 v11.1 库，验证 onReady 不再崩 ----
  const dB = mkdtempSync(join(tmpdir(), 'h7b-'));
  const pB = join(dB, 'mind.db');
  let host = null;
  try {
    makeV11(pB, { rows: 12 });
    const raw = new DatabaseSync(pB);
    raw.exec('DROP TABLE life_events');
    raw.exec(OLD_LIFE_EVENTS_DDL);
    const t = iso(Date.now());
    raw.prepare('INSERT INTO life_events(at,kind,payload,event_id) VALUES(?,?,?,?)').run(t, 'tick', '{"a":1}', null);
    raw.prepare('INSERT INTO life_events(at,kind,payload,event_id) VALUES(?,?,?,?)').run(t, 'tick', '{"a":2}', 'v11-1');
    raw.prepare('INSERT INTO life_events(at,kind,payload,event_id) VALUES(?,?,?,?)').run(t, 'tick', '{"a":3}', 'keep-me-unchanged');
    raw.close();

    host = createGenericHost({ log: quietLog, persona: () => PERSONA, embed: async () => null });
    const rt = createPlugin(host.ctx, {
      dbPath: pB, ownerQq: OWNER, scope: SCOPE, autoMigrate: true,
      v14: { toolset: 'lite', skipIdleTurn: true },
    });
    let bootErr = null;
    try { await host.start(); } catch (e) { bootErr = String((e && e.stack) || e); }
    rec.ok('H7-11 真库形状上完整启动不抛 no such column: event_type',
      !bootErr && !/no such column: event_type/i.test(bootErr || ''), bootErr && bootErr.slice(0, 220));
    if (!bootErr) {
      const cols = rt.db.prepare('PRAGMA table_info("life_events")').all().map(c => c.name);
      rec.ok('H7-12 启动后 life_events 已有 event_type 列', cols.includes('event_type'), cols);
      const n = rt.db.prepare('SELECT COUNT(*) AS n FROM life_events').get().n;
      rec.eq('H7-13 启动后 3 条事件行仍在', n, 3);
      const dup = rt.db.prepare('SELECT COUNT(*) AS n FROM (SELECT event_id FROM life_events GROUP BY event_id HAVING COUNT(*)>1)').get().n;
      rec.eq('H7-14 启动后无重复 event_id', dup, 0);
      const s = await host.userMessage({ text: '还记得我住哪吗', scope: SCOPE, ownerQq: OWNER });
      rec.ok('H7-15 真库形状上 lite+skipIdle 仍能正常注入',
        (s.get('dsh-life.memory') || '').length > 0, (s.get('dsh-life.memory') || '').length);
      rec.eq('H7-16 真库形状上 lite 仍只 5 工具', host.tools.length, 5);
      const mem = rt.db.prepare('SELECT COUNT(*) AS n FROM memories').get().n;
      rec.ok('H7-17 升级后原有 12 条记忆未丢失', mem >= 12, mem);
      host.stop();
    }
  } catch (e) {
    rec.ok('H7 端到端无异常', false, String((e && e.stack) || e).slice(0, 300));
    try { host && host.stop(); } catch { /* ignore */ }
  }
  try { rmSync(dB, { recursive: true, force: true }); } catch { /* ignore */ }
  rec.end();
}

// ============================================================ H8 补丁04 判定表
//
// 宿主侧真问题（主人原话，2026-11-06）：「她每次会给自己设置个到几点醒的闹钟，
// 但是现版本总是莫名其妙让她提前起来，比如说要六点起，但是她在三点到六点
// 一直被唤醒，虽然没发消息，但是依然消耗很大。」
// 根因在 qq-bridge（见 解决方案/补丁04-抑制定时空唤醒/README.md），
// 判定函数 wake-guard.mjs 随补丁一起发，这里直接测它：
//   · 闹钟没到 + 没有真人新消息 + 定时类 → 抑制（不动闹钟）
//   · 真人找她（@/名字/提问/拍一拍/关键词/新消息）→ 一律照常醒（功能不能减）
//   · 闹钟到点 → 一律照常醒
const GUARD = new URL('../../../解决方案/补丁04-抑制定时空唤醒/wake-guard.mjs', import.meta.url);

async function h8(rec, work) {
  rec.begin('H8', '补丁04 判定表：休息/潜水期不空唤醒，真人找她照常醒，忙只拉长间隔',
    '只认主人明说的「要睡/休息/在忙」，不猜钟点、不猜沉默时长（宿主侧）');
  let mod = null;
  try {
    mod = await import(GUARD.href);
  } catch (e) {
    rec.ok('H8-0 能加载 wake-guard.mjs', false, String(e && e.message).slice(0, 200));
    rec.end();
    return;
  }
  const { shouldSuppressWake, isTimerWakeReason } = mod;
  const NOW = Date.parse('2026-11-06T03:10:00+08:00');
  const alarm6 = '2026-11-06T06:00:00+08:00';
  const finite = { infinite: false, sleepUntil: alarm6 };
  const infinite = { infinite: true, sleepUntil: null };

  // ── ① 有限潜水：闹钟是唯一放行点 ──
  const t1 = shouldSuppressWake({ wakeConfig: finite, reason: 'replyCheck', unreadCount: 0, now: NOW });
  rec.ok('H8-1 闹钟未到 + 无未读 + replyCheck → 抑制',
    t1.suppress === true && t1.why === 'before-alarm', t1);
  rec.ok('H8-2 抑制时保留原闹钟时间（不改写、不清空）',
    t1.until === Date.parse(alarm6) && t1.remainingMs === 170 * 60 * 1000, t1);
  const t2 = shouldSuppressWake({ wakeConfig: finite, reason: 'proactiveCheck', unreadCount: 0, now: NOW });
  rec.ok('H8-3 proactiveCheck 同样被抑制（能力不删，只是不打断闹钟）', t2.suppress === true, t2);
  const t3 = shouldSuppressWake({ wakeConfig: finite, reason: 'replyCheck@seq88', unreadCount: 0, now: NOW });
  rec.ok('H8-4 带 @seq 后缀的定时原因也认得出', t3.suppress === true, t3);
  rec.ok('H8-5 到期前 1ms 抑制、到期后 1ms 放行',
    shouldSuppressWake({ wakeConfig: finite, reason: 'timeout', unreadCount: 0, now: Date.parse(alarm6) - 1 }).suppress === true &&
    shouldSuppressWake({ wakeConfig: finite, reason: 'timeout', unreadCount: 0, now: Date.parse(alarm6) + 1 }).suppress === false, null);

  // ── ② 真人找她：任何状态都放行 ──
  for (const r of ['atMention', 'nameMention', 'question', 'poke', 'keyword', 'speaker', 'anyMessage']) {
    rec.ok(`H8-6 真人找她不抑制（${r}）`,
      shouldSuppressWake({ wakeConfig: finite, reason: r, unreadCount: 0, now: NOW }).suppress === false, r);
  }
  rec.ok('H8-7 有未读真人消息时定时类也不抑制（不能丢消息）',
    shouldSuppressWake({ wakeConfig: finite, reason: 'replyCheck', unreadCount: 2, now: NOW }).suppress === false, null);
  rec.ok('H8-8 他说了要睡时，真人说话照样醒（不误伤）',
    shouldSuppressWake({ wakeConfig: infinite, reason: 'atMention', resting: true, now: NOW }).suppress === false, null);

  // ── ③ 休息态：夜里 / 她自己在睡 ──
  rec.ok('H8-9 主人明说「要睡了」+ timeout → 抑制（不看钟点）',
    shouldSuppressWake({ wakeConfig: infinite, reason: 'timeout', resting: true, now: NOW }).why === 'resting', null);
  rec.ok('H8-9b 没说要睡（哪怕凌晨 3 点）+ timeout → 放行（严禁按钟点判休息）',
    shouldSuppressWake({ wakeConfig: infinite, reason: 'timeout', resting: false, now: NOW }).suppress === false, null);
  rec.ok('H8-10 要睡 + bootstrap → 放行（不许永眠）',
    shouldSuppressWake({ wakeConfig: infinite, reason: 'bootstrap', resting: true, now: NOW }).suppress === false, null);

  // ── ④ 无限潜水日常：replyCheck 没人接话就别查 ──
  rec.ok('H8-11 无限潜水 + replyCheck 无人接话 → 抑制',
    shouldSuppressWake({ wakeConfig: infinite, reason: 'replyCheck', now: NOW }).why === 'reply-check-nobody-replied', null);
  rec.ok('H8-12 该开关可关（cfg.suppressIdleReplyCheck=false 回到旧行为）',
    shouldSuppressWake({ wakeConfig: infinite, reason: 'replyCheck', now: NOW, cfg: { suppressIdleReplyCheck: false } }).suppress === false, null);

  // ── ⑤ proactiveCheck 默认不节流（不能砍主动性）──
  rec.ok('H8-13 默认 proactiveMinGapMs=0，刚醒过也放行（不砍主动性）',
    shouldSuppressWake({ wakeConfig: infinite, reason: 'proactiveCheck', now: NOW, lastWakeAt: NOW - 30 * 60000 }).why === 'proactive-ok', null);
  rec.ok('H8-14 显式配 90min 时才节流（可选项，默认不开）',
    shouldSuppressWake({ wakeConfig: infinite, reason: 'proactiveCheck', now: NOW, lastWakeAt: NOW - 30 * 60000, cfg: { proactiveMinGapMs: 90 * 60000 } }).why === 'proactive-too-soon', null);
  rec.ok('H8-15 没有 lastWakeAt 记录 → 放行（不因缺数据就不说话）',
    shouldSuppressWake({ wakeConfig: infinite, reason: 'proactiveCheck', now: NOW, lastWakeAt: 0 }).suppress === false, null);

  // ── ⑥ 主人明说「在忙」：只拉长到 60min，不全压掉 ──
  rec.ok('H8-16 忙 + 50 分钟前醒过 → 仍抑制（<60min）',
    shouldSuppressWake({ wakeConfig: infinite, reason: 'proactiveCheck', now: NOW, ownerBusy: true, lastWakeAt: NOW - 50 * 60000 }).why === 'busy-too-soon', null);
  rec.ok('H8-17 忙 + 60 分钟整 → 放行（到点照样找他，不全部压掉）',
    shouldSuppressWake({ wakeConfig: infinite, reason: 'proactiveCheck', now: NOW, ownerBusy: true, lastWakeAt: NOW - 60 * 60000 }).why === 'busy-gap-reached', null);
  rec.ok('H8-18 同样 30 分钟：不忙放行、忙抑制（阈值只在忙时生效）',
    shouldSuppressWake({ wakeConfig: infinite, reason: 'proactiveCheck', now: NOW, ownerBusy: false, lastWakeAt: NOW - 30 * 60000 }).suppress === false &&
    shouldSuppressWake({ wakeConfig: infinite, reason: 'proactiveCheck', now: NOW, ownerBusy: true, lastWakeAt: NOW - 30 * 60000 }).suppress === true, null);
  rec.ok('H8-19 忙不改变 timeout / replyCheck 的判定',
    shouldSuppressWake({ wakeConfig: infinite, reason: 'timeout', ownerBusy: true, now: NOW }).suppress === false &&
    shouldSuppressWake({ wakeConfig: infinite, reason: 'replyCheck', ownerBusy: true, now: NOW }).suppress === true, null);

  // ── ⑦ 保守放行 ──
  rec.ok('H8-20 无限潜水/无闹钟/垃圾值一律保守放行（不误伤）',
    shouldSuppressWake({ wakeConfig: { infinite: true, sleepUntil: null }, reason: 'timeout', unreadCount: 0, now: NOW }).suppress === false &&
    shouldSuppressWake({ wakeConfig: null, reason: 'timeout', unreadCount: 0, now: NOW }).suppress === false &&
    shouldSuppressWake({ wakeConfig: { infinite: false, sleepUntil: 'x' }, reason: 'timeout', unreadCount: 0, now: NOW }).suppress === false, null);
  rec.ok('H8-21 定时类判定表与 bridge.js 一致（timeout/replyCheck/proactiveCheck/bootstrap/admin）',
    ['timeout', 'replyCheck', 'proactiveCheck', 'bootstrap', 'admin'].every(r => isTimerWakeReason(r) === true) &&
    ['atMention', 'nameMention', 'question', 'poke', 'keyword'].every(r => isTimerWakeReason(r) === false), null);
  rec.end();
}
