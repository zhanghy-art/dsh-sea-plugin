// sandbox/scenarios/i-experience.mjs — I 组：体验向沙盒（2026-11-06 新增）
//
// 主人要求「再跑一轮沙盒，主要检测回复速度、花费、体验感、所有新增功能、
// 对不可用老功能的修补」。A–H 组关注「会不会崩、数据对不对」，I 组关注
// 「用起来什么感觉、贵不贵、快不快、v13 那些坏掉的东西修好没有」。
//
//   I1  回复速度 —— onPreStep 单轮耗时分布（P50/P95/最慢），空唤醒轮耗时，
//       检索规模对耗时的影响；全部本机实测，不含模型生成时间。
//   I2  花费 —— 一次完整对话每轮注入字符与固定开销（工具 schema / 固定提示），
//       四配置对比；给出 426 tok/s 口径下「一轮值多少 token」。
//   I3  体验感 —— 注入段读起来像不像话：有没有标签泄漏/memid/JSON/空段；
//       出站清洗、回声重写、睡着时的短回复。
//   I4  新增功能 —— 13 个工具逐个真调用 + v14 新模块（睡眠阶段/投递队列/
//       做梦/缺口/建边/人格漂移/信念冲突/印记/思绪流）逐个真跑。
//   I5  老功能修补 —— v13 六类脏数据（undefined 脏列/双行 life_state/
//       毫秒字符串/edges 恒空/type 全 NULL/proposals 只进不出）逐条验证修好。
//   I6  长跑体验 —— 连续 30 轮不崩、注入长度不膨胀、状态不漂移。
//
// 全程 tmpdir 模拟库，不碰任何真实运行数据。
import { mkdtempSync, rmSync, readFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { PKG, OWNER, SCOPE, makeV11 } from '../lib.mjs';
import { createGenericHost } from '../../src/host/generic.mjs';
import createPlugin from '../../src/index.mjs';
import { DEFAULTS, mergeConfig } from '../../src/kit/config.mjs';
import * as sleepMod from '../../src/life/sleep-stage.mjs';

const quietLog = { info() {}, warn() {}, error() {} };
const PERSONA = '你叫小鱼，是一条住在主人电脑里的小鲸鱼。性格软、话不多、有点黏人；说话用简体中文，短句。';
const SEED = [
  '主人现居上海市浦东新区，查天气带伞默认用上海浦东',
  '主人要求真到必须换会话那天一定提前告诉他',
  '主人完全接纳小鱼的样子，说长成什么样都接受',
  '主人喜欢喝冰美式，不加糖',
  '主人养了一条叫年糕的橘猫',
];

/** 造临时库 + 完整插件实例 */
async function boot(extraCfg = {}, { dirty = false, rows = 30 } = {}) {
  const d = mkdtempSync(join(tmpdir(), 'iexp-'));
  const dbPath = join(d, 'mind.db');
  makeV11(dbPath, { rows, dirty });
  const host = createGenericHost({ log: quietLog, persona: () => PERSONA, embed: async () => null });
  const rt = createPlugin(host.ctx, { dbPath, ownerQq: OWNER, scope: SCOPE, ...extraCfg });
  await host.start();
  const remember = host.tools.find((t) => t.name === 'life_remember');
  for (const fact of SEED) {
    try { await remember.run({ fact, category: 'fact', confidence: 0.9 }); } catch { /* 断言里看 */ }
  }
  const cleanup = () => {
    try { host.stop(); } catch { /* ignore */ }
    try { rmSync(d, { recursive: true, force: true }); } catch { /* ignore */ }
  };
  const tool = (n) => host.tools.find((t) => t.name === n);
  // rt 上没有 cfg（插件内部变量），这里按同样的 merge 规则算一份给断言用
  const cfg = mergeConfig(DEFAULTS, extraCfg);
  return { host, rt, dbPath, d, cleanup, tool, db: rt.db, cfg };
}

const pct = (arr, p) => {
  if (!arr.length) return 0;
  const s = [...arr].sort((a, b) => a - b);
  return s[Math.min(s.length - 1, Math.floor((s.length - 1) * p))];
};
const avg = (arr) => (arr.length ? arr.reduce((a, b) => a + b, 0) / arr.length : 0);
const estTok = (ch) => Math.round(ch * 1.05);

// ============================================================ I1 回复速度
async function i1(rec) {
  rec.begin('I1', '回复速度：单轮注入耗时分布 + 空唤醒轮开销（本机实测）',
    '主人关心「变慢了没有」。这里量的是插件侧每轮要花的时间（不含模型生成）');
  const b = await boot();
  const H = b.host;
  const turns = [];
  const scripts = [
    '上海今天要带伞吗', '还记得我住哪吗', '年糕今天怎么样', '我有点累',
    '帮我记一下明天要开会', '晚安', '早上好', '我回来了', '今天吃什么',
    '你睡了吗', '我不开心', '陪我聊会儿',
  ];
  for (const text of scripts) {
    const t0 = performance.now();
    const sec = await H.userMessage({ text, scope: SCOPE, ownerQq: OWNER });
    turns.push({ ms: performance.now() - t0, chars: (sec.get('dsh-life.memory') || '').length });
  }
  const msList = turns.map((t) => t.ms);
  rec.ok('12 轮全部正常返回注入段', turns.every((t) => t.chars > 0), turns.filter((t) => !t.chars).length);
  rec.ok('单轮注入 P50 < 200ms（本机模拟库口径）', pct(msList, 0.5) < 200, { p50: +pct(msList, 0.5).toFixed(1), p95: +pct(msList, 0.95).toFixed(1) });
  rec.ok('单轮注入 P95 < 800ms', pct(msList, 0.95) < 800, +pct(msList, 0.95).toFixed(1));
  rec.ok('最慢一轮 < 2000ms', Math.max(...msList) < 2000, +Math.max(...msList).toFixed(1));

  // 数据库规模对耗时的影响：340 条 vs 30 条
  const big = await boot({}, { rows: 340 });
  const bigMs = [];
  for (const text of scripts.slice(0, 6)) {
    const t0 = performance.now();
    await big.host.userMessage({ text, scope: SCOPE, ownerQq: OWNER });
    bigMs.push(performance.now() - t0);
  }
  rec.ok('340 条记忆库里单轮注入 P95 < 1500ms', pct(bigMs, 0.95) < 1500, +pct(bigMs, 0.95).toFixed(1));
  rec.note('speed', {
    p50: +pct(msList, 0.5).toFixed(1), p95: +pct(msList, 0.95).toFixed(1),
    avg: +avg(msList).toFixed(1), max: +Math.max(...msList).toFixed(1),
    big340_p95: +pct(bigMs, 0.95).toFixed(1),
  });
  big.cleanup();

  // 空唤醒轮：skipIdleTurn 开与不开的耗时差
  const off = await boot({});
  const on = await boot({ v14: { skipIdleTurn: true } });
  const measureIdle = async (env) => {
    await env.host.userMessage({ text: '正常一轮', scope: SCOPE, ownerQq: OWNER });
    const arr = [];
    for (let i = 0; i < 6; i++) {
      const t0 = performance.now();
      await env.host.userMessage({ text: '(检查有没有人回我)', scope: SCOPE, ownerQq: OWNER, wakeReason: 'timeout' });
      arr.push(performance.now() - t0);
    }
    return avg(arr);
  };
  const offIdle = await measureIdle(off);
  const onIdle = await measureIdle(on);
  rec.ok('skipIdleTurn 开启后空唤醒轮更快（省掉检索/向量/拼装）', onIdle <= offIdle, { off: +offIdle.toFixed(2), on: +onIdle.toFixed(2) });
  rec.eq('skipIdleTurn 开启后 idleSkips 累计 6', on.rt.idleSkips || 0, 6);
  rec.eq('默认关闭时 idleSkips 恒 0', off.rt.idleSkips || 0, 0);
  rec.note('idleSpeed', { offMs: +offIdle.toFixed(2), onMs: +onIdle.toFixed(2), savedPct: offIdle ? +((1 - onIdle / offIdle) * 100).toFixed(1) : 0 });
  off.cleanup();
  on.cleanup();
  b.cleanup();
  rec.end();
}

// ============================================================ I2 花费
async function i2(rec) {
  rec.begin('I2', '花费：每轮注入字符与固定开销（426 tok/s 口径）',
    '把「一次唤醒要花多少 token」拆成可复现的三块：工具 schema / 固定提示 / 每轮记忆段');
  const b = await boot();
  const H = b.host;
  // 工具 schema（name+description+40 包装，与 H4 同口径）
  const indexSrc = readFileSync(join(PKG, 'src/index.mjs'), 'utf8');
  const re = /(?:ctx\.tools\?\.register\?\.|reg)\(\{([\s\S]*?)\n\s*\}\);/g;
  const chars = {};
  let m;
  while ((m = re.exec(indexSrc))) {
    const nm = /name:\s*'([^']+)'/.exec(m[1]);
    const ds = /description:\s*'([^']*)'/.exec(m[1]);
    if (nm) chars[nm[1]] = nm[1].length + (ds?.[1] || '').length + 40;
  }
  const schemaChars = Object.values(chars).reduce((a, b2) => a + b2, 0);
  rec.eq('13 个工具的 schema 全部统计到', Object.keys(chars).length, 13);
  rec.ok('工具 schema 总字符在 700–1500 之间（13 个工具，非 2870）', schemaChars > 700 && schemaChars < 1500, schemaChars);

  // 每轮记忆段
  const mems = [];
  for (const text of ['上海今天要带伞吗', '年糕今天怎么样', '帮我记一下明天要开会', '晚安']) {
    const sec = await H.userMessage({ text, scope: SCOPE, ownerQq: OWNER });
    mems.push((sec.get('dsh-life.memory') || '').length);
  }
  const memAvg = avg(mems);
  rec.ok('每轮记忆段平均 60–400 字符（不膨胀）', memAvg >= 60 && memAvg <= 400, +memAvg.toFixed(1));
  const fixedChars = schemaChars + 67; // 67 = dsh.mjs 里硬编码的工具提示
  rec.ok('单次唤醒固定开销（schema+提示）≈ 1000–1600 字符', fixedChars > 1000 && fixedChars < 1600, fixedChars);
  rec.note('cost', {
    schemaChars, schemaTok: estTok(schemaChars),
    fixedPromptChars: 67, fixedPromptTok: estTok(67),
    memAvgChars: +memAvg.toFixed(1), memAvgTok: estTok(memAvg),
    perWakeChars: fixedChars + Math.round(memAvg),
    perWakeTok: estTok(fixedChars + Math.round(memAvg)),
  });

  // 四配置对比（与 H4 同脚本，这里只看总字符）
  const cases = [
    ['A-默认', {}, null],
    ['B-lite', { v14: { toolset: 'lite' } }, 5],
    ['C-跳过空唤醒', { v14: { skipIdleTurn: true } }, 13],
    ['D-lite+跳过', { v14: { toolset: 'lite', skipIdleTurn: true } }, 5],
  ];
  const rows = [];
  for (const [name, extra, expectTools] of cases) {
    const env = await boot(extra);
    if (expectTools != null) rec.eq(`${name} 工具数 = ${expectTools}`, env.host.tools.length, expectTools);
    let total = 0;
    const seq = ['上海今天要带伞吗', '还记得我住哪吗', '晚安', '(检查)', '(检查)', '(检查)'];
    const reasons = [null, null, null, 'timeout', 'replyCheck', 'proactiveCheck'];
    for (let i = 0; i < seq.length; i++) {
      const sec = await env.host.userMessage({
        text: seq[i], scope: SCOPE, ownerQq: OWNER,
        ...(reasons[i] ? { wakeReason: reasons[i] } : {}),
      });
      total += (sec.get('dsh-life.memory') || '').length;
    }
    const toolChars = expectTools === 5
      ? ['life_remember', 'life_propose', 'life_mark_sent', 'life_recall', 'life_status'].reduce((a, n) => a + (chars[n] || 0), 0)
      : schemaChars;
    rows.push({ name, total, toolChars, wakeChars: toolChars + 67 + total });
    env.cleanup();
  }
  const A = rows[0], B2 = rows[1], C = rows[2], D = rows[3];
  rec.ok('lite 单次唤醒字符明显少于默认（>40%）', B2.wakeChars < A.wakeChars * 0.6, { A: A.wakeChars, B: B2.wakeChars });
  rec.ok('跳过空唤醒的累计字符不高于默认', C.total <= A.total, { A: A.total, C: C.total });
  rec.ok('D（lite+跳过）最省', D.wakeChars <= B2.wakeChars && D.wakeChars <= C.wakeChars, { D: D.wakeChars, B: B2.wakeChars, C: C.wakeChars });
  rec.note('fourConfigs', rows);
  b.cleanup();
  rec.end();
}

// ============================================================ I3 体验感
async function i3(rec) {
  rec.begin('I3', '体验感：注入段可读性 / 出站清洗 / 回声重写 / 睡着短回复',
    '不问「对不对」，问「给人看像不像话」：有没有标签泄漏、memid、JSON、空段');
  const b = await boot();
  const H = b.host;
  const sec = await H.userMessage({ text: '还记得我住哪吗', scope: SCOPE, ownerQq: OWNER });
  const mem = sec.get('dsh-life.memory') || '';
  rec.ok('注入段非空', mem.length > 0, mem.length);
  rec.ok('注入段以【人格】开头（结构完整）', mem.startsWith('【人格】'), mem.slice(0, 20));
  rec.ok('注入段含【记忆】段', mem.includes('【记忆】'), null);
  // 脏东西检查
  const leaks = ['mem_', '<memid', 'memid:', 'session-', 'sha256', '{"', 'undefined', 'null,', '[object'];
  const hit = leaks.filter((x) => mem.includes(x));
  rec.ok('注入段无 memid / session / JSON 回显 / undefined', hit.length === 0, hit);
  rec.ok('注入段不含四个以上连续换行（无空段堆叠）', !/\n{4,}/.test(mem), null);
  rec.ok('注入段长度 < 1600 字符（L1 上限内）', mem.length < 1600, mem.length);
  // 分段计数
  const sections = mem.split('\n').filter((l) => l.startsWith('【'));
  rec.ok('分段标签 ≥3 个（人格/记忆/摘要/状态里至少三个）', sections.length >= 3, sections);

  // 出站清洗：标签/路径/JSON 回显应被剥掉
  // v14 新库 id 形状是 'm' + 6 位 hex（engine.mjs:44 newId）；老库是整数 id
  const dirtyReply = '好的【记忆】m1a2b3c 我记得 你住浦东 {"scope":"private","k":1,"n":2} 上海';
  const cleaned = H.reply ? await H.reply({ text: dirtyReply }) : null;
  rec.ok('宿主 reply 通道可调用', cleaned !== undefined, typeof cleaned);
  // 直接测 cleaner（不依赖宿主实现细节）
  const { cleanOutgoing } = await import('../../src/outlet/cleaner.mjs');
  const c1 = cleanOutgoing(dirtyReply);
  rec.ok('cleanOutgoing 剥掉 v14 形状的 memid', !c1.text.includes('m1a2b3c'), c1.text.slice(0, 60));
  rec.ok('cleanOutgoing 剥掉注入标签', !c1.text.includes('【记忆】'), c1.text.slice(0, 60));
  rec.ok('cleanOutgoing 记录被移除项', (c1.removed || []).length > 0, c1.removed);
  rec.ok('cleanOutgoing 保留正常内容「浦东」', c1.text.includes('浦东'), c1.text);
  const c2 = cleanOutgoing('今天天气不错，我们去散步吧');
  rec.ok('干净文本不被误改', c2.text === '今天天气不错，我们去散步吧', c2.text);

  // 回声重写：与最近说过的话重复时命中断言
  const { isEcho } = await import('../../src/outlet/cleaner.mjs');
  const echo = isEcho('今天天气不错，我们去散步吧', ['今天天气不错，我们去散步吧'], DEFAULTS);
  rec.ok('完全相同的话判为回声', echo === true, echo);
  const noEcho = isEcho('我去看看年糕在干嘛', ['今天天气不错，我们去散步吧'], DEFAULTS);
  rec.ok('不相关的话不判回声', noEcho === false, noEcho);

  // 睡着时短回复
  const { classifySleepReply, sleepShortReply } = await import('../../src/life/delivery.mjs');
  await b.tool('life_sleep').run({ mode: 'sleep' });
  const clsUrgent = classifySleepReply({ userText: '救命！', scope: SCOPE, ownerQq: OWNER, cfg: b.cfg });
  const clsNormal = classifySleepReply({ userText: '我想要那个', scope: SCOPE, ownerQq: OWNER, cfg: b.cfg });
  const clsGroup = classifySleepReply({ userText: '在吗', scope: 'group:1', ownerQq: OWNER, cfg: b.cfg });
  rec.ok('睡着时紧急词 → 短回复', clsUrgent === 'reply-short', clsUrgent);
  rec.ok('睡着时普通私聊 → 排队', clsNormal === 'queue', clsNormal);
  rec.ok('睡着时群聊 → 丢弃', clsGroup === 'drop', clsGroup);
  const short = sleepShortReply(b.cfg);
  rec.ok('短回复文案非空且短（<30 字）', typeof short === 'string' && short.length > 0 && short.length < 30, short);
  await b.tool('life_sleep').run({ mode: 'awake' });

  // 人格段是否真的用了宿主给的人格
  rec.ok('注入段带上了宿主 persona', mem.includes('小鲸鱼'), null);
  b.cleanup();
  rec.end();
}

// ============================================================ I4 新增功能
async function i4(rec) {
  rec.begin('I4', '所有新增功能：13 工具 + v14 新模块逐个真跑',
    '每一个 v14 新增能力都至少跑一次真实调用，不能只靠静态断言说「有」');
  const b = await boot();
  const { tool, db, rt } = b;
  const now = Date.now();

  // ---- 13 个工具全部可调用 ----
  const calls = {
    life_remember: { fact: 'I4 新增功能验证写入的一条事实', category: 'fact', confidence: 0.85 },
    life_recall: { query: '上海' },
    life_status: {},
    life_lifebook: { action: 'list' },
    life_persona_review: { action: 'list' },
    life_memory_review: { action: 'list' },
    life_gap: { action: 'list' },
    life_sleep: { mode: 'status' },
    life_delivery_poll: {},
    life_delivery_ack: { ids: [] },
    life_propose: { intent: 'checkin', say: '在吗', why: '想你了', risk: 'low' },
    life_mark_sent: { proposal_id: 'none' },
    life_forget: { memory_id: 'none' },
  };
  const matrix = {};
  for (const [n, args] of Object.entries(calls)) {
    const t = tool(n);
    if (!t) { matrix[n] = 'MISSING'; continue; }
    try { const r = await t.run(args); matrix[n] = { ok: true, keys: Object.keys(r || {}).slice(0, 8) }; }
    catch (e) { matrix[n] = { ok: false, err: String(e.message).slice(0, 120) }; }
  }
  rec.eq('13 个工具全部注册', b.host.tools.length, 13);
  rec.ok('13 个工具全部能进 run 不抛异常', Object.values(matrix).every((v) => v !== 'MISSING' && (v.ok !== false)), Object.entries(matrix).filter(([, v]) => v === 'MISSING' || v.ok === false));
  rec.note('toolMatrix', matrix);

  // ---- 睡眠阶段 ----
  const st = sleepMod.sleepStage(rt.state, now, rt.cfg);
  rec.ok('sleepStage 返回四阶段之一', ['awake', 'nrem_light', 'nrem_deep', 'rem'].includes(st), st);
  const settled = sleepMod.settleStages(rt.state, { now, minutes: 180, cfg: rt.cfg, db, dreamEnabled: false, scope: SCOPE });
  rec.ok('settleStages 返回状态对象', !!settled && !!settled.state, settled && settled.state && settled.state.sleep && settled.state.sleep.stage);
  rec.ok('能量始终在 0–1 之间（不会溢出）', settled.state.energy >= 0 && settled.state.energy <= 1, settled.state.energy);

  // ---- 投递队列 ----
  await tool('life_sleep').run({ mode: 'sleep' });
  const q1 = (await import('../../src/life/delivery.mjs')).queueDelivery(rt.state, { text: '睡着时想说的话', kind: 'proactive' }, { now });
  const q2 = (await import('../../src/life/delivery.mjs')).queueDelivery(rt.state, { text: '睡着时想说的话', kind: 'proactive' }, { now: now + 500 });
  rec.ok('睡着时消息进队列', q1.ok === true, q1.reason || 'ok');
  rec.ok('6 小时内同文去重', q2.ok === false && q2.reason === 'duplicate', q2.reason);
  const polled = await tool('life_delivery_poll').run({});
  rec.ok('睡着时 poll 不出队（等醒）', polled.sleeping === true && polled.items.length === 0, { sleeping: polled.sleeping, n: polled.items.length });
  await tool('life_sleep').run({ mode: 'awake' });
  const polled2 = await tool('life_delivery_poll').run({});
  rec.ok('醒了以后 poll 能取到', polled2.items.length >= 1, polled2.items.length);
  const acked = await tool('life_delivery_ack').run({ ids: polled2.items.map((x) => x.id) });
  rec.ok('ack 后队列清空', acked.ok === true && acked.pending === 0, { ok: acked.ok, pending: acked.pending });

  // ---- 缺口 / 顿悟 ----
  const gapOpen = await tool('life_gap').run({ action: 'open', question: '主人到底喜不喜欢被叫小鱼', tension: 0.7 });
  rec.ok('开缺口成功', gapOpen.ok === true, gapOpen.reason || 'ok');
  const gapList = await tool('life_gap').run({ action: 'list' });
  rec.ok('缺口列表能看到刚开的', (gapList.gaps || []).length >= 1, (gapList.gaps || []).length);

  // ---- 建边 ----
  const built = await tool('life_status').run({});
  rec.ok('life_status 能读到 capacity', !!built.capacity, built.capacity && Object.keys(built.capacity));
  const edgesMod = await import('../../src/memory/edges.mjs');
  const dry = edgesMod.buildEdges(db, { now, dryRun: true });
  rec.ok('建边 dryRun 不写字且返回结构完整', dry.dryRun === true && typeof dry.inserted === 'number', { inserted: dry.inserted, dryRun: dry.dryRun });

  // ---- 人格漂移 ----
  const pd = await tool('life_persona_review').run({ action: 'build' });
  rec.ok('人格漂移能生成 diff', pd.ok !== false, pd.ok === false ? pd.reason : Object.keys(pd).slice(0, 6));

  // ---- 信念冲突 / 印记 ----
  const belief = await import('../../src/memory/belief-pool.mjs');
  const al = belief.negativeAlerts(db, rt.state, { now, cfg: rt.cfg });
  rec.ok('告警能跑通（返回数组）', Array.isArray(al), al.length);
  const cons = belief.consistencySample(db, { now, scope: SCOPE });
  rec.ok('一致性抽样结构完整', !!cons && typeof cons.sampled === 'number' && cons.target === 30, cons && { sampled: cons.sampled, target: cons.target });

  // ---- 思绪流 ----
  sleepMod.think(rt.state, '有点想主人了', { now });
  const thoughts = sleepMod.currentThoughts(rt.state, now);
  rec.ok('思绪流能记下一条', (thoughts || []).length >= 1, (thoughts || []).length);
  const tc = sleepMod.thoughtContext(rt.state, now);
  rec.ok('思绪上下文非空且带「不一定要说出来」语气', typeof tc === 'string' && tc.length > 0, tc && tc.slice(0, 40));

  // ---- 夜间巩固 ----
  const nightly = await import('../../src/maintenance/nightly.mjs');
  const n = nightly.runNightly(db, { now, buildEdges: () => edgesMod.buildEdges(db, { now }) });
  rec.ok('夜间巩固能跑通', !!n && typeof n === 'object', n && Object.keys(n).slice(0, 8));
  rec.ok('夜间巩固返回 cold/archive 计数字段', 'cold' in n && 'archive' in n, n && { cold: n.cold, archive: n.archive });

  b.cleanup();
  rec.end();
}

// ============================================================ I5 老功能修补
async function i5(rec) {
  rec.begin('I5', '对不可用老功能的修补：v13 六类脏数据逐条验证',
    '升级前真库里有六类坏掉的东西；这里在模拟脏库上验证每一类都被修好，且用户数据一条不少');
  const b = await boot({}, { dirty: true });
  const { db } = b;
  const before = db.prepare('SELECT COUNT(*) AS n FROM memories').get().n;

  // ① undefined 脏列
  const cols = db.prepare('PRAGMA table_info(memories)').all().map((c) => c.name);
  rec.ok('① undefined 脏列已被删除', !cols.includes('undefined'), cols.includes('undefined') ? 'still-there' : 'gone');
  rec.ok('memories 列数在正常范围（<100，脏列不残留）', cols.length < 100, cols.length);

  // ② life_state 双行
  const lsRows = db.prepare('SELECT id FROM life_state').all();
  rec.ok('② life_state 只有单行（消除 id=1 与 singleton 双写）', lsRows.length <= 1, lsRows.map((r) => r.id));

  // ③ 毫秒字符串 / 混合时间格式
  const mixed = db.prepare("SELECT COUNT(*) AS n FROM memories WHERE typeof(created_at) != 'text'").get().n;
  rec.ok('③ created_at 全部是文本（无毫秒数字串混入）', mixed === 0, mixed);

  // ④ edges 不再恒空（建过边以后会有真行，或至少表可用）
  const edgeCols = db.prepare('PRAGMA table_info(edges)').all().map((c) => c.name);
  rec.ok('④ edges 表带 basis 列（可解释「为什么连」）', edgeCols.includes('basis'), edgeCols);
  const dry = (await import('../../src/memory/edges.mjs')).buildEdges(db, { now: Date.now(), dryRun: false });
  rec.ok('④ buildEdges 真实执行不抛且返回 real 字段', typeof dry.real === 'boolean', dry);

  // ⑤ life_events.type / event_type
  const evCols = db.prepare('PRAGMA table_info(life_events)').all().map((c) => c.name);
  rec.ok('⑤ life_events 已有 event_type 列（v13 全 NULL 的老列不再唱主角）', evCols.includes('event_type'), evCols);
  const evCount = db.prepare('SELECT COUNT(*) AS n FROM life_events').get().n;
  rec.ok('⑤ life_events 表可读', evCount >= 0, evCount);

  // ⑥ action_proposals 只进不出 → 过期清理
  const stale = db.prepare("SELECT COUNT(*) AS n FROM action_proposals WHERE status IN ('pending','allowed') AND created_at < ?").get(Date.now() - 7 * 86400000).n;
  rec.ok('⑥ 过期 pending 提案已被清理（7 天前的不再挂着）', stale === 0, stale);

  // 数据一条不少
  const after = db.prepare('SELECT COUNT(*) AS n FROM memories').get().n;
  rec.ok('修补后用户记忆条数 ≥ 升级前（不清用户数据）', after >= before, { before, after });

  // 脏库上完整跑一轮
  const sec = await b.host.userMessage({ text: '还记得我住哪吗', scope: SCOPE, ownerQq: OWNER });
  rec.ok('脏库修补后照常注入', (sec.get('dsh-life.memory') || '').length > 0, (sec.get('dsh-life.memory') || '').length);
  const st = await b.tool('life_status').run({});
  rec.ok('脏库修补后 life_status 正常', st.ok === true, st.ok);
  rec.note('dirtyRepair', { before, after, cols: cols.length, lifeStateRows: lsRows.length, evCount });
  b.cleanup();
  rec.end();
}

// ============================================================ I6 长跑体验
async function i6(rec) {
  rec.begin('I6', '长跑体验：连续 30 轮不崩、注入不膨胀、状态不漂移',
    '主人天天用，最怕「用着用着变慢/变怪」。这里连跑 30 轮看曲线');
  const b = await boot({ v14: { skipIdleTurn: true } });
  const H = b.host;
  const texts = [
    '早上好', '今天天气怎么样', '我有点累', '年糕又在拆家', '帮我记一下周五要交报告',
    '你睡了吗', '我出门了', '路上好堵', '午饭吃什么', '我想你了',
    '晚安', '我回来了', '今天好忙', '有点烦', '陪我聊会儿',
  ];
  const mems = [];
  const times = [];
  for (let round = 0; round < 30; round++) {
    const text = texts[round % texts.length];
    const t0 = performance.now();
    const sec = await H.userMessage({ text: `${text}（第${round + 1}轮）`, scope: SCOPE, ownerQq: OWNER });
    times.push(performance.now() - t0);
    mems.push((sec.get('dsh-life.memory') || '').length);
    // 每隔几轮插一个空唤醒
    if (round % 5 === 4) {
      await H.userMessage({ text: '(检查有没有人回我)', scope: SCOPE, ownerQq: OWNER, wakeReason: 'replyCheck' });
    }
  }
  rec.eq('30 轮全部完成', mems.length, 30);
  rec.ok('每轮注入都非空', mems.every((x) => x > 0), mems.filter((x) => !x).length);
  const first10 = avg(mems.slice(0, 10));
  const last10 = avg(mems.slice(-10));
  rec.ok('后 10 轮注入长度不膨胀（≤ 前 10 轮 1.6 倍）', last10 <= first10 * 1.6, { first10: +first10.toFixed(1), last10: +last10.toFixed(1) });
  rec.ok('全程注入长度都在 1600 字符上限内', Math.max(...mems) < 1600, Math.max(...mems));
  rec.ok('后 10 轮耗时不退化（P95 ≤ 前 10 轮 2 倍）', pct(times.slice(-10), 0.95) <= pct(times.slice(0, 10), 0.95) * 2 + 50, { early: +pct(times.slice(0, 10), 0.95).toFixed(1), late: +pct(times.slice(-10), 0.95).toFixed(1) });
  rec.eq('空唤醒轮全部被复用（30 轮里 6 次）', b.rt.idleSkips || 0, 6);
  // 状态合理性
  const s = b.rt.state;
  rec.ok('能量在 0–1 之间', s.energy >= 0 && s.energy <= 1, s.energy);
  rec.ok('激素全在 0–1 之间', Object.values(s.hormones).every((v) => v >= 0 && v <= 1), s.hormones);
  rec.ok('状态里有 sleep 段且阶段合法', !!s.sleep && ['awake', 'nrem_light', 'nrem_deep', 'rem'].includes(s.sleep.stage), s.sleep && s.sleep.stage);
  rec.note('longRun', {
    rounds: 30, idleSkips: b.rt.idleSkips,
    memFirst10: +first10.toFixed(1), memLast10: +last10.toFixed(1),
    p95Early: +pct(times.slice(0, 10), 0.95).toFixed(1), p95Late: +pct(times.slice(-10), 0.95).toFixed(1),
    energy: +s.energy.toFixed(3),
  });
  b.cleanup();
  rec.end();
}

export async function runI(rec) {
  await i1(rec);
  await i2(rec);
  await i3(rec);
  await i4(rec);
  await i5(rec);
  await i6(rec);
}
