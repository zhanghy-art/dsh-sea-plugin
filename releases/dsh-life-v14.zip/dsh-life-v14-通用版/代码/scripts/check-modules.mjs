#!/usr/bin/env node
// scripts/check-modules.mjs — 启动自检：语法 / 缺失导入 / 循环依赖 / 孤儿模块（v14 P3）
// 借鉴 Gitee ai-companion-dashboard 的 test/selftest.mjs + checks.mjs：
//   node --check 逐文件、正则收集 exportsOf、相对 import 建图、DFS 找环。
// 目标：0 循环 / 0 孤儿 / 0 缺失依赖，并可输出「N 模块 / M 依赖边」的看板口径。
// 用法：node scripts/check-modules.mjs [--strict]
import { readdirSync, readFileSync, statSync } from 'node:fs';
import { join, dirname, resolve, relative } from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';

const HERE = dirname(fileURLToPath(import.meta.url));
const ROOT = resolve(HERE, '..');
const SRC = join(ROOT, 'src');
const strict = process.argv.includes('--strict');

function walk(dir) {
  const out = [];
  for (const name of readdirSync(dir)) {
    const p = join(dir, name);
    if (statSync(p).isDirectory()) out.push(...walk(p));
    else if (name.endsWith('.mjs')) out.push(p);
  }
  return out;
}

const files = walk(SRC);
const errors = [];
const exportsOf = new Map();
const importsOf = new Map();

// 1) 语法 + 2) 导出名
for (const f of files) {
  const rel = relative(ROOT, f).replace(/\\/g, '/');
  try { execFileSync(process.execPath, ['--check', f], { stdio: 'pipe' }); }
  catch (e) { errors.push(`语法错误 ${rel}: ${String(e.stderr || e.message).slice(0, 160)}`); continue; }
  const src = readFileSync(f, 'utf8');
  const names = new Set();
  for (const re of [
    /export\s+(?:async\s+)?function\s+([A-Za-z_$][\w$]*)/g,
    /export\s+(?:const|let|var)\s+([A-Za-z_$][\w$]*)/g,
    /export\s+class\s+([A-Za-z_$][\w$]*)/g,
  ]) { let m; while ((m = re.exec(src))) names.add(m[1]); }
  const em = src.match(/export\s*\{([^}]+)\}/g) || [];
  for (const block of em) {
    for (const part of block.replace(/export\s*\{|\}/g, '').split(',')) {
      const n = part.trim().split(/\s+as\s+/).pop().trim();
      if (n) names.add(n);
    }
  }
  exportsOf.set(f, names);
}

// 3) 相对 import 建图 + 校验具名导入
const IMPORT_RE = /import\s+(?:([\w$]+)\s*,\s*)?(?:\{([^}]*)\}|\*\s+as\s+([\w$]+)|([\w$]+))?\s*from\s*['"](\.[^'"]+)['"]/g;
for (const f of files) {
  const src = readFileSync(f, 'utf8');
  const list = [];
  let m;
  while ((m = IMPORT_RE.exec(src))) {
    const spec = m[5];
    const target = resolve(dirname(f), spec.endsWith('.mjs') ? spec : spec + '.mjs');
    const named = (m[2] || '').split(',').map(x => x.trim().split(/\s+as\s+/)[0].trim()).filter(Boolean);
    list.push({ target, named, spec });
    if (!files.includes(target)) continue;   // 外部模块不查
    const avail = exportsOf.get(target) || new Set();
    for (const n of named) {
      if (!avail.has(n)) errors.push(`缺失导入 ${relative(ROOT, f).replace(/\\/g, '/')}: ${n} ← ${spec}`);
    }
  }
  importsOf.set(f, list);
}

// 4) DFS 环检测
const graph = new Map(files.map(f => [f, (importsOf.get(f) || []).map(x => x.target).filter(t => files.includes(t))]));
const cycles = [];
const color = new Map();
const stack = [];
function dfs(n) {
  color.set(n, 1); stack.push(n);
  for (const t of graph.get(n) || []) {
    if (color.get(t) === 1) {
      const i = stack.indexOf(t);
      cycles.push([...stack.slice(i), t].map(p => relative(ROOT, p).replace(/\\/g, '/')));
    } else if (!color.get(t)) dfs(t);
  }
  stack.pop(); color.set(n, 2);
}
for (const f of files) if (!color.get(f)) dfs(f);

// 5) 孤儿（既不被引用、也不引用别人；入口文件豁免）
const incoming = new Map(files.map(f => [f, 0]));
for (const [f, ts] of graph) for (const t of ts) incoming.set(t, (incoming.get(t) || 0) + 1);
const entryHints = ['src/index.mjs', 'src/host/dsh.mjs', 'src/host/generic.mjs', 'src/maintenance/nightly.mjs'];
const orphans = files.filter(f => {
  const rel = relative(ROOT, f).replace(/\\/g, '/');
  return incoming.get(f) === 0 && (graph.get(f) || []).length === 0 && !entryHints.some(h => rel.endsWith(h));
}).map(f => relative(ROOT, f).replace(/\\/g, '/'));

const edges = [...graph.values()].reduce((n, a) => n + a.length, 0);
console.log(`模块 ${files.length} / 依赖边 ${edges} / 循环 ${cycles.length} / 孤儿 ${orphans.length}`);
if (cycles.length) for (const c of cycles.slice(0, 5)) console.log('  循环: ' + c.join(' → '));
if (orphans.length) console.log('  孤儿: ' + orphans.join(', '));
for (const e of errors.slice(0, 20)) console.log('  ' + e);
if (errors.length > 20) console.log(`  ... 另有 ${errors.length - 20} 条`);
const bad = errors.length || cycles.length || (strict && orphans.length);
console.log(bad ? '✗ 模块自检失败' : '✓ 模块自检通过');
if (bad) process.exit(1);
