#!/usr/bin/env node
import { readFileSync, writeFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { parseEvalDataset, runRetrievalEval } from '../src/eval/retrieval-eval.mjs';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const args = process.argv.slice(2);
const json = args.includes('--json');
const datasetArg = args.find((arg) => arg.startsWith('--dataset='))?.slice('--dataset='.length)
  || join(ROOT, 'eval', 'zh-retrieval.json');
const outArg = args.find((arg) => arg.startsWith('--out='))?.slice('--out='.length);
const dataset = parseEvalDataset(readFileSync(resolve(ROOT, datasetArg), 'utf8'));
const result = await runRetrievalEval(dataset, { root: ROOT });
if (outArg) writeFileSync(resolve(ROOT, outArg), JSON.stringify(result, null, 2) + '\n', 'utf8');

if (json) {
  console.log(JSON.stringify(result, null, 2));
} else {
  console.log(`dataset=${dataset.name || datasetArg}`);
  console.log(`recall@${result.topK}=${result.recallAtK} mrr=${result.mrr} forbiddenLeaks=${result.forbiddenLeaks}`);
  for (const item of result.cases) {
    console.log(`${item.hit ? 'PASS' : 'FAIL'} ${item.id} rr=${item.reciprocalRank.toFixed(2)} leaks=${item.leaks}`);
  }
}
if (!result.passed) process.exit(1);
