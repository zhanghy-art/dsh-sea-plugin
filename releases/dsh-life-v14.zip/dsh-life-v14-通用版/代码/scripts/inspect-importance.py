#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""scripts/inspect-importance.py — 升级前后对账旧库的 importance 分布

用途：你已经按 11.1 的方案手工调过 importance，升级前先跑这个，
      确认「升级不会改它」「运行期有没有别的机制会改它」。

只用标准库 sqlite3，不需要 Node。
用法：
  python3 scripts/inspect-importance.py --db ~/.dsh/dsh-life/mind.db
  python3 scripts/inspect-importance.py --db mind.db --export before.csv
"""
import argparse
import csv
import os
import sqlite3
import sys
from collections import Counter


def connect(path):
    if not os.path.exists(path):
        print(f"库不存在：{path}")
        sys.exit(2)
    con = sqlite3.connect(path)
    con.row_factory = sqlite3.Row
    return con


def has_col(con, table, col):
    try:
        return col in [r[1] for r in con.execute(f"PRAGMA table_info({table})").fetchall()]
    except sqlite3.OperationalError:
        return False


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", required=True)
    ap.add_argument("--export", default="", help="导出 CSV 快照路径")
    args = ap.parse_args()

    con = connect(args.db)
    total = con.execute("SELECT COUNT(*) FROM memories WHERE invalid_reason IS NULL").fetchone()[0]
    if not total:
        print("库里没有有效记忆。")
        return

    print(f"库：{args.db}")
    print(f"有效记忆：{total} 条\n")

    # ---- 分布 ----
    buckets = Counter()
    for r in con.execute("SELECT importance FROM memories WHERE invalid_reason IS NULL"):
        v = float(r["importance"] or 0)
        if v >= 0.95:
            buckets["0.95–1.00"] += 1
        elif v >= 0.90:
            buckets["0.90–0.95"] += 1
        elif v >= 0.70:
            buckets["0.70–0.90"] += 1
        elif v >= 0.50:
            buckets["0.50–0.70"] += 1
        else:
            buckets["0.00–0.50"] += 1

    print("== importance 分布 ==")
    for k in ["0.95–1.00", "0.90–0.95", "0.70–0.90", "0.50–0.70", "0.00–0.50"]:
        n = buckets.get(k, 0)
        pct = n / total * 100
        bar = "█" * int(pct / 2)
        print(f"  {k}  {n:>5} 条  {pct:5.1f}%  {bar}")

    hi90 = sum(1 for r in con.execute("SELECT importance FROM memories WHERE invalid_reason IS NULL")
               if float(r["importance"] or 0) >= 0.90)
    hi95 = sum(1 for r in con.execute("SELECT importance FROM memories WHERE invalid_reason IS NULL")
               if float(r["importance"] or 0) >= 0.95)
    print(f"\n  importance ≥0.90：{hi90} 条（{hi90 / total * 100:.1f}%），v14 水位 8%")
    print(f"  importance ≥0.95：{hi95} 条（{hi95 / total * 100:.1f}%），v14 水位 3%")

    # ---- 升级会不会动它 ----
    print("\n== 升级动作对 importance 的影响 ==")
    print("  升级时执行的回填只有三条，且都带 WHERE ... IS NULL：")
    print("    belief      ← COALESCE(beta, 0.7)   （只填空值）")
    print("    valid_from  ← COALESCE(confirmed_at, created_at)")
    print("    content_hash← 新生成")
    print("  protection_tier ← 一律置 'normal'（不追认 core）")
    print("  → importance 不在回填清单里，升级过程完全不写这个字段。")

    # ---- 运行期有没有别的机制会动它 ----
    print("\n== 运行期对 importance 的改动路径 ==")
    print("  enforceTierQuota：只改 protection_tier（core→stable→normal），不改 importance。")
    print("  enforceImportanceQuota：会把 0.90+ 超水位的那部分降到 0.85 ——")
    print("    该函数在 v14.0 的写入主流程中【未被调用】，只有显式调用才生效。")

    # ---- tier 配额会不会影响你调过的条目 ----
    if has_col(con, "memories", "protection_tier"):
        tier_rows = con.execute(
            "SELECT protection_tier, COUNT(*) n FROM memories WHERE invalid_reason IS NULL GROUP BY protection_tier"
        ).fetchall()
        print("\n== 保护层级分布 ==")
        for r in tier_rows:
            print(f"  {r['protection_tier'] or '(空)'}：{r['n']} 条")
        stable = sum(r["n"] for r in tier_rows if r["protection_tier"] == "stable")
        if stable > total * 0.15:
            excess = stable - int(total * 0.15)
            print(f"  ⚠ stable 超过 15% 水位，写入时会有 {excess} 条被降为 normal（只改层级，不改 importance）")
    else:
        print("\n（该库尚未升级，没有 protection_tier 列——正是升级前应该看到的样子）")

    # ---- 导出快照 ----
    if args.export:
        cols = ["id", "scope", "category", "importance", "emotional_salience", "confirmed_at", "cold"]
        rows = con.execute(
            "SELECT id, scope, category, importance, emotional_salience, confirmed_at, cold "
            "FROM memories WHERE invalid_reason IS NULL ORDER BY importance DESC"
        ).fetchall()
        with open(args.export, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(cols)
            for r in rows:
                w.writerow([r[c] for c in cols])
        print(f"\n已导出快照：{args.export}（{len(rows)} 条，按 importance 降序）")
        print("升级后再跑一次 --export after.csv，用 diff 对比即可确认一字未改。")

    con.close()


if __name__ == "__main__":
    main()
