#!/usr/bin/env node
// Explicit, opt-in schema decision. Dry-run is the default.
import { DatabaseSync } from 'node:sqlite';
import { migrateEdgesBasis } from '../src/kit/optional-migrations.mjs';

const args = process.argv.slice(2);
const dbPath = args.find((arg) => arg.startsWith('--db='))?.slice('--db='.length)
  || (args.includes('--db') ? args[args.indexOf('--db') + 1] : '');
const apply = args.includes('--apply');
if (!dbPath) {
  console.error('usage: node scripts/migrate-edges-basis.mjs --db <mind.db> [--apply]');
  process.exit(2);
}
const db = new DatabaseSync(dbPath);
try {
  const out = migrateEdgesBasis(db, { apply });
  console.log(JSON.stringify(out));
  if (!out.ok) process.exit(1);
} finally {
  db.close();
}
