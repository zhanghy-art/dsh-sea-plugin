#!/usr/bin/env node
// scripts/privacy-scan.mjs — 打包期隐私门禁（借 arcdream-hub 的 build_release 思路）
// 发布前跑一次：命中任何一条即退出码 1，中止打包。
// 运行期只能拦「要写进记忆的凭据」，拦不住「代码/文档里残留的真实路径与昵称」——所以必须有这一层。
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join, relative } from 'node:path';

const ROOT = process.argv[2] || '.';
const SKIP_DIRS = new Set(['node_modules', '.git', 'sandbox/work', 'sandbox/logs', '.sources']);
const SKIP_EXT = new Set(['.png', '.jpg', '.jpeg', '.gif', '.webp', '.zip', '.db', '.bak', '.ico']);

const RULES = [
  // —— 真实路径（v14 打包期门禁的原有职责）——
  ['win-abs-path', /[A-Za-z]:\\(?:Users|Documents|Desktop|dsh|v13|code)[^\s'"`)]{0,80}/g],
  ['home-abs-path', /\/(?:Users|home)\/[A-Za-z0-9._-]+\/(?![.\/])[^\s'"`)]{0,60}/g],
  // —— 真实凭据（v14.2 合入 WorkBuddy 的 HIGH 规则集）——
  ['openai-key', /\bsk-(?:proj-|ant-)?[A-Za-z0-9_-]{20,}\b/g],
  ['aws-key', /\bAKIA[0-9A-Z]{16}\b/g],
  ['github-token', /\bgh[pousr]_[A-Za-z0-9]{30,}\b/g],
  ['slack-token', /\bxox[baprs]-[A-Za-z0-9-]{10,}\b/g],
  ['api-key', /\b(api[_-]?key\s*[:=]\s*\S{8,}|password\s*[:=]\s*\S{6,})/gi],
  ['pem', /-----BEGIN (?:RSA |EC |OPENSSH |DSA |PGP )?PRIVATE KEY-----/g],
  ['long-token', /\b[A-Za-z0-9_-]{40,}\b/g],
];

// 占位值：真凭据不会长这样（WB 的 PLACEHOLDER 口径）
const PLACEHOLDER = /^(null|undefined|true|false|<\s*[^>]+\s*>|\{\{[^}]+\}\}|your[-_ ]?|xxxx+|test|example|dummy|placeholder|todo)$/i;

// 项目自有的、允许出现的名字（避免误报）
const ALLOW = [/example\.com/g, /127\.0\.0\.1/g, /localhost/g, /dsh-life/g, /arcdream-hub/g];

// 测试夹具：这些字面量是「断言凭据拦截确实生效」用的假数据，不是真秘密。
// 只允许出现在 tests/ 下，且必须是这几个固定串，避免把真 key 混进白名单。
const FIXTURE = [
  { file: /^tests\//, sample: /^sk-abcdefghijklmnop/ },
  { file: /^tests\//, sample: /^-----BEGIN RSA PRIVATE KEY-----$/ },
  { file: /^tests\//, sample: /^api_key=/ },
  { file: /^tests\//, sample: /^password:/ },
];
const isFixture = (file, raw) => FIXTURE.some((f) => f.file.test(file) && f.sample.test(raw));

const hits = [];
function walk(dir) {
  for (const name of readdirSync(dir)) {
    const p = join(dir, name);
    const rel = relative(ROOT, p).replace(/\\/g, '/');
    if ([...SKIP_DIRS].some((d) => rel === d || rel.startsWith(d + '/'))) continue;
    if (/^sandbox\/work-archive-/.test(rel)) continue;
    if (/^sandbox\/[^/]*-retest(?:\/|$)/.test(rel)) continue;
    if (rel === 'scripts/privacy-scan.mjs') continue;   // 扫描器自身的规则表会命中自己
    const st = statSync(p);
    if (st.isDirectory()) { walk(p); continue; }
    const ext = name.slice(name.lastIndexOf('.')).toLowerCase();
    if (SKIP_EXT.has(ext)) continue;
    if (st.size > 2 * 1024 * 1024) continue;
    let text = '';
    try { text = readFileSync(p, 'utf8'); } catch { continue; }
    for (const [id, re] of RULES) {
      re.lastIndex = 0;
      let m;
      while ((m = re.exec(text))) {
        const raw = m[0];
        if (ALLOW.some((a) => a.test(raw))) continue;
        if (isFixture(rel, raw)) continue;
        // 占位符 / 文档示例：真凭据不会含反引号、尖括号或省略号
        if (/[`<>…]|\.\.\./.test(raw)) continue;
        if (PLACEHOLDER.test(raw)) continue;
        const line = text.slice(0, m.index).split('\n').length;
        hits.push({ id, file: rel, line, sample: raw.slice(0, 24) + (raw.length > 24 ? '…' : '') });
        if (hits.length > 200) return;
      }
    }
  }
}

walk(ROOT);
if (!hits.length) {
  console.log('[privacy-scan] PASS  未发现真实路径 / 凭据 / 长 token');
  process.exit(0);
}
console.log(`[privacy-scan] FAIL  ${hits.length} 处命中，已中止打包：`);
for (const h of hits.slice(0, 40)) console.log(`  ${h.id.padEnd(14)} ${h.file}:${h.line}  ${h.sample}`);
if (hits.length > 40) console.log(`  ... 其余 ${hits.length - 40} 处略`);
process.exit(1);
