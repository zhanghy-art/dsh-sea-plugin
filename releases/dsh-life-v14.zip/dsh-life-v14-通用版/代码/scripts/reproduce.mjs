#!/usr/bin/env node
// scripts/reproduce.mjs — 可复现证据包
// 用途：回应“不采信没有环境证据的完成声明”。输出环境指纹 + 三组断言摘要 + 关键参数快照，
// 可直接与 tests/expected.txt 做 diff。
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { DEFAULTS } from '../src/kit/config.mjs';

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..');
const out = [];
const line = (s = '') => out.push(s);

line('# dsh-life 可复现报告');
line(`生成时间：${new Date().toISOString()}`);
line(`Node：${process.versions.node}`);
line(`平台：${process.platform}/${process.arch}`);
line(`策略版本：${DEFAULTS.random.policyVersion}`);
line('');

// 1) 环境能力
let hasSqlite = true;
try { await import('node:sqlite'); } catch { hasSqlite = false; }
line(`node:sqlite：${hasSqlite ? '可用' : '不可用（数据库组将 SKIP）'}`);
line('');

// 2) 三个测试文件
const suites = [
  ['tests/verify.mjs', '基线（v11.1 继承）'],
  ['tests/verify12.mjs', 'v12.1 新增'],
  ['tests/verify13.mjs', 'v13.0 收敛'],
];
let totalPass = 0, totalFail = 0, totalSkip = 0;
for (const [f, name] of suites) {
  let stdout = '';
  try {
    stdout = execFileSync(process.execPath, [join(ROOT, f)], { encoding: 'utf8' });
  } catch (e) {
    stdout = (e.stdout || '') + (e.stderr || '');
  }
  const m = stdout.match(/PASS\s+(\d+)\s*\/\s*FAIL\s+(\d+)(?:\s*\/\s*SKIP\s+(\d+))?/) ||
            stdout.match(/结果[^：]*：PASS\s+(\d+)\s*\/\s*FAIL\s+(\d+)/);
  const p = Number(m?.[1] ?? 0), fl = Number(m?.[2] ?? 0), sk = Number(m?.[3] ?? 0);
  totalPass += p; totalFail += fl; totalSkip += sk;
  line(`${f}  ${name}：PASS ${p} / FAIL ${fl} / SKIP ${sk}`);
}
line('');
line(`合计：PASS ${totalPass} / FAIL ${totalFail} / SKIP ${totalSkip}`);

// 2.5 升级验证（Python sqlite3，不依赖 node:sqlite）
try {
  const rep = readFileSync(join(ROOT, 'tests/upgrade-report.txt'), 'utf8');
  const m = rep.match(/合计：PASS (\d+) \/ FAIL (\d+)/);
  line(`scripts/verify-upgrade.py  升级验证：PASS ${m?.[1] ?? '?'} / FAIL ${m?.[2] ?? '?'}`);
} catch { line('scripts/verify-upgrade.py  升级验证：（未生成报告，先跑 python3 scripts/verify-upgrade.py）'); }
line('');

// 3) 关键参数快照（比对用，不是全部参数）
line('## 关键参数快照');
const snap = {
  'retrieval.gate': [DEFAULTS.retrieval.textFloor, DEFAULTS.retrieval.cosFloor, DEFAULTS.retrieval.scoreFloor, DEFAULTS.retrieval.beliefFloor],
  'retrieval.topK': DEFAULTS.retrieval.topK,
  'weight.coreHalfLifeFactor': DEFAULTS.weight.coreHalfLifeFactor,
  'weight.coreFloor': DEFAULTS.weight.coreFloor,
  'memory.injectionCooldownHours': DEFAULTS.memory.injectionCooldownHours,
  'lifecycle.archiveTurns': DEFAULTS.lifecycle.archiveTurns,
  'capabilities': DEFAULTS.capabilities,
  'reflex': [DEFAULTS.reflex.threshold, DEFAULTS.reflex.explicitGain, DEFAULTS.reflex.decayPerTick],
  'random': [DEFAULTS.random.leadThreshold, DEFAULTS.random.samplePool],
  'fsrs.cap': DEFAULTS.fsrs.stabilityCap,
  'budget': DEFAULTS.budget,
};
for (const [k, v] of Object.entries(snap)) line(`${k} = ${JSON.stringify(v)}`);
line('');

// 4) 源码指纹（确保对的是同一份代码）
const files = ['schema.sql', 'src/index.mjs', 'src/memory/weight.mjs', 'src/memory/engine.mjs', 'src/memory/search.mjs', 'src/outlet/cleaner.mjs'];
line('## 源码指纹（sha256 前 12 位）');
for (const f of files) {
  try {
    const h = createHash('sha256').update(readFileSync(join(ROOT, f))).digest('hex').slice(0, 12);
    line(`${f} = ${h}`);
  } catch { line(`${f} = （缺失）`); }
}

const text = out.join('\n');
writeFileSync(join(ROOT, 'tests/report.txt'), text);
console.log(text);
