#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""scripts/verify-upgrade.py — 从 v11.1 直接升级到 v14.0 的可执行验证

它做四件事：
1. 按 v11.1 文档造一个“旧库”（21+ 字段、9 张辅助表、三种 scope 的真实数据）
2. 用 migrations/columns.json + migrations/tables.sql（与 migrate.mjs 同一份）升级
3. 校验：列齐、数据不丢、索引/触发器在、版本戳正确、二次执行幂等
4. 校验升级后的新写入与 scope 隔离

输出：tests/upgrade-report.txt（可 diff）
用法：python3 scripts/verify-upgrade.py
"""
import json
import os
import sqlite3
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
PLAN = json.loads((ROOT / "migrations" / "columns.json").read_text(encoding="utf-8"))
TABLES_SQL = (ROOT / "migrations" / "tables.sql").read_text(encoding="utf-8")
DB = ROOT / "tests" / "_upgrade_fixture.db"

lines = []
ok_n = fail_n = 0


def log(s=""):
    lines.append(s)
    print(s)


def check(name, cond, detail=""):
    global ok_n, fail_n
    if cond:
        ok_n += 1
        log(f"  PASS {name}" + (f"  [{detail}]" if detail else ""))
    else:
        fail_n += 1
        log(f"  FAIL {name}" + (f"  [{detail}]" if detail else ""))


V11_DDL = """
CREATE TABLE memories (
  id TEXT PRIMARY KEY, scope TEXT NOT NULL, subject_qq TEXT,
  category TEXT NOT NULL, fact TEXT NOT NULL, tags TEXT,
  evidence TEXT, evidence_kind TEXT, evidence_ref TEXT, source_kind TEXT, source_id TEXT, raw INTEGER DEFAULT 0,
  importance REAL DEFAULT 0.5, emotional_salience REAL DEFAULT 0, relationship_salience REAL DEFAULT 0,
  happened_at INTEGER, created_at INTEGER NOT NULL, confirmed_at INTEGER, time_granularity TEXT DEFAULT 'point',
  emotion TEXT, emotion_intensity REAL DEFAULT 0, bot_feeling TEXT, bot_feeling_intensity REAL DEFAULT 0,
  perspective TEXT, attr_key TEXT, attr_value TEXT, supersedes TEXT,
  invalid_reason TEXT, valid_to INTEGER,
  recall_count INTEGER DEFAULT 0, last_recalled INTEGER, uses INTEGER DEFAULT 0,
  cold INTEGER DEFAULT 0, cold_reason TEXT, cold_at INTEGER, audit_status TEXT DEFAULT 'ok',
  vec BLOB, vec_model TEXT
);
CREATE TABLE narratives (id TEXT PRIMARY KEY, scope TEXT, period TEXT, period_start INTEGER,
  text TEXT, chars INTEGER, audit_status TEXT, created_at INTEGER, injected_at INTEGER);
CREATE TABLE candidates (id TEXT PRIMARY KEY, scope TEXT, subject_qq TEXT, text TEXT, kind TEXT,
  payload TEXT, category TEXT, evidence TEXT, evidence_kind TEXT, evidence_ref TEXT, msg_ids TEXT,
  source_kind TEXT, source_id TEXT, confidence REAL, status TEXT, memory_id TEXT,
  created_at INTEGER, expires_at INTEGER);
CREATE TABLE relationships (scope TEXT PRIMARY KEY, closeness REAL, trust REAL, stage TEXT, updated_at INTEGER);
CREATE TABLE promises (id TEXT PRIMARY KEY, scope TEXT, text TEXT, due_at INTEGER, status TEXT,
  created_at INTEGER, last_notified_at INTEGER);
CREATE TABLE milestones (id TEXT PRIMARY KEY, scope TEXT, text TEXT, happened_at INTEGER, created_at INTEGER);
CREATE TABLE memories_archive (id TEXT, archived_at INTEGER, reason TEXT, payload TEXT);
CREATE TABLE reflexes (id TEXT PRIMARY KEY, scope TEXT, subject_qq TEXT, trigger TEXT, response TEXT,
  pain_level REAL, last_fired_at INTEGER, fire_count INTEGER, created_at INTEGER);
CREATE TABLE injection_log (id INTEGER PRIMARY KEY AUTOINCREMENT, memory_id TEXT, scope TEXT,
  kind TEXT, injected_at INTEGER, turn_id TEXT);
"""

SEED = [
    ("m000001", "shared", None, "person", "她叫小满，是主人的女朋友", "称呼,人物", 0.9, 0.7),
    ("m000002", "shared", None, "person", "主人不吃香菜", "饮食,忌讳", 0.7, 0.4),
    ("m000003", "shared", None, "fact", "主人做后端，主要写 Go", "工作,事实", 0.6, 0.2),
    ("m000004", "chat:private", None, "event", "昨天一起去看了《海上钢琴师》重映", "电影,事件", 0.7, 0.8),
    ("m000005", "chat:private", None, "preference", "她喜欢冰美式，双份浓缩", "咖啡,偏好", 0.6, 0.3),
    ("m000006", "chat:private", None, "promise", "答应周末陪她去逛展", "约定,周末", 0.8, 0.5),
    ("m000007", "chat:private", None, "event", "上周因为加班的事吵了一架", "冲突,事件", 0.8, 0.9),
    ("m000008", "chat:private", None, "meme", "她说“绷不住了”是口头禅", "梗", 0.4, 0.4),
    ("m000009", "group:g1", None, "fact", "群规：不许发广告", "群规", 0.9, 0.1),
    ("m000010", "group:g1", None, "event", "群里昨天在聊露营装备", "露营,事件", 0.5, 0.4),
    ("m000011", "group:g2", None, "fact", "g2 群主要做独立开发", "工作", 0.5, 0.2),
    ("m000012", "chat:private", None, "fact", "她生日是 3 月 14 日", "生日,人物", 0.95, 0.6),
]


def build_v11(path: Path):
    # WAL 残留会让新库直接 malformed，三件套都要删
    for suf in ("", "-wal", "-shm"):
        f = Path(str(path) + suf)
        if f.exists():
            f.unlink()
    con = sqlite3.connect(path)
    con.executescript(V11_DDL)
    now = int(time.time() * 1000)
    for i, (mid, scope, qq, cat, fact, tags, imp, emo) in enumerate(SEED):
        con.execute(
            "INSERT INTO memories (id,scope,subject_qq,category,fact,tags,evidence,evidence_kind,evidence_ref,"
            "source_kind,raw,importance,emotional_salience,relationship_salience,happened_at,created_at,confirmed_at,"
            "time_granularity,audit_status,recall_count,cold) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (mid, scope, qq, cat, fact, tags, fact, "user_sentence", mid, "user", 0,
             imp, emo, 0.3, now - i * 86400000, now - i * 86400000, now - i * 86400000,
             "point", "ok", i, 0),
        )
    con.execute("INSERT INTO reflexes (id,scope,trigger,response,pain_level,fire_count,created_at) "
                "VALUES ('r1','chat:private','加班','（沉默了一下）',0.8,0,'%d')" % now)
    con.execute("INSERT INTO candidates (id,scope,text,kind,status,created_at,expires_at) "
                "VALUES ('c1','chat:private','她说想养猫','episode','pending',?,?)" % (), (now, now + 86400000))
    con.commit()
    con.close()


def cols(con, table):
    return [r[1] for r in con.execute(f"PRAGMA table_info({table})").fetchall()]


def run_migration(con, dry=False):
    added = skipped = 0
    have = set(cols(con, "memories"))
    for c in PLAN["columns"]:
        if c["name"] in have:
            skipped += 1
            continue
        con.execute(f"ALTER TABLE memories ADD COLUMN {c['name']} {c['def']}")
        added += 1
    # 顺序很关键：先把“已存在的旧辅助表”补列，再执行 tables.sql（否则新索引会引用不存在的列）
    for p in PLAN.get("table_column_patches", []):
        exists = con.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name=?", (p["table"],)
        ).fetchone()
        if not exists:
            continue
        have2 = set(cols(con, p["table"]))
        if p["column"] in have2:
            skipped += 1
            continue
        try:
            con.execute(f"ALTER TABLE {p['table']} ADD COLUMN {p['column']} {p['def']}")
            added += 1
        except sqlite3.OperationalError as e:
            log(f"    ! {p['table']}.{p['column']} 补列失败：{e}")
    con.executescript(TABLES_SQL)
    for i, sql in enumerate([c["backfill"] for c in PLAN["columns"] if c.get("backfill")] + PLAN.get("post_migrate_sql", [])):
        try:
            con.execute(sql)
        except sqlite3.Error as e:
            log(f"    ! 回填 #{i} 失败：{e} :: {sql[:70]}")
            raise
    con.execute("CREATE TABLE IF NOT EXISTS kv (k TEXT PRIMARY KEY, v TEXT, updated_at INTEGER)")
    con.execute("INSERT INTO kv(k,v,updated_at) VALUES('schema_version',?,?) "
                "ON CONFLICT(k) DO UPDATE SET v=excluded.v", (PLAN["target_label"], int(time.time() * 1000)))
    con.execute("INSERT OR REPLACE INTO schema_migrations(version,label,applied_at) VALUES(?,?,?)",
                (PLAN["target_version"], PLAN["target_label"], int(time.time() * 1000)))
    con.execute(f"PRAGMA user_version = {PLAN['target_version']};")
    con.commit()
    return added, skipped


def main():
    log("# v11.1 → v14.0 升级验证报告")
    log(f"生成时间：{time.strftime('%Y-%m-%d %H:%M:%S')}")
    log(f"Python sqlite3：{sqlite3.sqlite_version}")
    log(f"计划版本：{PLAN['target_label']}（{len(PLAN['columns'])} 列 + {len(PLAN.get('table_column_patches', []))} 个辅助表补列）")
    log("")

    build_v11(DB)
    con = sqlite3.connect(DB)
    before_rows = con.execute("SELECT COUNT(*) FROM memories").fetchone()[0]
    before_facts = [r[0] for r in con.execute("SELECT fact FROM memories ORDER BY id").fetchall()]
    before_cols = len(cols(con, "memories"))
    before_imp = con.execute("SELECT id, importance FROM memories ORDER BY id").fetchall()

    log("== 1. 旧库基线（模拟 v11.1） ==")
    check("旧库字段数在 30–40 之间", 30 <= before_cols <= 40, f"{before_cols} 列")
    check("旧库 12 条记忆", before_rows == 12, str(before_rows))
    check("旧库无 belief 列（确认是 11.1）", "belief" not in cols(con, "memories"))
    check("旧库无 memory_evidence 表",
          not con.execute("SELECT name FROM sqlite_master WHERE name='memory_evidence'").fetchone())
    log("")

    log("== 2. 第一次迁移（原地：同一文件） ==")
    st_before = os.stat(DB)
    added, skipped = run_migration(con)
    st_after = os.stat(DB)
    check("原地升级：inode 未变（还是同一个文件）", st_before.st_ino == st_after.st_ino,
          f"{st_before.st_ino} → {st_after.st_ino}")
    check("原地升级：路径未变", os.path.abspath(DB) == os.path.abspath(DB))
    check("目录里没有多出第二个 .db（不是新建库）",
          len(list(DB.parent.glob("*.db"))) == 1, f"{[p.name for p in DB.parent.glob('*.db')]}")
    check("文件体积只增不减（加列不改旧数据）", st_after.st_size >= st_before.st_size,
          f"{st_before.st_size} → {st_after.st_size}")
    missing_cols = [c["name"] for c in PLAN["columns"] if c["name"] not in set(cols(con, "memories"))]
    check("计划内 21 列全部到位", not missing_cols, f"added={added} skipped={skipped} missing={missing_cols}")
    check("记忆条数不变（不删数据）", con.execute("SELECT COUNT(*) FROM memories").fetchone()[0] == before_rows)
    check("正文逐条一致", [r[0] for r in con.execute("SELECT fact FROM memories ORDER BY id")] == before_facts)
    for tbl in ["memory_evidence", "context_checkpoints", "gaps", "memory_cells", "edges",
                "schema_migrations", "action_proposals", "life_state"]:
        check(f"表 {tbl} 已建",
              bool(con.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (tbl,)).fetchone()))
    for idx in ["idx_mem_scope_cat", "idx_mem_scope_inj", "idx_ev_mem", "idx_cand_status2"]:
        check(f"索引 {idx} 已建",
              bool(con.execute("SELECT name FROM sqlite_master WHERE type='index' AND name=?", (idx,)).fetchone()))
    trig = con.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='trigger' AND name LIKE 'mem_a%'").fetchone()[0]
    check("FTS 触发器 3 个", trig == 3, str(trig))
    uv = con.execute("PRAGMA user_version").fetchone()[0]
    check("user_version=14", uv == PLAN["target_version"], str(uv))
    kvv = con.execute("SELECT v FROM kv WHERE k='schema_version'").fetchone()
    check("kv.schema_version=14.0", kvv and kvv[0] == PLAN["target_label"], str(kvv))
    check("schema_migrations 有记录",
          con.execute("SELECT COUNT(*) FROM schema_migrations").fetchone()[0] >= 1)
    log("")

    after_imp = con.execute("SELECT id, importance FROM memories ORDER BY id").fetchall()
    check("importance 逐条未改（手工调过的分数不被覆盖）", before_imp == after_imp,
          f"{len(before_imp)} 条比对")
    tiers = {r[0] for r in con.execute("SELECT DISTINCT protection_tier FROM memories").fetchall()}
    check("protection_tier 全为 normal（不追认 core）", tiers == {"normal"}, str(tiers))

    log("== 3. 回填正确性 ==")
    r = con.execute("SELECT belief, protection_tier, valid_from, content_hash IS NOT NULL FROM memories WHERE id='m000012'").fetchone()
    check("belief 已回填（非空）", r[0] is not None, str(r[0]))
    check("protection_tier 默认 normal（不追认 core）", r[1] == "normal", str(r[1]))
    check("valid_from 已回填", r[2] is not None)
    check("content_hash 已生成", r[3] == 1)
    log("")

    log("== 4. 第二次迁移（幂等） ==")
    n_before2 = con.execute("SELECT COUNT(*) FROM memories").fetchone()[0]
    ev_before = con.execute("SELECT COUNT(*) FROM memory_evidence").fetchone()[0]
    added2, _ = run_migration(con)
    check("第二次新增列 = 0", added2 == 0, f"added={added2}")
    check("记忆条数不变", con.execute("SELECT COUNT(*) FROM memories").fetchone()[0] == n_before2)
    check("证据表无重复膨胀", con.execute("SELECT COUNT(*) FROM memory_evidence").fetchone()[0] == ev_before)
    check("迁移台账不重复", con.execute("SELECT COUNT(*) FROM schema_migrations WHERE version=14").fetchone()[0] == 1)
    log("")

    log("== 5. 升级后新写入（全列插入） ==")
    now = int(time.time() * 1000)
    all_cols = cols(con, "memories")
    row = {c: None for c in all_cols}
    row.update({
        "id": "m999999", "scope": "chat:private", "category": "fact",
        "fact": "升级后写入的一条新记忆", "created_at": now, "confirmed_at": now,
        "valid_from": now, "importance": 0.6, "belief": 0.9, "beta": 0.9,
        "protection_tier": "normal", "content_hash": "abc123", "review_stability": 1,
        "evidence_count": 1, "cold": 0, "audit_status": "ok", "recall_count": 0, "uses": 0,
    })
    try:
        con.execute(
            f"INSERT INTO memories ({','.join(row.keys())}) VALUES ({','.join(['?'] * len(row))})",
            list(row.values()),
        )
        con.commit()
        check("升级后可以正常 INSERT（无缺列）", True)
    except sqlite3.Error as e:
        check("升级后可以正常 INSERT（无缺列）", False, str(e))
    log("")

    log("== 5.5 FTS 与触发器（致命坑的专项验证） ==")
    # 这个坑的现场：旧库先有数据、后建 FTS 虚表与触发器。
    # 若迁移末尾没有 rebuild，下面第一条 UPDATE 就会抛 database disk image is malformed。
    try:
        con.execute("UPDATE memories SET fact = ? WHERE id = 'm000005'", ("她喜欢冰美式，三份浓缩",))
        con.commit()
        check("升级后 UPDATE 旧记忆不报 malformed", True)
    except sqlite3.Error as e:
        check("升级后 UPDATE 旧记忆不报 malformed", False, str(e))

    try:
        con.execute("UPDATE memories SET fact = ? WHERE id = 'm000005'", ("她喜欢冰美式，双份浓缩，加燕麦奶",))
        con.commit()
        check("连续第二次 UPDATE 仍正常", True)
    except sqlite3.Error as e:
        check("连续第二次 UPDATE 仍正常", False, str(e))

    try:
        hit = con.execute("SELECT COUNT(*) FROM mem_fts WHERE mem_fts MATCH ?", ("燕麦奶",)).fetchone()[0]
        check("FTS 索引与正文同步（MATCH 命中新内容）", hit >= 1, f"{hit} 条")
    except sqlite3.Error as e:
        check("FTS 索引与正文同步（MATCH 命中新内容）", False, str(e))

    try:
        con.execute("DELETE FROM memories WHERE id = 'm000008'")
        con.commit()
        check("DELETE 不报错（删除触发器正常）", True)
    except sqlite3.Error as e:
        check("DELETE 不报错（删除触发器正常）", False, str(e))

    try:
        rows = con.execute("SELECT COUNT(*) FROM mem_fts").fetchone()[0]
        live = con.execute("SELECT COUNT(*) FROM memories").fetchone()[0]
        check("FTS 行数与正文一致", rows == live, f"fts={rows} memories={live}")
    except sqlite3.Error as e:
        check("FTS 行数与正文一致", False, str(e))
    log("")

    log("== 6. scope 隔离（D2） ==")
    def retrieve(scopes):
        ph = ",".join(["?"] * len(scopes))
        return con.execute(
            f"SELECT id FROM memories WHERE scope IN ({ph}) AND invalid_reason IS NULL AND cold=0", scopes
        ).fetchall()

    private_hits = retrieve(["chat:private", "shared"])
    group_hits = retrieve(["group:g1", "shared"])
    check("私聊检索不含群记忆", all(not h[0].startswith("m00001") or True for h in private_hits)
          and not any(h[0] in ("m000009", "m000010", "m000011") for h in private_hits), f"{len(private_hits)} 条")
    check("g1 检索不含 g2 记忆", not any(h[0] == "m000011" for h in group_hits), f"{len(group_hits)} 条")
    check("shared 两边都可见", any(h[0] == "m000001" for h in private_hits)
          and any(h[0] == "m000001" for h in group_hits))
    log("")

    log("== 7. 完整性 ==")
    check("integrity_check=ok", con.execute("PRAGMA integrity_check").fetchone()[0] == "ok")
    con.close()
    for suf in ("", "-wal", "-shm"):
        Path(str(DB) + suf).unlink(missing_ok=True)

    log("")
    log(f"合计：PASS {ok_n} / FAIL {fail_n}")
    (ROOT / "tests" / "upgrade-report.txt").write_text("\n".join(lines), encoding="utf-8")
    return 0 if fail_n == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
