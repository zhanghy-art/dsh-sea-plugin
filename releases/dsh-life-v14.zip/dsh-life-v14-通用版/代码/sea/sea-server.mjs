// sea/sea-server.mjs — 识海面板后端（只读旁路，第四章）
// 只 GET，只读打开，不占上下文、不调模型。
import http from 'node:http';
import { join } from 'node:path';

const PORT = Number(process.env.SEA_PORT || 8765);
const DB = process.env.SEA_DB || join(process.env.HOME || '.', '.dsh', 'dsh-life', 'mind.db');

let db = null;
async function connect() {
  try {
    const { DatabaseSync } = await import('node:sqlite');
    db = new DatabaseSync(DB, { readOnly: true });
    console.log('[sea] 已连接（只读）：' + DB);
  } catch (e) {
    console.warn('[sea] 无法打开库，进入演示模式：' + e.message);
    db = null;
  }
}

const json = (res, code, obj) => {
  const body = JSON.stringify(obj);
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(body);
};

const routes = {
  '/api/sea/nodes': (q) => {
    const limit = Math.min(Number(q.get('limit') || 200), 500);
    return db.prepare(
      `SELECT id, category, fact, tags, importance, emotional_salience, beta, region,
              cold, COALESCE(confirmed_at, created_at) AS t
       FROM memories WHERE invalid_reason IS NULL ORDER BY importance DESC LIMIT ?`
    ).all(limit);
  },
  '/api/sea/hormones': () => {
    const row = db.prepare('SELECT state_json FROM life_state WHERE id = 1').get();
    if (!row) return { hormones: {}, needs: {} };
    const s = JSON.parse(row.state_json);
    return { hormones: s.hormones, needs: s.needs, phase: s.phase, revision: s.revision };
  },
  '/api/sea/stats': () => {
    const q = (sql) => db.prepare(sql).get();
    return {
      memories: q('SELECT COUNT(*) AS n FROM memories WHERE invalid_reason IS NULL').n,
      cold: q('SELECT COUNT(*) AS n FROM memories WHERE cold = 1').n,
      candidates: q("SELECT COUNT(*) AS n FROM candidates WHERE status = 'pending'").n,
      events: q('SELECT COUNT(*) AS n FROM life_events').n,
      snapshots: q('SELECT COUNT(*) AS n FROM life_snapshots').n,
    };
  },
  '/api/sea/search': (q) => {
    const kw = `%${(q.get('q') || '').replace(/[%_]/g, '')}%`;
    return db.prepare(
      `SELECT id, fact, importance, cold FROM memories
       WHERE (fact LIKE ? OR tags LIKE ?) AND invalid_reason IS NULL LIMIT 30`
    ).all(kw, kw);
  },
  '/api/why': (q) => {
    const id = q.get('id');
    const m = db.prepare('SELECT * FROM memories WHERE id = ?').get(id);
    if (!m) return { error: 'not found' };
    return {
      id: m.id, fact: m.fact,
      importance: m.importance, beta: m.beta, beta_src: m.beta_src,
      emotional_salience: m.emotional_salience, relationship_salience: m.relationship_salience,
      confirmed_at: m.confirmed_at, created_at: m.created_at,
      recall_count: m.recall_count, cold: m.cold, cold_reason: m.cold_reason,
      invalid_reason: m.invalid_reason, region: m.region,
    };
  },
};

const server = http.createServer((req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  if (req.method !== 'GET') return json(res, 405, { error: 'read-only' });
  if (!db) return json(res, 200, { demo: true, items: [], note: '演示模式·非真实数据' });
  const fn = routes[url.pathname];
  if (!fn) return json(res, 404, { error: 'not found' });
  try { json(res, 200, fn(url.searchParams)); }
  catch (e) { json(res, 500, { error: e.message }); }
});

await connect();
server.listen(PORT, () => console.log(`[sea] http://localhost:${PORT}  (只读)`));
