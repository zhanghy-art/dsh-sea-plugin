// src/action/speak.mjs — 三道串联的主动决策（10.13 / 14.2 / 10.12）
// 第一道 speakWeight（想不想说）→ 第二道 utility（该不该说）→ 第三道硬闸（能不能说）
// 随机只出现在第二道与第三道之间，且必须可复现。
import { createHash } from 'node:crypto';
import { DEFAULTS } from '../kit/config.mjs';

/** 想说度：六维终于能影响主动了，但仍受硬闸约束 */
export function speakWeight(needs, cfg = DEFAULTS) {
  const w = cfg.speak.w;
  const rest = Math.max(cfg.speak.restFloor, Number(needs?.rest ?? 0.5));
  const social = Math.max(0, Math.min(1, Number(needs?.social ?? 0.5)));
  return Math.min(1, w.base + w.social * social + w.rest * rest);
}

/**
 * 软化裁定（v13.0）：speakWeight 不再单独否决，而是作为 utility 的一个加项。
 * 原因：它当硬闸时，六维低 → 永远不说话（历史上 utility 0.50<0.62 全灭的翻版）。
 * 需要硬否决时把 cfg.speak.hardGate 设为 true。
 */
export function speakBonus(needs, cfg = DEFAULTS) {
  const sw = speakWeight(needs, cfg);
  // 0.40 以下给 0 分加成（不说，但不禁止），0.40–0.80 线性，0.80 以上封顶 +0.12
  const w = cfg.speak.bonusWeight ?? 0.12;
  const lo = cfg.speak.floor;
  if (sw <= lo) return 0;
  return Math.min(w, ((sw - lo) / (1 - lo)) * w);
}

export function canSpeak(needs, cfg = DEFAULTS) {
  const sw = speakWeight(needs, cfg);
  const hard = cfg.speak.hardGate === true;
  return { ok: hard ? sw >= cfg.speak.floor : true, speakWeight: sw, soft: !hard, bonus: speakBonus(needs, cfg) };
}

/** 把 speakWeight 折进 utility（合并两家的写法） */
export function utilityWithSpeak(utility, needs, cfg = DEFAULTS) {
  return Math.min(1, utility + speakBonus(needs, cfg));
}

/**
 * 确定性伪随机（14.2）：seed 由作用域、时间桶、候选 id、策略版本共同决定。
 * 同一个 15 分钟桶、同一组候选 → 同一个结果，可复现、可解释。
 */
export function detRandom(seedParts, { bucketMinutes = 15, now = Date.now(), policyVersion = DEFAULTS.random.policyVersion } = {}) {
  const bucket = Math.floor(now / (bucketMinutes * 60000));
  const seed = createHash('sha256')
    .update([...seedParts, String(bucket), policyVersion].join('|'))
    .digest();
  return seed.readUInt32BE(0) / 0x100000000;
}

/**
 * 受控抽样：第一名领先 ≥0.15 直接选它；否则只在 top3 内按 utility 权重抽。
 * 这是“随机”唯一允许出现的位置（图 1 的裁定落地）。
 */
export function pickWithRandom(candidates, opts = {}) {
  const cfg = DEFAULTS.random;
  const now = opts.now || Date.now();
  const list = [...candidates].sort((a, b) => b.score - a.score).slice(0, cfg.samplePool);
  if (!list.length) return { picked: null, reason: 'empty' };
  if (list.length === 1) return { picked: list[0], reason: 'single' };
  if (list[0].score - list[1].score >= cfg.leadThreshold) {
    return { picked: list[0], reason: 'lead', lead: list[0].score - list[1].score };
  }
  const r = detRandom(['active', ...list.map(x => x.id).sort()], { now });
  const total = list.reduce((s, x) => s + Math.max(0.01, x.score), 0);
  let acc = 0;
  for (const c of list) {
    acc += Math.max(0.01, c.score) / total;
    if (r <= acc) return { picked: c, reason: 'sampled', r };
  }
  return { picked: list[0], reason: 'fallback', r };
}

/** 硬闸七条：任何一条不满足就不发（随机不能突破） */
export function hardGates(state, now = Date.now(), cfg = DEFAULTS, preset = {}) {
  const hour = new Date(now).getHours();
  const [qs, qe] = cfg.quietHours;
  const quiet = qs < qe ? (hour >= qs && hour < qe) : (hour >= qs || hour < qe);
  const c = state.counters || {};
  const social = state.social || {};
  const backoffUntil = (social.lastProactiveAt || 0) + (social.proactiveBackoffMinutes || 0) * 60000;
  const gates = [
    ['quiet', !quiet],
    ['min-interval', now - (social.lastProactiveAt || 0) >= (preset.minIntervalMin ?? cfg.active.minIntervalMin) * 60000],
    ['per-hour', (c.proactiveThisHour || 0) < (preset.perHour ?? cfg.active.perHour)],
    ['per-day', (c.proactiveToday || 0) < (preset.perDay ?? cfg.active.perDay)],
    ['backoff', now >= backoffUntil],
    ['safe-mode', !state.flags?.safeMode],
    ['switch', preset.enabled !== false],
  ];
  const failed = gates.filter(g => !g[1]).map(g => g[0]);
  return { ok: failed.length === 0, failed };
}

/** 追话（10.12）：私聊专用、单例、每小时 ≤2、30–180 秒后补一句 */
export function planFollowup({ lastUserAt = 0, lastBotAt = 0, followupCountThisHour = 0, isPrivate = true, now = Date.now() }, cfg = DEFAULTS) {
  const f = cfg.followup;
  if (!f.enabled) return { ok: false, reason: 'disabled' };
  if (f.privateOnly && !isPrivate) return { ok: false, reason: 'group' };
  if (followupCountThisHour >= f.perHourMax) return { ok: false, reason: 'hourly' };
  if (!lastUserAt || now - lastUserAt < 5000) return { ok: false, reason: 'too-early' };
  if (lastBotAt && now - lastBotAt < 30000) return { ok: false, reason: 'just-spoke' };
  const delay = f.delayMinS + detRandom(['followup', String(lastUserAt)], { now }) * (f.delayMaxS - f.delayMinS);
  return { ok: true, delayMs: Math.round(delay * 1000), maxBubbles: f.maxBubbles };
}

/**
 * utility 十项加权（v11.1 10.8 原文公式，一项都不许改）：
 *   0.22·explicit + 0.18·relevance + 0.18·commitment + 0.14·relationship
 * + 0.12·socialNeed + 0.08·curiosity + 0.08·contextualFit
 * − 0.20·intrusionRisk − 0.15·repetitionRisk − 0.10·recentPenalty
 * 全部输入先夹到 0–1；结果夹到 0–1（负项可能把它压到 0 以下）。
 */
export function utilityOf(features = {}, cfg = DEFAULTS) {
  const w = cfg.active.weights;
  const f = (k) => Math.max(0, Math.min(1, Number(features[k] ?? 0)));
  const raw =
    w.explicit * f('explicit') +
    w.relevance * f('relevance') +
    w.commitment * f('commitment') +
    w.relationship * f('relationship') +
    w.socialNeed * f('socialNeed') +
    w.curiosity * f('curiosity') +
    w.contextualFit * f('contextualFit') +
    w.intrusionRisk * f('intrusionRisk') +
    w.repetitionRisk * f('repetitionRisk') +
    w.recentPenalty * f('recentPenalty');
  return Math.max(0, Math.min(1, raw));
}

/**
 * 滞回判定（v11.1 10.8）：进入 ≥0.62、退出 <0.45。
 * 不设滞回会在线上下抖动——刚过线发一条，发完略降，再发一条。
 * @param {number} utility
 * @param {boolean} wasOpen 上一轮是否处于“想说”状态
 */
export function hysteresisPass(utility, wasOpen, cfg = DEFAULTS) {
  const enter = cfg.active.utilityEnter;
  const exit = cfg.active.utilityExit;
  const open = wasOpen ? utility >= exit : utility >= enter;
  return { open, threshold: wasOpen ? exit : enter, utility };
}

/** 主入口：三闸串联（想不想 → 该不该 → 能不能），随机只在中间 */
export function decideProactive({ needs, features, state, now = Date.now(), wasOpen = false, preset = {}, cfg = DEFAULTS } = {}) {
  const speak = canSpeak(needs, cfg);
  if (!speak.ok) return { send: false, stage: 'speakWeight', speak };
  const utility = utilityOf(features, cfg);
  const hyst = hysteresisPass(utility, wasOpen, cfg);
  if (!hyst.open) return { send: false, stage: 'utility', utility, speak };
  const gates = hardGates(state, now, cfg, preset);
  if (!gates.ok) return { send: false, stage: 'hardGate', failed: gates.failed, utility, speak };
  return { send: true, stage: 'pass', utility, speak, bonus: speak.bonus };
}
