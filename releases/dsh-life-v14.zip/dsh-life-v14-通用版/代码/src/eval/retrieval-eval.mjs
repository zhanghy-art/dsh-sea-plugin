// Dependency-free Chinese retrieval evaluator for the DSH memory kernel.
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { DEFAULTS } from '../kit/config.mjs';
import { writeMemory } from '../memory/engine.mjs';
import { searchMemory } from '../memory/search.mjs';

function idSet(values) {
  return new Set((values || []).map(String));
}

export async function runRetrievalEval(dataset, {
  root,
  now = Date.now(),
  minRecall = Number(dataset?.thresholds?.recallAtK ?? 0.75),
  minMrr = Number(dataset?.thresholds?.mrr ?? 0.55),
  maxLeaks = Number(dataset?.thresholds?.forbiddenLeaks ?? 0),
} = {}) {
  if (!root) throw new Error('root is required');
  if (!Array.isArray(dataset?.cases) || !dataset.cases.length) throw new Error('dataset cases required');
  const db = new DatabaseSync(':memory:');
  db.exec(readFileSync(join(root, 'schema.sql'), 'utf8'));
  const topK = Math.max(1, Number(dataset.topK) || 5);
  const results = [];
  try {
    for (const item of dataset.cases) {
      const byKey = new Map();
      for (const memory of item.memories || []) {
        const r = await writeMemory(db, {
          fact: memory.fact,
          category: memory.category || 'fact',
          confidence: 1,
          force_direct: true,
          scope: item.scope,
          source_kind: memory.source_kind || 'owner',
          source_id: 'eval',
          evidence_kind: 'user_sentence',
          evidence_ref: `eval:${item.id}:${memory.key}`,
          importance: Number(memory.importance ?? 0.8),
          emotional_salience: Number(memory.emotional_salience ?? 0),
        }, { cfg: DEFAULTS, now });
        byKey.set(memory.key, r.id);
      }
      const forbidden = new Map();
      for (const memory of item.otherScopeMemories || []) {
        const r = await writeMemory(db, {
          fact: memory.fact,
          category: memory.category || 'fact',
          confidence: 1,
          force_direct: true,
          scope: memory.scope,
          source_kind: 'owner',
          source_id: 'eval-other',
          evidence_kind: 'user_sentence',
          evidence_ref: `eval:${item.id}:other:${memory.key}`,
          importance: Number(memory.importance ?? 0.8),
        }, { cfg: DEFAULTS, now });
        forbidden.set(memory.key, r.id);
      }
      const expectedIds = new Set((item.expected || []).map((key) => String(byKey.get(key))).filter(Boolean));
      const forbiddenIds = new Set((item.forbidden || []).map((key) => String(forbidden.get(key))).filter(Boolean));
      const found = searchMemory(db, item.query, {
        cfg: DEFAULTS,
        now,
        scope: item.scope,
        topK,
        bm25: true,
        ignoreCooldown: true,
        rerankMode: 'off',
      });
      const ranked = found.items.map((entry) => String(entry.mem.id));
      const first = ranked.findIndex((id) => expectedIds.has(id));
      const leaks = ranked.filter((id) => forbiddenIds.has(id)).length;
      const noPositiveExpected = expectedIds.size === 0;
      const hit = noPositiveExpected ? leaks === 0 : first >= 0;
      results.push({
        id: item.id,
        query: item.query,
        ranked,
        expectedIds: [...expectedIds],
        forbiddenIds: [...forbiddenIds],
        hit,
        reciprocalRank: noPositiveExpected ? (hit ? 1 : 0) : (first >= 0 ? 1 / (first + 1) : 0),
        leaks,
        droppedGate: found.debug?.droppedGate || 0,
      });
    }
  } finally {
    db.close();
  }
  const total = results.length;
  const hits = results.filter((x) => x.hit).length;
  const recallAtK = total ? hits / total : 0;
  const mrr = total ? results.reduce((sum, x) => sum + x.reciprocalRank, 0) / total : 0;
  const forbiddenLeaks = results.reduce((sum, x) => sum + x.leaks, 0);
  return {
    version: dataset.version || 1,
    topK,
    total,
    hits,
    recallAtK: Number(recallAtK.toFixed(4)),
    mrr: Number(mrr.toFixed(4)),
    forbiddenLeaks,
    thresholds: { minRecall, minMrr, maxLeaks },
    passed: recallAtK >= minRecall && mrr >= minMrr && forbiddenLeaks <= maxLeaks,
    cases: results,
  };
}

export function parseEvalDataset(raw) {
  const data = typeof raw === 'string' ? JSON.parse(raw) : raw;
  if (!data || !Array.isArray(data.cases)) throw new Error('invalid eval dataset');
  return data;
}
