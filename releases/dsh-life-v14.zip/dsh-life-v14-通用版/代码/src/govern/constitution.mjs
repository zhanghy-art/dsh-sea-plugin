// src/govern/constitution.mjs — 宪法锁 L0（12.6）+ 分级自动审批（12.7）+ 主动计划闸（10.11）
import { normalize, isAbsolute, join } from 'node:path';
import { DEFAULTS } from '../kit/config.mjs';

const PROTECTED_DIRS = ['src', 'schema.sql'];
const PROTECTED_FILES = ['config.yml', 'config.yaml', 'schema.sql'];
const PROTECTED_CFG_KEYS = ['budget', 'quietHours', 'privacy', 'permissions', 'capabilities'];

export const l0Enabled = () => process.env.DSH_L0 !== 'off';

/** 任何工具触碰核心即拒；异常闭门（拿到判断不了的东西，一律拒） */
export function guardWrite(targetPath, { root = process.cwd() } = {}) {
  if (!l0Enabled()) return { ok: true, reason: 'L0-off' };
  try {
    const rel = normalize(isAbsolute(targetPath) ? targetPath : join(root, targetPath)).replace(/\\/g, '/');
    const normRoot = normalize(root).replace(/\\/g, '/');
    const inner = rel.startsWith(normRoot) ? rel.slice(normRoot.length + 1) : rel;
    if (inner.split('/').some(seg => PROTECTED_DIRS.includes(seg))) {
      return { ok: false, reason: 'L0:src' };
    }
    if (PROTECTED_FILES.includes(inner.split('/').pop())) return { ok: false, reason: 'L0:file' };
    if (inner.startsWith('self-made/')) return { ok: true, reason: 'self-made' };
    return { ok: true };
  } catch (e) {
    return { ok: false, reason: 'L0:error-closed' };
  }
}

/** 配置写保护：只允许安全方向（调低频率、调长冷却），不允许反向 */
export function guardConfigPatch(patch = {}) {
  const deny = [];
  for (const k of Object.keys(patch)) {
    if (PROTECTED_CFG_KEYS.includes(k)) deny.push(`L0:cfg.${k}`);
  }
  return { ok: deny.length === 0, deny };
}

const ALLOW_PREFIX = ['memory_', 'ops_status', 'ops_logs', 'ops_checks', 'sea_read'];
const DENY_PREFIX = ['db_drop', 'db_delete_all', 'credential_', 'group_admin', 'code_write'];

export function classifyTool(name, params = {}) {
  const n = String(name || '');
  if (DENY_PREFIX.some(p => n.startsWith(p))) return 'deny';
  const hasPath = Object.values(params).some(v => typeof v === 'string' && (v.includes('/') || v.includes('\\') || v.startsWith('http')));
  if (hasPath) return 'ask';                       // 参数能带路径/URL 的一律 ask
  if (name === 'ops' && ['status', 'logs', 'checks', 'memory', 'candidates', 'selfcheck', 'diagnose'].includes(params.action)) return 'allow';
  if (ALLOW_PREFIX.some(p => n.startsWith(p))) return 'allow';
  return 'ask';
}

/** 主动计划闸：凭证驱动（10.11） */
export function vetProposal(p, { memories = [], now = Date.now(), saidRecently = [] } = {}) {
  if (!p || !p.say) return { ok: false, reason: 'empty' };
  if (String(p.say).length > 40) return { ok: false, reason: 'too-long' };
  if (!['promise', 'milestone', 'residue', 'mingle'].includes(p.intent)) return { ok: false, reason: 'intent' };
  const mem = memories.find(m => m.id === p.evidence_id);
  if (!mem) return { ok: false, reason: 'no-evidence' };
  if (mem.invalid_reason || mem.cold) return { ok: false, reason: 'evidence-dead' };
  if (Number(mem.beta ?? 0.6) < 0.55) return { ok: false, reason: 'evidence-low-beta' };
  if (saidRecently.some(s => s.includes(String(p.say).slice(0, 8)))) return { ok: false, reason: 'repeat' };
  if (p.risk === 'high') return { ok: false, reason: 'high-risk-needs-owner' };
  return { ok: true };
}
