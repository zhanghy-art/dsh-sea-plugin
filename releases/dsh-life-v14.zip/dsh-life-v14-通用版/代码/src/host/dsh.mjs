// src/host/dsh.mjs — DSH 真机适配器（v14.1）
//
// 为什么需要这一层：
//   src/index.mjs 是 v11.1 的插件入口，它假设宿主提供
//     ctx.lifecycle.onReady / onPreStep / onTurnStopping
//     ctx.systemPrompt.persona() / section(name, text)
//     ctx.timer.every / ctx.tools.register({name, run}) / ctx.embed
//   但当前 DSH 的 cordis 插件只有：
//     ctx.systemPrompt.context({name, order, text})   ← v11-bridge 在用，已验证
//     ctx.on('session/event', (subject, event) => …)  ← v11-bridge 在用，已验证
//     ctx.tools.register(defineTool({...}))            ← 官方 dsh-tool-* 的写法
//   直接装 index.mjs 会「加载成功但一条逻辑都不跑」，所以这里做形状转换。
//
// 三条硬规矩（都是这轮装机踩出来的）：
//   1) 每个能力都先探测再调用，缺了就打日志——绝不静默降级，否则就是「装了不用」。
//   2) 注入用「事件驱动 + 缓存」，不用 setInterval 拉取：DSH 重放历史会瞬间触发大量
//      session/event，定时器叠上去会卡住加载（v11-bridge 的血泪注释）。
//   3) 出口改写拿不到钩子：DSH 插件不能改 assistant 文本，这里只做「检测 + 记账 +
//      下一轮压制」，真正的改写发生在 QQ 桥接（outbound-clean.js）。

import createPlugin from '../index.mjs';
import { appendFileSync } from 'node:fs';

// ---- 装机探针：只在真加载时才会写这个文件（诊断「装了不跑」用，随时可删）----
const BOOT_LOG = new URL('./.boot.log', import.meta.url);
function boot(msg) {
  try { appendFileSync(BOOT_LOG, `${new Date().toISOString()} ${msg}\n`); } catch { /* 写不了就算了 */ }
}
boot('import-ok pid=' + process.pid);

// 必须与 package.json 的 name 一致：cordis 用这个 name 做插件标识，profile 的
// cordis.patch.yml 里 `name: 'dsh-life-v14'` 也要对得上，否则「装上但不加载」。
// install-log 里记过的「装了不跑」三根因之一就是这三处不一致（package.json / 本文件 / patch）。
export const name = 'dsh-life-v14';
// cordis 的 inject 是「访问许可」：不在列表里的服务，ctx.<name> 一碰就抛
// cannot get property "tools" without inject。工具注册要 tools，注入要 systemPrompt。
export const inject = ['systemPrompt', 'tools'];

const ORDER = 45;          // 在 v11:life(40) 之后
const MAX_CACHE_LINES = 24;

export function apply(ctx, config = {}) {
  boot('apply-enter');
  try {
    return applyInner(ctx, config);
  } catch (e) {
    boot('apply-crash=' + (e?.stack || e?.message || e));
    try { console.error('[dsh-life] apply 失败（已隔离，不影响宿主）：', e?.message || e); } catch {}
    return {};
  }
}

function applyInner(ctx, config = {}) {
  const cfg = config || {};
  const log = makeLog(ctx);
  const caps = { systemPromptContext: false, sessionEvent: false, tools: false, timer: true, embed: false };
  const sections = new Map();     // name -> text（v13 通过 section() 写进来）
  const readyCbs = [];
  const preCbs = [];
  const stopCbs = [];
  const intervals = [];
  const pendingTools = [];

  // ---------- 能力探测（打印清单，不静默） ----------
  const probe = (fn) => { try { return fn() === true; } catch (e) { boot('probe-fail=' + (e?.message || e)); return false; } };
  caps.systemPromptContext = probe(() => typeof ctx.systemPrompt?.context === 'function');
  caps.sessionEvent = probe(() => typeof ctx.on === 'function');
  caps.tools = probe(() => typeof ctx.tools?.register === 'function');
  caps.embed = probe(() => typeof ctx.embed === 'function');
  boot('caps=' + JSON.stringify(caps));

  log.info('[dsh-life] 适配器加载：systemPrompt.context=' + caps.systemPromptContext +
    ' session/event=' + caps.sessionEvent + ' tools=' + caps.tools + ' embed=' + caps.embed);


  // ---------- 把 DSH ctx 包成 v13 期望的形状 ----------
  const compat = {
    log,
    embed: caps.embed ? (t) => ctx.embed(t) : undefined,
    emit: (evt, payload) => {
      try { ctx.emit?.(evt, payload); } catch { /* 宿主没有 emit 就算了，不是必需 */ }
    },
    lifecycle: {
      onReady: (cb) => readyCbs.push(cb),
      onPreStep: (cb) => preCbs.push(cb),
      onTurnStopping: (cb) => stopCbs.push(cb),
    },
    systemPrompt: {
      // DSH 没有“人格”服务；人格由 agent preset 提供，这里只留接口不硬编内容。
      persona: () => '',
      section: (n, text) => {
        if (typeof text === 'string' && text) sections.set(n, text);
        else sections.delete(n);
      },
    },
    timer: {
      every: (ms, fn) => {
        const t = setInterval(() => { try { fn(); } catch (e) { log.error('[dsh-life] tick: ' + e.message); } }, ms);
        if (t.unref) t.unref();
        intervals.push(t);
        return t;
      },
    },
    tools: {
      register: (tool) => {
        if (!caps.tools) { log.warn('[dsh-life] 宿主没有 ctx.tools.register，工具 ' + (tool?.name || '?') + ' 不注册'); return; }
        pendingTools.push(tool);
      },
    },
  };

  // ---------- 建 v13 runtime（apply 里同步触发 onReady） ----------
  const rt = createPlugin(compat, cfg);

  (async () => {
    for (const cb of readyCbs) {
      try { await cb(); } catch (e) { boot('ready-fail=' + (e?.message || e)); log.error('[dsh-life] ready 失败：' + (e?.stack || e?.message || e)); }
    }
    // 工具要在 defineTool 可用之后再注册（DSH 内部包，沙盒里没有，所以动态 import）
    await registerPendingTools(ctx, pendingTools, caps, log);
    log.info('[dsh-life] v13.0 已就绪（库结构/记忆/状态都已加载）');
    boot('ready-ok tools=' + pendingTools.length);
  })();

  // ---------- 注入段：每次拼提示词时被调用 ----------
  if (caps.systemPromptContext) {
    ctx.systemPrompt.context({
      name: 'dsh-life:memory',
      order: ORDER,
      text: () => {
        const parts = [];
        const mem = sections.get('dsh-life.memory');
        if (mem) parts.push(mem);
        const reflex = sections.get('dsh-life.reflex');
        if (reflex) parts.push(reflex);
        // 工具提示必须每轮都在：v14.0 原包把写入通道做成了工具却没在任何地方说明，
        // 模型不知道有 life_remember，引擎就永远空转（库里一条新记忆都不会有）。
        parts.push('【工具】想到该长期记住的事（人物/偏好/约定/事实）就调 life_remember；想主动找主人说话先调 life_propose。');
        return parts.join('\n');
      },
    });
    boot('registered=skein');
  } else {
    log.warn('[dsh-life] 没有 systemPrompt.context：记忆段落注入不了（这是「装了不用」的典型症状）');
  }

  // ---------- 事件驱动：记一条 → 检索 → 下一轮注入 ----------
  if (caps.sessionEvent) {
    ctx.on('session/event', (subject, event) => {
      const type = event?.type;
      if (type !== 'user/message' && type !== 'assistant/message') {
        // 历史重放会打很多别的类型，直接忽略，不做任何计算
        return;
      }
      if (type === 'user/message') {
        const text = textOf(event.data);
        if (!text) return;
        const message = {
          text,
          scope: cfg.scope || undefined,
          ownerQq: cfg.ownerQq,
          groupId: cfg.groupId,
          id: event.data?.id ?? event.data?.messageId ?? event.id ?? null,
        };
        // 不 await：事件不能被记忆逻辑拖住；结果进 cache，下一轮注入。
        Promise.resolve()
          .then(async () => { for (const cb of preCbs) await cb({ message }); })
          .catch((e) => log.warn('[dsh-life] preStep: ' + (e?.message || e)));
        return;
      }
      // assistant/message：出口检测（改不了正文，只检测）
      const reply = { text: textOf(event.data), rewrite: false };
      if (!reply.text) return;
      Promise.resolve()
        .then(async () => { for (const cb of stopCbs) await cb({ reply, message: { text: reply.text } }); })
        .catch((e) => log.error('[dsh-life] turnStopping: ' + (e?.message || e)));
    });
    boot('registered=session-event');
  } else {
    log.warn('[dsh-life] 没有 ctx.on(session/event)：记忆不会随对话增长（装了也不会用）');
  }

  // ---------- 清场 ----------
  try {
    ctx.on?.('dispose', () => {
      for (const t of intervals) clearInterval(t);
    });
  } catch { /* 宿主没有 dispose 就算了 */ }

  return rt;
}

// ---------- 工具层适配 ----------
/**
 * 把 v13 的 {name, description, run} 转成 DSH 的 defineTool 定义。
 * 动态 import：@deepseek-ai/dsh-tools 只在 DSH 进程里可解析，沙盒/单测里拿不到，
 * 拿不到就明确报一句，不静默。
 */
async function registerPendingTools(ctx, tools, caps, log) {
  if (!tools.length) return;
  let defineTool = null;
  try {
    const mod = await import('@deepseek-ai/dsh-tools');
    defineTool = mod.defineTool || mod.default?.defineTool || null;
  } catch (e) {
    log.warn('[dsh-life] 取不到 @deepseek-ai/dsh-tools（' + (e?.message || e) + '），' + tools.length + ' 个工具不注册');
    return;
  }
  for (const tool of tools) {
    try {
      ctx.tools.register(defineTool({
        name: tool.name,
        description: tool.description,
        parameters: tool.parameters || { type: 'object', additionalProperties: true, properties: {} },
        async execute(args) {
          const r = await tool.run(args || {});
          return { content: [{ type: 'text', text: JSON.stringify(r ?? {}) }], data: r };
        },
      }));
      log.info('[dsh-life] 工具已注册：' + tool.name);
    } catch (e) {
      log.warn('[dsh-life] 工具 ' + tool?.name + ' 注册失败：' + (e?.message || e));
    }
  }
}

// ---------- 小工具 ----------
function makeLog(ctx) {
  const base = (...a) => { try { console.log(...a); } catch { /* ignore */ } };
  const warn = (...a) => { try { console.warn(...a); } catch { /* ignore */ } };
  const error = (...a) => { try { console.error(...a); } catch { /* ignore */ } };
  const via = (pick, fallback) => (...a) => {
    try { const fn = pick(); if (typeof fn === 'function') { fn(...a); return; } } catch { /* 宿主 logger 形状不对就用兜底 */ }
    fallback(...a);
  };
  return {
    info: via(() => ctx?.log?.info, base),
    warn: via(() => ctx?.log?.warn, warn),
    error: via(() => ctx?.log?.error, error),
  };
}

/** 从 session/event 的 data 里取纯文本（user 与 assistant 两种形状都认） */
function textOf(data) {
  if (!data) return '';
  if (typeof data.text === 'string') return data.text;
  const msg = data.message || data;
  const content = msg?.content;
  if (typeof content === 'string') return content;
  if (!Array.isArray(content)) return '';
  const out = [];
  for (const b of content) {
    if (b && b.type === 'text' && typeof b.text === 'string') out.push(b.text);
  }
  return out.join('\n');
}
