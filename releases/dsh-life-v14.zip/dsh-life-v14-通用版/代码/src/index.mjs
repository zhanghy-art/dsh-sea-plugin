// src/index.mjs — 插件装配（v11.1 的 index.ts 原地升级）
// DSH Cordis 插件的入口：只做装配，不写业务逻辑。
// v14：所有新增能力通过 v14On(cfg, cap) 判定，总闸 capabilities.v14=false 时
//      全部新代码路径不执行，行为与 v13.0 逐字节一致（可整包回滚）。
// 三条硬规则：① 状态数值写入口唯一（life-state / sleep-stage）；② 情绪/rerank/梦境/印记
//      不写 memories 正文、不进 effWeight、不改 belief；③ 新链路失败一律降级、永不阻断回复。
import { DEFAULTS, mergeConfig, v14On, v14Mode } from './kit/config.mjs';
import { loadPromptPack } from './prompt/pack.mjs';
import { inspectEdgesBasis } from './kit/optional-migrations.mjs';
import { shadowLog, inShadow } from './kit/shadow.mjs';
import { lifeDir } from './kit/paths.mjs';
import { openDb, ensureSchema } from './kit/db.mjs';
import { nextId } from './kit/ids.mjs';
import { kvGet, kvSet } from './kit/db.mjs';
import { normalizeScope, isGroup as isGroupScope, visibleScopes } from './kit/scope.mjs';
import { recover, saveState, lifeTick, defaultState, phaseOf, dayKeyOf, adoptLegacyState } from './life/life-state.mjs';
import { searchMemory, logInjection } from './memory/search.mjs';
import { writeMemory, scanCold, enforceTierQuota, enforceImportanceQuota } from './memory/engine.mjs';
import { EmbeddingCache } from './memory/embedding-cache.mjs';
import { ActivationBook } from './reflex/activation.mjs';
import { SessionLifecycle, buildHandoffPrompt, validateHandoff } from './session/lifecycle.mjs';
import { compose, stateLine } from './prompt/composer.mjs';
import { cleanOutgoing, trimToolResult, isEcho, stripFrames } from './outlet/cleaner.mjs';
import { runNightly, Breaker, capacityReport } from './maintenance/nightly.mjs';
import { vetProposal } from './govern/constitution.mjs';
import { rerank, allowOnExplicitAsk } from './life/attention.mjs';
import { pickReviewCard, markFloated } from './memory/fsrs.mjs';
import { canSpeak, hardGates, pickWithRandom, planFollowup } from './action/speak.mjs';
import { remFromGaps, epiphany, decayGaps, openGap, tryCloseGap } from './memory/gaps.mjs';
import { settleLifecycle } from './life/sleep.mjs';

// ---- v14 新增模块 ----
import { hormoneTargets, applyResonance } from './life/hormone-source.mjs';
import { localVec, backfillVectors, LOCAL_MODEL, vecToBlob } from './memory/vec-local.mjs';
import { buildEdges } from './memory/edges.mjs';
import { rerankWithExternal, readStats, bumpStats } from './memory/rerank.mjs';
import { settleStages, dreamContext, thoughtContext, think, currentThoughts, suggestThought, recentDreams, archiveDreams, dreamsByNight, inSleepWindow } from './life/sleep-stage.mjs';
import { desireMoodTick, clampDelta } from './life/lexicon.mjs';
import { appraiseEvent, applyAppraisal, recordAppraisal, recentAppraisals } from './life/appraisal.mjs';
import { elapsedMinutes, advanceV14 } from './life/clock.mjs';
import { isSleeping, queueDelivery, pollDeliveries, ackDeliveries, pendingDeliveryCount, classifySleepReply, sleepShortReply } from './life/delivery.mjs';
import { buildPersonaDiff, applyPersonaDiff, listPersonaDiffs, personaSnapshot } from './life/persona-drift.mjs';
import { preWrite, retract, extractFacts, reloadHighPriority } from './memory/governance.mjs';
import { reviewCandidate, sweepCandidates } from './memory/candidates.mjs';
import { recallCards, recallDetail } from './memory/recall-card.mjs';
import { addPromise, closePromise, addMilestone, addNarrative, upsertRelationship, lifebookSnapshot } from './memory/lifebook.mjs';
import { detectConflicts, generateImprint, negativeAlerts, consistencySample, listConflicts, resolveConflict } from './memory/belief-pool.mjs';
import { promoteTier } from './memory/evidence.mjs';

/** 写入统一入口：治理钩子 + 本地向量兜底，宿主工具与自动提取都走它 */
function rememberDeps(rt, cfg) {
  const deps = { cfg, now: Date.now(), state: rt.state };
  if (v14On(cfg, 'governance')) deps.preWrite = (input, o) => preWrite(rt.db, input, o);
  if (v14On(cfg, 'localVector')) { deps.localVec = localVec; deps.vecModel = LOCAL_MODEL; }
  return deps;
}

// v14.1.2 沙盒 H 组 / 降 token：精简工具集只注册这 5 个高频核心工具。
// 其余 8 个（sleep / delivery_poll / delivery_ack / gap / lifebook /
// persona_review / memory_review / forget）默认仍在 full 集里，lite 时按需再单独开。
// 依据：materials/measure-runtime.mjs 实测 13 工具 schema ≈1424 token，占单次唤醒
// dsh-life 侧固定开销（≈1605 token）的 89%，是最大头。
const LITE_TOOL_NAMES = new Set([
  'life_remember', 'life_propose', 'life_mark_sent', 'life_recall', 'life_status',
]);

export default function createPlugin(ctx, userConfig = {}) {
  const cfg = mergeConfig(DEFAULTS, userConfig);
  const rt = {
    db: null, state: null, book: new ActivationBook(cfg), cache: null,
    session: null, breaker: null, ready: false, safeMode: false,
    recentSaid: [], turnId: 0, lastUserAt: 0, lastFloatAt: 0,
    rerankFrozenUntil: 0, bootScope: null, lastUserText: undefined,
    lastSections: new Map(),   // 缓存「上一正常轮实际写入的注入段」，供空唤醒轮原样复用
  };

  // 工具注册统一入口：full（默认）逐字节等价于原来的 13 个 ctx.tools?.register?.()；
  // lite 只放行 5 个核心工具。默认 cfg.v14.toolset === 'full'，所以不打开开关时
  // 行为与升级前完全一致（可整包回退，不破坏任何既有断言）。
  const toolsetMode = cfg.v14?.toolset === 'lite' ? 'lite' : 'full';
  let regPass = 0, regDrop = 0;
  const reg = (tool) => {
    if (toolsetMode === 'lite' && !LITE_TOOL_NAMES.has(tool?.name)) {
      regDrop += 1;
      return;
    }
    regPass += 1;
    return ctx.tools?.register?.(tool);
  };
  rt.toolset = { mode: toolsetMode, registered: () => regPass, dropped: () => regDrop };

  // 注入段统一写入口：既写给宿主，也在插件侧缓存一份。
  // 空唤醒轮（skipIdleTurn）用缓存把「上一正常轮」的段原样写回宿主 ——
  // 这样无论是 dsh.mjs 的持久 Map，还是 generic.mjs 每轮 clear() 的 Map，
  // 拿到的 system prompt 尾段都与上一轮一字不差，宿主 prompt cache 才能命中。
  const put = (key, text) => {
    rt.lastSections.set(key, text);
    return ctx.systemPrompt?.section?.(key, text);
  };

  // 空唤醒判定（只在 cfg.v14.skipIdleTurn === true 时启用，默认关）。
  // qq-bridge 的 timeout / replyCheck / proactiveCheck 会在「设了闹钟却没到点」时
  // 反复把模型拉起来，但并没有新的用户输入 —— 这类轮次重算检索/向量/反射纯属烧 token。
  // 判定优先用宿主显式 wakeReason，其次用「无文本 / 与上一轮文本完全相同」兜底。
  const isIdleWake = (ev) => {
    const wr = ev?.wakeReason || ev?.message?.wakeReason || '';
    if (wr && /^(timeout|replyCheck|proactiveCheck|bootstrap|admin)$/.test(String(wr).split(':')[0])) return true;
    const text = ev?.message?.text || '';
    if (!text) return true;
    return rt.lastUserText !== undefined && text === rt.lastUserText;
  };

  // ---------- 装配：runtime/ready ----------
  ctx.lifecycle?.onReady?.(async () => {
    const dbPath = userConfig.dbPath || process.env.DSH_LIFE_DB || lifeDir('mind.db');
    rt.db = await openDb(dbPath);
    const schemaInfo = userConfig.autoMigrate === false
      ? { fresh: false, added: 0, rebuilt: false, skipped: true }
      : await ensureSchema(rt.db, { dbPath, cfg, log: ctx.log });
    if (schemaInfo.backupPath) ctx.log?.info?.(`[dsh-life] 升级前已备份：${schemaInfo.backupPath}`);
    if (schemaInfo.fresh) ctx.log?.info?.(`[dsh-life] 新建库：${dbPath}`);
    else if (schemaInfo.added) ctx.log?.info?.(`[dsh-life] 原地升级：${dbPath} 新增 ${schemaInfo.added} 列${schemaInfo.rebuilt ? '，已重建 FTS 索引' : ''}`);
    else ctx.log?.info?.(`[dsh-life] 库结构已是最新：${dbPath}`);

    // v14 P0 / D13：不跑迁移脚本直接启动时，也要把 v11 宽表状态接管过来，避免心情/激素归零
    if (v14On(cfg)) {
      try {
        const a = adoptLegacyState(rt.db, cfg);
        if (a.adopted) ctx.log?.info?.('[dsh-life] v11 状态已接管（六维/激素/关系）');
      } catch (e) { ctx.log?.warn?.('[dsh-life] legacy adopt skipped: ' + e.message); }
    }

    const rec = recover(rt.db, cfg);
    if (rec.safeMode) {
      rt.safeMode = true;
      rt.state = defaultState();
      ctx.log?.warn?.(`[dsh-life] safeMode: ${rec.reason}（只应答、不主动、不注入）`);
    } else {
      rt.state = rec.state;
    }
    if (!v14On(cfg)) {
      delete rt.state.sleep;
      delete rt.state.thoughtStream;
      delete rt.state.affect;
      delete rt.state.counters?.lastTickAt;
    }
    rt.book.load(rt.db.prepare('SELECT * FROM reflexes').all());
    // v14 P0 / D4：宿主没给 embed 时用本地 hash384，让 vec 通道真正生效
    rt.cache = new EmbeddingCache(
      lifeDir('embed-cache.json'),
      async (t) => {
        if (typeof ctx.embed === 'function') {
          try { const v = await ctx.embed(t); if (v?.length) return v; } catch { /* 回退本地 */ }
        }
        return v14On(cfg, 'localVector') ? localVec(t) : null;
      }
    );
    // 旧记忆补向量（只写 vec/vec_model，不碰正文与权重）
    if (v14On(cfg, 'localVector')) {
      try {
        const b = backfillVectors(rt.db, { limit: cfg.v14.vec.backfillLimit });
        if (b.filled) ctx.log?.info?.(`[dsh-life] 本地向量补齐 ${b.filled} 条`);
      } catch (e) { ctx.log?.warn?.('[dsh-life] vec backfill skipped: ' + e.message); }
    }
    rt.session = new SessionLifecycle(rt.db, { cfg, root: lifeDir('cold') });
    rt.breaker = new Breaker(rt.db);
    if (v14On(cfg)) rt.state.counters.lastTickAt = Date.now();
    if (v14On(cfg, 'prompts') && cfg.v14.prompts.enabled !== false) {
      try {
        const pack = loadPromptPack({
          root: cfg.v14.prompts.root || undefined,
          ids: cfg.v14.prompts.systemIds,
        });
        put('dsh-life.policy', pack.text);
        ctx.log?.info?.(`[dsh-life] prompt pack ${pack.version} loaded (${pack.chars} chars)`);
      } catch (e) {
        ctx.log?.warn?.('[dsh-life] prompt pack skipped: ' + e.message);
      }
    }
    rt.ready = true;
    ctx.log?.info?.('[dsh-life] ready, revision=' + rt.state.revision + (v14On(cfg) ? ' (v14 on)' : ' (v13 compat)'));
  });

  // ---------- 每轮：onPreStep ----------
  ctx.lifecycle?.onPreStep?.(async (ev) => {
    if (!rt.ready || rt.safeMode) return;
    const text = ev?.message?.text || '';

    // v14.1.2 降 token：空唤醒轮直接复用上一轮 system prompt 尾段。
    // 不 appendRaw / 不检索 / 不算向量 / 不写注入台账 / 不动反射，
    // 也不重写 dsh-life.memory —— dsh.mjs 的 compat.section 是持久 Map，
    // 内容一字不变 → 宿主 prompt cache 命中。默认关闭（skipIdleTurn=false）。
    // 只有「已经有过一个正常轮」才允许跳过：判据是缓存里真的有 dsh-life.memory
    //（上一正常轮注入的尾段）。注意 lastSections 在 onReady 阶段就被常驻的
    // dsh-life.policy 填过（size 恒 ≥1），所以不能用 size>0 当判据 —— 首轮就是
    // 空唤醒时只有 policy、没有 memory，若强行跳过宿主会拿到空注入（H-29/H-30 实测抓到）。
    if (cfg.v14?.skipIdleTurn === true && rt.lastSections.has('dsh-life.memory') && isIdleWake(ev)) {
      rt.idleSkips = (rt.idleSkips || 0) + 1;
      // generic 宿主每轮 clear()，这里把缓存的上一轮段原样写回；
      // dsh.mjs 是持久 Map，重写同样内容不影响 prompt cache 命中。
      for (const [k, v] of rt.lastSections) put(k, v);
      return;
    }
    rt.lastUserText = text;
    // 反射段是本轮条件触发的，正常轮先清缓存，避免空唤醒轮复播一条过期提醒。
    rt.lastSections.delete('dsh-life.reflex');

    const scope = normalizeScope(ev?.message?.scope, {
      ownerQq: cfg.ownerQq ?? ev?.message?.ownerQq ?? ev?.message?.userId,
      groupId: ev?.message?.groupId,
    });
    const now = Date.now();
    const group = isGroupScope(scope);
    const previousUserAt = Number(rt.state.social?.lastUserAt || rt.lastUserAt || 0);
    rt.currentScope = scope;

    rt.turnId += 1;
    rt.session.onTurn();
    rt.session.appendRaw(scope, 'user', text, now);

    // v14 P0 / D2：补上催产素缺失的真实信号源（全库唯一写入点）
    if (v14On(cfg, 'socialTimestamps')) {
      rt.state.social.lastUserAt = now;
      rt.state.social.silentStreak = 0;
      rt.lastUserAt = now;
    }

    // 1) 预热
    rt.cache.warm(text);

    // 2) 检索（分舱 → 双通道 → 边一跳 → 保底 → 可选轻量重排）
    let hits = { items: [], debug: {} };
    try {
      const qvec = await rt.cache.getOrCompute(text);
      const searchOpts = {
        cfg, now, queryVec: qvec, scope,
        cooldownHours: cfg.memory.injectionCooldownHours,
      };
      if (v14On(cfg, 'bm25')) searchOpts.bm25 = true;
      const rerankMode = v14Mode(cfg, 'rerank');
      if (rerankMode !== 'off') {
        searchOpts.rerankMode = rerankMode;
        searchOpts.rerank = rerankMode === 'on';
        searchOpts.rerankTop = cfg.v14.rerank.top;
        searchOpts.mood = { P: Number(rt.state.hormones?.dopamine ?? 0.5) };
      }
      hits = searchMemory(rt.db, text, searchOpts);
      // 可选外部 cross-encoder（本地 ONNX / GPU sidecar），失败/超时一律回落
      if (rerankMode === 'on' && typeof cfg.rerankFn === 'function' && hits.items.length >= 4) {
        const rr = await rerankWithExternal(text, hits.items, {
          rerankFn: cfg.rerankFn, timeoutMs: cfg.v14.rerank.timeoutMs,
          rerankWeight: cfg.v14.rerank.weight, topN: cfg.v14.rerank.top,
          frozenUntil: rt.rerankFrozenUntil, keep: cfg.retrieval.topK,
          cfg, now,
        });
        hits.items = rr.items;
        if (rr.stats.fallback) {
          rt.rerankFrozenUntil = now + cfg.v14.rerank.cooldownMs;
          bumpStats(rt.db, 'fallback', 1);
        }
      }
    } catch (e) {
      ctx.log?.warn?.('[dsh-life] search degraded: ' + e.message);
    }

    // 2.5) 注意力倾斜：只在门槛之后重排，不改权重（3.10）
    if (cfg.attention?.enabled && hits.items.length) {
      hits.items = allowOnExplicitAsk(rerank(hits.items, rt.state.hormones, cfg), text);
    }

    // 2.6) 复习浮卡
    let reviewLine = '';
    try {
      const card = pickReviewCard(rt.db, {
        cfg, now, lastFloatAt: rt.lastFloatAt || 0,
        scoreOf: (m) => hits.items.find(x => x.mem.id === m.id)?.score ?? 0.4,
      });
      if (card) { reviewLine = card.prompt; rt.lastFloatAt = now; markFloated(rt.db, card.mem.id, now, cfg); }
    } catch { /* 浮卡失败不影响主流程 */ }

    // 2.7) v14 情绪共振：想起即反应（单次 ≤0.03，不改变事实与权重）
    if (v14On(cfg, 'hormoneTargetDriven')) {
      try { applyResonance(rt.state, hits.items, { cfg, maxNudge: cfg.v14.hormone.resonanceNudge }); }
      catch { /* 共振失败不影响主流程 */ }
    }
    // 2.8) v14 structured appraisal: event -> explainable dimensions -> bounded delta.
    if (v14On(cfg, 'appraisal') || v14On(cfg, 'lexicon')) {
      try {
        const gapMs = previousUserAt ? now - previousUserAt : 0;
        const appraisal = appraiseEvent(text, {
          state: rt.state, now, gapMs,
          maxNudge: cfg.v14.appraisal?.maxNudge ?? cfg.v14.lexicon.maxNudge,
        });
        const applied = applyAppraisal(rt.state, appraisal, cfg, {
          maxNudge: cfg.v14.appraisal?.maxNudge ?? cfg.v14.lexicon.maxNudge,
        });
        rt.state.immediateBasis = { source: 'appraisal', matched: appraisal.matched, ...applied };
        if (appraisal.matched?.length) {
          recordAppraisal(rt.db, appraisal, {
            scope, turnId: `t${rt.turnId}`, source: 'user', now,
            applied,
          });
        }
      } catch { /* ignore */ }
    }

    // 3) 组装（稳定前缀在前；L1 → facts → summary → state → stage → snippets）
    const l1 = ctx.systemPrompt?.persona?.() || '';
    let facts = hits.items.map(it => ({ line: formatMemoryLine(it.mem, it.mode) }));

    // v14 P2：新会话/重置后重读高权重记忆，补图 S7-3「换个新脑子这页又翻不到了」
    if (v14On(cfg, 'reloadOnSession') && (rt.session.turns <= 1 || rt.turnId <= 1)) {
      try {
        const scopes = visibleScopes(scope, { ownerQq: cfg.ownerQq });
        const pinned = reloadHighPriority(rt.db, { scopes, limit: cfg.v14.governance.reloadLimit, now, cfg });
        const seenIds = new Set(hits.items.map(x => x.mem.id));
        const extra = pinned.filter(p => !seenIds.has(p.id))
          .map(p => ({ line: `[要紧] ${p.fact}` }));
        facts = [...extra, ...facts];
      } catch { /* 重读失败用原结果 */ }
    }

    const stateTxt = stateLine({
      phase: rt.state.phase, energy: rt.state.energy, hormones: rt.state.hormones,
      stage: rt.state.relationship.stage,
      selfReport: v14On(cfg, 'sleepStages') ? selfReportOf(rt.state) : '',
      dominant: rt.state.affect?.dominant || '',
    });
    const handoff = rt.session.readHandoff(scope, now);
    const summary = handoff || '(无)';

    // v14 P1：念头流 / 梦 / 触发卡（都是纯文字，不报数值）
    const snippets = [];
    const triggerCards = [];
    if (reviewLine) snippets.push({ line: reviewLine });
    if (v14On(cfg, 'dreams')) {
      const d = dreamContext(rt.state, now, cfg);
      if (d) snippets.push({ line: d });
    }
    if (v14On(cfg, 'thoughtStream')) {
      const t = thoughtContext(rt.state, now);
      if (t) triggerCards.push({ line: t });
    }
    const composed = compose({
      l1, facts, summary,
      state: mayInjectState(rt.state, now) ? stateTxt : '',
      stage: '', snippets, triggerCards,
    }, { group });

    put('dsh-life.memory', composed.text);

    // 4) 记录注入（v14：同时做情感指纹再巩固，只更新 anchor_ground）
    if (hits.items.length) {
      logInjection(rt.db, hits.items, now, `t${rt.turnId}`, {
        reconsolidate: v14On(cfg, 'affectFingerprint'),
        reconsolidateCoef: cfg.v14.affect.reconsolidateCoef,
        state: rt.state,
      });
    }
    rt.state.counters.stateLineAt = now;

    // 5) 反射激活度累积（每轮）
    const refs = rt.db.prepare('SELECT * FROM reflexes WHERE scope = ? OR scope = ?').all(scope, 'shared');
    for (const r of refs) {
      const explicit = text.includes(r.trigger);
      const sim = explicit ? 1 : textScoreLite(text, r.trigger);
      rt.book.bump(r.id, sim, explicit, r.pain_level);
    }
    const picked = rt.book.pick(now, dayKeyOf(now));
    if (picked) {
      const r = refs.find(x => x.id === picked.id);
      if (r && rt.state.counters.emotionInjectToday < cfg.reflex.maxDaily) {
        put('dsh-life.reflex', `【提醒】${r.response}`);
        rt.book.fire(picked.id, now, dayKeyOf(now));
        rt.state.counters.emotionInjectToday += 1;
      }
    }
    rt.book.persist(rt.db);
  });

  // ---------- 回复后：onTurnStopping（全局 try/catch，失败不阻断） ----------
  ctx.lifecycle?.onTurnStopping?.(async (ev) => {
    try {
      if (!rt.ready) return;
      const raw = ev?.reply?.text || '';
      const now = Date.now();
      let out = stripFrames(raw);
      if (isEcho(out, rt.recentSaid, cfg)) {
        out = echoRewriteHint(out);
        ev.reply.rewrite = true;
      }
      rt.recentSaid.push(out);
      if (rt.recentSaid.length > 20) rt.recentSaid.shift();
      const cleaned = cleanOutgoing(out);
      ev.reply.text = cleaned.text;

      const scope = normalizeScope(ev?.message?.scope, {
        ownerQq: cfg.ownerQq ?? ev?.message?.ownerQq ?? ev?.message?.userId,
        groupId: ev?.message?.groupId,
      });
      rt.session.appendRaw(scope, 'bot', cleaned.text, now);
      rt.currentScope = scope;
      // v14 P0 / D2：bot 说话时间也要写，催产素才知道「刚聊过」
      if (v14On(cfg, 'socialTimestamps')) rt.state.social.lastBotAt = now;

      // v14 delivery contract: while asleep the host gets an explicit defer hint and
      // the text is persisted for a later wake-up drain. We never claim it was sent.
      if (v14On(cfg, 'sleepQueue') && isSleeping(rt.state)) {
        // v14 Q3：睡着时不再一律排队——主人私聊命中紧急词回一句极短，
        // 群聊/非主人私聊直接丢（不占队列），其余才排队。
        const verdict = classifySleepReply({
          userText: String(ev?.message?.text || ''), scope, ownerQq: cfg.ownerQq, cfg,
        });
        ev.reply.sleeping = true;
        if (verdict === 'reply-short' && ev?.reply) {
          ev.reply.text = sleepShortReply(cfg);
          ev.reply.shortReply = true;
          ev.reply.delivery = 'immediate-short';
        } else if (verdict === 'drop') {
          ev.reply.delivery = 'dropped';
        } else {
          const queued = queueDelivery(rt.state, {
            text: cleaned.text, kind: 'reply', scope, urgent: ev?.reply?.urgent === true,
          }, { now, max: cfg.v14.sleep.queueMax });
          ev.reply.delivery = queued.ok ? 'deferred' : 'not-queued';
          if (queued.ok) saveState(rt.db, rt.state, now, cfg);
        }
      }

      // v14 P2：自动提取事实（Mem0 借鉴）——只产候选，低置信自动进 candidates，不直写
      const autoExtractMode = v14Mode(cfg, 'autoExtract');
      if (autoExtractMode !== 'off') {
        try {
          const userText = String(ev?.message?.text || '');
          const msgId = ev?.message?.id ?? ev?.message?.messageId ?? null;
          for (const cand of extractFacts(userText, {
            cfg, scope, now, turnId: `t${rt.turnId}`,
            msgIds: msgId ? [String(msgId)] : [], sourceId: scope,
          })) {
            if (autoExtractMode === 'shadow') {
              shadowLog(rt.db, 'autoExtract', {
                fact: cand.fact, category: cand.category,
                confidence: cand.confidence, evidence_ref: cand.evidence_ref,
              }, now);
            } else {
              await writeMemory(rt.db, cand, rememberDeps(rt, cfg));
            }
          }
        } catch { /* 抽取失败不影响回复 */ }
      }
      // v14 P1：念头流用规则生成一条「脑子里挂着的事」，不调模型（零依赖）
      if (v14On(cfg, 'thoughtStream') && rt.turnId % 8 === 0) {
        try {
          const line = suggestThought(rt.db, rt.state, { now });
          think(rt.state, line, { now, tone: 'neutral' });
        } catch { /* ignore */ }
      }

      if (rt.session.shouldSummarize()) {
        ctx.emit?.('dsh-life:summarize', { scope, turns: 15 });
        rt.session.sinceSummary = 0;
      }
      if (rt.session.shouldArchive()) {
        if (rt.session.readHandoff(scope, now)) {
          rt.session.archive(scope, rt.session.readHandoff(scope, now), now);
          ctx.emit?.('dsh-life:archive', { scope });
        } else {
          ctx.log?.warn?.('[dsh-life] skip archive: 无有效纪要（宁缺勿编）');
        }
      }
    } catch (e) {
      ctx.log?.error?.('[dsh-life] turnStopping failed: ' + e.message);
    }
  });

  // ---------- 定时：15 分钟 lifeTick + 夜间巩固 ----------
  ctx.timer?.every?.(15 * 60 * 1000, () => {
    try {
      if (!rt.ready) return;
      const now = Date.now();
      const v14 = v14On(cfg);
      const elapsed = elapsedMinutes(rt.state, now, {
        defaultMinutes: 15,
        maxCatchUpHours: cfg.v14.sleep.maxCatchUpHours,
      });
      const minutes = v14 ? elapsed.minutes : 15;

      // v14 P0 / D1: data-driven hormone targets. Off means exact v13 behavior.
      let hormoneOpts = {};
      if (v14 && v14On(cfg, 'hormoneTargetDriven')) {
        try {
          const ht = hormoneTargets(rt.db, rt.state, { cfg, now, scanLimit: cfg.v14.hormone.scanLimit });
          hormoneOpts = {
            hormoneTargets: ht.targets, hormoneBasis: ht.basis, hormoneSource: ht.source,
            maxMovePerHour: cfg.v14.hormone.maxMovePerHour,
          };
        } catch (e) { ctx.log?.warn?.('[dsh-life] hormone targets degraded: ' + e.message); }
      }

      if (v14 && v14On(cfg, 'sleepStages')) {
        // One energy owner: settleStages owns energy; lifeTick is told not to drift it.
        const advanced = advanceV14(rt.state, {
          now,
          minutes,
          cfg,
          db: rt.db,
          dreamEnabled: v14On(cfg, 'dreams'),
          scope: rt.currentScope || null,
          hormoneOpts,
          stepMinutes: cfg.v14.sleep.stepMinutes,
        });
        rt.state = advanced.state;
      } else {
        const settled = settleLifecycle(rt.state, {
          frozen: rt.state.flags?.safeMode,
          minutes,
          now,
          cfg,
        });
        rt.state = settled.skipped ? rt.state : settled.state;
        rt.state = lifeTick(rt.state, minutes, now, cfg, hormoneOpts);
        if (v14) rt.state.counters.lastTickAt = now;
      }

      if (elapsed.capped) rt.state.flags.longAbsence = true;
      if (minutes >= 12 * 60) rt.state.flags.longAbsence = true;

      // v14 P1: needs -> hormones linkage remains a separate, clamped proposal.
      if (v14 && v14On(cfg, 'lexicon')) {
        try {
          const d = desireMoodTick(rt.state.needs, rt.state, { now, cfg });
          if (d) {
            for (const [k, v] of Object.entries(clampDelta(d.delta, cfg.v14.lexicon.maxNudge))) {
              rt.state.hormones[k] = Math.max(cfg.hormone.floor[k] ?? 0,
                Math.min(cfg.hormone.cap ?? 0.97, Number(rt.state.hormones[k] ?? 0.5) + v));
            }
            rt.state.counters.desireMoodAt = d.at;
          }
        } catch { /* ignore */ }
      }

      rt.book.decayAll(Math.min(minutes, 1440));
      saveState(rt.db, rt.state, now, cfg);
      if (new Date(now).getHours() >= 4) runNightly(rt.db, nightlyOpts(rt, cfg, now));
    } catch (e) {
      ctx.log?.error?.('[dsh-life] tick failed: ' + e.message);
    }
  });

  // ---------- 工具：主动计划闸 ----------
  reg({
    name: 'life_propose',
    description: '主动开口前先提交计划，通过 evidence 校验才会发送',
    async run(proposal) {
      const sp = canSpeak(rt.state.needs, cfg);
      if (!sp.ok) return { sent: false, reason: 'speak-weight', speakWeight: sp.speakWeight };
      const gate = hardGates(rt.state, Date.now(), cfg, { preset: cfg.preset });
      if (!gate.ok) return { sent: false, reason: 'hard-gate:' + gate.failed.join(',') };
      const mem = proposal?.evidence_id
        ? rt.db.prepare('SELECT * FROM memories WHERE id = ?').get(proposal.evidence_id)
        : null;
      // v14：假设语气条目不得作为主动发言的证据
      if (v14On(cfg, 'hypothetical') && mem && String(mem.anchor_ground || '').includes('hypothetical')) {
        return { sent: false, reason: 'hypothetical-evidence' };
      }
      const vet = vetProposal(proposal, { memories: mem ? [mem] : [], saidRecently: rt.recentSaid });
      if (!vet.ok) return { sent: false, reason: vet.reason };
      const pid = nextId(rt.db, 'action_proposals', 'p');
      rt.db.prepare('INSERT INTO action_proposals(id,intent,say,why,evidence_id,expected_effect,risk,status,created_at) VALUES(?,?,?,?,?,?,?,?,?)')
        .run(pid, proposal.intent, proposal.say, proposal.why, proposal.evidence_id,
             proposal.expected_effect || '', proposal.risk || 'low', 'queued', Date.now());
      let deferred = false;
      if (v14On(cfg, 'sleepQueue') && isSleeping(rt.state)) {
        const q = queueDelivery(rt.state, {
          text: proposal.say, kind: 'proactive', scope: rt.currentScope,
          proposalId: pid, urgent: proposal.urgent === true,
        }, { now: Date.now(), max: cfg.v14.sleep.queueMax });
        deferred = q.ok;
        if (q.ok) saveState(rt.db, rt.state, Date.now(), cfg);
      }
      return {
        queued: true, proposalId: pid, say: proposal.say,
        speakWeight: sp.speakWeight, deferredUntilWake: deferred,
      };
    },
  });

  reg({
    name: 'life_mark_sent',
    description: '宿主发送成功后调用，把 queued 的计划标记为 sent',
    async run({ proposal_id, host_message_id } = {}) {
      if (!proposal_id) return { ok: false, reason: 'missing-id' };
      const row = rt.db.prepare('SELECT status FROM action_proposals WHERE id = ?').get(proposal_id);
      if (!row) return { ok: false, reason: 'not-found' };
      if (row.status !== 'queued') return { ok: false, reason: 'not-queued', status: row.status };
      rt.db.prepare("UPDATE action_proposals SET status='sent', sent_at=? WHERE id=? AND status='queued'")
        .run(Date.now(), proposal_id);
      if (host_message_id) {
        rt.db.prepare('INSERT INTO kv(k,v,updated_at) VALUES(?,?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v')
          .run('last_sent:' + proposal_id, String(host_message_id), Date.now());
      }
      rt.state.social.lastProactiveAt = Date.now();
      if (v14On(cfg, 'socialTimestamps')) rt.state.social.lastBotAt = Date.now();
      rt.state.counters.proactiveToday = (rt.state.counters.proactiveToday || 0) + 1;
      const queued = rt.state.sleep?.pendingDeliveries || [];
      const ids = queued.filter((x) => String(x.proposalId) === String(proposal_id)).map((x) => x.id);
      if (ids.length) ackDeliveries(rt.state, ids, { now: Date.now() });
      return { ok: true, status: 'sent' };
    },
  });

  reg({
    name: 'life_sleep',
    description: '查看/设置睡眠模式：auto / sleep / awake。设置会写入持久状态核。',
    async run({ mode = 'status' } = {}) {
      if (!v14On(cfg, 'sleepStages')) return { ok: false, reason: 'sleep-stages-disabled', sleeping: false };
      if (mode === 'status') {
        return { ok: true, mode: rt.state.sleep?.manual || 'auto', stage: rt.state.sleep?.stage || 'awake', sleeping: isSleeping(rt.state) };
      }
      if (!['auto', 'sleep', 'awake'].includes(mode)) return { ok: false, reason: 'bad-mode' };
      rt.state.sleep = rt.state.sleep || {};
      rt.state.sleep.manual = mode;
      const now = Date.now();
      const staged = settleStages(rt.state, {
        now, minutes: 5, cfg, db: rt.db, dreamEnabled: false,
        scope: rt.currentScope || null,
      });
      rt.state = staged.state;
      rt.state.counters.lastTickAt = now;
      saveState(rt.db, rt.state, now, cfg);
      return { ok: true, mode, stage: rt.state.sleep.stage, sleeping: isSleeping(rt.state) };
    },
  });

  reg({
    name: 'life_delivery_poll',
    description: '睡眠队列出队。宿主确认可投递后调用，发送成功再用 life_delivery_ack 删除。',
    async run({ limit = 5, include_urgent_while_asleep = false } = {}) {
      if (!v14On(cfg, 'sleepQueue')) return { ok: false, reason: 'sleep-queue-disabled', items: [] };
      return { ok: true, ...pollDeliveries(rt.state, { limit, includeUrgentWhileAsleep: include_urgent_while_asleep === true }) };
    },
  });

  reg({
    name: 'life_delivery_ack',
    description: '宿主发送成功后确认队列项，避免重复投递。',
    async run({ ids = [] } = {}) {
      if (!v14On(cfg, 'sleepQueue')) return { ok: false, reason: 'sleep-queue-disabled' };
      const out = ackDeliveries(rt.state, ids, { now: Date.now() });
      saveState(rt.db, rt.state, Date.now(), cfg);
      return out;
    },
  });

  reg({
    name: 'life_gap',
    description: '缺口池：list/open/close/epiphany。用于“没答上来、后来补上证据”的可解释闭环。',
    async run({ action = 'list', question, gap_id, tension, evidence, coverage } = {}) {
      if (!v14On(cfg)) return { ok: false, reason: 'v14-disabled' };
      const scope = rt.currentScope || (cfg.ownerQq ? `private:${cfg.ownerQq}` : 'solo');
      if (action === 'list') {
        return {
          ok: true,
          gaps: rt.db.prepare(
            'SELECT id, question, tension, resolved, closed_by, created_at FROM gaps WHERE scope = ? ORDER BY resolved ASC, tension DESC LIMIT 30'
          ).all(scope),
        };
      }
      if (action === 'open') {
        if (!question) return { ok: false, reason: 'missing-question' };
        return { ok: true, ...openGap(rt.db, {
          question, scope,
          tension: Number.isFinite(Number(tension)) ? Number(tension) : 0.5,
          now: Date.now(),
        }) };
      }
      if (!gap_id) return { ok: false, reason: 'missing-id' };
      const gap = rt.db.prepare('SELECT scope FROM gaps WHERE id = ?').get(gap_id);
      if (!gap) return { ok: false, reason: 'not-found' };
      if (gap.scope !== scope) return { ok: false, reason: 'scope-denied' };
      if (action === 'close') {
        return tryCloseGap(rt.db, gap_id, {
          strongestEvidence: Number(evidence || 0),
          coverage: Number(coverage || 0),
          closedBy: 'manual-evidence',
          now: Date.now(),
        });
      }
      if (action === 'epiphany') {
        const out = epiphany(rt.db, gap_id, rt.state, cfg);
        if (out) saveState(rt.db, rt.state, Date.now(), cfg);
        return out ? { ok: true, ...out } : { ok: false, reason: 'not-open' };
      }
      return { ok: false, reason: 'bad-action' };
    },
  });

  reg({
    name: 'life_recall',
    description: '分层回忆：给 query 返回少量记忆卡；给 memory_id 再读单条详情/证据，避免一次性塞入全文。',
    async run({ query, memory_id, include_raw = false, limit = 3 } = {}) {
      if (!v14On(cfg)) return { ok: false, reason: 'v14-disabled' };
      const scope = rt.currentScope || (cfg.ownerQq ? `private:${cfg.ownerQq}` : 'solo');
      if (memory_id) {
        return recallDetail(rt.db, memory_id, {
          scopes: visibleScopes(scope, { ownerQq: cfg.ownerQq }),
          includeRaw: include_raw === true,
        });
      }
      if (!query) return { ok: false, reason: 'missing-query-or-id' };
      return recallCards(rt.db, query, {
        scope, ownerQq: cfg.ownerQq, limit, cfg, now: Date.now(),
      });
    },
  });

  reg({
    name: 'life_lifebook',
    description: '长期生活簿：承诺、里程碑、阶段叙事、关系快照。结构化写入既有表，不伪造事实记忆。',
    async run({ action = 'list', text, due_at, happened_at, period, status, id } = {}) {
      if (!v14On(cfg)) return { ok: false, reason: 'v14-disabled' };
      const scope = rt.currentScope || (cfg.ownerQq ? `private:${cfg.ownerQq}` : 'solo');
      try {
        if (action === 'list') return { ok: true, ...lifebookSnapshot(rt.db, { scope }) };
        if (action === 'promise_add') return addPromise(rt.db, { scope, text, dueAt: due_at });
        if (action === 'promise_close') return closePromise(rt.db, id, { status: status || 'done' });
        if (action === 'milestone_add') return addMilestone(rt.db, { scope, text, happenedAt: happened_at });
        if (action === 'narrative_add') return addNarrative(rt.db, { scope, text, period: period || 'day' });
        if (action === 'relationship_sync') {
          return upsertRelationship(rt.db, {
            scope,
            closeness: rt.state.relationship?.closeness ?? 0.5,
            trust: rt.state.relationship?.trust ?? 0.5,
            stage: rt.state.relationship?.stage || 'normal',
          });
        }
        return { ok: false, reason: 'bad-action' };
      } catch (e) { return { ok: false, reason: 'lifebook-failed', message: e.message }; }
    },
  });

  // ---------- 工具：人格慢漂移（模型不能改人格，只能提议；owner 终审 apply 才落快照） ----------
  reg({
    name: 'life_persona_review',
    description: '人格慢漂移审阅。action=list 看历史 diff；action=build 现在生成一份候选（只写 life_events，不生效）；action=apply 把某份 diff 落成人格快照（需 owner 确认后才可调用）。',
    async run({ action = 'list', eventId, event_id, limit = 5 } = {}) {
      if (!v14On(cfg)) return { ok: false, reason: 'v14-disabled' };
      const id = eventId || event_id;
      try {
        if (action === 'list') {
          return { ok: true, diffs: listPersonaDiffs(rt.db, { limit }), snapshot: personaSnapshotSafe() };
        }
        if (action === 'build') {
          const r = buildPersonaDiff(rt.db, { cfg, now: Date.now() });
          if (r.ok) kvSet(rt.db, 'persona:lastDiffAt', String(Date.now()));
          return r;
        }
        if (action === 'apply') {
          if (!id) return { ok: false, reason: 'missing-event-id' };
          return applyPersonaDiff(rt.db, id, { cfg, now: Date.now() });
        }
        return { ok: false, reason: 'bad-action' };
      } catch (e) { return { ok: false, reason: 'persona-failed', message: e.message }; }
    },
  });

  function personaSnapshotSafe() {
    try { return personaSnapshot(rt.db); } catch { return {}; }
  }

  // ---------- 工具：记忆写入 ----------
  reg({
    name: 'life_remember',
    description: '把一件值得长期记住的事写进记忆库。category 取 fact(事实)/preference(偏好)/person(人物)/promise(约定)/event(经历)；把握不大就传低 confidence，会自动进候选，不会硬写。',
    async run({ fact, category, confidence, evidence, subject } = {}) {
      if (!fact || String(fact).trim().length < 2) return { ok: false, reason: 'empty' };
      if (String(fact).length > cfg.memory.maxChars) return { ok: false, reason: 'too-long' };
      try {
        const r = await writeMemory(rt.db, {
          fact: String(fact).trim(),
          category: category || 'fact',
          confidence: Number.isFinite(Number(confidence)) ? Number(confidence) : 0.8,
          source_kind: 'user_sentence',
          evidence_kind: 'user_sentence',
          evidence_ref: evidence || 'tool:life_remember',
          scope: rt.currentScope || (cfg.ownerQq ? `private:${cfg.ownerQq}` : 'solo'),
          subject,
        }, rememberDeps(rt, cfg));
        return { ok: r.action === 'insert' || r.action === 'candidate' || r.action === 'superseded' || r.action === 'duplicate', ...r };
      } catch (e) {
        return { ok: false, reason: 'write-failed', message: e?.message };
      }
    },
  });

  // ---------- v14 工具：agent 自管记忆 / 翻案 / 可观测 ----------
  reg({
    name: 'life_memory_review',
    description: '审核候选记忆：accept(重跑 15 步写入管线)/reject/defer；也可列出待审候选与信念冲突',
    async run({ action = 'list', candidate_id, decision, reason, limit } = {}) {
      if (!v14On(cfg)) return { ok: false, reason: 'v14-disabled' };
      try {
        const scope = rt.currentScope || (cfg.ownerQq ? `private:${cfg.ownerQq}` : 'solo');
        if (action === 'list') {
          return {
            ok: true,
            pending: rt.db.prepare(
              "SELECT id, text, category, confidence, created_at FROM candidates WHERE status='pending' AND scope=? ORDER BY created_at DESC LIMIT ?"
            ).all(scope, limit || 20),
          };
        }
        if (action === 'conflicts') {
          return { ok: true, conflicts: listConflicts(rt.db, { limit: limit || 20, scope }) };
        }
        if (action === 'resolve' && candidate_id) {
          const mem = rt.db.prepare('SELECT scope FROM memories WHERE id=?').get(candidate_id);
          if (!mem) return { ok: false, reason: 'not-found' };
          if (mem.scope !== scope) return { ok: false, reason: 'scope-denied' };
          return resolveConflict(rt.db, candidate_id, { verdict: decision || 'ok' });
        }
        if (!candidate_id || !decision) return { ok: false, reason: 'missing-args' };
        const candidate = rt.db.prepare('SELECT scope FROM candidates WHERE id=?').get(candidate_id);
        if (!candidate) return { ok: false, reason: 'not-found' };
        if (candidate.scope !== scope) return { ok: false, reason: 'scope-denied' };
        return await reviewCandidate(rt.db, candidate_id, { decision, reason, cfg, now: Date.now() });
      } catch (e) { return { ok: false, reason: 'review-failed', message: e.message }; }
    },
  });

  reg({
    name: 'life_forget',
    description: '把一条记忆盖章作废（不删行，可翻案），需给理由',
    async run({ memory_id, reason } = {}) {
      if (!v14On(cfg)) return { ok: false, reason: 'v14-disabled' };
      if (!memory_id) return { ok: false, reason: 'missing-id' };
      const scope = rt.currentScope || (cfg.ownerQq ? `private:${cfg.ownerQq}` : 'solo');
      const mem = rt.db.prepare('SELECT scope FROM memories WHERE id=?').get(memory_id);
      if (!mem) return { ok: false, reason: 'not-found' };
      if (mem.scope !== scope) return { ok: false, reason: 'scope-denied' };
      return retract(rt.db, memory_id, reason || 'agent-requested');
    },
  });

  reg({
    name: 'life_status',
    description: '查看 v14 运行状态：激素归因、检索统计、睡眠阶段、梦、念头流、容量、一致性抽样',
    async run() {
      if (!v14On(cfg)) return { ok: true, v14: false, revision: rt.state?.revision };
      try {
        return {
          ok: true, v14: true,
          revision: rt.state?.revision,
          hormoneSource: rt.state?.hormoneSource || 'baseline-decay',
          hormoneBasis: rt.state?.hormoneBasis || null,
          sleep: rt.state?.sleep || null,
          pendingDeliveries: pendingDeliveryCount(rt.state),
          thoughts: currentThoughts(rt.state).length,
          dreams: recentDreams(rt.db, { limit: 10, scope: rt.currentScope || null }),
          recentAppraisals: recentAppraisals(rt.db, { scope: rt.currentScope, limit: cfg.v14.appraisal?.historyLimit || 20 }),
          retrieval: readStats(rt.db),
          capacity: capacityReport(rt.db),
          consistency: consistencySample(rt.db, { scope: rt.currentScope || null }),
          optionalSchema: inspectEdgesBasis(rt.db),
        };
      } catch (e) { return { ok: false, reason: e.message }; }
    },
  });

  return rt;
}

// ---------- v14 小工具 ----------
function nightlyOpts(rt, cfg, now) {
  const o = { now, cfg };
  if (!v14On(cfg)) return o;
  if (v14On(cfg, 'edgesBuild')) {
    o.buildEdges = () => buildEdges(rt.db, { now, pairCap: 8 });
  }
  // Q5：dreamLog 过 softLimit 才归档进 dreams 表（表由 schema 建好，不猜）
  if (v14On(cfg, 'dreams')) {
    o.archiveDreams = () => archiveDreams(rt.db, rt.state, { now, cfg });
  }
  // Q8：每 diffEveryDays 天出一次人格 diff 候选（只写 life_events，不生效）
  o.personaDiff = () => {
    const every = Number(cfg.v14?.persona?.diffEveryDays ?? 14);
    const last = Number(kvGet(rt.db, 'persona:lastDiffAt') || 0);
    if (now - last < every * 86400000) return { skipped: true };
    const r = buildPersonaDiff(rt.db, { now, cfg });
    if (r.ok) kvSet(rt.db, 'persona:lastDiffAt', String(now));
    return r;
  };
  o.decayGaps = () => decayGaps(rt.db, { now });
  o.quota = () => {
    try {
      enforceTierQuota(rt.db, now, cfg);
      if (cfg.memory.importanceQuota === true) enforceImportanceQuota(rt.db, now, cfg);
      return true;
    } catch { return false; }
  };
  // core 晋升：把 evidence.mjs 整套接进夜间（v13 里它从未被调用）
  o.health = () => {
    let promoted = 0;
    try {
      const rows = rt.db.prepare("SELECT id FROM memories WHERE protection_tier != 'core' AND invalid_reason IS NULL LIMIT 100").all();
      for (const r of rows) {
        try { if (promoteTier(rt.db, r.id, { now })?.ok) promoted++; } catch { /* ignore */ }
      }
    } catch { /* ignore */ }
    return { ...capacityReport(rt.db), promoted };
  };
  const beliefMode = v14Mode(cfg, 'beliefPool');
  if (beliefMode === 'on') {
    o.conflicts = () => detectConflicts(rt.db, { now, cfg });
    o.alerts = () => negativeAlerts(rt.db, rt.state, { now, cfg });
  } else if (beliefMode === 'shadow') {
    o.conflicts = () => inShadow(rt.db, 'beliefPool', () => detectConflicts(rt.db, { now, cfg }), now);
    o.alerts = () => inShadow(rt.db, 'beliefPool', () => negativeAlerts(rt.db, rt.state, { now, cfg }), now);
  }
  const imprintMode = v14Mode(cfg, 'imprint');
  if (imprintMode !== 'off') {
    const runImprint = () => {
      const m = rt.db.prepare("SELECT * FROM memories WHERE importance >= 0.85 AND invalid_reason IS NULL ORDER BY importance DESC LIMIT 1").get();
      if (!m) return { ok: false, reason: 'no-candidate' };
      return generateImprint(rt.db, m, {
        now, cfg, maxImprints: cfg.v14.imprint.max, cooldownDays: cfg.v14.imprint.cooldownDays,
        independentEvidence: 2,
      });
    };
    o.imprint = imprintMode === 'shadow'
      ? () => inShadow(rt.db, 'imprint', runImprint, now)
      : runImprint;
  }
  return o;
}

/** 自我报告：只从状态推一句话，不带数值（Gitee「她自己说烦」的极简版） */
function selfReportOf(state) {
  const h = state?.hormones || {};
  if (Number(h.cortisol) >= 0.7) return '有点烦';
  if (Number(h.serotonin) <= 0.30) return '提不起劲';
  if (state?.sleep?.sleepDebt >= 0.6) return '有点困';
  return '';
}

// ---------- 小工具 ----------
function formatMemoryLine(mem, mode) {
  const tag = mem.category === 'person' ? '人物' : mem.category === 'promise' ? '约定' : '事实';
  // v14：假设语气保留「如果/要是/前提」的限定，绝不写成陈述事实
  const hedge = mode === 'hypothetical' ? '（当时只是假设）'
    : mode === 'hedged' ? '（不太确定）' : '';
  return `[${tag}] ${mem.fact}${hedge}`;
}

/** 状态行注入闸：偏离 >0.10 且 60 分钟最多 1 次 */
function mayInjectState(state, now) {
  if (now - (state.counters.stateLineAt || 0) < 60 * 60000) return false;
  const target = 0.5;
  return Math.abs(state.needs.mood - target) > 0.10 || Math.abs(state.energy - target) > 0.10;
}

function textScoreLite(a, b) {
  if (!a || !b) return 0;
  let n = 0;
  for (let i = 0; i < b.length - 1; i++) if (a.includes(b.slice(i, i + 2))) n++;
  return Math.min(1, n / Math.max(1, b.length - 1));
}

function echoRewriteHint(text) {
  return text;
}
