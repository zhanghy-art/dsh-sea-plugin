// src/kit/dirty-data.mjs — v14 脏数据治理（真库实测出来的六类，逐条可逆、逐条可审计）
//
// 为什么要单独一个模块：v13 在本机跑了一个多月，攒下的脏数据不是「设计问题」，
// 是「运行时事故的沉淀」——拼错的 ALTER 造出一列 undefined、两条 life_state 并行、
// 时间列 TEXT/数值混写、722 条过期提案永远挂着 pending、索引建了两遍。
// 这些东西每次启动都会被读到，不清掉，v14 的新链路就永远跑在泥里。
//
// 设计铁律：
//   1) 只做「能被解释的清理」，删任何东西之前先把证据写进 dirty_report（可回滚、可追问）
//   2) 每次只跑一遍，靠 kv('dirty:v14') 打戳，重复启动一律 no-op
//   3) 任何一步失败只跳过那一步，不阻断升级（脏数据不该让插件起不来）
//   4) 绝不碰 memories 的正文、belief、protection_tier（那是人格资产，不是脏数据）

export const DIRTY_STAMP_KEY = 'dirty:v14';

// 注意：这里绝不 import './db.mjs'。db.mjs 会 import 本模块去做升级判定，
// 反过来再依赖 db.mjs 就成环（模块自检 E1/E2 会直接判死）。kv 读写只有两句 SQL，
// 就地写掉比引一层更干净。
function kvRead(db, k) {
  try { return db.prepare('SELECT v FROM kv WHERE k = ?').get(k)?.v ?? null; }
  catch { return null; }
}

function kvWrite(db, k, v, now) {
  db.prepare(
    'INSERT INTO kv(k,v,updated_at) VALUES(?,?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v, updated_at=excluded.updated_at'
  ).run(k, v, now);
}

/** 老库里那些「拼错的 ALTER」留下的列名。只认这几个，不做模糊匹配。 */
export const JUNK_COLUMNS = ['undefined', 'null', 'NULL', ''];

const isJunkColumn = (name) => JUNK_COLUMNS.includes(String(name));

/* ------------------------------------------------------------------ */
/* 1) 拼错的 ALTER 造出的垃圾列                                          */
/* ------------------------------------------------------------------ */
export function inspectJunkColumns(db) {
  const found = [];
  for (const t of db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").all()) {
    let cols;
    try { cols = db.prepare(`PRAGMA table_info("${t.name}")`).all(); } catch { continue; }
    for (const c of cols) if (isJunkColumn(c.name)) found.push({ table: t.name, column: c.name });
  }
  return found;
}

export function dropJunkColumns(db, { apply = false } = {}) {
  const found = inspectJunkColumns(db);
  if (!found.length) return { found: 0, dropped: [], skipped: [] };
  if (!apply) return { found: found.length, dropped: [], skipped: found, dryRun: true };
  const dropped = [], skipped = [];
  for (const { table, column } of found) {
    try {
      // 这些列没进任何索引、没被任何查询引用（代码里从未出现过），所以 DROP 不会牵一发动全身。
      // 若 SQLite 版本太老不支持 DROP COLUMN，退化成「留着但永不再读」，不阻断。
      db.exec(`ALTER TABLE "${table}" DROP COLUMN "${column}"`);
      dropped.push(`${table}.${column}`);
    } catch (e) {
      skipped.push({ table, column, reason: e.message });
    }
  }
  return { found: found.length, dropped, skipped };
}

/* ------------------------------------------------------------------ */
/* 2) life_state 的残留行（id='singleton'，state_json 为 NULL）           */
/* ------------------------------------------------------------------ */
export function inspectLifeStateRows(db) {
  let rows;
  try {
    rows = db.prepare(
      "SELECT id, typeof(id) AS t, revision, length(state_json) AS sj, updated_at FROM life_state"
    ).all();
  } catch { return { rows: [], primary: null, residue: [] }; }
  // 判据：state_json 有内容、revision > 0 的那条才是真状态；
  // 剩下的是历史上「写错 id」留下的空壳（实测 id='singleton'、revision=0、state_json=NULL）。
  const usable = rows.filter(r => r.sj !== null && r.sj > 0);
  usable.sort((a, b) => (Number(b.revision) || 0) - (Number(a.revision) || 0));
  const primary = usable[0] || rows[0] || null;
  const residue = rows.filter(r => r !== primary && (r.sj === null || r.sj === 0));
  return { rows, primary, residue };
}

export function cleanLifeStateRows(db, { apply = false } = {}) {
  const { primary, residue } = inspectLifeStateRows(db);
  if (!residue.length) return { removed: [], kept: primary?.id ?? null };
  if (!apply) return { wouldRemove: residue.map(r => r.id), kept: primary?.id ?? null, dryRun: true };
  const removed = [];
  for (const r of residue) {
    try {
      db.prepare('DELETE FROM life_state WHERE id = ?').run(r.id);
      removed.push(r.id);
    } catch { /* 单行删不掉不影响整体 */ }
  }
  return { removed, kept: primary?.id ?? null };
}

/* ------------------------------------------------------------------ */
/* 3) TEXT 时间里的「毫秒数带 .0」与 ISO 串统一成整数毫秒                  */
/* ------------------------------------------------------------------ */
/**
 * 把 '1793539724176.0' / '2026-11-02T09:55:56+08:00' 这种混写时间归一成整数毫秒。
 * 只处理「代码里当数值用」的列，不动 memories.created_at 这类展示列。
 */
export const TIME_COLUMNS = [
  { table: 'life_state', column: 'updated_at' },
  { table: 'injection_log', column: 'created_at' },
  { table: 'life_snapshots', column: 'created_at' },
];

const ISO_TO_MS = (col) => `CAST(strftime('%s', replace(substr(${col},1,19),'T',' ')) AS INTEGER) * 1000`;

export function inspectMixedTime(db) {
  const out = [];
  for (const { table, column } of TIME_COLUMNS) {
    try {
      const total = db.prepare(`SELECT COUNT(*) AS n FROM "${table}"`).get().n;
      const text = db.prepare(`SELECT COUNT(*) AS n FROM "${table}" WHERE typeof("${column}")='text'`).get().n;
      const dotZero = db.prepare(
        `SELECT COUNT(*) AS n FROM "${table}" WHERE typeof("${column}")='text' AND "${column}" GLOB '*[0-9].[0-9]*'`
      ).get().n;
      // 「纯数字但存成 TEXT」也是脏的：代码按数值比较时它会被当成字符串，
      // SQLite 里 '1793539724176' < 1793539724177 的比较结果跟你想的不一样。
      const numText = db.prepare(
        `SELECT COUNT(*) AS n FROM "${table}"
         WHERE typeof("${column}")='text' AND "${column}" NOT GLOB '*[^0-9.]*' AND "${column}" <> ''`
      ).get().n;
      const iso = db.prepare(
        `SELECT COUNT(*) AS n FROM "${table}" WHERE typeof("${column}")='text' AND "${column}" LIKE '____-__-__T%'`
      ).get().n;
      const ints = db.prepare(`SELECT COUNT(*) AS n FROM "${table}" WHERE typeof("${column}")='integer'`).get().n;
      // 真正的「脏」只有两种：带 .0 尾巴的、ISO 串的。
      // 纯数字文本不算脏——这些列在 v11.1 里就是 TEXT 亲和性，
      // 写整数进去 SQLite 会按亲和性转回文本存储，typeof 永远是 text。
      // 值已经是正确的毫秒数，读出来 Number() 照样能用，强改类型得整表重建，不值得。
      const dirty = dotZero + iso;
      out.push({ table, column, total, text, dotZero, numText, iso, ints, dirty });
    } catch { /* 表或列不存在就跳过 */ }
  }
  return out;
}

export function normalizeMixedTime(db, { apply = false } = {}) {
  const report = [];
  for (const { table, column } of TIME_COLUMNS) {
    let before;
    try { before = inspectMixedTime(db).find(x => x.table === table && x.column === column); } catch { continue; }
    if (!before || before.text === 0) continue;
    if (!apply) { report.push({ ...before, dryRun: true }); continue; }
    try {
      // '...0.0' → 取整数部分；ISO 串 → strftime 换算。两者都只在本列是 TEXT 时动手。
      // 三种形状都要收：'1793539724176.0'（带 .0）、'1793539724176'（纯数字串）、
      // '2026-11-02T09:55:56+08:00'（ISO）。只认这三种，其它文本原样留着不动。
      db.exec(`UPDATE "${table}"
               SET "${column}" = CASE
                 WHEN typeof("${column}") <> 'text' THEN "${column}"
                 WHEN "${column}" GLOB '*[A-Za-z]*' AND "${column}" LIKE '____-__-__T%'
                   THEN ${ISO_TO_MS(`"${column}"`)}
                 WHEN "${column}" NOT GLOB '*[^0-9.]*' AND "${column}" <> ''
                   THEN CAST(CAST("${column}" AS REAL) AS INTEGER)
                 ELSE "${column}"
               END
               WHERE typeof("${column}") = 'text'`);
      const after = inspectMixedTime(db).find(x => x.table === table && x.column === column);
      report.push({ ...before, after });
    } catch (e) {
      report.push({ ...before, error: e.message });
    }
  }
  return report;
}

/* ------------------------------------------------------------------ */
/* 4) 过期提案：v13 里 722 条 pending 永远不动                            */
/* ------------------------------------------------------------------ */
/**
 * v13 的 action_proposals 用 status='pending'，v14 的写入路径用 'queued'。
 * 老库里那些 pending 全部早已过期（实测 722 条 expires_at 都在 11-02 之前），
 * 它们既不会被发送、也不会被清理，只会一直占着表——这里统一判死。
 */
export const PROPOSAL_DEAD_STATUS = ['pending', 'allowed'];

export function inspectStaleProposals(db, { now = Date.now() } = {}) {
  try {
    const rows = db.prepare(
      `SELECT status, COUNT(*) AS n,
              SUM(CASE WHEN expires_at IS NOT NULL THEN 1 ELSE 0 END) AS with_exp
       FROM action_proposals GROUP BY status`
    ).all();
    const parse = (v) => {
      if (v === null || v === undefined || v === '') return null;
      if (typeof v === 'number') return v;
      const s = String(v);
      if (/^\d{10,}$/.test(s)) return Number(s);
      const t = Date.parse(s.includes('T') ? s : s.replace(' ', 'T'));
      return Number.isFinite(t) ? t : null;
    };
    let stale = 0;
    for (const r of db.prepare('SELECT id, status, expires_at FROM action_proposals').all()) {
      if (!PROPOSAL_DEAD_STATUS.includes(r.status)) continue;
      const exp = parse(r.expires_at);
      if (exp !== null && exp < now) stale++;
    }
    return { byStatus: rows, stale, now };
  } catch (e) { return { byStatus: [], stale: 0, error: e.message }; }
}

export function expireStaleProposals(db, { apply = false, now = Date.now() } = {}) {
  const info = inspectStaleProposals(db, { now });
  if (!info.stale) return { ...info, expired: 0 };
  if (!apply) return { ...info, expired: 0, dryRun: true };
  let expired = 0;
  for (const r of db.prepare('SELECT id, status, expires_at FROM action_proposals').all()) {
    if (!PROPOSAL_DEAD_STATUS.includes(r.status)) continue;
    const s = String(r.expires_at ?? '');
    const exp = /^\d{10,}$/.test(s) ? Number(s) : Date.parse(s.includes('T') ? s : s.replace(' ', 'T'));
    if (!Number.isFinite(exp) || exp >= now) continue;
    try {
      // 用 'expired' 而不是删除：提案是「当时想说什么」的证据，删了就没法复盘。
      db.prepare("UPDATE action_proposals SET status = 'expired', drop_reason = COALESCE(drop_reason, 'v14-stale-cleanup') WHERE id = ?")
        .run(r.id);
      expired++;
    } catch { /* 单行失败继续 */ }
  }
  return { ...info, expired };
}

/* ------------------------------------------------------------------ */
/* 5) 重复索引                                                          */
/* ------------------------------------------------------------------ */
/** 归一化索引定义，只留「表 + 列序列」用于判重。 */
const normIndex = (sql) => {
  const m = /ON\s+["'`]?(\w+)["'`]?\s*\(([^)]*)\)/i.exec(sql || '');
  if (!m) return null;
  return m[1].toLowerCase() + '(' + m[2].split(',').map(s => s.trim().toLowerCase()).join(',') + ')';
};

export function inspectDuplicateIndexes(db) {
  const idx = db.prepare(
    "SELECT name, tbl_name, sql FROM sqlite_master WHERE type='index' AND sql IS NOT NULL AND name NOT LIKE 'sqlite_%'"
  ).all();
  const groups = new Map();
  for (const i of idx) {
    const key = normIndex(i.sql);
    if (!key) continue;
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(i);
  }
  const dups = [];
  for (const [key, list] of groups) {
    if (list.length < 2) continue;
    // 保留名字最短的那个（通常是原始定义），其余判为重复
    const sorted = [...list].sort((a, b) => a.name.length - b.name.length || a.name.localeCompare(b.name));
    dups.push({ key, keep: sorted[0].name, drop: sorted.slice(1).map(x => x.name) });
  }
  return dups;
}

export function dropDuplicateIndexes(db, { apply = false } = {}) {
  const dups = inspectDuplicateIndexes(db);
  if (!dups.length) return { groups: 0, dropped: [] };
  if (!apply) return { groups: dups.length, dropped: [], wouldDrop: dups.flatMap(d => d.drop), dryRun: true };
  const dropped = [];
  for (const g of dups) {
    for (const name of g.drop) {
      try { db.exec(`DROP INDEX IF EXISTS "${name}"`); dropped.push(name); } catch { /* ignore */ }
    }
  }
  return { groups: dups.length, dropped };
}

/* ------------------------------------------------------------------ */
/* 6) 向量模型冲突：外部 bge-m3:1024 vs 本地 hash384                      */
/* ------------------------------------------------------------------ */
/**
 * 真库 240 行有 bge-m3:1024 的向量、100 行没有。v14 的本地向量是 hash384，
 * 两者维度不同、绝不能混算余弦。策略：只补 NULL 的行，已存在的模型一律不动。
 */
export function inspectVectorModels(db) {
  try {
    const rows = db.prepare('SELECT vec_model, COUNT(*) AS n FROM memories GROUP BY vec_model').all();
    return {
      models: rows.map(r => ({ model: r.vec_model, count: r.n })),
      hasForeign: rows.some(r => r.vec_model && r.vec_model !== 'hash384'),
      nullCount: rows.filter(r => !r.vec_model).reduce((a, r) => a + r.n, 0),
    };
  } catch (e) { return { models: [], hasForeign: false, nullCount: 0, error: e.message }; }
}

/* ------------------------------------------------------------------ */
/* 总入口：一次性、幂等、可审计                                          */
/* ------------------------------------------------------------------ */
export function runDirtyCleanup(db, { log = null, now = Date.now(), force = false } = {}) {
  const stamp = kvRead(db, DIRTY_STAMP_KEY);
  if (stamp && !force) return { skipped: true, stamp };

  const report = { at: now, junk: null, lifeState: null, time: null, proposals: null, indexes: null, vectors: null };
  const warn = (m) => { try { log?.warn?.('[dsh-life] ' + m); } catch { /* ignore */ } };
  const info = (m) => { try { log?.info?.('[dsh-life] ' + m); } catch { /* ignore */ } };

  db.exec('BEGIN IMMEDIATE');
  try {
    try { report.junk = dropJunkColumns(db, { apply: true }); }
    catch (e) { report.junk = { error: e.message }; warn('垃圾列清理失败：' + e.message); }

    try { report.lifeState = cleanLifeStateRows(db, { apply: true }); }
    catch (e) { report.lifeState = { error: e.message }; warn('life_state 残行清理失败：' + e.message); }
    if (report.lifeState?.removed?.length) {
      info(`life_state 清掉 ${report.lifeState.removed.length} 条空壳，保留 ${report.lifeState.kept}`);
    }

    try { report.time = normalizeMixedTime(db, { apply: true }); }
    catch (e) { report.time = { error: e.message }; warn('时间列归一失败：' + e.message); }

    try { report.proposals = expireStaleProposals(db, { apply: true, now }); }
    catch (e) { report.proposals = { error: e.message }; warn('过期提案清理失败：' + e.message); }
    if (report.proposals?.expired) info(`过期提案判死 ${report.proposals.expired} 条（保留证据，不删行）`);

    try { report.indexes = dropDuplicateIndexes(db, { apply: true }); }
    catch (e) { report.indexes = { error: e.message }; warn('重复索引清理失败：' + e.message); }

    try { report.vectors = inspectVectorModels(db); } catch { /* 只读，失败无妨 */ }

    kvWrite(db, DIRTY_STAMP_KEY, JSON.stringify(report), now);

    db.exec('COMMIT');
  } catch (e) {
    try { db.exec('ROLLBACK'); } catch { /* ignore */ }
    warn('脏数据治理整体回滚：' + e.message);
    return { failed: true, message: e.message };
  }

  // 治理报告单独留一份，方便事后追问「你到底删了什么」
  try {
    kvWrite(db, 'dirty:v14:report', JSON.stringify(report), now);
  } catch { /* ignore */ }

  return report;
}

/** 只读诊断：不写库，给 doctor / 面板用 */
export function diagnoseDirty(db, { now = Date.now() } = {}) {
  return {
    junk: inspectJunkColumns(db),
    lifeState: inspectLifeStateRows(db),
    time: inspectMixedTime(db),
    proposals: inspectStaleProposals(db, { now }),
    duplicateIndexes: inspectDuplicateIndexes(db),
    vectors: inspectVectorModels(db),
  };
}
