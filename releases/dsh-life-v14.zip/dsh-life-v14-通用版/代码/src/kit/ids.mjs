// src/kit/ids.mjs — 主键策略（v13.0 新增）
// 为什么需要这一层：
//   v11.1 旧库的 memories.id 是 INTEGER（文档第十一章 DDL 明写），
//   而 v12.x/14.0 的写入管线用 'm' + 6 位 hex 的 TEXT 主键。
//   在 INTEGER PRIMARY KEY 的表里插 TEXT 会直接报 datatype mismatch，
//   这是「原库直升级」路上的第一个硬墙（codex v13.2 第 8 章实测）。
// 裁定（融合指南 4.2）：主键类型采 codex —— 旧库 INTEGER 保留，新库同样用 INTEGER。
//   - 旧库：整数自增（MAX(id)+1），不建新表、不搬数据
//   - 旧库若某张辅助表历史上就是 TEXT 主键（部分 11.x 手改库），运行时探测后继续用 TEXT
// 这一层的价值不是「生成 id」，是把「主键类型」这件事从 12 个调用点收敛到 1 处。
import { randomBytes } from 'node:crypto';

const INT_TYPES = new Set(['INTEGER', 'INT', 'BIGINT']);
const TEXT_TYPES = new Set(['TEXT', 'VARCHAR', 'CHAR', 'CLOB', '']);

const cache = new Map();

/** 读取某张表的主键列名与类型；表不存在返回 null */
export function primaryKeyOf(db, table) {
  let rows;
  try {
    rows = db.prepare(`PRAGMA table_info("${table}")`).all();
  } catch {
    return null;
  }
  if (!rows || !rows.length) return null;
  const pk = rows.find(c => Number(c.pk) === 1) || rows.find(c => c.name === 'id');
  if (!pk) return null;
  const type = String(pk.type || '').toUpperCase();
  return { column: pk.name, type, integer: INT_TYPES.has(type), text: TEXT_TYPES.has(type) };
}

/**
 * 该表的主键形态：'int' | 'text' | 'none'
 * 结果按 (db, table) 缓存；表结构在进程内不会变。
 */
export function idKind(db, table) {
  const key = table;
  if (cache.has(key)) return cache.get(key);
  const pk = primaryKeyOf(db, table);
  let kind = 'none';
  if (pk) kind = pk.integer ? 'int' : 'text';
  cache.set(key, kind);
  return kind;
}

/** 新库/新表统一用 INTEGER；这里给需要显式整数 id 的旧表用 */
export function nextIntId(db, table) {
  const row = db.prepare(`SELECT COALESCE(MAX(id), 0) AS m FROM "${table}"`).get();
  return Number(row?.m || 0) + 1;
}

/** TEXT 主键的短 id（只在旧库辅助表为 TEXT 时使用） */
export function nextTextId(prefix = 'x') {
  return prefix + randomBytes(4).toString('hex');
}

/**
 * 取下一个主键。自动按实际表结构选择整数或文本。
 * @param {object} db
 * @param {string} table 表名
 * @param {string} prefix 仅 TEXT 表使用
 */
export function nextId(db, table, prefix = 'x') {
  const kind = idKind(db, table);
  if (kind === 'int') return nextIntId(db, table);
  return nextTextId(prefix);
}

/** 内存态比较用：null 安全地归一成同一类型（避免 '12' !== 12 导致的冷却/去重失效） */
export function sameId(a, b) {
  if (a == null || b == null) return false;
  if (typeof a === 'number' && typeof b === 'number') return a === b;
  return String(a) === String(b);
}

/** 落库参数用：INTEGER 表传数字，TEXT 表传字符串 */
export function idParam(db, table, id) {
  const kind = idKind(db, table);
  if (kind === 'int') {
    const n = Number(id);
    return Number.isFinite(n) ? n : id;
  }
  return String(id);
}
