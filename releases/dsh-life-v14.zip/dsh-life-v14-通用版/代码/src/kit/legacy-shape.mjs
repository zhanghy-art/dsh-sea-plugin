// src/kit/legacy-shape.mjs — 老库表结构「宽松化」（v14.0 新增，P0 修复）
//
// 为什么必须有这一层：
//   真库不是 schema.sql 建出来的，是从 v11.1 一路 ALTER 演化来的。多张表至今仍是
//   v11.1 的原始 DDL，带着 v12+ 代码根本不填的 NOT NULL 列：
//     life_events      at TEXT NOT NULL / kind TEXT NOT NULL / seq INTEGER PK AUTOINCREMENT
//     action_proposals at TEXT NOT NULL
//     memories_archive row_json TEXT NOT NULL
//     milestones       title TEXT NOT NULL / 无 scope,text,happened_at
//     promises         无 scope,last_notified_at
//     narratives       kind TEXT NOT NULL
//   `CREATE TABLE IF NOT EXISTS` 对已存在的表不会重建，所以 schema.sql 里写的新列定义
//   对老库完全无效。后果是所有写入静默失败（异常被上层 catch 吞掉）：
//     实测真库：life_events.type 1074 行全 NULL、action_proposals.created_at 735 行全 NULL、
//     归档 6 行后再没长过、事件流按 type 查永远是空的。
//   这是 v13 装在本机之后「记忆不进、提取不出、队列只进不出」的总根源。
//
// 修法（不做破坏性迁移）：
//   1) 新 schema 的列 → 全部补齐
//   2) 老表独有的列 → 原样保留（作为可空列），一个字节都不丢
//   3) 同名列直接复制；语义等价的旧列单独映射（at→created_at、kind→event_type…）
//   4) 全程单事务，任何一步失败整表回滚，绝不留下半张表
//   5) 只在「确实写不进去」时才动，能写就不碰（幂等、可重复调用）

/** 老库时间列是 ISO 文本，新库是毫秒整数；typeof 判断，已回填的整数不会二次乘 1000 */
/** COALESCE 至少要两个参数，只有一个时直接用它；零个给 NULL */
const pick = (...xs) => {
  const v = xs.filter((x) => x && x !== 'NULL');
  if (!v.length) return 'NULL';
  if (v.length === 1) return v[0];
  return `COALESCE(${v.join(', ')})`;
};

const msOf = (col) =>
  `(CASE WHEN typeof("${col}")='text' ` +
  `THEN CAST(strftime('%s', replace(substr("${col}",1,19),'T',' ')) AS INTEGER) * 1000 ` +
  `ELSE "${col}" END)`;

/**
 * 每张表的重建配方。
 *  copy(has, ms) 里：
 *    has(name) → 源表有该列
 *    ms(name)  → 该列存在的毫秒表达式，不存在给 NULL
 */
const RECIPES = {
  // v11.1: (seq PK, at NOT NULL, kind NOT NULL, payload, delta, revision, applied_at, type, event_id, created_at)
  // v12+ : (event_id PK, revision, event_type, event_json, type, payload, created_at NOT NULL, applied_at)
  // 实测 1074 行：kind 有 7 种值、type 全 NULL、created_at 仅 611 行有值。
  life_events: {
    cols: [
      ['event_id', 'TEXT PRIMARY KEY'],
      ['revision', 'INTEGER'],
      ['event_type', 'TEXT'],
      ['event_json', 'TEXT'],
      ['type', 'TEXT'],
      ['payload', 'TEXT'],
      ['created_at', 'INTEGER NOT NULL'],
      ['applied_at', 'INTEGER'],
    ],
    keep: [['seq', 'INTEGER'], ['at', 'TEXT'], ['kind', 'TEXT'], ['delta', 'TEXT']],
    copy: (has, ms) => ({
      event_id: has('event_id')
        ? `COALESCE(NULLIF(event_id,''), 'v11-' || ${has('seq') ? 'seq' : 'rowid'})`
        : `'v11-' || ${has('seq') ? 'seq' : 'rowid'}`,
      revision: has('revision') ? 'revision' : '0',
      // 优先级：已有的 event_type 值 → v14 写过的 type → v11.1 的 kind。
      // 必须用 COALESCE 串起来而不是「有列就用列」：真库的 type 列存在但 1074 行全 NULL，
      // 直接取 type 会把 event_type 也写成 NULL，等于白搬。
      event_type: pick(has('event_type') ? 'event_type' : null, has('type') ? 'type' : null,
        has('kind') ? 'kind' : null),
      event_json: has('event_json') ? `COALESCE(event_json, ${has('payload') ? 'payload' : "'{}'"}, '{}')`
        : has('payload') ? 'payload' : "'{}'",
      type: pick(has('type') ? 'type' : null, has('kind') ? 'kind' : null),
      payload: has('payload') ? 'payload' : 'NULL',
      // created_at NOT NULL：新毫秒列 → 老的 at 文本 → 现在
      created_at: `COALESCE(${pick(has('created_at') ? 'created_at' : null, ms('at'))}, ${Date.now()})`,
      applied_at: ms('applied_at'),
      seq: has('seq') ? 'seq' : 'NULL',
      at: has('at') ? 'at' : 'NULL',
      kind: has('kind') ? 'kind' : 'NULL',
      delta: has('delta') ? 'delta' : 'NULL',
    }),
    verify: (db, before) => db.prepare('SELECT COUNT(*) AS n FROM life_events').get().n === before,
  },

  // v11.1: (id PK, at NOT NULL, kind, reason, utility, status, expires_at, detail, drop_reason,
  //          intent, say, why, evidence_id, expected_effect, risk, created_at, sent_at)
  // 实测 735 行 created_at 全 NULL；722 条 pending 靠 expires_at 判过期，绝不能丢。
  action_proposals: {
    cols: [
      ['id', 'TEXT PRIMARY KEY'],
      ['intent', 'TEXT'], ['say', 'TEXT'], ['why', 'TEXT'],
      ['evidence_id', 'INTEGER'], ['expected_effect', 'TEXT'], ['risk', "TEXT DEFAULT 'low'"],
      ['status', "TEXT DEFAULT 'queued'"],
      ['created_at', 'INTEGER'], ['sent_at', 'INTEGER'], ['drop_reason', 'TEXT'],
    ],
    keep: [['at', 'TEXT'], ['kind', 'TEXT'], ['reason', 'TEXT'], ['utility', 'REAL'],
      ['expires_at', 'TEXT'], ['detail', 'TEXT']],
    copy: (has, ms) => ({
      id: has('id') ? `COALESCE(NULLIF(id,''), 'p-v11-' || rowid)` : `'p-v11-' || rowid`,
      intent: has('intent') ? 'intent' : 'NULL',
      say: has('say') ? 'say' : 'NULL',
      why: has('why') ? 'why' : 'NULL',
      evidence_id: has('evidence_id') ? 'evidence_id' : 'NULL',
      expected_effect: has('expected_effect') ? 'expected_effect' : 'NULL',
      risk: has('risk') ? "COALESCE(risk,'low')" : "'low'",
      status: has('status') ? "COALESCE(status,'queued')" : "'queued'",
      // created_at 可由老 at 补；不补的话 735 条在 v14 里全算「没有创建时间」
      created_at: pick(has('created_at') ? 'created_at' : null, ms('at')),
      sent_at: ms('sent_at'),
      drop_reason: has('drop_reason') ? 'drop_reason' : 'NULL',
      at: has('at') ? 'at' : 'NULL',
      kind: has('kind') ? 'kind' : 'NULL',
      reason: has('reason') ? 'reason' : 'NULL',
      utility: has('utility') ? 'utility' : 'NULL',
      expires_at: has('expires_at') ? 'expires_at' : 'NULL',
      detail: has('detail') ? 'detail' : 'NULL',
    }),
    verify: (db, before) => db.prepare('SELECT COUNT(*) AS n FROM action_proposals').get().n === before,
  },

  // v11.1 把整行 JSON 存在 row_json（NOT NULL），新代码读 payload。两个都留，互不覆盖。
  memories_archive: {
    cols: [['id', 'TEXT'], ['archived_at', 'INTEGER'], ['reason', 'TEXT'], ['payload', 'TEXT']],
    keep: [['row_json', 'TEXT']],
    copy: (has, ms) => ({
      id: has('id') ? 'id' : 'NULL',
      archived_at: ms('archived_at'),
      reason: has('reason') ? 'reason' : 'NULL',
      payload: has('payload') ? `COALESCE(payload, ${has('row_json') ? 'row_json' : 'NULL'})`
        : has('row_json') ? 'row_json' : 'NULL',
      row_json: has('row_json') ? 'row_json' : 'NULL',
    }),
    verify: (db, before) => db.prepare('SELECT COUNT(*) AS n FROM memories_archive').get().n === before,
  },

  // v11.1: (id INTEGER PK AUTOINCREMENT, title NOT NULL, at TEXT, importance REAL DEFAULT 0.5, created_at TEXT NOT NULL)
  // v12+ : (id, scope NOT NULL, text, happened_at INTEGER, created_at INTEGER)
  milestones: {
    cols: [
      ['id', 'INTEGER PRIMARY KEY AUTOINCREMENT'],
      ['scope', "TEXT NOT NULL DEFAULT 'shared'"],
      ['text', 'TEXT'], ['happened_at', 'INTEGER'], ['created_at', 'INTEGER'],
    ],
    keep: [['title', 'TEXT'], ['at', 'TEXT'], ['importance', 'REAL']],
    copy: (has, ms) => ({
      id: has('id') ? 'id' : 'NULL',
      scope: has('scope') ? "COALESCE(scope,'shared')" : "'shared'",
      text: has('text') ? `COALESCE(text, ${has('title') ? 'title' : 'NULL'})`
        : has('title') ? 'title' : 'NULL',
      happened_at: pick(has('happened_at') ? 'happened_at' : null, ms('at')),
      created_at: ms('created_at'),
      title: has('title') ? 'title' : 'NULL',
      at: has('at') ? 'at' : 'NULL',
      importance: has('importance') ? 'importance' : 'NULL',
    }),
    verify: (db, before) => db.prepare('SELECT COUNT(*) AS n FROM milestones').get().n === before,
  },

  // v11.1: (id INTEGER PK AUTOINCREMENT, text NOT NULL, direction, due_at TEXT, status, memory_id, created_at TEXT NOT NULL)
  // v12+ : (id, scope NOT NULL, text, due_at INTEGER, status, created_at INTEGER, last_notified_at INTEGER)
  promises: {
    cols: [
      ['id', 'INTEGER PRIMARY KEY AUTOINCREMENT'],
      ['scope', "TEXT NOT NULL DEFAULT 'shared'"],
      ['text', 'TEXT'], ['due_at', 'INTEGER'], ['status', "TEXT DEFAULT 'pending'"],
      ['created_at', 'INTEGER'], ['last_notified_at', 'INTEGER'],
    ],
    keep: [['direction', 'TEXT'], ['memory_id', 'INTEGER']],
    copy: (has, ms) => ({
      id: has('id') ? 'id' : 'NULL',
      scope: has('scope') ? "COALESCE(scope,'shared')" : "'shared'",
      text: has('text') ? 'text' : 'NULL',
      due_at: ms('due_at'),
      status: has('status') ? "COALESCE(status,'pending')" : "'pending'",
      created_at: ms('created_at'),
      last_notified_at: has('last_notified_at') ? 'last_notified_at' : '0',
      direction: has('direction') ? 'direction' : 'NULL',
      memory_id: has('memory_id') ? 'memory_id' : 'NULL',
    }),
    verify: (db, before) => db.prepare('SELECT COUNT(*) AS n FROM promises').get().n === before,
  },

  // v11.1: (id INTEGER PK AUTOINCREMENT, period NOT NULL, kind NOT NULL, text NOT NULL,
  //          audit_status, created_at TEXT NOT NULL, scope, period_start, chars, injected_at)
  // 实测 0 行，但结构必须对齐，否则第一条日记就写不进去。
  narratives: {
    cols: [
      ['id', 'INTEGER PRIMARY KEY AUTOINCREMENT'],
      ['scope', "TEXT NOT NULL DEFAULT 'shared'"],
      ['period', 'TEXT'], ['kind', 'TEXT'],
      ['text', 'TEXT'], ['chars', 'INTEGER'], ['audit_status', "TEXT DEFAULT 'ok'"],
      ['period_start', 'INTEGER'], ['created_at', 'INTEGER'], ['injected_at', 'INTEGER'],
    ],
    keep: [],
    copy: (has, ms) => ({
      id: has('id') ? 'id' : 'NULL',
      scope: has('scope') ? "COALESCE(scope,'shared')" : "'shared'",
      period: has('period') ? 'period' : 'NULL',
      kind: has('kind') ? 'kind' : 'NULL',
      text: has('text') ? 'text' : 'NULL',
      chars: has('chars') ? 'chars' : 'NULL',
      audit_status: has('audit_status') ? "COALESCE(audit_status,'ok')" : "'ok'",
      period_start: ms('period_start'),
      created_at: ms('created_at'),
      injected_at: ms('injected_at'),
    }),
    verify: (db, before) => db.prepare('SELECT COUNT(*) AS n FROM narratives').get().n === before,
  },
};

const colsOfSafe = (db, t) => {
  try { return db.prepare(`PRAGMA table_info("${t}")`).all(); } catch { return []; }
};

/**
 * 判断某张表是否「按新列集写不进去」。
 * 判据（任一成立即需重建）：
 *   a) 新 schema 要的列缺失
 *   b) 存在 NOT NULL 且无默认值、且新代码 INSERT 不会提供的列
 * 只做静态判断，不试写（试写会污染库）。
 */
export function needsRelax(db, table, requiredByCode) {
  const info = colsOfSafe(db, table);
  if (!info.length) return false;
  const recipe = RECIPES[table];
  if (!recipe) return false;
  const have = new Set(info.map((c) => c.name));
  const missing = recipe.cols.filter(([n]) => !have.has(n)).map(([n]) => n);
  if (missing.length) return true;
  // 「代码会提供」必须严格用调用方给的清单，不能拿新 schema 全列兜底：
  // 新 schema 里有列（如 narratives.kind）是老表 NOT NULL、而代码根本不写的，
  // 拿全列兜底会漏判，实测 narratives 就是这么被跳过的、第一条日记写不进去。
  // 调用方没给清单时才退回新 schema 全列（保守：宁可不重建，也不误重建）。
  const provided = new Set(requiredByCode || recipe.cols.map(([n]) => n));
  return info.some((c) => c.notnull && c.dflt_value === null && Number(c.pk) === 0 && !provided.has(c.name));
}

/**
 * 单表重建。全程一个事务；任何异常（含 verify 失败）整表回滚，原表不受影响。
 * @returns {{rebuilt:boolean, rows?:number, reason?:string}}
 */
export function relaxTable(db, table, { now = Date.now() } = {}) {
  const recipe = RECIPES[table];
  if (!recipe) return { rebuilt: false, reason: 'no-recipe' };
  const info = colsOfSafe(db, table);
  if (!info.length) return { rebuilt: false, reason: 'no-table' };

  const have = new Set(info.map((c) => c.name));
  const has = (n) => have.has(n);
  const ms = (n) => (has(n) ? msOf(n) : 'NULL');

  const before = (() => {
    try { return db.prepare(`SELECT COUNT(*) AS n FROM "${table}"`).get().n; } catch { return 0; }
  })();

  const newCols = recipe.cols.map(([n, d]) => [n, d]);
  for (const [n, t] of recipe.keep) if (has(n) && !newCols.some(([x]) => x === n)) newCols.push([n, t]);

  // copy 返回「列名 → SQL 表达式」的对象。用对象而不是数组：
  //   keep 里的老列可能改成可空后仍与新列重名，数组按位置对齐极易错位（实测 12!=8）。
  let map;
  try { map = recipe.copy(has, ms); }
  catch (e) { return { rebuilt: false, reason: 'copy-build: ' + e.message }; }
  const missingExpr = newCols.filter(([n]) => !(n in map)).map(([n]) => n);
  if (missingExpr.length) {
    return { rebuilt: false, reason: `copy-missing ${missingExpr.join(',')}` };
  }
  const copyExpr = newCols.map(([n]) => map[n]);

  const tmp = `_relax_${table}`;
  db.exec('BEGIN IMMEDIATE');
  try {
    db.exec(`DROP TABLE IF EXISTS "${tmp}"`);
    db.exec(`CREATE TABLE "${tmp}" (${newCols.map(([n, d]) => `"${n}" ${d}`).join(', ')})`);

    // v14.1.2 真库副本实测（R-3/R-9 抓到）：老表把 event_id / id 当普通可空列，
    // 新 schema 把它们提升为 TEXT PRIMARY KEY。回滚增量转移后的真库里，
    // life_events 有 463 行 event_id 为 NULL，recipe 按 seq 补出的 'v11-<seq>'
    // 又与现存的 463 个 'v11-<N>' 非空值撞车 → INSERT 报
    // "UNIQUE constraint failed: _relax_life_events.event_id"，整表回滚；
    // 后面 tables.sql 建索引引用 event_type 直接崩（no such column: event_type）。
    // 做法：事务内先把 NULL/空/重复的主键原地补成「绝对唯一」值 = 前缀 || rowid：
    //   · 前缀取一个现存非空主键里不存在的候选，杜绝与既有值相撞；
    //   · rowid 天然唯一，重复组里只留 MIN(rowid) 一行，其余一并补值；
    //   · 已有非空且唯一的主键一个字节都不改（跨表引用安全）；
    //   · 整段在同一个事务里，失败随 ROLLBACK 一起回滚，原表不受影响。
    const pkCol = newCols.find(([, d]) =>
      /PRIMARY KEY/i.test(d) && !/AUTOINCREMENT/i.test(d) && /TEXT/i.test(d));
    if (pkCol) {
      const pk = pkCol[0];
      const options = ['relax-', 'v11fix-', 'legacy-', '__pk__'];
      let prefix = options.find((p) => !db.prepare(
        `SELECT 1 FROM "${table}" WHERE "${pk}" LIKE ? LIMIT 1`).get(p + '%'));
      if (!prefix) prefix = '__pk' + Date.now() + '-';
      // 确定性：先把要补值的 rowid 在 JS 里算好再逐条 UPDATE，
      // 不依赖 SQLite 对「UPDATE 里的 NOT IN 子查询是否物化」的实现细节。
      const rows = db.prepare(`SELECT rowid AS rid, "${pk}" AS v FROM "${table}"`).all();
      const seen = new Set();
      const fix = [];
      for (const r of rows) {
        const v = r.v;
        if (v === null || v === undefined || v === '') { fix.push(r.rid); continue; }
        const k = String(v);
        if (seen.has(k)) fix.push(r.rid);
        else seen.add(k);
      }
      if (fix.length) {
        const st = db.prepare(`UPDATE "${table}" SET "${pk}" = ? WHERE rowid = ?`);
        for (const rid of fix) st.run(prefix + rid, rid);
      }
    }

    db.exec(
      `INSERT INTO "${tmp}" (${newCols.map(([n]) => `"${n}"`).join(',')}) ` +
      `SELECT ${copyExpr.join(', ')} FROM "${table}"`
    );
    const after = db.prepare(`SELECT COUNT(*) AS n FROM "${tmp}"`).get().n;
    if (after !== before || !recipe.verify(db, before)) {
      throw new Error(`行数不一致：重建前 ${before}，重建后 ${after}`);
    }
    // 索引/触发器依赖原表，随 DROP 一并消失，重建后由 ensureV14Indexes 补回
    db.exec(`DROP TABLE "${table}"`);
    db.exec(`ALTER TABLE "${tmp}" RENAME TO "${table}"`);
    db.exec('COMMIT');
    return { rebuilt: true, rows: before, at: now };
  } catch (e) {
    try { db.exec('ROLLBACK'); } catch { /* ignore */ }
    try { db.exec(`DROP TABLE IF EXISTS "${tmp}"`); } catch { /* ignore */ }
    return { rebuilt: false, reason: e.message };
  }
}

/**
 * 入口：把所有「写不进去」的老表一次性修好。
 * @param db
 * @param opts.columnsByTable { [table]: string[] } 代码实际会 INSERT 的列，用来判断 NOT NULL 缺口
 */
export function relaxLegacyTables(db, { columnsByTable = {}, log = null } = {}) {
  const out = { checked: 0, rebuilt: [], skipped: [], failed: [] };
  for (const table of Object.keys(RECIPES)) {
    out.checked++;
    let need;
    try { need = needsRelax(db, table, columnsByTable[table]); }
    catch (e) { out.failed.push({ table, reason: e.message }); continue; }
    if (!need) { out.skipped.push(table); continue; }
    const r = relaxTable(db, table);
    if (r.rebuilt) {
      out.rebuilt.push({ table, rows: r.rows });
      log?.info?.(`[dsh-life] 老库表结构已宽松化：${table}（${r.rows} 行原样保留）`);
    } else {
      out.failed.push({ table, reason: r.reason });
      log?.warn?.(`[dsh-life] 表结构宽松化失败：${table} — ${r.reason}`);
    }
  }
  return out;
}

/** 供测试与诊断：报告每张表当前是否需要重建 */
export function diagnoseLegacyShape(db, { columnsByTable = {} } = {}) {
  const rows = [];
  for (const table of Object.keys(RECIPES)) {
    const info = colsOfSafe(db, table);
    if (!info.length) { rows.push({ table, present: false, needsRelax: false }); continue; }
    const have = new Set(info.map((c) => c.name));
    const recipe = RECIPES[table];
    const missing = recipe.cols.filter(([n]) => !have.has(n)).map(([n]) => n);
    const provided = new Set(columnsByTable[table] || recipe.cols.map(([n]) => n));
    const notNullGap = info
      .filter((c) => c.notnull && c.dflt_value === null && Number(c.pk) === 0 && !provided.has(c.name))
      .map((c) => c.name);
    rows.push({
      table, present: true,
      rows: db.prepare(`SELECT COUNT(*) AS n FROM "${table}"`).get().n,
      missing, notNullGap,
      needsRelax: missing.length > 0 || notNullGap.length > 0,
    });
  }
  return rows;
}
