// Optional schema changes that need an explicit DSH decision. Nothing in this
// module runs automatically from plugin startup.
import { SCHEMA_VERSION } from './config.mjs';
export function inspectEdgesBasis(db) {
  const cols = db.prepare('PRAGMA table_info(edges)').all().map((row) => row.name);
  if (!cols.length) return { ok: false, reason: 'edges-table-missing', hasBasis: false };
  return { ok: true, hasBasis: cols.includes('basis'), columns: cols };
}

export function migrateEdgesBasis(db, { apply = false, now = Date.now() } = {}) {
  const before = inspectEdgesBasis(db);
  if (!before.ok) return { ...before, applied: false };
  if (before.hasBasis) return { ok: true, applied: false, alreadyPresent: true };
  if (!apply) return { ok: true, applied: false, wouldAdd: true };

  db.exec('BEGIN IMMEDIATE');
  try {
    db.exec('ALTER TABLE edges ADD COLUMN basis TEXT');
    try { db.exec(`PRAGMA user_version = ${SCHEMA_VERSION}`); } catch { /* optional compatibility */ }
    try {
      db.prepare(
        'INSERT INTO kv(k,v,updated_at) VALUES(?,?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v, updated_at=excluded.updated_at'
      ).run('schema_version', String(SCHEMA_VERSION), now);
    } catch { /* old/minimal test databases may not have kv */ }
    db.exec('COMMIT');
    return { ok: true, applied: true, schemaVersion: SCHEMA_VERSION };
  } catch (e) {
    try { db.exec('ROLLBACK'); } catch { /* ignore */ }
    return { ok: false, applied: false, reason: 'migration-failed', message: e.message };
  }
}
