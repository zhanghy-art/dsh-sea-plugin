// src/kit/paths.mjs - cross-platform home-directory resolution
import os from 'node:os';
import path from 'node:path';

/** DSH can run with HOME unset on Windows. Never turn that into a literal "undefined" path. */
export function homeDir() {
  const candidates = [
    os.homedir(),
    process.env.USERPROFILE,
    process.env.HOME,
    process.env.HOMEDRIVE && process.env.HOMEPATH
      ? process.env.HOMEDRIVE + process.env.HOMEPATH
      : '',
  ];
  for (const candidate of candidates) {
    const value = String(candidate || '').trim();
    if (value && value !== 'undefined' && path.isAbsolute(value)) return value;
  }
  return process.cwd();
}

export function lifeDir(...parts) {
  return path.join(homeDir(), '.dsh', 'dsh-life', ...parts);
}
