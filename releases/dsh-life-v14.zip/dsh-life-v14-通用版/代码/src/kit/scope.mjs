// src/kit/scope.mjs — 作用域（v13.0 新增）
// 解决的问题：
//   v11.1 旧库的 scope 编码是 private:<qq> / group:<id> / shared:<qq> / global:<bot>，
//   而 v12.x 代码把默认值写死成 'chat:private'。
//   在旧库上，这个默认值匹配不到任何一行 —— 检索永远空、写入永远落进一个新造的假 scope。
//   （codex v13.2 实测：ima 包在 5003 行旧库上 recall@10 = 0）
// 裁定（融合指南 3.2 / 4.1）：
//   - 不改写旧库里的 scope 值（旧数据逐行不变）
//   - 所有召回 SQL 必须先过 scope 约束，且约束用「当前 scope + shared 家族」拼出来
//   - 任何没传 scope 的调用都不得默认成私人 scope（宁可查不到，也不可跨会话泄漏）
export const SHARED = 'shared';
export const GLOBAL = 'global';

export const isPrivate = (s) => String(s || '').startsWith('private:') || s === 'chat:private';
export const isGroup = (s) => String(s || '').startsWith('group:') || s === 'chat:group';
export const isShared = (s) => String(s || '') === SHARED || String(s || '').startsWith('shared:');

/**
 * 把任意来源的 scope 归一到 v11.1 的编码。
 * @returns {string} private:<qq> | group:<id> | shared | shared:<qq> | global
 */
export function normalizeScope(input, { ownerQq = null, groupId = null } = {}) {
  const raw = String(input ?? '').trim();
  if (!raw) {
    if (groupId) return `group:${groupId}`;
    if (ownerQq) return `private:${ownerQq}`;
    return 'private:owner';
  }
  if (raw === 'chat:private' || raw === 'private' || raw === 'solo' || raw === 'private:') {
    return ownerQq ? `private:${ownerQq}` : 'private:owner';
  }
  if (raw === 'chat:group' || raw === 'group' || raw === 'group:') {
    return groupId ? `group:${groupId}` : 'group:unknown';
  }
  if (raw === SHARED || raw === 'chat:shared') return SHARED;
  if (raw === GLOBAL || raw.startsWith('global:') || raw === 'chat:global') return raw;
  return raw;
}

/**
 * 可见集：当前 scope + shared 家族。
 * 返回的数组里，以 '%' 结尾的项按 LIKE 处理，其余是精确匹配。
 * 私聊只能看见自己的 private + shared；群聊只能看见本群 + shared。
 */
export function visibleScopes(scope, { ownerQq = null, groupId = null } = {}) {
  const cur = normalizeScope(scope, { ownerQq, groupId });
  if (isShared(cur)) return [SHARED, 'shared:%'];
  if (cur.startsWith(GLOBAL)) return [cur, SHARED, 'shared:%'];
  // v11.1 单用户模式的旧数据 scope 全是 'solo'（实测本机 339 条 100% 是 solo）。
  // 不把 'solo' 放进本人私聊的可见集，升级后就会「记忆都在、一条也搜不到」。
  // 安全边界：只有「当前私聊就是 owner」时才并入 ——
  //   · 配了 ownerQq：必须等于它；
  //   · 没配 ownerQq（单用户部署的常态）：视当前私聊为 owner。
  if (isPrivate(cur)) {
    const qq = cur.slice('private:'.length);
    if (!ownerQq || String(qq) === String(ownerQq)) return [cur, 'solo', SHARED, 'shared:%'];
  }
  return [cur, SHARED, 'shared:%'];
}

/**
 * 生成 scope 约束 SQL 片段与参数。
 * @param {string[]} scopes visibleScopes() 的返回值
 * @returns {{sql:string, params:any[]}}
 */
export function scopeClause(scopes) {
  const exact = [];
  const likes = [];
  for (const s of scopes || []) {
    if (s == null || s === '') continue;
    if (String(s).endsWith('%')) likes.push(s);
    else exact.push(s);
  }
  const parts = [];
  const params = [];
  if (exact.length) {
    parts.push(`scope IN (${exact.map(() => '?').join(',')})`);
    params.push(...exact);
  }
  for (const l of likes) {
    parts.push('scope LIKE ?');
    params.push(l);
  }
  // 没有可用 scope：永远为假。这不是保守，是正确 —— 没有身份就不该读到任何人的记忆。
  if (!parts.length) return { sql: '1=0', params: [] };
  return { sql: '(' + parts.join(' OR ') + ')', params };
}

/** 某条记录是否属于当前可见集（内存态判断用） */
export function scopeVisible(recordScope, scope, opts = {}) {
  const scopes = visibleScopes(scope, opts);
  const s = String(recordScope || '');
  for (const v of scopes) {
    if (String(v).endsWith('%')) {
      if (s.startsWith(String(v).slice(0, -1))) return true;
    } else if (s === v) return true;
  }
  return false;
}
