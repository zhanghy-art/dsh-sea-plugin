// Three-state shadow support: execute the real path inside a savepoint, always
// roll it back, then append a compact audit event. Shadow is not a second code path.
export function shadowLog(db, cap, payload, now = Date.now()) {
  try {
    const id = 'sh_' + now.toString(36) + '_' + Math.random().toString(36).slice(2, 8);
    const body = JSON.stringify(payload ?? {}).slice(0, 4000);
    db.prepare(
      'INSERT INTO life_events(event_id, revision, event_type, event_json, type, payload, created_at, applied_at) ' +
      'VALUES(?,?,?,?,?,?,?,NULL)'
    ).run(id, 0, 'shadow:' + cap, body, 'shadow:' + cap, body, now);
    return true;
  } catch { return false; }
}

export function inShadow(db, cap, fn, now = Date.now()) {
  let out;
  let ok = false;
  let err = null;
  try {
    db.exec('SAVEPOINT v14_shadow');
    try {
      out = fn();
      ok = true;
    } finally {
      try { db.exec('ROLLBACK TO v14_shadow'); } catch { /* ignore */ }
      try { db.exec('RELEASE v14_shadow'); } catch { /* ignore */ }
    }
  } catch (e) {
    err = String((e && e.message) || e);
    try { db.exec('ROLLBACK TO v14_shadow'); } catch { /* ignore */ }
    try { db.exec('RELEASE v14_shadow'); } catch { /* ignore */ }
  }
  shadowLog(db, cap, { ok, would: ok ? out : null, error: err }, now);
  return { ok, shadow: true, would: out, error: err };
}
