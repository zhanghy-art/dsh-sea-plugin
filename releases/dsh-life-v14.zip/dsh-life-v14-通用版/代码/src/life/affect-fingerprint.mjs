// src/life/affect-fingerprint.mjs — 记忆条目的「情感指纹」（v14 P1）
// 借鉴 dsh-emotion-memory 0.1.0：写入时记录编码时刻的 PAD 与主导情绪，被想起时再巩固（系数 0.15）。
// 关键取舍：PAD 只作**记忆条目的编码标记**，绝不成为第二套运行时情绪状态。
// 状态核仍是 v13 四激素 + needs 六维；这里只是把当前状态的一个快照压进 memories.anchor_ground JSON。
// 铁律：再巩固只更新 anchor_ground，绝不改写 fact 正文、不进 effWeight、不改 belief。
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, Number(v) || 0));

/** 从 v13 四激素折出一个 0–1 的 PAD 快照（−1…1 语义压缩到 0…1 便于存储） */
export function padFromHormones(h = {}) {
  const cortisol = clamp(h.cortisol ?? 0.30, 0, 1);
  const dopamine = clamp(h.dopamine ?? 0.50, 0, 1);
  const oxytocin = clamp(h.oxytocin ?? 0.40, 0, 1);
  const serotonin = clamp(h.serotonin ?? 0.60, 0, 1);
  const P = clamp(0.5 + 0.30 * (dopamine - 0.5) + 0.20 * (serotonin - 0.6) - 0.25 * (cortisol - 0.3), 0, 1);
  const A = clamp(0.45 + 0.35 * (cortisol - 0.3) + 0.20 * (dopamine - 0.5), 0, 1);
  const D = clamp(0.5 + 0.35 * (serotonin - 0.6) - 0.20 * (cortisol - 0.3), 0, 1);
  return { P: Number(P.toFixed(3)), A: Number(A.toFixed(3)), D: Number(D.toFixed(3)) };
}

export function dominantWord(pad) {
  if (pad.P >= 0.65 && pad.A >= 0.6) return '开心';
  if (pad.P <= 0.35 && pad.A >= 0.6) return '绷着';
  if (pad.P <= 0.35 && pad.A < 0.45) return '低落';
  if (pad.P >= 0.6 && pad.D >= 0.6) return '安心';
  return '平常';
}

/** Prefer the appraised runtime PAD; fall back to the v13 hormone projection. */
export function padFromState(state = {}) {
  const pad = state?.affect?.pad;
  if (pad && [pad.P, pad.A, pad.D].every((v) => Number.isFinite(Number(v)))) {
    return {
      P: clamp(pad.P, 0, 1),
      A: clamp(pad.A, 0, 1),
      D: clamp(pad.D, 0, 1),
    };
  }
  return padFromHormones(state?.hormones || {});
}

/** 写入时用：产出 anchor_ground 增量 + 可直接填进已有 7 列的值 */
export function makeFingerprint(state = {}, { now = Date.now(), salience = null } = {}) {
  const pad = padFromState(state);
  const word = dominantWord(pad);
  const sig = salience == null
    ? Math.min(1, Math.max(0.15, (Math.abs(pad.A - 0.5) + Math.abs(pad.P - 0.5))))
    : clamp(salience, 0, 1);
  return {
    affect: { ...pad, word, salience: Number(sig.toFixed(3)), at: now },
    words: [word],
    emotion_intensity: Number(sig.toFixed(3)),
  };
}

/** 把指纹合进写入 input（不覆盖已有 anchor_ground 的其他键） */
export function attachFingerprint(input, state, { now = Date.now() } = {}) {
  const fp = makeFingerprint(state, { now });
  let ag = {};
  if (input.anchor_ground) {
    try { ag = typeof input.anchor_ground === 'string' ? JSON.parse(input.anchor_ground) : { ...input.anchor_ground }; }
    catch { ag = {}; }
  }
  return {
    ...input,
    anchor_ground: { ...ag, affect: fp.affect },
    emotion: input.emotion ?? (fp.affect.P < 0.4 ? 'negative' : fp.affect.P > 0.62 ? 'positive' : 'neutral'),
    bot_feeling: input.bot_feeling ?? fp.words[0],
    bot_feeling_intensity: input.bot_feeling_intensity ?? fp.emotion_intensity,
  };
}

/**
 * 被想起时再巩固：用当前状态微调指纹，保留编码时的词，另记「最近想起时的情绪」。
 * 只 UPDATE anchor_ground；fact / importance / belief 一律不碰。
 * @returns {{updated:number, skipped:number}}
 */
export function reconsolidate(db, items, state, { coef = 0.15, now = Date.now() } = {}) {
  if (!db || !Array.isArray(items) || !items.length) return { updated: 0, skipped: 0 };
  let updated = 0, skipped = 0;
  const cur = padFromState(state);
  let st;
  try { st = db.prepare('UPDATE memories SET anchor_ground = ? WHERE id = ?'); } catch { return { updated: 0, skipped: items.length }; }
  const get = db.prepare('SELECT id, anchor_ground FROM memories WHERE id = ?');
  for (const it of items) {
    const id = it?.mem?.id ?? it?.id;
    if (id == null) { skipped++; continue; }
    let row;
    try { row = get.get(id); } catch { skipped++; continue; }
    if (!row) { skipped++; continue; }
    let ag = {};
    try { ag = row.anchor_ground ? JSON.parse(row.anchor_ground) : {}; } catch { ag = {}; }
    const old = ag.affect;
    if (!old || typeof old !== 'object') { skipped++; continue; }
    const mix = (a, b) => Number((a * (1 - coef) + b * coef).toFixed(3));
    ag.affect = {
      ...old,
      P: mix(old.P ?? cur.P, cur.P), A: mix(old.A ?? cur.A, cur.A), D: mix(old.D ?? cur.D, cur.D),
      lastRecalledWord: dominantWord(cur),
      lastRecalledAt: now,
      hits: Number(old.hits || 0) + 1,
    };
    try { st.run(JSON.stringify(ag), id); updated++; } catch { skipped++; }
  }
  return { updated, skipped };
}

/** 心境一致度（0–1），供 rerank 的 ≤0.05 偏置使用 */
export function moodCongruence(anchorGround, state) {
  if (!anchorGround) return 0;
  let ag = anchorGround;
  if (typeof ag === 'string') { try { ag = JSON.parse(ag); } catch { return 0; } }
  if (!ag?.affect || !Number.isFinite(Number(ag.affect.P))) return 0;
  const cur = padFromState(state);
  return Number((1 - Math.min(1, Math.abs(Number(ag.affect.P) - cur.P))).toFixed(3));
}
