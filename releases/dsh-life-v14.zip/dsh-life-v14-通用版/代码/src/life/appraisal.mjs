// Structured appraisal: event -> explainable state delta.
// The model never writes numbers directly. Rules produce a small proposal, then the
// scheduler clamps and applies it through the existing LifeState.
import { DEFAULTS } from '../kit/config.mjs';
import { detectImmediate, clampDelta } from './lexicon.mjs';
import { padFromHormones, dominantWord } from './affect-fingerprint.mjs';

const clamp01 = (v) => Math.max(0, Math.min(1, Number(v) || 0));

function eventClass(matches = []) {
  if (matches.includes('scold')) return 'conflict';
  if (matches.includes('apology')) return 'repair';
  if (matches.includes('affection')) return 'affection';
  if (matches.includes('praise')) return 'praise';
  if (matches.includes('vulnerable')) return 'care';
  if (matches.includes('dismissive')) return 'distance';
  if (matches.includes('insomnia')) return 'late-night';
  return 'ordinary';
}

/**
 * Appraise one user event. The output is intentionally low-dimensional and
 * explainable; numerical coordinates are derived locally, not guessed by the model.
 */
export function appraiseEvent(text, {
  state = null,
  now = Date.now(),
  gapMs = 0,
  maxNudge = 0.03,
} = {}) {
  const immediate = detectImmediate(text, { gapMs, now, maxNudge });
  if (!immediate) {
    return {
      version: 1,
      eventClass: 'ordinary',
      confidence: 0.2,
      matched: [],
      delta: {},
      needsDelta: {},
      dimensions: {
        goalCongruence: 0.5,
        novelty: 0.1,
        control: 0.5,
        certainty: 0.5,
        socialSignificance: 0,
        valence: 0,
        arousal: 0,
      },
      source: 'rule-v1',
    };
  }

  const kind = eventClass(immediate.matched);
  const d = clampDelta(immediate.delta, maxNudge);
  const positive = Number(d.dopamine || 0) + Number(d.oxytocin || 0) + Number(d.serotonin || 0) > Number(d.cortisol || 0);
  const negative = Number(d.cortisol || 0) > Number(d.dopamine || 0) + Number(d.oxytocin || 0) + Number(d.serotonin || 0);
  const intensity = clamp01(Object.values(d).reduce((n, v) => n + Math.abs(Number(v) || 0), 0) / Math.max(0.001, maxNudge * 4));
  const needsDelta = {};
  if (kind === 'affection' || kind === 'care' || kind === 'repair') {
    needsDelta.social = 0.02;
    needsDelta.closeness = 0.02;
    needsDelta.mood = 0.01;
  }
  if (kind === 'conflict' || kind === 'distance') {
    needsDelta.social = -0.015;
    needsDelta.mood = -0.02;
  }

  return {
    version: 1,
    eventClass: kind,
    confidence: 0.68,
    matched: immediate.matched,
    delta: d,
    needsDelta,
    dimensions: {
      goalCongruence: positive ? 0.7 : negative ? 0.30 : 0.5,
      novelty: kind === 'ordinary' ? 0.2 : 0.45,
      control: kind === 'conflict' ? 0.35 : 0.55,
      certainty: 0.65,
      socialSignificance: ['affection', 'care', 'conflict', 'repair'].includes(kind) ? 0.8 : 0.4,
      valence: positive ? intensity : negative ? -intensity : 0,
      arousal: ['conflict', 'praise', 'affection'].includes(kind) ? 0.65 : 0.45,
    },
    source: 'rule-v1',
    stateBefore: state ? {
      hormones: { ...(state.hormones || {}) },
      pad: state.affect?.pad || padFromHormones(state.hormones || {}),
    } : null,
    at: now,
  };
}

/** Apply one appraisal under the same clamp/floor/cap regime as LifeState. */
export function applyAppraisal(state, appraisal, cfg = DEFAULTS, { maxNudge = 0.03 } = {}) {
  if (!state || !appraisal) return { changed: false };
  const oldPad = state.affect?.pad || padFromHormones(state.hormones || {});
  const d = clampDelta(appraisal.delta || {}, maxNudge);
  const before = { ...(state.hormones || {}) };

  for (const [k, v] of Object.entries(d)) {
    state.hormones[k] = Math.max(
      cfg.hormone?.floor?.[k] ?? 0,
      Math.min(cfg.hormone?.cap ?? 0.97, Number(state.hormones[k] ?? cfg.hormone?.init?.[k] ?? 0.5) + Number(v || 0)),
    );
  }

  for (const [k, v] of Object.entries(appraisal.needsDelta || {})) {
    if (typeof state.needs?.[k] !== 'number') continue;
    state.needs[k] = clamp01(state.needs[k] + Number(v || 0));
  }

  const dims = appraisal.dimensions || {};
  const a = Number(dims.arousal || 0);
  const v = Number(dims.valence || 0);
  state.affect = {
    ...(state.affect || {}),
    pad: {
      P: Number(Math.max(0, Math.min(1, Number(oldPad.P ?? 0.5) + v * 0.12)).toFixed(3)),
      A: Number(Math.max(0, Math.min(1, Number(oldPad.A ?? 0.5) + a * 0.08)).toFixed(3)),
      D: Number(Math.max(0, Math.min(1, Number(oldPad.D ?? 0.5) + (positiveControl(appraisal) ? 0.04 : -0.03))).toFixed(3)),
    },
    eventClass: appraisal.eventClass || 'ordinary',
    dominant: dominantWord({
      P: Number(oldPad.P ?? 0.5) + v * 0.12,
      A: Number(oldPad.A ?? 0.5) + a * 0.08,
      D: Number(oldPad.D ?? 0.5),
    }),
    confidence: Number(appraisal.confidence || 0),
    lastEventAt: Number(appraisal.at || Date.now()),
  };

  return {
    changed: [...Object.keys(d), ...Object.keys(appraisal.needsDelta || {})].length > 0,
    before,
    after: { ...(state.hormones || {}) },
    pad: state.affect.pad,
  };
}

function positiveControl(appraisal) {
  const d = appraisal.delta || {};
  return Number(d.dopamine || 0) + Number(d.serotonin || 0) >= Number(d.cortisol || 0);
}

/** Persist the immutable appraisal record. life_events keeps zero-DDL compatibility. */
export function recordAppraisal(db, appraisal, {
  scope = 'shared',
  turnId = null,
  source = 'user',
  now = Date.now(),
  applied = null,
  clampHit = [],
} = {}) {
  if (!db || !appraisal) return { ok: false, reason: 'empty' };
  const id = `appraisal:${now}:${Math.random().toString(36).slice(2, 8)}`;
  try {
    const payload = {
      scope, turnId, source, appraisal,
      applied: applied || null,
      clampHit: Array.isArray(clampHit) ? clampHit : [],
    };
    db.prepare(
      'INSERT INTO life_events(event_id,revision,event_type,event_json,type,payload,created_at,applied_at) ' +
      'VALUES(?,?,?,?,?,?,?,?)'
    ).run(
      id, 0, 'appraisal', JSON.stringify(payload),
      'appraisal', JSON.stringify(payload), now, now,
    );
    return { ok: true, id };
  } catch {
    return { ok: false, reason: 'log-failed' };
  }
}

export function recentAppraisals(db, { scope = null, limit = 20 } = {}) {
  let rows = [];
  try {
    rows = db.prepare(
      "SELECT event_json, created_at FROM life_events WHERE event_type='appraisal' ORDER BY created_at DESC LIMIT ?"
    ).all(limit);
  } catch { return []; }
  return rows
    .map((r) => {
      try {
        const parsed = JSON.parse(r.event_json);
        return { ...parsed, createdAt: r.created_at };
      } catch { return null; }
    })
    .filter(Boolean)
    .filter((x) => !scope || x.scope === scope);
}
