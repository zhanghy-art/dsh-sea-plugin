// Real elapsed-time settlement for v14.
// v13 called sleep settlement with a literal 15 minutes, so an eight-hour lid-close
// recovered only one tick. This module advances the persisted state in bounded segments.
import { settleStages } from './sleep-stage.mjs';
import { lifeTick } from './life-state.mjs';

const MINUTE = 60000;

export function elapsedMinutes(state, now = Date.now(), {
  defaultMinutes = 15,
  maxCatchUpHours = 72,
} = {}) {
  const last = Number(state?.counters?.lastTickAt || 0);
  if (!last) return { rawMinutes: defaultMinutes, minutes: defaultMinutes, capped: false, from: now - defaultMinutes * MINUTE };
  const raw = Math.max(0, (now - last) / MINUTE);
  const max = Math.max(15, Number(maxCatchUpHours) * 60);
  return {
    rawMinutes: raw,
    minutes: Math.min(raw, max),
    capped: raw > max,
    from: last,
  };
}

/**
 * Advance v14-managed state without calling the legacy settleLifecycle path.
 * Energy is owned only by settleStages; lifeTick is told not to touch energy.
 */
export function advanceV14(state, {
  now = Date.now(),
  minutes = 15,
  cfg,
  db = null,
  dreamEnabled = true,
  hormoneOpts = {},
  stepMinutes = 30,
  scope = null,
} = {}) {
  const total = Math.max(0, Number(minutes) || 0);
  const step = Math.max(5, Math.min(120, Number(stepMinutes) || 30));
  if (total <= 0) return { state, dreams: [], segments: 0, wokeFrom: [] };

  let cursor = now - total * MINUTE;
  let remaining = total;
  let next = state;
  const dreams = [];
  const wokeFrom = [];
  let segments = 0;

  while (remaining > 0.001) {
    const part = Math.min(step, remaining);
    cursor += part * MINUTE;
    const staged = settleStages(next, {
      now: cursor,
      minutes: part,
      cfg,
      db,
      dreamEnabled,
      scope,
    });
    next = staged.state;
    if (staged.dream) dreams.push(staged.dream);
    if (staged.wokeFrom) wokeFrom.push(staged.wokeFrom);
    next = lifeTick(next, part, cursor, cfg, {
      ...hormoneOpts,
      manageEnergy: false,
    });
    remaining -= part;
    segments++;
  }

  next.counters = next.counters || {};
  next.counters.lastTickAt = now;
  next.flags = next.flags || {};
  if (total >= 8 * 60) next.flags.longAbsence = true;
  return { state: next, dreams, segments, wokeFrom };
}
