// Persistent delivery queue used while the character is asleep.
// The plugin never claims a message was sent; it only exposes what a host may deliver.
const DEFAULT_MAX = 20;

function ensure(state) {
  state.sleep = state.sleep && typeof state.sleep === 'object' ? state.sleep : {};
  state.sleep.pendingDeliveries = Array.isArray(state.sleep.pendingDeliveries)
    ? state.sleep.pendingDeliveries
    : [];
  return state.sleep.pendingDeliveries;
}

export function isSleeping(state) {
  const stage = String(state?.sleep?.stage || 'awake');
  return stage !== 'awake';
}

export function queueDelivery(state, payload = {}, {
  now = Date.now(),
  max = DEFAULT_MAX,
} = {}) {
  const list = ensure(state);
  const text = String(payload.text || payload.say || '').trim();
  if (!text) return { ok: false, reason: 'empty' };
  const dedup = list.some((x) => x.text === text && now - Number(x.at || 0) < 6 * 3600000);
  if (dedup) return { ok: false, reason: 'duplicate' };
  const item = {
    id: `delivery:${now}:${Math.random().toString(36).slice(2, 8)}`,
    text,
    kind: payload.kind || 'reply',
    scope: payload.scope || null,
    proposalId: payload.proposalId || null,
    urgent: payload.urgent === true,
    at: now,
    status: 'pending',
  };
  list.push(item);
  while (list.length > Math.max(1, Number(max) || DEFAULT_MAX)) list.shift();
  return { ok: true, item, pending: list.length };
}

export function pollDeliveries(state, {
  now = Date.now(),
  limit = 5,
  includeUrgentWhileAsleep = false,
} = {}) {
  const list = ensure(state);
  if (isSleeping(state) && !includeUrgentWhileAsleep) {
    return { sleeping: true, items: [], total: list.filter((x) => x.status === 'pending').length };
  }
  const items = list
    .filter((x) => x.status === 'pending')
    .sort((a, b) => Number(b.urgent) - Number(a.urgent) || a.at - b.at)
    .slice(0, Math.max(1, Number(limit) || 5))
    .map((x) => ({ ...x, offeredAt: now, status: 'offered' }));
  const offered = new Map(items.map((x) => [x.id, x]));
  for (let i = 0; i < list.length; i++) {
    if (offered.has(list[i].id)) list[i] = offered.get(list[i].id);
  }
  return { sleeping: false, items, total: list.filter((x) => x.status === 'pending').length };
}

export function ackDeliveries(state, ids = [], { now = Date.now() } = {}) {
  const wanted = new Set((Array.isArray(ids) ? ids : [ids]).map(String));
  const list = ensure(state);
  let acked = 0;
  for (const item of list) {
    if (wanted.has(String(item.id)) && item.status !== 'acked') {
      item.status = 'acked';
      item.ackedAt = now;
      acked++;
    }
  }
  state.sleep.pendingDeliveries = list.filter((x) => x.status !== 'acked').slice(-DEFAULT_MAX);
  return { ok: true, acked, pending: state.sleep.pendingDeliveries.length };
}

export function pendingDeliveryCount(state) {
  return ensure(state).filter((x) => x.status === 'pending').length;
}

/**
 * 睡着时收到消息怎么处理（v14：三级，不再一律排队）。
 * - 'reply-short'：主人私聊 + 命中紧急词 → 允许回一句极短
 * - 'queue'      ：主人私聊、不紧急 → 排队，醒了再说
 * - 'drop'       ：群聊 / 非主人私聊 → 直接丢，不占队列
 */
export function classifySleepReply({ userText = '', scope = '', ownerQq = null, cfg = {} } = {}) {
  const s = String(scope || '');
  const isGroup = s.startsWith('group:') || s === 'chat:group';
  const owner = ownerQq == null ? null : String(ownerQq);
  const isOwnerPrivate = !isGroup && (owner ? s === `private:${owner}` : s.startsWith('private:'));
  if (isGroup || !isOwnerPrivate) return 'drop';
  const words = cfg?.sleep?.urgentWords || [];
  const text = String(userText || '');
  if (words.some((w) => w && text.includes(String(w)))) return 'reply-short';
  return 'queue';
}

export function sleepShortReply(cfg = {}) {
  return String(cfg?.sleep?.shortReply || '睡了，明早说');
}
