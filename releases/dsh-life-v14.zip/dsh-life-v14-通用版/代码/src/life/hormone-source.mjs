// src/life/hormone-source.mjs — 让四激素由「真实数据」驱动，而不是时间函数
// v14 P0：修 v13.0 的 D1/D2 死链（lifeTick 传 stepHormones(s.hormones, {}, ...)）。
// 设计：每次心跳用六路 SQL 从既有表聚合出目标值，激素向目标收敛而非向固定基线回归。
// 每个信号带 basis（计数 / 归一值 / 命中的记忆 id），面板可回答「这个数从哪几行算出来的」。
// 没有数据 = 没有信号 = 贴着基线，不编造波动。
// 铁律：只产出 targets，不写 memories、不进 effWeight、不改可信度；写入口仍是 life-state.mjs。
import { DEFAULTS } from '../kit/config.mjs';

export const clamp01 = (v) => Math.max(0, Math.min(1, Number(v) || 0));

const all = (db, sql, ...args) => { try { return db.prepare(sql).all(...args); } catch { return []; } };
const get = (db, sql, ...args) => { try { return db.prepare(sql).get(...args) || {}; } catch { return {}; } };

const isNeg = (e) => ['negative', 'sad', 'anger', 'fear', 'sadness', 'anxious', '委屈', '难过', '生气', '害怕'].includes(String(e || '').toLowerCase());
const isPos = (e) => ['positive', 'joy', 'happy', 'calm', 'love', '开心', '高兴', '安心', '感动'].includes(String(e || '').toLowerCase());
const msOf = (r, k) => Number(r?.[k + '_ms'] ?? r?.[k]) || 0;

/**
 * 六路信号源 → 四激素目标值 + 可归因 basis。
 * @returns {{targets:object, basis:object, source:'data-driven'|'baseline-decay'}}
 */
export function hormoneTargets(db, state = {}, { cfg = DEFAULTS, now = Date.now(), scanLimit = 240 } = {}) {
  const init = cfg.hormone.init;
  const soc = state?.social || {};
  const HOUR = 3600000;

  // 1) 情绪记忆：按新鲜度衰减累加负荷（情绪 7 天半衰、关系/成就 90 天半衰）
  const rows = all(db,
    'SELECT * FROM memories WHERE invalid_reason IS NULL AND cold = 0 ' +
    'ORDER BY COALESCE(confirmed_at_ms, created_at_ms) DESC LIMIT ?', scanLimit);
  let negLoad = 0, rumLoad = 0, posLoad = 0, relLoad = 0, impLoad = 0;
  const negIds = [], posIds = [], relIds = [];
  for (const r of rows) {
    const t = msOf(r, 'confirmed_at') || msOf(r, 'created_at') || now;
    const ageD = Math.max(0, (now - t) / 86400000);
    const fShort = Math.pow(0.5, ageD / 7);
    const fLong = Math.pow(0.5, ageD / 90);
    const es = clamp01(r.emotional_salience);
    const rc = Number(r.recall_count ?? 0);
    const neg = isNeg(r.emotion), pos = isPos(r.emotion);
    if (neg && es > 0) { negLoad += es * fShort; if (negIds.length < 8) negIds.push(r.id); }
    if (neg && es > 0 && rc >= 6) rumLoad += es * fShort;   // 反刍：与 weight.mjs recall>=6 同口径
    if (pos && es > 0) { posLoad += es * fShort; if (posIds.length < 8) posIds.push(r.id); }
    const rs = clamp01(r.relationship_salience);
    if (rs > 0) { relLoad += rs * fLong; if (relIds.length < 8) relIds.push(r.id); }
    const im = clamp01(r.importance);
    if (im >= 0.7) impLoad += im * fLong;
  }
  // 饱和而非放大：约 3 条封顶
  const nNeg = clamp01(negLoad / 3), nRum = clamp01(rumLoad / 3), nPos = clamp01(posLoad / 3);
  const nRel = clamp01(relLoad / 3), nImp = clamp01(impLoad / 3);

  // 2) 缺口张力（没想明白的事 → 皮质醇）
  const gap = get(db, 'SELECT COUNT(*) AS n, COALESCE(SUM(tension),0) AS t FROM gaps WHERE resolved = 0');
  const nGap = clamp01((Number(gap.t) || 0) / 3);

  // 3) 近 24h 被想起（共激活 → 多巴胺）
  const inj = get(db, 'SELECT COUNT(*) AS n FROM injection_log WHERE injected_at >= ?', now - 24 * HOUR);
  const nInject = clamp01((Number(inj.n) || 0) / 20);

  // 4) 近 7 天主动发言被宿主确认发出（做成了一件事 → 血清素）
  const sent = get(db, "SELECT COUNT(*) AS n FROM action_proposals WHERE status = 'sent' AND created_at >= ?", now - 7 * 24 * HOUR);
  const nSent = clamp01((Number(sent.n) || 0) / 10);

  // 5) 沉淀为 core 的记忆数（长期被认可的份量 → 血清素）
  const core = get(db, "SELECT COUNT(*) AS n FROM memories WHERE protection_tier = 'core' AND invalid_reason IS NULL");
  const nCore = clamp01((Number(core.n) || 0) / 10);

  // 6) 最近一次真实接触（有人说话才黏人 → 催产素）
  const lastTouch = Math.max(Number(soc.lastUserAt) || 0, Number(soc.lastBotAt) || 0);
  const touchFresh = lastTouch > 0 ? Math.exp(-(now - lastTouch) / HOUR / 12) : 0;
  const closeness = clamp01(state?.relationship?.closeness ?? 0.5);
  const nConfirm = clamp01((Number(inj.n) || 0) / 40);

  const targets = {
    cortisol:  clamp01(init.cortisol  + 0.50 * nNeg + 0.25 * nGap + 0.15 * nRum - 0.15 * nPos),
    dopamine:  clamp01(init.dopamine  + 0.45 * nPos + 0.20 * nConfirm + 0.20 * nInject - 0.25 * nNeg),
    oxytocin:  clamp01(init.oxytocin  + 0.35 * touchFresh + 0.30 * nRel + 0.20 * closeness - 0.20 * (1 - touchFresh)),
    serotonin: clamp01(init.serotonin + 0.35 * nImp + 0.20 * nSent + 0.15 * nCore + 0.10 * nConfirm - 0.15 * nNeg),
  };

  const basis = {
    negative:  { count: negIds.length, load: Number(negLoad.toFixed(3)), ids: negIds },
    positive:  { count: posIds.length, load: Number(posLoad.toFixed(3)), ids: posIds },
    relation:  { count: relIds.length, load: Number(relLoad.toFixed(3)), ids: relIds },
    rumination: Number(rumLoad.toFixed(3)),
    gaps:      { count: Number(gap.n) || 0, tension: Number(gap.t) || 0 },
    injected24h: Number(inj.n) || 0,
    sent7d:    Number(sent.n) || 0,
    core:      Number(core.n) || 0,
    lastTouchAt: lastTouch,
    touchFresh: Number(touchFresh.toFixed(4)),
    scanned: rows.length,
  };

  const anySignal = negIds.length || posIds.length || relIds.length || Number(gap.n) ||
    Number(inj.n) || Number(sent.n) || Number(core.n) || lastTouch || nImp > 0;
  return { targets, basis, source: anySignal ? 'data-driven' : 'baseline-decay' };
}

/**
 * 向目标移动（带每小时限幅，floor/cap 语义与原版一致）。
 * 不传 targets 时返回 null —— 调用方据此逐字节保持 v13.0 旧行为。
 */
export function stepHormonesToTarget(cur, targets, hours = 0.25, cfg = DEFAULTS, maxMove = 0.20) {
  if (!targets) return null;
  const h = cfg.hormone;
  const maxStep = Math.max(0, Number(maxMove)) * Math.max(0, hours);
  const out = {};
  for (const k of Object.keys(h.init)) {
    const c = Number(cur?.[k] ?? h.init[k]);
    const t = clamp01(Number(targets[k] ?? c));
    const d = Math.max(-maxStep, Math.min(maxStep, t - c));
    out[k] = Math.max(h.floor[k] ?? 0, Math.min(h.cap ?? 0.97, c + d));
  }
  return out;
}

/**
 * 情绪共振：本轮检索命中的记忆带情绪 → 当场微幅挪动激素（不等心跳）。
 * 单次上限 maxNudge（默认 0.03）；无情绪命中返回 null，不改变任何数值。
 */
export function applyResonance(state, hits, { cfg = DEFAULTS, maxNudge = 0.03 } = {}) {
  if (!state?.hormones || !Array.isArray(hits) || !hits.length) return null;
  const init = cfg.hormone.init;
  const cap = cfg.hormone.cap ?? 0.97;
  const d = { cortisol: 0, dopamine: 0, oxytocin: 0, serotonin: 0 };
  const ids = [];
  for (const it of hits) {
    const m = it.mem || it;
    const es = clamp01(m.emotional_salience);
    if (es <= 0) continue;
    ids.push(m.id);
    if (isNeg(m.emotion)) { d.cortisol += 0.02 * es; d.dopamine -= 0.01 * es; }
    else if (isPos(m.emotion)) { d.dopamine += 0.02 * es; d.cortisol -= 0.01 * es; }
    if (clamp01(m.relationship_salience) > 0.3) d.oxytocin += 0.015 * es;
    if (clamp01(m.importance) >= 0.7) d.serotonin += 0.01 * es;
  }
  if (!ids.length) return null;
  const lim = Math.max(0, Number(maxNudge));
  for (const k of Object.keys(d)) {
    const v = Math.max(-lim, Math.min(lim, d[k]));
    state.hormones[k] = Math.max(cfg.hormone.floor[k] ?? 0,
      Math.min(cap, Number(state.hormones[k] ?? init[k]) + v));
  }
  return { ids, delta: d, maxNudge: lim };
}
