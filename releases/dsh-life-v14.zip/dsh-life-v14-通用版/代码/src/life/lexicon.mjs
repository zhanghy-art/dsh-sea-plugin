// src/life/lexicon.mjs — 词典法「反应式情绪」（v14 P1，对应后补建议第 4 条）
// 关键设计：词典法不持有状态、不写库，只产出 delta 提案，交给 life-state 调度层限幅后回写。
// 长期状态仍由 v13 四激素 + needs 六维独占 —— 绝不形成第二套情绪引擎。
// 事件规则借鉴 Gitee ai-companion-dashboard/src/affect.mjs（7 条正则 / 最多命中 2 条 / 间隔分级），
// 数值已折算到 v13 的 0–1 四激素语义。
import { DEFAULTS } from '../kit/config.mjs';

export const clamp01 = (v) => Math.max(0, Math.min(1, Number(v) || 0));

/** 统一限幅：所有情绪扰动都必须经过这里（千问 maxNudge=0.03 / Gitee ±0.03 同源） */
export function clampDelta(delta, max = 0.03) {
  const lim = Math.max(0, Number(max));
  const out = {};
  for (const k of Object.keys(delta || {})) {
    out[k] = Math.max(-lim, Math.min(lim, Number(delta[k]) || 0));
  }
  return out;
}

/** 假设语气标记：保留「如果 / 要是 / 前提」，不把猜测写成事实 */
export const HEDGE_WORDS = ['如果', '要是', '假如', '假设', '前提', '万一', '倘若', '或许', '可能吧', '说不定', '我猜'];
export const HYPOTHETICAL_KIND = 'hypothetical';
export function isHypothetical(text) {
  const t = String(text || '');
  const hit = HEDGE_WORDS.filter(w => t.includes(w));
  return { kind: hit.length ? HYPOTHETICAL_KIND : null, markers: hit };
}

/** 凭据拦截：宁拦错，不放行（借 dsh-identity-relay v0.3 FAQ Q7） */
const CREDENTIAL = [
  /\bsk-[A-Za-z0-9_-]{12,}\b/, /api[_-]?key\s*[:=]\s*\S{8,}/i,
  /password\s*[:=]\s*\S{6,}/i, /passwd\s*[:=]\s*\S{6,}/i,
  /-----BEGIN [A-Z ]*PRIVATE KEY-----/, /\bBearer\s+[A-Za-z0-9._-]{20,}/,
  /\b[A-Za-z0-9_-]{40,}\.[A-Za-z0-9_-]{20,}\b/,
];
export function hasCredential(text) {
  return CREDENTIAL.some(re => re.test(String(text || '')));
}

/** 事件 → 四激素 delta 提案（不是七情维度，避免第二套情绪引擎） */
export const LEXICON_RULES = [
  { id: 'vulnerable', re: /累|加班|困|头疼|生病|发烧|压力大|难受|撑不住/, d: { oxytocin: 0.012, cortisol: 0.008 } },
  { id: 'affection', re: /喜欢你|爱你|想你|抱抱|亲亲|摸摸头|宝贝|乖/, d: { dopamine: 0.015, oxytocin: 0.018 } },
  { id: 'praise', re: /可爱|好看|厉害|真棒|好聪明|了不起|牛啊/, d: { dopamine: 0.016, serotonin: 0.008 } },
  { id: 'scold', re: /滚|闭嘴|烦死了|别烦我|你懂什么|废物|没用/, d: { cortisol: 0.022, serotonin: -0.014 } },
  { id: 'apology', re: /对不起|我错了|抱歉|别生气|原谅我/, d: { oxytocin: 0.010, cortisol: -0.012 } },
  { id: 'dismissive', re: /^(嗯|哦|噢|额|行|好|随便|知道了|在忙)[。！？!?.…]*$/, d: { cortisol: 0.010, dopamine: -0.008 } },
  { id: 'insomnia', re: /睡不着|失眠|还在吗|没睡|熬夜/, d: { oxytocin: 0.008, cortisol: 0.006 } },
];

/**
 * 单轮即时检测。
 * @returns {{delta:object, matched:string[], basis:object}|null} 无命中返回 null，不改变任何数值
 */
export function detectImmediate(text, { gapMs = 0, now = Date.now(), maxNudge = 0.03 } = {}) {
  const t = String(text || '').replace(/\s+/g, '').trim();
  if (!t) return null;
  const delta = { cortisol: 0, dopamine: 0, oxytocin: 0, serotonin: 0 };
  const matched = [];

  // 间隔分级（在规则之前，借 Gitee affect.mjs 的 24/8/3h）
  if (gapMs > 24 * 3600000) { delta.cortisol += 0.010; delta.oxytocin -= 0.008; matched.push('gap:24h'); }
  else if (gapMs > 8 * 3600000) { delta.cortisol += 0.006; matched.push('gap:8h'); }
  else if (gapMs > 3 * 3600000) { delta.cortisol += 0.003; matched.push('gap:3h'); }

  let hits = 0;
  for (const rule of LEXICON_RULES) {
    if (hits >= 2) break;                       // 一条消息最多命中 2 条
    if (!rule.re.test(t)) continue;
    for (const [k, v] of Object.entries(rule.d)) delta[k] += v;
    matched.push(rule.id); hits++;
  }
  // 凌晨 1–5 点
  const hour = new Date(now).getHours();
  if (hour >= 1 && hour < 5) { delta.oxytocin += 0.004; matched.push('late-night'); }
  if (!matched.length) return null;
  return { delta: clampDelta(delta, maxNudge), matched, basis: { source: 'lexicon', hour } };
}

/** 指数半衰衰减（借 Gitee mood.mjs，纯函数，供睡眠/反刍复用） */
export function decayToward(value, target, elapsedMs, halfLifeMs) {
  if (!(elapsedMs > 0) || !(halfLifeMs > 0)) return value;
  return target + (Number(value) - target) * Math.pow(0.5, elapsedMs / halfLifeMs);
}

/** 柔和饱和 / 端点收缩：接近满格时步长衰减（借 Gitee mood.mjs:220） */
export function softSaturation(cur, d, { cap = 0.95 } = {}) {
  const head = d > 0 ? 1 - cur : cur;
  const soft = Math.min(1, Math.max(0.03, Math.pow(Math.max(0.005, head), 0.75) * 1.2));
  return Math.max(0, Math.min(cap, cur + d * soft));
}

/** 反刍 streak：40 分钟内重复触发 → 半衰 +33%，最多 +99%（借 Gitee mood.mjs） */
export function ruminationHalfLife(baseHalf, rum = { at: 0, streak: 0 }, now = Date.now()) {
  const within = now - Number(rum.at || 0) < 40 * 60000;
  const streak = within ? Math.min(3, Number(rum.streak || 0) + 1) : 0;
  return { halfLife: baseHalf * (1 + streak * 0.33), streak, at: now };
}

/**
 * 六欲 → 四激素联动（借 Gitee desires.mjs desireMoodTick，阈值换算到 0–1）。
 * 25 分钟冷却，avg<0.40 压低多巴胺、抬高皮质醇；单次限幅 ±0.03。
 */
export function desireMoodTick(needs = {}, state = {}, { now = Date.now(), maxNudge = 0.03, cfg = DEFAULTS } = {}) {
  const last = Number(state?.counters?.desireMoodAt || 0);
  if (now - last < 25 * 60000) return null;
  const vals = ['social', 'curiosity', 'rest', 'mood', 'closeness', 'energy'].map(k => clamp01(needs[k] ?? 0.5));
  const avg = vals.reduce((a, b) => a + b, 0) / vals.length;
  const low = vals.filter(v => v < 0.35).length;
  let dopamine = 0, cortisol = 0;
  if (avg < 0.40) { cortisol += 0.012; dopamine -= 0.008; }
  if (avg > 0.75) { dopamine += 0.008; cortisol -= 0.004; }
  cortisol += low * 0.003;
  dopamine -= low * 0.002;
  if (low >= 3) cortisol += 0.005;
  const delta = clampDelta({ cortisol, dopamine, oxytocin: 0, serotonin: 0 }, maxNudge);
  return { delta, avg: Number(avg.toFixed(3)), low, at: now };
}
