// src/life/life-state.mjs — LifeState 单行 + 事件重放（11.1–11.5）
// v13.0 变化：激素标度统一 0–1（指南共识第 1 条），旧库 0–100 状态在 recover 时一次性折算。
import { DEFAULTS, SCHEMA_VERSION } from '../kit/config.mjs';
import { tx, kvGet, kvSet } from '../kit/db.mjs';
import { normalizeHormones, clamp01 } from '../kit/units.mjs';
import { stepHormonesToTarget } from './hormone-source.mjs';
import { createHash } from 'node:crypto';

export { clamp01 };

export function defaultState(now = Date.now()) {
  return {
    schemaVersion: 13,
    revision: 0,
    needs: { social: 0.5, curiosity: 0.5, rest: 0.7, mood: 0.6, closeness: 0.5, energy: 0.7 },
    hormones: { ...DEFAULTS.hormone.init },
    energy: 0.7,
    phase: phaseOf(now),
    social: { lastUserAt: 0, lastBotAt: 0, lastProactiveAt: 0, silentStreak: 0, proactiveBackoffMinutes: 120 },
    relationship: { closeness: 0.5, trust: 0.5, stage: 'normal' },
    counters: {
      proactiveToday: 0, proactiveThisHour: 0, emotionInjectToday: 0,
      dayKey: dayKeyOf(now), stateLineAt: 0, lastTickAt: now,
    },
    affect: {
      pad: { P: 0.53, A: 0.45, D: 0.55 },
      eventClass: 'ordinary', dominant: '平常', confidence: 0,
    },
    sleep: {
      stage: 'awake', stageSince: 0, sleepDebt: 0,
      dreamLog: [], lastDreamAt: 0, awakenedFrom: null,
      pendingDeliveries: [], manual: 'auto',
    },
    thoughtStream: [],
    flags: { safeMode: false, shadowMode: false, deepNight: false },
  };
}

export function dayKeyOf(now) {
  const d = new Date(now);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

export function phaseOf(now) {
  const h = new Date(now).getHours();
  if (h >= 5 && h < 9) return 'morning';
  if (h >= 9 && h < 12) return 'peak';
  if (h >= 12 && h < 18) return 'afternoon';
  if (h >= 18 && h < 23) return 'evening';
  return 'night';
}

export const PHASE_ENERGY = { morning: 0.7, peak: 1.0, afternoon: 0.6, evening: 0.8, night: 0.3 };

export function hashState(s) {
  return createHash('sha256').update(JSON.stringify(s)).digest('hex');
}

export function loadState(db) {
  // v13 用 id=1 单行；v11.1 用 id='singleton' 宽表。先按 v13 读，读不到再认旧行
  // （adoptLegacyState 会把旧行搬成 id=1，但「只读打开、还没迁移」的库也得能读出来）。
  const sel = 'SELECT revision, schema_version, state_json FROM life_state WHERE id = ?';
  let row;
  try {
    row = db.prepare('SELECT revision, schema_version, state_json FROM life_state WHERE id = 1').get()
      || db.prepare('SELECT revision, schema_version, state_json FROM life_state WHERE id = ' + "'singleton'").get();
  } catch {
    row = db.prepare('SELECT revision, state_json FROM life_state WHERE id = 1').get()
      || db.prepare('SELECT revision, state_json FROM life_state WHERE id = ' + "'singleton'").get();
    if (row) row.schema_version = null;
  }
  if (!row) return null;
  if (!row.state_json) return null;   // v11 宽表没有 state_json：交给 adoptLegacyState，不要造空状态
  return { revision: row.revision, schemaVersion: row.schema_version, state: JSON.parse(row.state_json) };
}

/** 六维：先惯性后限幅（顺序不可反） */
export function stepNeeds(prev, target, cfg = DEFAULTS) {
  const out = {};
  for (const k of Object.keys(prev)) {
    const t = target[k] ?? prev[k];
    const mixed = cfg.needs.inertia * prev[k] + (1 - cfg.needs.inertia) * t;
    out[k] = clamp01(Math.max(prev[k] - cfg.needs.clamp, Math.min(prev[k] + cfg.needs.clamp, mixed)));
  }
  return out;
}

/** 激素：向基线回归 + 双向增量 × SCALE（0–1 标度，上限 cap 而非 100） */
export function stepHormones(cur, delta = {}, hours = 0.25, cfg = DEFAULTS) {
  const h = cfg.hormone;
  const out = {};
  for (const k of Object.keys(h.init)) {
    const decayed = h.init[k] + (Number(cur[k] ?? h.init[k]) - h.init[k]) * Math.pow(h.decay[k], hours);
    const d = (delta[k] || 0) * h.scale;
    out[k] = Math.max(h.floor[k], Math.min(h.cap ?? 0.97, decayed + d));
  }
  return out;
}

/**
 * 15 分钟 tick（11.3）：注意 elapsed<5 分钟抖动保护。
 * v14：新增第 5 参 opts.hormoneTargets —— 传了则向数据目标收敛并记 hormoneBasis；
 *      不传则逐字节保持 v13.0 旧行为（旧测试零破坏、总闸关闭时可完全回退）。
 */
export function lifeTick(state, elapsedMin, now = Date.now(), cfg = DEFAULTS, opts = {}) {
  if (elapsedMin < 5) return state;
  const hours = elapsedMin / 60;
  const s = structuredClone(state);
  const night = phaseOf(now) === 'night';
  s.needs.social = clamp01(s.needs.social + 0.012 * hours);
  s.needs.curiosity = clamp01(s.needs.curiosity + 0.007 * hours);
  s.needs.rest = clamp01(s.needs.rest + (night ? -0.030 : 0.004) * hours);
  if (opts.manageEnergy !== false) {
    s.energy = clamp01(s.energy + 0.5 * (PHASE_ENERGY[phaseOf(now)] * 0.8 + 0.2 - s.energy) * Math.min(1, hours));
  }
  if (opts.hormoneTargets) {
    const moved = stepHormonesToTarget(s.hormones, opts.hormoneTargets, hours, cfg,
      opts.maxMovePerHour ?? 0.20);
    if (moved) {
      s.hormones = moved;
      s.hormoneBasis = opts.hormoneBasis ?? null;
      s.hormoneSource = opts.hormoneSource || 'data-driven';
    }
  } else {
    s.hormones = stepHormones(s.hormones, {}, hours, cfg);
  }
  s.phase = phaseOf(now);
  s.flags = s.flags || {};
  s.flags.deepNight = night;
  s.revision += 1;
  return s;
}

/** 保存：单行 + 快照限容（30 份 / 512MB，至少 7 份） */
export function saveState(db, state, now = Date.now(), cfg = DEFAULTS) {
  const json = JSON.stringify(state);
  const h = hashState(state);
  // v11.1 的 life_snapshots 是 (revision, at NOT NULL, state NOT NULL, hormones)，
  // v13 是 (revision, state_hash, snapshot_json, state_json, size_bytes, created_at)。
  // 旧库直接插新列会撞 at/state 的 NOT NULL，所以两种列集都填。
  const snapCols = (() => { try { return db.prepare('PRAGMA table_info(life_snapshots)').all().map(r => r.name); } catch { return []; } })();
  const legacyCols = snapCols.includes('at') && snapCols.includes('state');
  return tx(db, () => {
    // v14：这些时间列在 v11.1 老库里是 TEXT 亲和性。传 JS number 进去时，SQLite 会
    // 先把它当 REAL 再转 TEXT，于是 '1793824621501' 落库变成 '1793824621501.0'——
    // 每次写都留一条尾巴，脏数据永远清不干净（实测二次启动必被判成 mixed-time，
    // U10-b 因此反复失败）。Math.round 只能保证值是整数，挡不住 REAL→TEXT 这条转换。
    // 唯一可靠的做法是直接传**字符串**，SQLite 原样存。
    const tsNum = Math.round(Number(now) || Date.now());
    const ts = String(tsNum);
    db.prepare(
      'INSERT INTO life_state(id, revision, schema_version, state_json, updated_at) VALUES(1,?,?,?,?) ' +
      'ON CONFLICT(id) DO UPDATE SET revision=excluded.revision, schema_version=excluded.schema_version, ' +
      'state_json=excluded.state_json, updated_at=excluded.updated_at'
    ).run(state.revision, state.schemaVersion ?? SCHEMA_VERSION, json, ts);
    if (legacyCols) {
      db.prepare('INSERT OR REPLACE INTO life_snapshots(revision, at, state, hormones, state_hash, snapshot_json, state_json, size_bytes, created_at) VALUES(?,?,?,?,?,?,?,?,?)')
        .run(state.revision, new Date(tsNum).toISOString(), json, JSON.stringify(state.hormones || {}), h, json, json, Buffer.byteLength(json), ts);
    } else {
      db.prepare('INSERT OR REPLACE INTO life_snapshots(revision, state_hash, snapshot_json, state_json, size_bytes, created_at) VALUES(?,?,?,?,?,?)')
        .run(state.revision, h, json, json, Buffer.byteLength(json), ts);
    }
    trimSnapshots(db);
    return { revision: state.revision, hash: h };
  });
}

export function trimSnapshots(db) {
  const rows = db.prepare('SELECT revision, size_bytes FROM life_snapshots ORDER BY revision DESC').all();
  let bytes = 0;
  const keep = [];
  for (let i = 0; i < rows.length; i++) {
    bytes += rows[i].size_bytes || 0;
    const overCount = i >= 30;
    const overSize = bytes > 512 * 1024 * 1024;
    if ((overCount || overSize) && keep.length >= 7) break;
    keep.push(rows[i].revision);
  }
  const keepSet = new Set(keep);
  const all = rows.map(r => r.revision);
  const del = db.prepare('DELETE FROM life_snapshots WHERE revision = ?');
  for (const rev of all) if (!keepSet.has(rev)) del.run(rev);
}

/** 启动恢复七步（11.4） */
export function recover(db, cfg = DEFAULTS) {
  const integ = db.prepare('PRAGMA integrity_check').get();
  const ok = Object.values(integ || {})[0] === 'ok';
  if (!ok) return { safeMode: true, reason: 'integrity' };
  const loaded = loadState(db);
  if (!loaded) return { safeMode: false, state: defaultState(), firstRun: true };
  const snap = db.prepare('SELECT state_hash FROM life_snapshots WHERE revision = ?').get(loaded.revision);
  if (snap && snap.state_hash !== hashState(loaded.state)) {
    return { safeMode: true, reason: 'snapshot-mismatch' };
  }
  const lastRev = db.prepare('SELECT MAX(revision) AS r FROM life_events').get()?.r || loaded.revision;
  const state = loaded.state;
  state.revision = Math.max(state.revision, lastRev);
  state.counters = state.counters || {};
  if (!Number(state.counters.lastTickAt)) state.counters.lastTickAt = Date.now();
  state.affect = state.affect || {
    pad: { P: 0.53, A: 0.45, D: 0.55 },
    eventClass: 'ordinary', dominant: '平常', confidence: 0,
  };
  state.sleep = state.sleep || {
    stage: 'awake', stageSince: 0, sleepDebt: 0,
    dreamLog: [], lastDreamAt: 0, awakenedFrom: null,
    pendingDeliveries: [], manual: 'auto',
  };
  state.thoughtStream = Array.isArray(state.thoughtStream) ? state.thoughtStream : [];
  // v13.0：旧库状态里的激素是 0–100（30/50/40/60），这里一次性折到 0–1。
  // 不折算的话，attention 的 0.55/0.80 阈值永远命中最高档（cortisol 30 会被读成 0.30 → 碰巧对，
  // 但 60/100 这些值在全量数据里会直接穿越阈值），composer 的状态行也会判错。
  state.hormones = normalizeHormones(state.hormones);
  if (Number(state.schemaVersion ?? 12) < 13) {
    state.schemaVersion = 13;
    state.flags = state.flags || {};
    state.flags.unitsMigrated = true;
  }
  return { safeMode: false, state };
}

/** 离线追赶：≤7 天，672 tick */
export function catchUp(state, offlineMs, cfg = DEFAULTS) {
  const ticks = Math.min(Math.floor(offlineMs / (15 * 60000)), 672);
  let s = state;
  for (let i = 0; i < ticks; i++) s = lifeTick(s, 15, Date.now(), cfg);
  return { state: s, ticks };
}

export { kvGet, kvSet };

/**
 * 把 v11.1 的「三张表 + 六维列」接管成 v13 的单行 state_json。
 *
 * 为什么非它不可：v11.1 的 life_state 是宽表（id='singleton'，social/curiosity/rest/mood/
 * closeness/energy 各一列），激素在 life_hormones 表（0–100 标度），关系在 life_relationship
 * 表；v13 只认 life_state(id=1).state_json。不做这一步，recover() 会读到空 → 用 defaultState()
 * 覆盖，记忆还在、但她的心情/激素/亲密度全部归零（「装了不用」的最坏形态）。
 *
 * 幂等：state_json 已有值就跳过；原值另存 kv('v11:state:*') 便于回滚对照。
 */
export function adoptLegacyState(db, cfg = DEFAULTS) {
  const cols = (t) => { try { return db.prepare(`PRAGMA table_info(${t})`).all().map(r => r.name); } catch { return []; } };
  if (!cols('life_state').length) return { adopted: false, reason: 'no-life_state' };

  const pick = (t) => { try { return db.prepare(`SELECT * FROM ${t} LIMIT 1`).get() || null; } catch { return null; } };
  const ls = pick('life_state');
  if (!ls) return { adopted: false, reason: 'empty' };
  if (ls.state_json) return { adopted: false, reason: 'already-v13' };

  const hm = pick('life_hormones');
  const rel = pick('life_relationship');

  const toUnit = (v) => {
    const n = Number(v);
    if (!Number.isFinite(n)) return null;
    return n > 1.5 ? Math.max(0, Math.min(1, n / 100)) : Math.max(0, Math.min(1, n));
  };

  const st = defaultState();
  // 六维：v11 列名与 v13 needs 同名，直接搬（都是 0–1）
  if (ls.social != null) st.needs.social = clamp01(ls.social);
  if (ls.curiosity != null) st.needs.curiosity = clamp01(ls.curiosity);
  if (ls.rest != null) st.needs.rest = clamp01(ls.rest);
  if (ls.mood != null) st.needs.mood = clamp01(ls.mood);
  if (ls.closeness != null) st.needs.closeness = clamp01(ls.closeness);
  if (ls.energy != null) { st.needs.energy = clamp01(ls.energy); st.energy = clamp01(ls.energy); }
  if (ls.phase) st.phase = ls.phase;
  if (Number.isFinite(Number(ls.revision))) st.revision = Number(ls.revision);

  // 四激素：v11 是 0–100，v13 要 0–1
  if (hm) {
    const h = {};
    for (const k of ['cortisol', 'dopamine', 'oxytocin', 'serotonin']) {
      const u = toUnit(hm[k]);
      if (u != null) h[k] = u;
    }
    st.hormones = { ...st.hormones, ...h };
  }

  // 关系（id='owner'）
  if (rel) {
    st.relationship = {
      closeness: rel.closeness != null ? clamp01(rel.closeness) : st.relationship.closeness,
      trust: rel.trust != null ? clamp01(rel.trust) : st.relationship.trust,
      stage: rel.stage || st.relationship.stage,
    };
  }

  // 其余 v11 状态留档，不丢（life_self 的自我认知、counters 的累计量）
  const self = (() => { try { return db.prepare('SELECT key, value FROM life_self').all(); } catch { return []; } })();
  const counters = (() => { try { return db.prepare('SELECT key, value FROM life_counters').all(); } catch { return []; } })();
  st.extra = {
    legacyV11: {
      life_state: ls, life_hormones: hm, life_relationship: rel,
      life_self: Object.fromEntries(self.map(r => [r.key, r.value])),
      life_counters: Object.fromEntries(counters.map(r => [r.key, r.value])),
      note: 'v11.1 原始状态留档；六维/激素/关系已按语义搬进 needs/hormones/relationship',
    },
  };
  st.schemaVersion = 13;
  st.flags = { ...(st.flags || {}), unitsMigrated: true, adoptedFromV11: true };

  // v11 那行的 id 是 'singleton'，v13 只认 id=1：先删旧行再按 id=1 写，避免出现两行状态
  db.prepare("DELETE FROM life_state WHERE id = 'singleton'").run();
  const r = saveState(db, st, Date.now(), cfg);
  try {
    kvSet(db, 'v11:life_state_backup', JSON.stringify({ life_state: ls, life_hormones: hm, life_relationship: rel }));
  } catch { /* ignore */ }
  return { adopted: true, revision: r.revision, needs: st.needs, hormones: st.hormones, relationship: st.relationship };
}
