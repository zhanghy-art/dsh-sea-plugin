// src/life/persona-drift.mjs — Q8：人格慢漂移（只出 diff，owner 终审才生效）
// 原则：模型不能改人格；插件只从「owner/self 来源 + 高重要度」的记忆里归纳候选，
//       写进 life_events(type='persona:diff')，由 owner 通过工具显式 apply 才落到 kv 快照。
import { DEFAULTS } from '../kit/config.mjs';
import { kvGet, kvSet } from '../kit/db.mjs';

const SNAP_KEY = 'persona:snapshot';
const TIER_OK = new Set(['user', 'owner', 'self', 'manual', 'user_sentence', 'user_confirm']);

function readSnapshot(db) {
  try { return JSON.parse(kvGet(db, SNAP_KEY) || '{}'); } catch { return {}; }
}

function newEventId(now) {
  return 'pd_' + now.toString(36) + '_' + Math.random().toString(36).slice(2, 7);
}

function logEvent(db, type, payload, now) {
  const id = newEventId(now);
  const body = JSON.stringify(payload || {});
  try {
    db.prepare(
      'INSERT INTO life_events(event_id, revision, event_type, event_json, type, payload, created_at, applied_at) ' +
      'VALUES(?,?,?,?,?,?,?,?)'
    ).run(id, 0, type, body, type, body, now, type === 'persona:applied' ? now : null);
    return id;
  } catch { return null; }
}

/** 汇总候选：同一 attr_key/分类只留重要度最高的一条 */
export function collectPersonaItems(db, { cfg = DEFAULTS, now = Date.now() } = {}) {
  const p = cfg?.v14?.persona || {};
  const minImp = Number(p.minImportance ?? 0.7);
  const maxItems = Number(p.maxItems ?? 12);
  let rows = [];
  try {
    rows = db.prepare(
      "SELECT id, category, fact, attr_key, attr_value, importance, source_kind " +
      "FROM memories WHERE invalid_reason IS NULL AND cold = 0 AND importance >= ? " +
      "AND category IN ('person','preference','rule','promise') " +
      "ORDER BY importance DESC, id DESC LIMIT 200"
    ).all(minImp);
  } catch { return []; }
  const seen = new Set();
  const out = [];
  for (const r of rows) {
    if (!TIER_OK.has(String(r.source_kind || ''))) continue;   // 只认 owner/self 类来源
    const key = String(r.attr_key || (r.category + ':' + String(r.attr_value || r.fact)).slice(0, 40));
    if (seen.has(key)) continue;
    seen.add(key);
    out.push({ key, category: r.category, text: String(r.fact), memoryId: r.id, importance: Number(r.importance || 0) });
    if (out.length >= maxItems) break;
  }
  return out;
}

/** 生成 diff：只写 life_events，不改任何事实、不写人格 */
export function buildPersonaDiff(db, { cfg = DEFAULTS, now = Date.now() } = {}) {
  const items = collectPersonaItems(db, { cfg, now });
  const snap = readSnapshot(db);
  const diff = [];
  for (const it of items) {
    const prev = snap[it.key]?.text ?? null;
    if (prev === it.text) continue;
    diff.push({ ...it, kind: prev == null ? 'add' : 'change', from: prev });
  }
  const removed = Object.keys(snap).filter((k) => !items.some((i) => i.key === k));
  const payload = { at: now, items: diff, removed, total: items.length, pending: true };
  const eventId = logEvent(db, 'persona:diff', payload, now);
  return { ok: !!eventId, eventId, added: diff.filter((d) => d.kind === 'add').length,
    changed: diff.filter((d) => d.kind === 'change').length, removed: removed.length, items: diff };
}

export function listPersonaDiffs(db, { limit = 5 } = {}) {
  try {
    return db.prepare(
      "SELECT event_id, event_json, created_at FROM life_events WHERE event_type='persona:diff' " +
      'ORDER BY created_at DESC LIMIT ?'
    ).all(Math.max(1, Number(limit) || 5)).map((r) => {
      try { return { eventId: r.event_id, at: r.created_at, ...JSON.parse(r.event_json) }; }
      catch { return { eventId: r.event_id, at: r.created_at, items: [] }; }
    });
  } catch { return []; }
}

/** owner 终审通过：把当前候选写成人格快照（带时间戳，可回滚） */
export function applyPersonaDiff(db, eventId, { cfg = DEFAULTS, now = Date.now() } = {}) {
  let row;
  try {
    row = db.prepare("SELECT event_json FROM life_events WHERE event_id = ? AND event_type='persona:diff'").get(eventId);
  } catch { return { ok: false, reason: 'read-failed' }; }
  if (!row) return { ok: false, reason: 'diff-not-found' };
  let payload;
  try { payload = JSON.parse(row.event_json); } catch { return { ok: false, reason: 'bad-json' }; }
  const snap = readSnapshot(db);
  const next = { ...snap };
  const appliedAt = now;
  for (const it of payload.items || []) {
    next[it.key] = { text: it.text, memoryId: it.memoryId, appliedAt };
  }
  for (const k of payload.removed || []) delete next[k];
  try { kvSet(db, SNAP_KEY, JSON.stringify(next)); } catch { return { ok: false, reason: 'write-failed' }; }
  const id = logEvent(db, 'persona:applied', { source: eventId, appliedAt, keys: Object.keys(next) }, now);
  return { ok: true, eventId: id, keys: Object.keys(next).length, appliedAt };
}

export function personaSnapshot(db) {
  return readSnapshot(db);
}
