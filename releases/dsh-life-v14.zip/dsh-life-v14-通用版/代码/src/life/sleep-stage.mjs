// src/life/sleep-stage.mjs — 睡眠阶段机 / 梦境 / 念头流 / 缺觉影响（v14 P1）
// 全部状态塞进 life_state.state_json 的嵌套字段，零新增表、零新增列。
// 硬约束：梦境只写 state.sleep.dreamLog，绝不写回 memories（鱼生 v12 的明确教训）。
// 参数借鉴 Gitee ai-companion-dashboard：梦 clear=0.45 / 20h 冷却 / 早 5–12 点才提，
// 念头流 3h 存活 / 最多 6 条 / 只注入前 3 条 / 标题明写「不一定要说出来」。
import { DEFAULTS } from '../kit/config.mjs';
import { scopeClause, scopeVisible, visibleScopes } from '../kit/scope.mjs';
import { remFromGaps } from '../memory/gaps.mjs';
import { clampDelta, clamp01 } from './lexicon.mjs';

export const STAGES = ['awake', 'nrem_light', 'nrem_deep', 'rem'];
export const THOUGHT_LIFE_MS = 3 * 3600000;
export const THOUGHT_MAX = 6;
export const DREAM_COOLDOWN_MS = 20 * 3600000;
export const DREAM_CONTEXT_HOURS = [5, 12];

const all = (db, sql, ...args) => { try { return db.prepare(sql).all(...args); } catch { return []; } };

function sleepBlock(state) {
  if (!state.sleep || typeof state.sleep !== 'object') {
    state.sleep = { stage: 'awake', stageSince: 0, sleepDebt: 0, dreamLog: [], lastDreamAt: 0, awakenedFrom: null };
  }
  return state.sleep;
}

/**
 * 睡眠窗口：cfg.sleepWindow.window === 'auto' 时取顶层 quietHours，
 * 也支持显式 { start, end }（跨零点自动处理）。
 */
export function sleepWindow(cfg = DEFAULTS) {
  const w = cfg?.sleep?.window;
  if (w && typeof w === 'object' && Number.isFinite(Number(w.start)) && Number.isFinite(Number(w.end))) {
    return [Number(w.start), Number(w.end)];
  }
  const q = cfg?.quietHours || [23, 8];
  return [Number(q[0]), Number(q[1])];
}

export function inSleepWindow(now = Date.now(), cfg = DEFAULTS) {
  const [a, b] = sleepWindow(cfg);
  const hour = new Date(now).getHours();
  return a < b ? (hour >= a && hour < b) : (hour >= a || hour < b);
}

/** 阶段机：夜里 + 精力低 / quietHours → nrem_light / nrem_deep / rem */
export function sleepStage(state, now = Date.now(), cfg = DEFAULTS) {
  const hour = new Date(now).getHours();
  const q = sleepWindow(cfg);
  const inQuiet = q[0] < q[1] ? (hour >= q[0] && hour < q[1]) : (hour >= q[0] || hour < q[1]);
  const night = hour >= 23 || hour < 8;
  const energy = clamp01(state?.energy ?? 0.7);
  const manual = String(state?.sleep?.manual || 'auto');
  if (manual === 'awake') return 'awake';
  if (manual !== 'sleep' && (!inQuiet || !night)) return 'awake';
  const deep = cfg.sleep?.deepHours || [0, 6];
  const inDeep = deep[0] < deep[1] ? (hour >= deep[0] && hour < deep[1]) : (hour >= deep[0] || hour < deep[1]);
  if (inDeep && energy < 0.45) return 'nrem_deep';
  // REM：临近醒来的两个小时，或每 90 分钟周期尾段
  if (hour >= 6 && hour < 8) return 'rem';
  if (Math.floor((hour * 60 + new Date(now).getMinutes()) / 90) % 3 === 2) return 'rem';
  return 'nrem_light';
}

/**
 * 分档精力结算 + 阶段切换（挂在既有 settleLifecycle 之后，不改其签名）。
 * @returns {{state, changed:boolean, dream:object|null, wokeFrom:string|null}}
 */
export function settleStages(state, {
  now = Date.now(), minutes = 15, cfg = DEFAULTS, db = null,
  dreamEnabled = true, scope = null,
} = {}) {
  const s = state && typeof state === 'object' ? state : {};
  const sl = sleepBlock(s);
  const prev = sl.stage || 'awake';
  const stage = sleepStage(s, now, cfg);
  const changed = prev !== stage;
  let wokeFrom = null;

  if (changed) {
    sl.stageSince = now;
    sl.stage = stage;
    if (prev !== 'awake' && stage === 'awake') { sl.awakenedFrom = prev; wokeFrom = prev; }
  }

  // 分档回血：深睡 > 浅睡 > REM > 醒着；醒着按小时掉（Gitee 精力动力学折算）
  // v14.2（WB 合并）：睡着只能涨到 sleepEnergyCap（默认 0.95），不再冲破 1；
  // 醒着只降不涨且地板是 0。拆掉 v13 naturalCap 0.60 的永久封顶；
  // energy 写入权由本模块独占（advanceV14 调 lifeTick 时传 manageEnergy:false）。
  const rates = { awake: -0.045, nrem_light: 0.10, nrem_deep: 0.22, rem: 0.06 };   // 每小时 0–1 变化
  const sleepCap = clamp01(Number(cfg?.v14?.sleep?.sleepEnergyCap ?? 0.95));
  const r = rates[stage] ?? 0;
  const cur = clamp01(s.energy ?? 0.7);
  s.energy = stage === 'awake'
    ? Math.max(0, cur + r * (minutes / 60))
    : Math.min(sleepCap, cur + r * (minutes / 60));
  if (stage !== 'awake') sl.sleepDebt = Math.max(0, Number(sl.sleepDebt || 0) - (minutes / 60) * 0.05);
  else sl.sleepDebt = Math.min(1, Number(sl.sleepDebt || 0) + (minutes / 60) * 0.02);

  // 被叫醒的脾气：深睡被叫醒 → 皮质醇短时上扬 + 精力恢复打折（走统一限幅）
  if (wokeFrom === 'nrem_deep' && s.hormones) {
    const d = clampDelta({ cortisol: 0.03, dopamine: -0.015, oxytocin: 0, serotonin: -0.01 }, 0.03);
    for (const [k, v] of Object.entries(d)) {
      s.hormones[k] = clamp01((s.hormones[k] ?? 0.5) + v);
    }
    s.energy = clamp01(s.energy - 0.03);
    sl.awakenedFrom = null;
  }

  const dream = dreamEnabled && stage === 'rem' ? maybeDream(db, s, { now, cfg, scope }) : null;
  return { state: s, changed, dream, wokeFrom };
}

/** 生成一场梦：素材来自真实缺口 + 近 24h 高情绪记忆 + 最近被想起的事；不写 memories */
export function maybeDream(db, state, { now = Date.now(), cfg = DEFAULTS, scope = null } = {}) {
  const sl = sleepBlock(state);
  if (now - Number(sl.lastDreamAt || 0) < DREAM_COOLDOWN_MS) return null;
  const visible = scope ? visibleScopes(scope) : null;
  const sc = visible ? scopeClause(visible) : { sql: '1=1', params: [] };
  const gaps = db ? remFromGaps(db, { limit: 1, threshold: 0.30, scopes: visible }) : [];
  const emo = db ? all(db,
    `SELECT id, fact FROM memories WHERE ${sc.sql} AND invalid_reason IS NULL AND cold = 0
     AND emotional_salience >= 0.4
     ORDER BY COALESCE(confirmed_at_ms, created_at_ms) DESC LIMIT 3`, ...sc.params) : [];
  const inj = db ? all(db,
    `SELECT DISTINCT memory_id FROM injection_log
     WHERE ${sc.sql} AND injected_at >= ? LIMIT 3`, ...sc.params, now - 24 * 3600000) : [];

  const bits = [];
  if (gaps.length) bits.push(gaps[0].text);
  for (const r of emo) bits.push(String(r.fact || '').slice(0, 20));
  if (!bits.length && inj.length) bits.push('白天反复想起的那件事');
  const text = bits.length
    ? `（梦见${bits.slice(0, 3).join('，又像')}，醒来只剩一点影子）`.slice(0, 160)
    : '（梦见平常的一天，画面很淡）';
  const clear = Math.random() < 0.45;      // 只记得一部分
  const dream = {
    at: now, text, clear, scope,
    level: Math.min(3, 1 + (gaps.length ? 1 : 0) + (emo.length >= 2 ? 1 : 0)),
    sources: { gaps: gaps.map(g => g.gapId), memories: emo.map(r => r.id), injections: inj.map(r => r.memory_id) },
    wroteToMemories: false,
  };
  sl.dreamLog = [...(sl.dreamLog || []), dream].slice(-30);
  sl.lastDreamAt = now;
  try {
    db?.prepare(
      'INSERT INTO life_events(event_id, revision, event_type, event_json, type, payload, created_at, applied_at) ' +
      'VALUES(?,?,?,?,?,?,?,?)'
    ).run(
      `dream:${now}:${Math.random().toString(36).slice(2, 8)}`, 0,
      'dream', JSON.stringify(dream), 'dream', JSON.stringify(dream), now, now,
    );
  } catch { /* dream log in state remains the primary record */ }
  return dream;
}

/** 早上才提梦；14 小时后不提；模糊的只给固定文案 */
export function dreamContext(state, now = Date.now(), cfg = DEFAULTS) {
  const list = state?.sleep?.dreamLog || [];
  if (!list.length) return '';
  const last = list[list.length - 1];
  if (now - Number(last.at || 0) > 14 * 3600000) return '';
  const h = new Date(now).getHours();
  const [a, b] = DREAM_CONTEXT_HOURS;
  if (h < a || h > b) return '';
  return last.clear
    ? `【昨晚的梦】${last.text}（可以在合适的时候提起，别每次都说）`
    : '【昨晚做了个梦】只记得零碎的画面，说不太清。';
}

export function recentDreams(db, { limit = 10, scope = null } = {}) {
  let rows = [];
  try {
    rows = db.prepare(
      "SELECT event_json, created_at FROM life_events WHERE event_type='dream' ORDER BY created_at DESC LIMIT ?"
    ).all(Math.max(20, Math.max(1, Number(limit) || 10) * 10));
  } catch { return []; }
  return rows.map((r) => {
    try { return { ...JSON.parse(r.event_json), createdAt: r.created_at }; }
    catch { return null; }
  }).filter((x) => x && (!scope || scopeVisible(x.scope, scope))).slice(0, Math.max(1, Number(limit) || 10));
}

// ---------- 念头流 ----------
export function think(state, text, { now = Date.now(), tone = '', weight = 1 } = {}) {
  const t = String(text || '').trim().slice(0, 60);
  if (!t) return null;
  const list = (state.thoughtStream || []).filter(x => now - Number(x.at || 0) < THOUGHT_LIFE_MS);
  if (list.some(x => x.text === t && now - Number(x.at || 0) < 20 * 60000)) return null;  // 20 分钟同文去重
  list.push({ at: now, text: t, tone, weight });
  state.thoughtStream = list.slice(-THOUGHT_MAX);
  return state.thoughtStream[state.thoughtStream.length - 1];
}

export function currentThoughts(state, now = Date.now()) {
  return (state?.thoughtStream || [])
    .filter(x => now - Number(x.at || 0) < THOUGHT_LIFE_MS)
    .sort((a, b) => b.at - a.at);
}

/** 注入文案：只给前 3 条、不报数值、标题明写「不一定要说出来」 */
export function thoughtContext(state, now = Date.now()) {
  const list = currentThoughts(state, now).slice(0, 3);
  if (!list.length) return '';
  return '【你脑子里刚挂着的事】（这些是你自己的念头，不一定要说出来，但会影响你怎么接话）\n' +
    list.map(x => '· ' + x.text).join('\n');
}

/** Build a short concern from real open gaps or salient memories, not a random catchphrase. */
export function suggestThought(db, state, { now = Date.now() } = {}) {
  const gap = db ? all(
    db,
    'SELECT question, tension FROM gaps WHERE resolved = 0 ORDER BY tension DESC, created_at DESC LIMIT 1'
  )[0] : null;
  if (gap?.question) return `还没想明白：${String(gap.question).slice(0, 22)}`;

  const mem = db ? all(
    db,
    `SELECT fact FROM memories
     WHERE invalid_reason IS NULL AND cold = 0 AND importance >= 0.65
     ORDER BY created_at_ms DESC, created_at DESC LIMIT 1`
  )[0] : null;
  if (mem?.fact) return `刚才那句「${String(mem.fact).slice(0, 18)}」还挂在心上`;

  const prev = currentThoughts(state, now)[0];
  if (prev) return `还在想刚才那个念头：${String(prev.text).slice(0, 18)}`;
  return '不知道他今晚会不会梦到我呢';
}

/** 缺觉影响入库：只降 confidence（让事实自动进候选），不改正文、不改 belief */
export function fatigueConfidenceFactor(state, cfg = DEFAULTS) {
  const e = clamp01(state?.energy ?? 0.7);
  const debt = clamp01(state?.sleep?.sleepDebt ?? 0);
  const floor = cfg.sleep?.lowEnergyThreshold ?? 0.20;
  if (e >= floor && debt < 0.5) return 1;
  return Math.max(0.55, 1 - (floor - Math.min(e, floor)) * 0.8 - debt * 0.15);
}

/**
 * Q5：dreamLog 超过 softLimit 才归档进 dreams 表（表由 schema 建好，不猜）。
 * 溢出前只留在 state 里——既省写放大，也不会让梦变成「记忆」。
 */
export function archiveDreams(db, state, { now = Date.now(), cfg = DEFAULTS, force = false } = {}) {
  const list = Array.isArray(state?.sleep?.dreamLog) ? state.sleep.dreamLog : [];
  const soft = Number(cfg?.v14?.dreams?.softLimit ?? 30);
  if (!force && list.length <= soft) return { archived: 0, skipped: true, count: list.length };
  let archived = 0;
  for (const d of list) {
    try {
      db.prepare(
        'INSERT INTO dreams(night, stage, level, text, from_ids, gap_ids, mood_json, clarity, created_at, archived_from) ' +
        'VALUES(?,?,?,?,?,?,?,?,?,?)'
      ).run(
        String(d.night || new Date(Number(d.at || now)).toISOString().slice(0, 10)),
        String(d.stage || 'rem'),
        Number(d.level || 1),
        String(d.text || ''),
        JSON.stringify(d.fromIds || []),
        JSON.stringify(d.gapIds || []),
        JSON.stringify(d.mood || {}),
        Number(d.clarity ?? 1),
        Number(d.at || now),
        'dreamLog'
      );
      archived += 1;
    } catch { /* 单条失败不影响其余 */ }
  }
  if (archived) state.sleep.dreamLog = [];
  return { archived, skipped: false, count: list.length };
}

/** Q5：按夜查询（面板/工具用）；表为空时返回空数组，不猜。 */
export function dreamsByNight(db, night, { limit = 20 } = {}) {
  try {
    return db.prepare('SELECT * FROM dreams WHERE night = ? ORDER BY created_at DESC LIMIT ?')
      .all(String(night), Math.max(1, Number(limit) || 20));
  } catch { return []; }
}
