// src/life/sleep.mjs — 睡眠回血（分段结算，来自一号/豆包）
// 关键：不按“总时长×速率”一次乘算，而是分段（深睡段 1.0/分，普通 0.2/分），
// 且设有自然上限（default 60/100）与 7 天积分上限。
import { DEFAULTS } from '../kit/config.mjs';

const inDeepHours = (hour, [a, b]) => (a < b ? hour >= a && hour < b : hour >= a || hour < b);

/**
 * 按分钟结算 energy（0–1 标度）。
 * @param cur 当前能量（0–1）
 * @param minutes 离线/休眠分钟数
 * @param now 结算时刻
 */
export function settleSleep(cur, minutes, now = Date.now(), cfg = DEFAULTS) {
  const s = cfg.sleep;
  const cap = Math.min(s.integralCapDays * 1440, Math.max(0, minutes));
  let energy = Math.max(0, Math.min(1, Number(cur)));
  let left = cap;
  let cursor = now - cap * 60000;

  while (left > 0) {
    const hour = new Date(cursor).getHours();
    // 计算本段持续到下一个整点或结束
    const nextHour = new Date(cursor);
    nextHour.setMinutes(0, 0, 0);
    nextHour.setHours(nextHour.getHours() + 1);
    const segMin = Math.min(left, Math.max(1, (nextHour.getTime() - cursor) / 60000));
    const deep = inDeepHours(hour, s.deepHours);
    const rate = (energy < s.lowEnergyThreshold || deep) ? s.deepRatePerMin : s.normalRatePerMin;
    energy = Math.min(1, energy + rate * segMin);
    left -= segMin;
    cursor += segMin * 60000;
  }

  // 自然上限：没有主动“喂”的情况下不超过 0.60
  const naturalCap = s.naturalCap;
  const capped = Math.min(energy, Math.max(Number(cur), naturalCap));
  return { energy: capped, raw: energy, capped: energy > capped };
}

/** 被人工“喂满”后缓慢回落（0.1/分 → 0–1 标度 0.01/分） */
export function decayOverfeed(cur, minutes, cfg = DEFAULTS) {
  const target = cfg.sleep.naturalCap;
  if (cur <= target) return cur;
  return Math.max(target, cur - 0.01 * minutes);
}

/** frozen（急停）状态不回血、不衰减：状态核冻结时整段跳过 */
export function settleLifecycle(state, { frozen = false, minutes = 0, now = Date.now(), cfg = DEFAULTS } = {}) {
  if (frozen) return { state, skipped: true };
  const { energy, capped } = settleSleep(state.energy, minutes, now, cfg);
  const s = structuredClone(state);
  s.energy = decayOverfeed(energy, 0, cfg);
  if (capped) s.flags = { ...(s.flags || {}), overfed: true };
  return { state: s, skipped: false };
}
