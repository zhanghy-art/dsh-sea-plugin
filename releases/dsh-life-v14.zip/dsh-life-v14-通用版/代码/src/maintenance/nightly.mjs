// src/maintenance/nightly.mjs — 夜间巩固 + 长期维护（第十九章）
import { DEFAULTS } from '../kit/config.mjs';
import { kvGet, kvSet } from '../kit/db.mjs';
import { scanCold } from '../memory/engine.mjs';
import { effWeight } from '../memory/weight.mjs';

export const EVENT_KEEP_DAYS = 90;
export const EVENT_KEEP_ROWS = 20000;
export const AUDIT_EVENT_KEEP_DAYS = 730;
export const AUDIT_EVENT_KEEP_ROWS = 100000;
export const AUDIT_EVENT_TYPES = ['appraisal', 'dream', 'imprint', 'belief-conflict', 'belief-resolved', 'negative-alert'];
export const CANDIDATE_KEEP_DAYS = 30;
export const INJECTION_LOG_DAYS = 30;

/** 能力熔断：连续失败 3 次 → 冻结 24h（12.8） */
export class Breaker {
  constructor(db, { threshold = 3, freezeHours = 24 } = {}) {
    this.db = db; this.threshold = threshold; this.freezeHours = freezeHours;
  }
  key(cap) { return `breaker:${cap}`; }
  fail(cap, now = Date.now()) {
    const raw = kvGet(this.db, this.key(cap));
    const s = raw ? JSON.parse(raw) : { n: 0, until: 0 };
    s.n += 1;
    if (s.n >= this.threshold) { s.until = now + this.freezeHours * 3600000; s.n = 0; }
    kvSet(this.db, this.key(cap), JSON.stringify(s));
    return { frozen: s.until > now, until: s.until };
  }
  ok(cap) { kvSet(this.db, this.key(cap), JSON.stringify({ n: 0, until: 0 })); }
  isFrozen(cap, now = Date.now()) {
    const raw = kvGet(this.db, this.key(cap));
    if (!raw) return { frozen: false };
    const s = JSON.parse(raw);
    return { frozen: s.until > now, until: s.until };
  }
  list() {
    const rows = this.db.prepare("SELECT k, v FROM kv WHERE k LIKE 'breaker:%'").all();
    return rows.map(r => ({ cap: r.k.slice(8), ...JSON.parse(r.v) }));
  }
}

/**
 * 夜间任务：04:00 之后任意时刻跑一次，同日幂等（last_nightly_day）。
 * @param db
 * @param opts { now, cfg, buildEdges?: ()=>{inserted:number}, narrate?: ()=>void }
 */
export function runNightly(db, opts = {}) {
  const now = opts.now || Date.now();
  const cfg = opts.cfg || DEFAULTS;
  const dayKey = new Date(now).toISOString().slice(0, 10);
  const last = kvGet(db, 'last_nightly_day');
  if (last === dayKey && !opts.force) return { skipped: true, dayKey };

  const report = { dayKey, candidates: 0, events: 0, auditEvents: 0, cold: 0, edges: 0, wal: 'ok', archive: 0, stampsPruned: 0, stampsKept: 0 };

  // 1) 候选过期与清理
  report.candidates = db.prepare(
    "UPDATE candidates SET status = 'expired' WHERE status = 'pending' AND expires_at < ?"
  ).run(now).changes ?? 0;
  db.prepare('DELETE FROM candidates WHERE status != ? AND created_at < ?')
    .run('pending', now - CANDIDATE_KEEP_DAYS * 86400000);

  // 2) Operational events keep 90 days / 20k rows. Long-lived memory/emotion
  // audit events keep two years / 100k rows so dreams and appraisal history remain
  // queryable without forcing two extra tables into schema v14.
  const auditTypes = AUDIT_EVENT_TYPES.map((x) => `'${x}'`).join(',');
  db.prepare(
    `DELETE FROM life_events
     WHERE COALESCE(event_type,type,'unknown') NOT IN (${auditTypes})
       AND created_at < ?`
  ).run(now - EVENT_KEEP_DAYS * 86400000);
  db.prepare(
    `DELETE FROM life_events
     WHERE COALESCE(event_type,type,'unknown') IN (${auditTypes})
       AND created_at < ?`
  ).run(now - AUDIT_EVENT_KEEP_DAYS * 86400000);
  const n = db.prepare('SELECT COUNT(*) AS n FROM life_events').get().n;
  if (n > EVENT_KEEP_ROWS) {
    const operational = db.prepare(
      `SELECT COUNT(*) AS n FROM life_events WHERE COALESCE(event_type,type,'unknown') NOT IN (${auditTypes})`
    ).get().n;
    const over = operational - EVENT_KEEP_ROWS;
    if (over > 0) {
      db.prepare(
        `DELETE FROM life_events WHERE event_id IN (
           SELECT event_id FROM life_events
           WHERE COALESCE(event_type,type,'unknown') NOT IN (${auditTypes})
           ORDER BY created_at ASC LIMIT ?
         )`
      ).run(over);
    }
  }
  const auditCount = db.prepare(
    `SELECT COUNT(*) AS n FROM life_events WHERE COALESCE(event_type,type,'unknown') IN (${auditTypes})`
  ).get().n;
  if (auditCount > AUDIT_EVENT_KEEP_ROWS) {
    db.prepare(
      `DELETE FROM life_events WHERE event_id IN (
         SELECT event_id FROM life_events
         WHERE COALESCE(event_type,type,'unknown') IN (${auditTypes})
         ORDER BY created_at ASC LIMIT ?
       )`
    ).run(auditCount - AUDIT_EVENT_KEEP_ROWS);
  }
  report.events = db.prepare('SELECT COUNT(*) AS n FROM life_events').get().n;
  report.auditEvents = db.prepare(
    `SELECT COUNT(*) AS n FROM life_events WHERE COALESCE(event_type,type,'unknown') IN (${auditTypes})`
  ).get().n;

  // 3) 注入日志 30 天
  db.prepare('DELETE FROM injection_log WHERE injected_at < ?').run(now - INJECTION_LOG_DAYS * 86400000);

  // 4) 转冷
  report.cold = scanCold(db, now, cfg, effWeight).length;

  // 5) 边生成（可选回调，避免夜间多一次模型调用）
  if (opts.buildEdges) {
    try { report.edges = opts.buildEdges()?.inserted ?? 0; } catch { report.edges = -1; }
  }

  // 5b–5f) v14 可选算子：全部由调用方显式注入，不传则与 v13.0 完全一致；
  //        每个独立 try/catch，任一失败都不影响其余夜间任务（失败不阻塞）。
  if (typeof opts.decayGaps === 'function') {
    try { report.gaps = opts.decayGaps(); } catch { report.gaps = -1; }
  }
  if (typeof opts.conflicts === 'function') {
    try { report.conflicts = opts.conflicts()?.isolated ?? 0; } catch { report.conflicts = -1; }
  }
  if (typeof opts.imprint === 'function') {
    try { report.imprint = opts.imprint()?.ok === true ? 1 : 0; } catch { report.imprint = -1; }
  }
  if (typeof opts.alerts === 'function') {
    try { report.alerts = opts.alerts()?.length ?? 0; } catch { report.alerts = -1; }
  }
  if (typeof opts.health === 'function') {
    try { report.health = opts.health(); } catch { /* ignore */ }
  }
  if (typeof opts.quota === 'function') {
    try { report.quota = opts.quota(); } catch { report.quota = -1; }
  }

  // 6) 失效记录归档。v14 preserves the row in memories as cold history:
  // "superseded/retracted" must remain explainable instead of disappearing after one night.
  //
  // [交付补丁 01] 主人/自己来源的原话永不因「年纪大」被自动删。
  // 依据：主人 2026-10-26 定的规矩「涉及不可逆删除必须先出清单给他看、他同意了才执行」；
  //       WorkBuddy 终版 U5.2 实测指出 v14 会把 source_kind='owner' 的旧盖章行删掉。
  // 判据（同时满足才保护，保证与 v14 自带 cross2 AC2「作废满 180 天的盖章行可清」不冲突）：
  //   a) source_kind 属于 owner/user/user_sentence/manual/self；
  //   b) 年龄只能从 created_at_ms 推出（valid_to_ms/cold_at_ms 都为空）——
  //      即「原话本身老」而非「已经明确盖章作废很久」。已盖章作废的行仍按 180 天清理。
  const STAMP_REASONS = ['conflict', 'superseded', 'manual', 'expired', 'duplicate', 'audit', 'retracted'];
  const OWNER_KINDS = ['owner', 'user', 'user_sentence', 'manual', 'self'];
  const dead = db.prepare(
    'SELECT id, invalid_reason, source_kind FROM memories WHERE invalid_reason IS NOT NULL LIMIT 500'
  ).all();
  for (const d of dead) {
    const row = db.prepare('SELECT * FROM memories WHERE id = ?').get(d.id);
    const exists = db.prepare('SELECT 1 AS x FROM memories_archive WHERE id = ? LIMIT 1').get(d.id);
    if (!exists) {
      db.prepare('INSERT INTO memories_archive(id, archived_at, reason, payload) VALUES(?,?,?,?)')
        .run(d.id, now, d.invalid_reason, JSON.stringify(row));
    }
    db.prepare('UPDATE memories SET cold = 1, cold_reason = COALESCE(cold_reason, ?) WHERE id = ?')
      .run('age', d.id);
    report.archive += 1;
    const retainDays = Number(cfg?.v14?.stamps?.retainDays ?? 180);
    const stampedAt = Number(row?.valid_to_ms ?? row?.cold_at_ms ?? row?.created_at_ms ?? now);
    const archiveExists = db.prepare('SELECT 1 AS x FROM memories_archive WHERE id = ? LIMIT 1').get(d.id);
    const ageOnlyFromCreatedAt = row?.valid_to_ms == null && row?.cold_at_ms == null;
    const ownerOriginal = OWNER_KINDS.includes(String(row?.source_kind ?? '')) && ageOnlyFromCreatedAt;
    if (retainDays > 0 && archiveExists && Number.isFinite(stampedAt) && now - stampedAt > retainDays * 86400000
        && !ownerOriginal) {
      db.prepare('DELETE FROM memories WHERE id = ?').run(d.id);
      report.stampsPruned += 1;
    }
  }
  // [交付补丁 01] 报告里给出「仍保留的盖章行数」，方便出清单给主人过目
  report.stampsKept = db.prepare(
    `SELECT COUNT(*) AS n FROM memories WHERE invalid_reason IS NOT NULL
     AND invalid_reason IN (${STAMP_REASONS.map(() => '?').join(',')})`
  ).get(...STAMP_REASONS).n;

  // 7) WAL 截断（必须放在最后）
  try { db.exec('PRAGMA wal_checkpoint(TRUNCATE);'); } catch { report.wal = 'failed'; }

  kvSet(db, 'last_nightly_day', dayKey);
  return report;
}

/** 容量与配额总表（19.6）的口径检查 */
export function capacityReport(db) {
  const q = (sql, ...a) => db.prepare(sql).get(...a);
  return {
    memories: q('SELECT COUNT(*) AS n FROM memories').n,
    cold: q('SELECT COUNT(*) AS n FROM memories WHERE cold = 1').n,
    hot: q('SELECT COUNT(*) AS n FROM memories WHERE cold = 0 AND invalid_reason IS NULL').n,
    candidates: q("SELECT COUNT(*) AS n FROM candidates WHERE status = 'pending'").n,
    events: q('SELECT COUNT(*) AS n FROM life_events').n,
    snapshots: q('SELECT COUNT(*) AS n FROM life_snapshots').n,
    snapshotBytes: q('SELECT COALESCE(SUM(size_bytes),0) AS n FROM life_snapshots').n,
    injections: q('SELECT COUNT(*) AS n FROM injection_log').n,
    edges: q('SELECT COUNT(*) AS n FROM edges').n,
  };
}
