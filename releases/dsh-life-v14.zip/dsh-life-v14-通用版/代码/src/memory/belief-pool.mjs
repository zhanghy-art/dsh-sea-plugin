// src/memory/belief-pool.mjs — 信念校验池 / 冲突隔离 / 不可逆印记 / 负向异常告警（v14 P3）
// 对应仿生人偶文档「四阶段排期」阶段 3–4 与「不可逆印记由调度层硬编码控制，LLM 无权写入」。
// 全部落在既有表：memories.audit_status / gaps / life_events / kv，零新增 DDL。
// 铁律：疑似冲突只隔离、不自动删除（自动判错的代价远大于漏判，留给人工终审）。
import { DEFAULTS } from '../kit/config.mjs';
import { dice, polarity, sharesTag } from './text.mjs';

const all = (db, sql, ...args) => { try { return db.prepare(sql).all(...args); } catch { return []; } };
const get = (db, sql, ...args) => { try { return db.prepare(sql).get(...args) || {}; } catch { return {}; } };

function logEvent(db, type, payload, now) {
  try {
    db.prepare('INSERT INTO life_events(event_id, revision, event_type, event_json, created_at) VALUES(?,?,?,?,?)')
      .run(`v14:${type}:${now}:${Math.random().toString(36).slice(2, 8)}`, 0, type, JSON.stringify(payload), now);
    return true;
  } catch { return false; }
}

/** 冲突检测：否定极性相反 + 共标签 + 字面相近 → 标 audit_status='conflict' 隔离 */
export function detectConflicts(db, { now = Date.now(), cfg = DEFAULTS, limit = 400 } = {}) {
  const rows = all(db,
    'SELECT id, scope, fact, tags, category, audit_status, belief FROM memories ' +
    'WHERE invalid_reason IS NULL AND cold = 0 ORDER BY COALESCE(created_at_ms, created_at) DESC LIMIT ?', limit);
  const floor = cfg.memory?.conflictDice ?? 0.35;
  const found = [];
  let isolated = 0;
  for (let i = 0; i < rows.length; i++) {
    for (let j = i + 1; j < rows.length; j++) {
      const a = rows[i], b = rows[j];
      if (a.scope !== b.scope) continue;                 // 跨舱不判，防泄漏
      if (a.audit_status === 'conflict' || b.audit_status === 'conflict') continue;
      if (dice(String(a.fact), String(b.fact)) < floor) continue;
      if (!sharesTag(a.tags, b.tags) && a.category !== b.category) continue;
      if (polarity(String(a.fact)) === polarity(String(b.fact))) continue;
      found.push({ a: a.id, b: b.id, scope: a.scope, reason: 'polarity-conflict' });
      // 只隔离「更不可信」的一方；不删、不改正文
      const weaker = (Number(b.belief ?? 0.6) <= Number(a.belief ?? 0.6)) ? b : a;
      try {
        db.prepare("UPDATE memories SET audit_status = 'conflict' WHERE id = ? AND (audit_status IS NULL OR audit_status = 'ok')")
          .run(weaker.id);
        isolated++;
      } catch { /* 旧库无列则只记录 */ }
      if (found.length >= 20) break;
    }
    if (found.length >= 20) break;
  }
  if (found.length) logEvent(db, 'belief-conflict', { count: found.length, pairs: found.slice(0, 5), isolated }, now);
  return { found, isolated };
}

export function listConflicts(db, { limit = 50, scope = null } = {}) {
  if (scope) {
    return all(db,
      "SELECT id, scope, fact, category, audit_status FROM memories WHERE audit_status = 'conflict' AND scope = ? LIMIT ?",
      scope, limit);
  }
  return all(db, "SELECT id, scope, fact, category, audit_status FROM memories WHERE audit_status = 'conflict' LIMIT ?", limit);
}

/** 解除隔离（人工终审后的唯一合法入口） */
export function resolveConflict(db, id, { verdict = 'ok', now = Date.now() } = {}) {
  try {
    db.prepare('UPDATE memories SET audit_status = ? WHERE id = ?').run(verdict, id);
    logEvent(db, 'belief-resolved', { id, verdict }, now);
    return { ok: true, id, verdict };
  } catch (e) { return { ok: false, reason: e.message }; }
}

/**
 * 不可逆印记生成闸门（调度层硬编码，LLM 无权写入）。
 * 条件全部满足才生成：重大事件 + importance 达标 + 独立证据 + 冷却期 + 未超上限。
 * 印记只影响表达倾向，不改事实、不进 effWeight。
 */
export function generateImprint(db, mem, { now = Date.now(), cfg = DEFAULTS, maxImprints = 12, cooldownDays = 30, independentEvidence = 0 } = {}) {
  const gate = {
    importance: Number(mem?.importance ?? 0) >= 0.85,
    category: ['person', 'promise', 'rule', 'event'].includes(String(mem?.category || '')),
    evidence: independentEvidence >= 2,
    notHypothetical: !String(mem?.anchor_ground || '').includes('hypothetical'),
  };
  if (Object.values(gate).some(v => !v)) return { ok: false, reason: 'gate', gate };
  const count = Number(get(db, "SELECT COUNT(*) AS n FROM life_events WHERE event_type = 'imprint'").n || 0);
  if (count >= maxImprints) return { ok: false, reason: 'cap', count };
  const last = all(db, "SELECT created_at FROM life_events WHERE event_type = 'imprint' ORDER BY created_at DESC LIMIT 1");
  if (last.length && now - Number(last[0].created_at) < cooldownDays * 86400000) {
    return { ok: false, reason: 'cooldown' };
  }
  const payload = {
    memoryId: mem.id, at: now, gate,
    irreversible: true, llmWritable: false, source: 'scheduler-hardcoded',
    effect: 'expression-bias-only',
  };
  const ok = logEvent(db, 'imprint', payload, now);
  return { ok, ...(ok ? { imprint: payload } : { reason: 'log-failed' }) };
}

/** 负向异常告警：状态越界 / 冲突堆积 / 候选积压 / 检索降级过多 / 死链回潮 */
export function negativeAlerts(db, state, { now = Date.now(), cfg = DEFAULTS } = {}) {
  const alerts = [];
  const h = state?.hormones || {};
  for (const [k, v] of Object.entries(h)) {
    if (!Number.isFinite(Number(v)) || Number(v) < 0 || Number(v) > 1) alerts.push({ level: 'high', kind: 'hormone-out-of-range', key: k, value: v });
  }
  const conflicts = Number(get(db, "SELECT COUNT(*) AS n FROM memories WHERE audit_status = 'conflict'").n || 0);
  if (conflicts > 5) alerts.push({ level: 'mid', kind: 'conflict-backlog', count: conflicts });
  const pending = Number(get(db, "SELECT COUNT(*) AS n FROM candidates WHERE status = 'pending'").n || 0);
  if (pending > 200) alerts.push({ level: 'mid', kind: 'candidate-backlog', count: pending });
  let stats = {};
  try { stats = JSON.parse(get(db, "SELECT v FROM kv WHERE k = 'retrieval_stats:fallback'").v || '{}'); } catch { /* ignore */ }
  if (Number(stats.total || 0) > 100) alerts.push({ level: 'mid', kind: 'retrieval-degradation', count: stats.total });
  const edges = Number(get(db, 'SELECT COUNT(*) AS n FROM edges').n || 0);
  if (edges === 0) alerts.push({ level: 'low', kind: 'edges-empty', hint: '建边未接入或尚未跑夜间巩固' });
  if (alerts.length) logEvent(db, 'negative-alert', { alerts }, now);
  return alerts;
}

/** 一致性抽样口径：偏好表「三十次回答前后一致」的可核对基线（只读） */
export function consistencySample(db, { now = Date.now(), limit = 30, scope = null } = {}) {
  const scoped = scope ? ' AND scope = ?' : '';
  const args = scope ? [scope, limit] : [limit];
  const rows = all(db,
    "SELECT id, fact, category, importance, audit_status FROM memories " +
    "WHERE category IN ('preference','person','rule') AND invalid_reason IS NULL AND cold = 0 " +
    "AND (audit_status IS NULL OR audit_status = 'ok')" + scoped +
    " ORDER BY importance DESC LIMIT ?", ...args);
  return { sampled: rows.length, target: 30, stable: rows.filter(r => Number(r.importance) >= 0.7).length, items: rows.map(r => r.id) };
}
