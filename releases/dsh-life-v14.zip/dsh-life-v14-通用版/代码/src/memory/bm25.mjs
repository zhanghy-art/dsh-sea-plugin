// src/memory/bm25.mjs — 字面相关性打分（v14 P2：修 v13.0 D5「LIKE 保底无相关性」）
// 纯 JS、零依赖。候选集内算局部 IDF，不额外全表扫描。
// 借鉴 Gitee ai-companion-dashboard/memory2.mjs 的 bigram + IDF + 共现联想思路。
// 铁律：只产出排序分，不写库、不进 effWeight。
import { shingles } from './text.mjs';
import { scopeClause } from '../kit/scope.mjs';

const STOP = new Set(['的', '了', '是', '我', '你', '他', '她', '它', '在', '和', '就', '都', '也', '不', '吗', '呢', '啊', '吧', '这', '那', '有', '没']);
const COMMON = new Set(['他说', '我说', '什么', '这个', '那个', '可以', '就是', '没有', '知道', '不是', '这样', '那样', '时候', '自己', '一个', '现在', '今天', '感觉', '好像']);

export function termsOf(text) {
  const out = new Set();
  for (const g of shingles(text)) {
    const t = String(g).trim();
    if (!t || STOP.has(t) || COMMON.has(t)) continue;
    out.add(t);
  }
  return [...out];
}

/** 共现联想：候选集内两两配对，每词保留权重最高的 8 个邻居 */
export function buildCooc(docs, { topN = 8, minCount = 2 } = {}) {
  const pair = new Map();
  for (const d of docs) {
    const gs = termsOf(`${d.fact || ''} ${d.tags || ''}`).slice(0, 28);
    if (gs.length < 2) continue;
    for (let i = 0; i < gs.length; i++) {
      for (let j = i + 1; j < gs.length; j++) {
        const k = gs[i] < gs[j] ? gs[i] + '\u0000' + gs[j] : gs[j] + '\u0000' + gs[i];
        pair.set(k, (pair.get(k) || 0) + 1);
      }
    }
  }
  const byTerm = new Map();
  for (const [k, c] of pair) {
    if (c < minCount) continue;
    const [a, b] = k.split('\u0000');
    if (!byTerm.has(a)) byTerm.set(a, []);
    if (!byTerm.has(b)) byTerm.set(b, []);
    byTerm.get(a).push([b, c]);
    byTerm.get(b).push([a, c]);
  }
  for (const [t, arr] of byTerm) {
    arr.sort((x, y) => y[1] - x[1]);
    byTerm.set(t, arr.slice(0, topN));
  }
  return byTerm;
}

/**
 * BM25 打分（结果归一到 0–1，便于与 cos / dice 融合）。
 * @param docs [{id, fact, tags}]
 * @returns {{scores:Map<number,number>, debug:object}}
 */
export function bm25Rank(query, docs = [], { k1 = 1.5, b = 0.75, cooc = true, minRel = 0 } = {}) {
  const qTerms = termsOf(query);
  const scores = new Map();
  if (!qTerms.length || !docs.length) return { scores, debug: { qTerms: 0, docs: 0, avgdl: 0 } };

  const tokenized = docs.map(d => ({
    id: d.id,
    terms: termsOf(`${d.fact || ''} ${d.tags || ''}`),
  }));
  const n = tokenized.length;
  let totalLen = 0;
  const df = new Map();
  for (const t of tokenized) {
    totalLen += t.terms.length || 1;
    for (const g of new Set(t.terms)) df.set(g, (df.get(g) || 0) + 1);
  }
  const avgdl = totalLen / Math.max(1, n);

  const co = cooc ? buildCooc(docs) : new Map();
  const expand = new Map();
  for (const q of qTerms) {
    for (const [w, c] of (co.get(q) || [])) {
      const weight = Math.min(1, c / 6);
      if (weight > (expand.get(w) || 0)) expand.set(w, weight);
    }
  }

  const raw = new Map();
  let maxRaw = 0;
  for (const t of tokenized) {
    const dl = t.terms.length || 1;
    const tf = new Map();
    for (const g of t.terms) tf.set(g, (tf.get(g) || 0) + 1);
    let s = 0, hits = 0;
    for (const q of qTerms) {
      const f = tf.get(q) || 0;
      if (!f) continue;
      hits++;
      const idf = Math.log(1 + (n - (df.get(q) || 0) + 0.5) / ((df.get(q) || 0) + 0.5));
      s += idf * (f * (k1 + 1)) / (f + k1 * (1 - b + b * dl / Math.max(1e-6, avgdl)));
    }
    // 共现扩展命中：0.45 * w（与 Gitee memory2 同口径），只在已有字面命中时生效
    if (hits > 0) {
      for (const [w, weight] of expand) if (tf.has(w)) s += 0.45 * weight;
    }
    if (s > maxRaw) maxRaw = s;
    raw.set(t.id, s);
  }
  for (const [id, s] of raw) {
    const v = maxRaw > 0 ? Math.min(1, s / maxRaw) : 0;
    if (v > minRel) scores.set(id, v);
  }
  return {
    scores,
    debug: { qTerms: qTerms.length, docs: n, avgdl: Number(avgdl.toFixed(2)), expand: expand.size, maxRaw: Number(maxRaw.toFixed(3)) },
  };
}

/** 供 L0 保底用：从全库挑字面最相关的一批 id（不排序、只给候选） */
export function bm25Candidates(db, query, { scopes = null, limit = 20, cfg } = {}) {
  let rows = [];
  try {
    const scoped = scopes?.length ? scopeClause(scopes) : { sql: '1=1', params: [] };
    const where = `WHERE ${scoped.sql.replace(/\bscope\b/g, 'scope')} AND invalid_reason IS NULL AND cold = 0`;
    rows = db.prepare(`SELECT id, fact, tags FROM memories ${where} ORDER BY COALESCE(confirmed_at_ms, created_at_ms) DESC LIMIT 600`)
      .all(...scoped.params);
  } catch { return []; }
  const { scores } = bm25Rank(query, rows);
  return [...scores.entries()].sort((a, b) => b[1] - a[1]).slice(0, limit)
    .map(([id, score]) => ({ id, score }));
}

function ftsQueryOf(query) {
  const text = String(query || '').trim();
  const terms = new Set();
  for (const word of text.match(/[A-Za-z0-9_]{2,}/g) || []) terms.add(word);
  for (const run of text.match(/[\u4e00-\u9fa5]+/g) || []) {
    if (run.length < 3) continue;
    for (let i = 0; i + 3 <= run.length; i++) terms.add(run.slice(i, i + 3));
  }
  return [...terms].slice(0, 12).map((t) => `"${t.replace(/"/g, '""')}"`).join(' OR ');
}

/**
 * FTS5-first candidate lookup. Short CJK queries (one/two characters) use LIKE,
 * because SQLite trigram cannot produce a token. Any FTS error degrades to LIKE.
 */
export function ftsCandidates(db, query, { scopes = null, limit = 600 } = {}) {
  const text = String(query || '').trim();
  if (!text) return [];
  const scoped = scopes?.length ? scopeClause(scopes) : { sql: '1=1', params: [] };
  const scopeSql = scoped.sql.replace(/\bscope\b/g, 'm.scope');
  const scopeParams = scoped.params;
  const match = ftsQueryOf(text);
  if (match) {
    try {
      const rows = db.prepare(
        `SELECT m.*, bm25(mem_fts) AS _fts_rank FROM mem_fts JOIN memories m ON m.rowid = mem_fts.rowid
         WHERE mem_fts MATCH ? AND ${scopeSql} AND m.invalid_reason IS NULL AND m.cold = 0
         ORDER BY bm25(mem_fts), COALESCE(m.created_at_ms, m.created_at) DESC LIMIT ?`
      ).all(match, ...scopeParams, Math.max(1, Number(limit) || 600));
      return rows.map((row) => {
        const rank = Number(row._fts_rank) || 0;
        const out = { ...row, _fts_score: 1 / (1 + Math.exp(rank)) };
        delete out._fts_rank;
        return out;
      });
    } catch { /* fall back to LIKE below */ }
  }
  try {
    const like = `%${text.slice(0, 30).replace(/[%_]/g, '')}%`;
    return db.prepare(
      `SELECT m.* FROM memories m
       WHERE ${scopeSql} AND (m.fact LIKE ? OR m.tags LIKE ?)
         AND m.invalid_reason IS NULL AND m.cold = 0
       ORDER BY COALESCE(m.created_at_ms, m.created_at) DESC LIMIT ?`
    ).all(...scopeParams, like, like, Math.max(1, Math.min(300, Number(limit) || 300)))
      .map((row) => ({ ...row, _fts_score: 0.65 }));
  } catch {
    return [];
  }
}
