// src/memory/edges.mjs — 让 edges 表有真实写入方（v13.0 D3：表恒空，面板只能 hash 摆坐标）
// 边只允许四种「真实发生过」的来源，每条边落库存 basis，可回答「为什么连」。
// 幂等：ON CONFLICT(from_id,to_id,type) DO UPDATE，重复建边只巩固权重，不产生重复行。
// 铁律：只影响可视化与一跳召回顺序，不写 memories 正文、不进 effWeight、不改可信度。
import { DEFAULTS } from '../kit/config.mjs';
import { dice, shingles } from './text.mjs';

const all = (db, sql, ...args) => { try { return db.prepare(sql).all(...args); } catch { return []; } };
const run = (db, sql, ...args) => { try { return db.prepare(sql).run(...args); } catch { return null; } };

/** 老库 edges 无 basis 列时自愈补列（只加列，不动旧行） */
export function ensureBasisColumn(db) {
  const cols = all(db, 'PRAGMA table_info(edges)').map(r => r.name);
  if (cols.includes('basis')) return { added: false };
  const r = run(db, 'ALTER TABLE edges ADD COLUMN basis TEXT');
  return { added: !!r };
}

function upsert(db, map, from, to, type, weight, basis, now) {
  if (from == null || to == null || String(from) === String(to)) return;
  const key = `${from}|${to}|${type}`;
  const prev = map.get(key);
  if (prev) { prev.weight = Math.min(1, prev.weight + 0.05); return; }
  map.set(key, { from_id: from, to_id: to, type, weight: Math.max(0.05, Math.min(1, weight)), basis, created_at: now });
}

/**
 * 从既有事实重建边。
 * @param opts {{now, scanLimit, pairCap, simFloor, dryRun}}
 * @returns {{inserted:number, bySource:object, real:boolean, dryRun:boolean}}
 */
export function buildEdges(db, opts = {}) {
  const now = opts.now || Date.now();
  const scanLimit = opts.scanLimit || 800;
  const pairCap = opts.pairCap || 8;
  const simFloor = opts.simFloor ?? 0.45;
  const dryRun = opts.dryRun === true;
  ensureBasisColumn(db);

  const map = new Map();
  const bySource = { 'co-recall': 0, 'co-creat': 0, supersede: 0, similar: 0 };
  const bump = (type) => { bySource[type] = (bySource[type] || 0) + 1; };

  // 1) co-recall：同一轮被一起想起（injection_log 同 turn_id）
  const inj = all(db,
    'SELECT memory_id, turn_id FROM injection_log WHERE turn_id IS NOT NULL ORDER BY injected_at DESC LIMIT 2000');
  const byTurn = new Map();
  for (const r of inj) {
    if (!byTurn.has(r.turn_id)) byTurn.set(r.turn_id, []);
    const arr = byTurn.get(r.turn_id);
    if (arr.length < 6 && !arr.includes(r.memory_id)) arr.push(r.memory_id);
  }
  for (const [turn, ids] of byTurn) {
    for (let i = 0; i < ids.length; i++) {
      for (let j = i + 1; j < ids.length; j++) {
        upsert(db, map, ids[i], ids[j], 'co-recall', 0.5, { turn, source: 'injection_log' }, now);
        upsert(db, map, ids[j], ids[i], 'co-recall', 0.5, { turn, source: 'injection_log' }, now);
        bump('co-recall');
      }
    }
  }

  // 2) co-creat：出自同一句话 / 同一窗口（origin_key 相同）
  const rows = all(db,
    'SELECT id, scope, fact, origin_key, supersedes, tags FROM memories ' +
    'WHERE invalid_reason IS NULL ORDER BY COALESCE(created_at_ms, created_at) DESC LIMIT ?', scanLimit);
  const byOrigin = new Map();
  for (const r of rows) {
    const k = String(r.origin_key || '');
    if (!k || k === 'null' || k === 'undefined') continue;
    if (!byOrigin.has(k)) byOrigin.set(k, []);
    byOrigin.get(k).push(r);
  }
  for (const [k, group] of byOrigin) {
    for (let i = 0; i < group.length; i++) {
      for (let j = i + 1; j < group.length; j++) {
        upsert(db, map, group[i].id, group[j].id, 'co-creat', 0.6, { origin_key: k }, now);
        upsert(db, map, group[j].id, group[i].id, 'co-creat', 0.6, { origin_key: k }, now);
        bump('co-creat');
      }
    }
  }

  // 3) supersede：写入管线第 9 步判定过的替代关系
  for (const r of rows) {
    if (!r.supersedes) continue;
    upsert(db, map, r.supersedes, r.id, 'supersede', 0.9, { rule: 'write-pipeline-step9' }, now);
    bump('supersede');
  }

  // 4) similar：同 scope 内 2-gram dice >= simFloor（跨舱不建，防泄漏）
  const byScope = new Map();
  for (const r of rows) {
    const s = String(r.scope || '');
    if (!byScope.has(s)) byScope.set(s, []);
    byScope.get(s).push(r);
  }
  for (const group of byScope.values()) {
    for (let i = 0; i < group.length && i < scanLimit; i++) {
      let n = 0;
      for (let j = i + 1; j < group.length && n < pairCap; j++) {
        const sim = dice(String(group[i].fact || ''), String(group[j].fact || ''));
        if (sim < simFloor) continue;
        upsert(db, map, group[i].id, group[j].id, 'similar', sim, { dice: Number(sim.toFixed(3)) }, now);
        upsert(db, map, group[j].id, group[i].id, 'similar', sim, { dice: Number(sim.toFixed(3)) }, now);
        bump('similar'); n++;
      }
    }
  }

  // 每节点最多 pairCap 条边（先按权重排序再截，避免随机截掉强边）
  const perNode = new Map();
  for (const e of map.values()) {
    if (!perNode.has(e.from_id)) perNode.set(e.from_id, []);
    perNode.get(e.from_id).push(e);
  }
  const kept = [];
  for (const list of perNode.values()) {
    list.sort((a, b) => b.weight - a.weight);
    kept.push(...list.slice(0, pairCap));
  }

  if (!dryRun) {
    const hasBasis = all(db, 'PRAGMA table_info(edges)').some(r => r.name === 'basis');
    const st = db.prepare(hasBasis
      ? 'INSERT INTO edges(from_id,to_id,type,weight,created_at,basis) VALUES(?,?,?,?,?,?) ' +
        'ON CONFLICT(from_id,to_id,type) DO UPDATE SET ' +
        'weight = MIN(1, edges.weight + excluded.weight * 0.2), basis = excluded.basis'
      : 'INSERT INTO edges(from_id,to_id,type,weight,created_at) VALUES(?,?,?,?,?) ' +
        'ON CONFLICT(from_id,to_id,type) DO UPDATE SET ' +
        'weight = MIN(1, edges.weight + excluded.weight * 0.2)');
    for (const e of kept) {
      try {
        if (hasBasis) st.run(e.from_id, e.to_id, e.type, e.weight, e.created_at, JSON.stringify(e.basis));
        else st.run(e.from_id, e.to_id, e.type, e.weight, e.created_at);
      } catch { /* 端点不存在 / 旧库约束则跳过，不影响主链路 */ }
    }
  }
  return { inserted: kept.length, bySource, real: kept.length > 0, dryRun };
}

/** 只读真实边；表为空返回 real:false，前端据此画「还没有关联」，绝不用下标/哈希补边 */
export function readGraph(db, { limit = 500, cfg = DEFAULTS } = {}) {
  const edges = all(db,
    'SELECT from_id, to_id, type, weight, basis FROM edges ORDER BY weight DESC LIMIT ?', limit);
  const ids = new Set();
  for (const e of edges) { ids.add(e.from_id); ids.add(e.to_id); }
  let nodes = [];
  if (ids.size) {
    const ph = [...ids].map(() => '?').join(',');
    nodes = all(db, `SELECT id, scope, category, fact FROM memories WHERE id IN (${ph})`, ...ids)
      .map(r => ({ id: r.id, scope: r.scope, category: r.category, label: String(r.fact || '').slice(0, 24) }));
  }
  return {
    edges: edges.map(e => {
      let basis = null;
      try { basis = JSON.parse(e.basis || 'null'); } catch { /* ignore */ }
      return { from_id: e.from_id, to_id: e.to_id, type: e.type, weight: e.weight, basis };
    }),
    nodes,
    real: edges.length > 0,
  };
}

export { shingles };
