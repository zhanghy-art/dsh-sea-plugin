// src/memory/embedding-cache.mjs — LRU 500 + 磁盘持久化 + 预热（2.18）
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'node:fs';
import { dirname } from 'node:path';

const keyOf = (text) => createHash('sha256').update(String(text)).digest('hex').slice(0, 32);

export class EmbeddingCache {
  /**
   * @param {string} diskPath  JSON 落盘路径（如 ~/.dsh/dsh-life/embed-cache.json）
   * @param {(text:string)=>Promise<Float32Array|null>} compute
   * @param {number} limit     LRU 容量，默认 500
   */
  constructor(diskPath, compute, limit = 500) {
    this.path = diskPath;
    this.compute = compute;
    this.limit = limit;
    this.map = new Map();     // key -> number[]（落盘友好）
    this.inflight = new Map();
    this.hits = 0; this.misses = 0;
    this.dirty = false;
    this.#load();
  }

  #load() {
    try {
      if (this.path && existsSync(this.path)) {
        const raw = JSON.parse(readFileSync(this.path, 'utf8'));
        for (const [k, v] of Object.entries(raw)) this.map.set(k, v);
      }
    } catch { /* 缓存坏了就当空 */ }
  }

  flush() {
    if (!this.dirty || !this.path) return;
    try {
      mkdirSync(dirname(this.path), { recursive: true });
      writeFileSync(this.path, JSON.stringify(Object.fromEntries(this.map)));
      this.dirty = false;
    } catch { /* 落盘失败不影响主流程 */ }
  }

  get(text) {
    const k = keyOf(text);
    if (this.map.has(k)) {
      const v = this.map.get(k);
      this.map.delete(k); this.map.set(k, v);   // LRU 提升
      this.hits++;
      return Float32Array.from(v);
    }
    return null;
  }

  async getOrCompute(text) {
    const hit = this.get(text);
    if (hit) return hit;
    const k = keyOf(text);
    if (this.inflight.has(k)) return this.inflight.get(k);
    const p = (async () => {
      this.misses++;
      const vec = await this.compute(text).catch(() => null);
      if (vec) {
        this.map.set(k, Array.from(vec, x => Math.round(x * 1000) / 1000)); // 浮点 3 位
        while (this.map.size > this.limit) this.map.delete(this.map.keys().next().value);
        this.dirty = true;
      }
      this.inflight.delete(k);
      return vec;
    })();
    this.inflight.set(k, p);
    return p;
  }

  /** 消息到达即预热：不 await，失败静默 */
  warm(text) {
    if (!text) return;
    this.getOrCompute(text).catch(() => {});
  }

  stats() {
    const n = this.hits + this.misses;
    return { size: this.map.size, hits: this.hits, misses: this.misses, hitRate: n ? this.hits / n : 0 };
  }
}
