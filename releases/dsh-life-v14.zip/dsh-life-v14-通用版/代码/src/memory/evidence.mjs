// src/memory/evidence.mjs — 证据独立性与 core 晋升判定（2.23）
// 为什么要独立键：core 准入要求“两条独立证据”，没有独立键就只能数条数，数条数会被同一段对话刷满。
export function addEvidence(db, memoryId, { independentKey, sourceKind, sourceId, ref, now = Date.now() }) {
  db.prepare(`INSERT OR IGNORE INTO memory_evidence
    (id, memory_id, independent_key, source_kind, source_id, ref, created_at)
    VALUES (?,?,?,?,?,?,?)`).run(
    'e' + Math.random().toString(16).slice(2, 10), memoryId, independentKey, sourceKind || 'user', sourceId || null, ref || null, now
  );
  const n = db.prepare('SELECT COUNT(*) AS n FROM memory_evidence WHERE memory_id = ?').get(memoryId).n;
  db.prepare('UPDATE memories SET evidence_count = ?, confirm_count = ? WHERE id = ?')
    .run(n, n > 1 ? n - 1 : 0, memoryId);
  return n;
}

export function independentEvidenceCount(db, memoryId) {
  return db.prepare('SELECT COUNT(DISTINCT independent_key) AS n FROM memory_evidence WHERE memory_id = ?').get(memoryId).n;
}

export function hasUserConfirm(db, memoryId) {
  const r = db.prepare(
    "SELECT COUNT(*) AS n FROM memory_evidence WHERE memory_id = ? AND source_kind IN ('user','manual')"
  ).get(memoryId).n;
  return r > 0;
}

export function hasUnresolvedConflict(db, memoryId) {
  const r = db.prepare(
    "SELECT COUNT(*) AS n FROM memories WHERE supersedes = ? AND invalid_reason IS NULL"
  ).get(memoryId).n;
  return r > 0;
}

/** 一条记忆够不够进 core（供 engine / nightly 调用） */
export function evaluateCore(db, memoryId, { now = Date.now(), classify } = {}) {
  const mem = db.prepare('SELECT * FROM memories WHERE id = ?').get(memoryId);
  if (!mem) return { ok: false, reason: 'not-found' };
  const ctx = {
    independentEvidence: independentEvidenceCount(db, memoryId),
    userConfirm: hasUserConfirm(db, memoryId),
    unresolvedConflict: hasUnresolvedConflict(db, memoryId),
    now,
  };
  return classify(mem, ctx);
}

/** 晋升：只由证据与时间驱动，绝不由“被想起的次数”驱动（防马太效应） */
export function promoteTier(db, memoryId, { now = Date.now(), classify } = {}) {
  const ev = evaluateCore(db, memoryId, { now, classify });
  if (!ev.ok) return ev;
  db.prepare("UPDATE memories SET protection_tier = 'core' WHERE id = ?").run(memoryId);
  return { ok: true, tier: 'core' };
}
