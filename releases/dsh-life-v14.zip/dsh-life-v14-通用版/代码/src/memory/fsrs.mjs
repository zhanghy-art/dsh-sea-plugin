// src/memory/fsrs.mjs — 复习调度（FSRS 简化版，来自六号）
// 作用：把“想起来”从被动召回扩展到主动提醒——“这条快忘了吧，该问一句了”。
// 约束：每轮最多浮 1 条、6 小时冷却、不占长期事实预算（借状态行余量）。
import { DEFAULTS } from '../kit/config.mjs';

export function stabilityDays(hits, cfg = DEFAULTS) {
  return Math.min(cfg.fsrs.stabilityCap, Math.max(1, Math.pow(2, Math.max(0, hits))));
}

/** 复习一次：stability 变长，due 推后 */
export function touchReview(mem, now = Date.now(), cfg = DEFAULTS) {
  const hits = Number(mem.recall_count ?? 0) + 1;
  const st = stabilityDays(hits, cfg);
  return {
    recall_count: hits,
    last_recalled: now,
    review_stability: st,
    review_due_at: now + st * 86400000,
  };
}

/**
 * 浮卡：该不该在今天提醒一句。
 * 条件：到期 + 当前检索分够 + 距上次提示 >6h + 每轮 ≤1 条。
 */
export function pickReviewCard(db, { now = Date.now(), scoreOf, cfg = DEFAULTS, lastFloatAt = 0 } = {}) {
  if (!cfg.fsrs.enabled) return null;
  if (now - lastFloatAt < cfg.fsrs.floatCooldownMinutes * 60000) return null;
  const rows = db.prepare(
    `SELECT * FROM memories
     WHERE invalid_reason IS NULL AND cold = 0
       AND review_due_at IS NOT NULL AND review_due_at <= ?
       AND protection_tier IN ('core','stable')
     ORDER BY review_due_at ASC LIMIT 5`
  ).all(now);
  for (const mem of rows) {
    const s = scoreOf ? scoreOf(mem) : 1;
    if (s < cfg.fsrs.floatMinScore) continue;
    return { mem, score: s, prompt: reviewPrompt(mem) };
  }
  return null;
}

/** 复习提示只给“问什么”，不给原文，避免变成复述（防穿帮） */
export function reviewPrompt(mem) {
  const topic = String(mem.fact || '').slice(0, 12);
  return `（想起了之前聊过的「${topic}」，可以顺口问一句，不要复述细节）`;
}

export function markFloated(db, id, now = Date.now(), cfg = DEFAULTS) {
  // v13.0 修复：浮卡=一次“想起来”，必须走 touchReview（stability 变长、due 推后），
  // 否则 review_due_at 永不前进，同一张卡天天浮、stability 永不增长。
  const mem = db.prepare('SELECT recall_count FROM memories WHERE id = ?').get(id);
  const next = touchReview(mem || {}, now, cfg);
  db.prepare('UPDATE memories SET recall_count = ?, last_recalled = ?, review_stability = ?, review_due_at = ? WHERE id = ?')
    .run(next.recall_count, next.last_recalled, next.review_stability, next.review_due_at, id);
}
