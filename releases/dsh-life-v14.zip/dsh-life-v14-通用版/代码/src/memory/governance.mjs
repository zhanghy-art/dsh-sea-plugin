// src/memory/governance.mjs — 记忆治理层（v14 P2）
// 汇总四份参考里可叠加、且不破坏 v13 写入管线的部分：
//   · 来源五档 owner > self > evidence > tool > inferred（dsh-identity-relay v0.3）
//   · 同键 subject 规则替换 / 盖章作废不删行 / 翻案（同上）
//   · 凭据拦截（同上 FAQ Q7）、假设语气打标（后补建议第 3 条）
//   · 自动提取事实（Mem0 借鉴）与 agent 自管记忆（Letta 借鉴）：只产候选，不直写
//   · 新会话重读高权重记忆（图 S7-3「换个新脑子这页又翻不到了」）
// 铁律：复用 writeMemory 15 步，不新开写入通道；低置信一律进 candidates；不物理删除任何行。
import { DEFAULTS } from '../kit/config.mjs';
import { dice } from './text.mjs';
import { hasCredential, isHypothetical, HYPOTHETICAL_KIND } from '../life/lexicon.mjs';
import { attachFingerprint } from '../life/affect-fingerprint.mjs';
import { fatigueConfidenceFactor } from '../life/sleep-stage.mjs';

export const SOURCE_TRUST = { owner: 0.95, self: 0.90, evidence: 0.78, tool: 0.65, inferred: 0.55, unknown: 0.55 };
export const SOURCE_ALIAS = {
  owner: 'owner', user: 'owner', user_sentence: 'owner', manual: 'owner',
  self: 'self', bot: 'self', promise: 'self',
  evidence: 'evidence', observed: 'evidence', world: 'evidence',
  tool: 'tool', tool_explicit: 'tool',
  inferred: 'inferred', model_inference: 'inferred', guess: 'inferred',
};

export function normalizeSource(kind) {
  const k = String(kind || '').toLowerCase();
  return SOURCE_ALIAS[k] || (k ? 'unknown' : 'unknown');
}

const all = (db, sql, ...args) => { try { return db.prepare(sql).all(...args); } catch { return []; } };
const get = (db, sql, ...args) => { try { return db.prepare(sql).get(...args) || null; } catch { return null; } };

/**
 * 写入前治理钩子（在 writeMemory 之前调用，返回新 input 或 {rejected}）。
 * 不改 writeMemory 的一个字节 —— 所有裁决都通过既有 input 字段表达。
 */
export function preWrite(db, input, { cfg = DEFAULTS, state = null } = {}) {
  const fact = String(input?.fact || '').trim();
  if (!fact) return { rejected: true, reason: 'empty' };

  // 1) 凭据拦截
  if (hasCredential(fact) || hasCredential(input.evidence)) return { rejected: true, reason: 'credential' };

  // 2) 来源五档 → belief 上限（写入时定档，不靠读的时候猜）
  const src = normalizeSource(input.source_kind || input.belief_src || input.evidence_kind);
  const cap = SOURCE_TRUST[src] ?? SOURCE_TRUST.unknown;
  const out = { ...input, source_kind: input.source_kind || src };
  if (out.belief != null) out.belief = Math.min(Number(out.belief), cap);
  else out.belief_src = src === 'owner' ? 'owner' : src === 'self' ? 'user_confirm' : 'inferred';

  // 3) 假设语气打标：kind=hypothetical 塞 anchor_ground（零 DDL），永不作为事实
  const hyp = isHypothetical(fact);
  let ag = {};
  if (out.anchor_ground) {
    try { ag = typeof out.anchor_ground === 'string' ? JSON.parse(out.anchor_ground) : { ...out.anchor_ground }; }
    catch { ag = {}; }
  }
  if (hyp.kind) {
    ag.kind = HYPOTHETICAL_KIND;
    ag.hedge = hyp.markers;
    out.confidence = Math.min(Number(out.confidence ?? 0.8), 0.55);   // 假设一律进候选
    out.belief = Math.min(Number(out.belief ?? cap), 0.55);
  }

  // 4) 同键 subject 规则替换：复用 engine 第 9 步的 attr_key 换值逻辑，不重复实现
  if (out.subject && !out.attr_key) { out.attr_key = 'subject:' + String(out.subject); out.attr_value = fact; }

  // 5) inferred 写入拦截：撞明确来源（user/manual/legacy）则合并，不新增（小鲸鱼 #47/#48 案例）
  if (out.source_kind === 'inferred' || src === 'inferred' || src === 'unknown') {
    const scope = out.scope;
    const prior = all(db,
      'SELECT id, fact, source_kind FROM memories WHERE scope = ? AND invalid_reason IS NULL ' +
      'ORDER BY COALESCE(created_at_ms, created_at) DESC LIMIT 120', scope);
    for (const p of prior) {
      if (normalizeSource(p.source_kind) === 'inferred') continue;
      const sim = dice(fact, String(p.fact || ''));
      const contain = String(p.fact || '').includes(fact) || fact.includes(String(p.fact || '')) ? 1 : 0;
      if (sim < 0.78 && !contain) continue;
      try {
        db.prepare('UPDATE memories SET uses = uses + 1, confirmed_at_ms = ? WHERE id = ?').run(Date.now(), p.id);
      } catch { /* 旧库无列则跳过 */ }
      return { rejected: true, reason: 'inferred-merged', duplicateOf: p.id };
    }
  }

  // 6) 缺觉影响入库：只降 confidence → 自动进 candidates，不改事实
  if (state) {
    const f = fatigueConfidenceFactor(state, cfg);
    if (f < 1) out.confidence = Number(out.confidence ?? 0.8) * f;
  }

  // 7) 情感指纹（写入时编码时刻快照）
  if (state?.hormones) Object.assign(out, attachFingerprint(out, state));
  if (Object.keys(ag).length) {
    let merged = {};
    try {
      merged = out.anchor_ground
        ? (typeof out.anchor_ground === 'string' ? JSON.parse(out.anchor_ground) : { ...out.anchor_ground })
        : {};
    } catch { merged = {}; }
    out.anchor_ground = { ...merged, ...ag };
  }
  return { input: out, source: src, hypothetical: !!hyp.kind };
}

/**
 * 盖章作废：不删行，写白名单内的 invalid_reason + valid_to，并把具体原因放进
 * anchor_ground.retractNote。v11.1 的 CHECK 不允许自造值 'retracted'。
 */
export const STAMP_REASON = 'manual';

export function retract(db, id, reason = 'retracted', { now = Date.now() } = {}) {
  const row = get(db, 'SELECT id, anchor_ground FROM memories WHERE id = ?', id);
  if (!row) return { ok: false, reason: 'not-found' };
  let ag = {};
  try { ag = row.anchor_ground ? JSON.parse(row.anchor_ground) : {}; } catch { ag = {}; }
  ag.retractNote = { reason, at: now };
  try {
    db.prepare('UPDATE memories SET invalid_reason = ?, valid_to = ?, valid_to_ms = ?, anchor_ground = ? WHERE id = ?')
      .run(STAMP_REASON, new Date(now).toISOString().slice(0, 19).replace('T', ' '), now, JSON.stringify(ag), id);
    return { ok: true, id, reason, deleted: false, stampedAs: STAMP_REASON };
  } catch {
    try {
      db.prepare('UPDATE memories SET invalid_reason = ?, valid_to = ?, anchor_ground = ? WHERE id = ?')
        .run(STAMP_REASON, new Date(now).toISOString().slice(0, 19).replace('T', ' '), JSON.stringify(ag), id);
      return { ok: true, id, reason, deleted: false, stampedAs: STAMP_REASON };
    } catch {
      try {
        db.prepare('UPDATE memories SET invalid_reason = ?, valid_to = ? WHERE id = ?')
          .run(STAMP_REASON, new Date(now).toISOString().slice(0, 19).replace('T', ' '), id);
        return { ok: true, id, reason, deleted: false, stampedAs: STAMP_REASON };
      } catch (e) { return { ok: false, reason: 'update-failed', message: e.message }; }
    }
  }
}

/**
 * 自动提取事实（Mem0 借鉴）：纯规则、零模型，产出候选 input 列表。
 * 只挑「稳定事实/偏好/约定」句式，其余一律不提；调用方把它们喂给 writeMemory，
 * 低 confidence 会自动落到 candidates，绝不直写脏数据。
 */
const FACT_RE = [
  { re: /(?:我叫|我是|我姓)([\u4e00-\u9fa5A-Za-z0-9]{1,12})/, category: 'person', tpl: m => `对方叫${m[1]}` },
  { re: /(?:我的生日是|我生日是)(\d{1,2}月\d{1,2}日?|\d{4}[-/]\d{1,2}[-/]\d{1,2})/, category: 'fact', tpl: m => `对方的生日是${m[1]}` },
  { re: /我(?:喜欢|爱吃|爱喝)([\u4e00-\u9fa5A-Za-z0-9]{1,16})/, category: 'preference', tpl: m => `对方喜欢${m[1]}` },
  { re: /我(?:对|吃)([\u4e00-\u9fa5A-Za-z0-9]{1,10})过敏/, category: 'preference', tpl: m => `对方对${m[1]}过敏` },
  { re: /(?:我们|我)?(?:约好|说好|约定)([\u4e00-\u9fa5A-Za-z0-9，。、 ]{2,30})/, category: 'promise', tpl: m => `约好${m[1]}` },
  { re: /(?:别|不要|不准)(?:再)?([\u4e00-\u9fa5A-Za-z0-9，。、 ]{2,30})/, category: 'rule', tpl: m => `不要${m[1]}` },
];
const SKIP_RE = /^(嗯|哦|好|行|哈哈|？|\?|在吗|早|晚安|收到)[\s。！？!?]*$/;

export function extractFacts(text, {
  cfg = DEFAULTS,
  scope = 'shared',
  now = Date.now(),
  msgIds = [],
  sourceId = null,
  turnId = null,
} = {}) {
  const t = String(text || '').trim();
  if (!t || t.length < 4 || t.length > 300 || SKIP_RE.test(t)) return [];
  if (hasCredential(t) || /^\[(文件|图片|语音|视频|表情|卡片)\]/.test(t)) return [];
  const out = [];
  for (const rule of FACT_RE) {
    const m = t.match(rule.re);
    if (!m) continue;
    const fact = rule.tpl(m).slice(0, cfg.memory?.maxChars ?? 500);
    const hyp = isHypothetical(t);
    out.push({
      fact, category: rule.category, scope,
      confidence: hyp.kind ? 0.45 : 0.58,       // <0.6 → 自动进候选
      source_kind: hyp.kind ? 'inferred' : 'owner',
      evidence_kind: 'user_sentence',
      evidence_ref: `auto:${turnId || now}`,
      source_id: sourceId,
      evidence: t.slice(0, 300),
      quote: t.slice(0, 300),
      msg_ids: Array.isArray(msgIds) ? msgIds : [],
      raw: t.slice(0, cfg.memory?.rawMaxChars ?? 900),
    });
    if (out.length >= 2) break;
  }
  return out;
}

/**
 * 新会话 / 上下文重置时重读高权重记忆：core + 高 importance + pinned 通道。
 * 只 SELECT，不写任何东西；由 index.mjs 塞进 composer 的 facts 前面。
 */
export function reloadHighPriority(db, { scopes = [], limit = 4, now = Date.now(), cfg = DEFAULTS } = {}) {
  if (!scopes.length) return [];
  const ph = scopes.map(() => '?').join(',');
  const rows = all(db,
    `SELECT id, fact, category, scope, importance, protection_tier, belief FROM memories
     WHERE scope IN (${ph}) AND invalid_reason IS NULL AND cold = 0
       AND (protection_tier = 'core' OR importance >= 0.85 OR category IN ('person','rule','promise'))
     ORDER BY (protection_tier = 'core') DESC, importance DESC, COALESCE(confirmed_at_ms, created_at_ms) DESC
     LIMIT ?`, ...scopes, limit);
  return rows.filter(r => !(r.belief != null && Number(r.belief) < (cfg.retrieval?.beliefFloor ?? 0.35)));
}
