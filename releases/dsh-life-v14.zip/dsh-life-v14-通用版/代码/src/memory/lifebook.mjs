// Long-lived promises, milestones, narratives and relationship snapshots.
// These are structured records, not substitutes for memories.
import { nextId } from '../kit/ids.mjs';

const nowOf = (now) => Number(now) || Date.now();

export function addPromise(db, {
  scope = 'shared', text, dueAt = null, now = Date.now(),
} = {}) {
  const body = String(text || '').trim();
  if (!body) return { ok: false, reason: 'empty' };
  const id = nextId(db, 'promises', 'p');
  db.prepare(
    'INSERT INTO promises(id,scope,text,due_at,status,created_at,last_notified_at) VALUES(?,?,?,?,?,?,?)'
  ).run(id, scope, body.slice(0, 500), dueAt == null ? null : nowOf(dueAt), 'pending', nowOf(now), 0);
  return { ok: true, id, status: 'pending' };
}

export function listPromises(db, { scope = null, status = null, limit = 30 } = {}) {
  const where = [];
  const args = [];
  if (scope) { where.push('scope = ?'); args.push(scope); }
  if (status) { where.push('status = ?'); args.push(status); }
  return db.prepare(
    `SELECT * FROM promises ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
     ORDER BY CASE status WHEN 'pending' THEN 0 ELSE 1 END, COALESCE(due_at,9223372036854775807), created_at DESC LIMIT ?`
  ).all(...args, Math.max(1, Number(limit) || 30));
}

export function closePromise(db, id, { status = 'done', now = Date.now() } = {}) {
  if (!['done', 'cancelled'].includes(status)) return { ok: false, reason: 'bad-status' };
  const row = db.prepare('SELECT id, status FROM promises WHERE id = ?').get(id);
  if (!row) return { ok: false, reason: 'not-found' };
  db.prepare('UPDATE promises SET status = ?, last_notified_at = ? WHERE id = ?').run(status, nowOf(now), id);
  return { ok: true, id, status };
}

export function addMilestone(db, { scope = 'shared', text, happenedAt = null, now = Date.now() } = {}) {
  const body = String(text || '').trim();
  if (!body) return { ok: false, reason: 'empty' };
  const id = nextId(db, 'milestones', 'm');
  db.prepare(
    'INSERT INTO milestones(id,scope,text,happened_at,created_at) VALUES(?,?,?,?,?)'
  ).run(id, scope, body.slice(0, 500), nowOf(happenedAt || now), nowOf(now));
  return { ok: true, id };
}

export function addNarrative(db, {
  scope = 'shared', period = 'day', text, periodStart = null, now = Date.now(),
} = {}) {
  const body = String(text || '').trim();
  if (!body) return { ok: false, reason: 'empty' };
  const id = nextId(db, 'narratives', 'n');
  db.prepare(
    'INSERT INTO narratives(id,scope,period,period_start,text,chars,audit_status,created_at,injected_at) ' +
    'VALUES(?,?,?,?,?,?,?,?,?)'
  ).run(id, scope, period, periodStart == null ? nowOf(now) : nowOf(periodStart),
    body.slice(0, 1200), Math.min(1200, body.length), 'ok', nowOf(now), 0);
  return { ok: true, id };
}

export function upsertRelationship(db, {
  scope, closeness = 0.5, trust = 0.5, stage = 'normal', now = Date.now(),
} = {}) {
  if (!scope) return { ok: false, reason: 'missing-scope' };
  db.prepare(
    'INSERT INTO relationships(scope,closeness,trust,stage,updated_at) VALUES(?,?,?,?,?) ' +
    'ON CONFLICT(scope) DO UPDATE SET closeness=excluded.closeness, trust=excluded.trust, stage=excluded.stage, updated_at=excluded.updated_at'
  ).run(scope, closeness, trust, stage, nowOf(now));
  return { ok: true, scope, closeness, trust, stage };
}

export function getRelationship(db, scope) {
  if (!scope) return null;
  return db.prepare('SELECT * FROM relationships WHERE scope = ?').get(scope) || null;
}

export function lifebookSnapshot(db, { scope = 'shared', now = Date.now() } = {}) {
  const promises = listPromises(db, { scope, limit: 20 });
  const milestones = db.prepare(
    'SELECT * FROM milestones WHERE scope = ? ORDER BY happened_at DESC, id DESC LIMIT 20'
  ).all(scope);
  const narratives = db.prepare(
    'SELECT id,period,period_start,text,audit_status,created_at FROM narratives WHERE scope = ? ORDER BY created_at DESC LIMIT 10'
  ).all(scope);
  return { scope, relationship: getRelationship(db, scope), promises, milestones, narratives, now };
}
