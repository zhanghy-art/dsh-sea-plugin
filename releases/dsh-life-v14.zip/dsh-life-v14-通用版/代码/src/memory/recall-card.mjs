// Compact recall cards and explicit deep recall.
// The first layer is cheap and bounded; full raw evidence is only returned by id.
import { scopeClause } from '../kit/scope.mjs';
import { searchMemory } from './search.mjs';

const clip = (s, n) => {
  const text = String(s || '').replace(/\s+/g, ' ').trim();
  return text.length > n ? text.slice(0, Math.max(0, n - 1)) + '…' : text;
};

export function cardOf(mem, { score = 0, keyword = '', now = Date.now() } = {}) {
  const fact = String(mem?.fact || '');
  const k = String(keyword || '').trim();
  let quote = fact.slice(0, 18);
  if (k) {
    const at = fact.indexOf(k);
    if (at >= 0) {
      const start = Math.max(0, at - 5);
      quote = fact.slice(start, Math.min(fact.length, at + k.length + 8));
    }
  }
  const when = Number(mem?.confirmed_at_ms ?? mem?.created_at_ms ?? 0);
  const date = when ? new Date(when).toISOString().slice(5, 16).replace('T', ' ') : '—';
  return {
    id: mem?.id ?? null,
    tag: mem?.category || 'fact',
    score: Number(Number(score || 0).toFixed(3)),
    time: date,
    summary: clip(fact, 42),
    quote: clip(quote, 24),
    tier: mem?.protection_tier || 'normal',
    belief: Number(mem?.belief ?? mem?.beta ?? 0.6),
    hypothetical: String(mem?.anchor_ground || '').includes('hypothetical'),
  };
}

export function recallCards(db, query, {
  scope,
  ownerQq = null,
  groupId = null,
  limit = 3,
  cfg,
  now = Date.now(),
} = {}) {
  const hits = searchMemory(db, query, {
    cfg, now, scope, ownerQq, groupId,
    ignoreCooldown: true,
    topK: Math.max(1, Math.min(6, Number(limit) || 3)),
  });
  return {
    ok: true,
    query,
    cards: hits.items.map((x) => cardOf(x.mem, { score: x.score, keyword: query, now })),
    debug: hits.debug,
  };
}

export function recallDetail(db, memoryId, {
  scopes = [],
  includeRaw = false,
  maxChars = 1200,
  allowRaw = true,
} = {}) {
  if (!memoryId) return { ok: false, reason: 'missing-id' };
  const sc = scopeClause(scopes);
  let row;
  try {
    row = db.prepare(
      `SELECT * FROM memories WHERE id = ? AND ${sc.sql} AND invalid_reason IS NULL`
    ).get(memoryId, ...sc.params);
  } catch { return { ok: false, reason: 'read-failed' }; }
  if (!row) return { ok: false, reason: 'not-found-or-out-of-scope' };

  let evidence = [];
  try {
    evidence = db.prepare(
      'SELECT quote, message_ids, source_kind, source_id, ref, asserted_at FROM memory_evidence WHERE memory_id = ? ORDER BY id ASC LIMIT 5'
    ).all(memoryId);
  } catch { /* legacy database may not have evidence quote columns */ }

  return {
    ok: true,
    card: cardOf(row, { score: 1 }),
    fact: String(row.fact || '').slice(0, maxChars),
    category: row.category,
    scope: row.scope,
    importance: row.importance,
    belief: row.belief ?? row.beta,
    protection_tier: row.protection_tier,
    valid_to_ms: row.valid_to_ms || null,
    evidence: evidence.map((e) => ({ ...e, quote: clip(e.quote, 180) })),
    raw: includeRaw && allowRaw ? String(row.raw || row.evidence || row.fact || '').slice(0, maxChars) : undefined,
    rawOmitted: !(includeRaw && allowRaw),
    rawDenied: includeRaw === true && allowRaw === false,
  };
}
