// src/memory/region-router.mjs — 分舱路由（2.11）
// 一级：本地关键词表（零模型成本）；置信度不足时可选小模型判定。
export const REGIONS = ['self', 'person', 'daily', 'project', 'emotion', 'promise', 'meme'];

const LEX = {
  self:    ['你是谁', '你喜欢', '你怎么想', '你的名字', '你叫什么', '你的设定', '你会不会', '你是不是'],
  person:  ['生日', '称呼', '妈妈', '爸爸', '姐姐', '哥哥', '弟弟', '妹妹', '奶奶', '爷爷', '忌讳', '老家', '住在'],
  project: ['项目', '版本', '代码', '部署', '仓库', 'bug', '接口', '文档', '方案', '架构', '服务器', '测试'],
  emotion: ['难过', '生气', '烦', '开心', '哭', '委屈', '焦虑', '崩溃', '吵架', '道歉', '和好', '害怕', '孤独'],
  promise: ['记得', '答应', '明天', '后天', '周末', '提醒', '约定', '别忘了', '几点', '叫我'],
  meme:    ['哈哈哈', '笑死', '什么鬼', '绝了', '离谱', 'nb', '草', '绷不住'],
  daily:   ['吃', '喝', '睡', '上班', '下班', '天气', '今天', '累', '地铁', '外卖', '咖啡'],
};

/**
 * @returns {{regions:string[], score:number, reason:string}}
 * score >= 0.4 视为命中；否则调用方走全库。
 */
export function route(text) {
  const t = String(text || '');
  const hits = [];
  for (const [region, words] of Object.entries(LEX)) {
    let n = 0;
    for (const w of words) if (t.includes(w)) n++;
    if (n > 0) hits.push({ region, n });
  }
  if (!hits.length) return { regions: [], score: 0, reason: 'no-lex-hit' };
  hits.sort((a, b) => b.n - a.n);
  const max = hits[0].n;
  const kept = hits.filter(h => h.n >= Math.max(1, max - 1)).map(h => h.region);
  // 置信度：命中词数 + 是否多舱一致
  const score = Math.min(1, 0.35 + 0.2 * max + (kept.length > 1 ? 0.1 : 0));
  return { regions: kept.slice(0, 3), score, reason: `lex:${kept.join('+')}` };
}

/** 写入侧定舱：无上下文时按分类映射 */
export function regionOfCategory(category, text = '') {
  const r = route(text);
  if (r.score >= 0.4) return r.regions[0];
  const map = { person: 'person', rule: 'self', promise: 'promise', meme: 'meme', preference: 'person' };
  return map[category] || 'daily';
}
