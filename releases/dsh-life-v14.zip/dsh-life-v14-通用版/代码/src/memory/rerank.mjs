// src/memory/rerank.mjs — 轻量重排层（v14 P2，对应后补建议第 2 条）
// 混合召回 top20 → 特征重排 → top6。默认纯函数、零依赖、零模型调用。
// 可选外挂：opts.rerankFn（本地 ONNX / cross-encoder），超时/失败/空分数一律回落原排序。
// 借鉴小鲸鱼技术档案的降级设计：500ms 超时、精确命中保底 0.85、明确无关降权、失败后 30s 不重试。
// 铁律：只改展示顺序，不写 memories、不进 effWeight、不改 belief。
const clamp01 = (v) => Math.max(0, Math.min(1, Number(v) || 0));

const TIME_WORDS = ['昨天', '前天', '上周', '上个月', '去年', '刚才', '那天', '当时', '以前', '上次'];
const CAUSE_WORDS = ['因为', '所以', '结果', '导致', '为什么', '原因'];
const CMP_WORDS = ['比', '更', '最', '不如', '还是', '区别'];
const PERSON_WORDS = ['你说过', '你答应', '他说的', '她说', '我记得你说', '我问过'];

/** 精确命中：查询里的数字出现在 fact，或长度>=3 的词精确出现 */
export function exactHit(query, mem) {
  const f = String(mem?.fact || '');
  const nums = String(query || '').match(/\d{4,}/g) || [];
  if (nums.some(n => f.includes(n))) return true;
  const qs = String(query || '').split(/[\s，。！？、,.!?]/).filter(x => x.length >= 3);
  return qs.some(q => f.includes(q));
}

/**
 * 纯函数特征重排。
 * @param hits searchMemory 的 items（{mem, score, ts, cos, eff, cov, rb, mode}）
 * @param opts {{cfg, now, topN, keep, mood, query, stats}}
 */
export function rerankHits(query, hits, opts = {}) {
  const cfg = opts.cfg || {};
  const r = cfg.retrieval || {};
  const topN = opts.topN ?? (cfg.retrieval?.rerankTop ?? 20);
  const keep = opts.keep ?? (r.topK ?? 6);
  const stats = { called: 1, topN: Math.min(topN, hits.length), keep, external: 'off', fallback: 0, exactProtected: 0, demoted: 0 };
  if (!hits.length) return { items: [], stats };

  const q = String(query || '');
  const mood = opts.mood || null;                       // {P,A,D} 或 {valence}
  const subset = hits.slice(0, topN);
  const scored = subset.map((h) => {
    const mem = h.mem || {};
    const ts = clamp01(h.ts), cos = clamp01(h.cos), eff = clamp01(h.eff), cov = clamp01(h.cov);
    let s = clamp01(h.score);

    // 1) 字面 / 向量一致性：两路都命中才加分，单路不放大
    s += 0.06 * Math.min(ts, cos);
    // 1b) BM25 相关性（searchMemory 已算好；独立特征，不替换主公式）
    s += 0.08 * clamp01(h.bm25);
    // 2) 覆盖度
    s += 0.05 * cov;
    // 3) 场景 / 时间 / 人物线索（v13 规格表「我们」列承诺但没接的三项）
    if (TIME_WORDS.some(w => q.includes(w)) && (mem.happened_at_ms || mem.time_granularity)) s += 0.03;
    if (CAUSE_WORDS.some(w => q.includes(w)) && (mem.evidence || mem.related_ids)) s += 0.02;
    if (CMP_WORDS.some(w => q.includes(w)) && (mem.cluster_id || mem.related_ids)) s += 0.02;
    if (PERSON_WORDS.some(w => q.includes(w))) s += 0.02;
    // 4) 长度归一：长条目按字数打折（短事实更该被想起）
    const len = String(mem.fact || '').length;
    if (len > 120) s *= 0.92;
    // 5) 短语连配：连续 4 字出现在 fact
    const phrase = q.replace(/\s/g, '').slice(0, 4);
    if (phrase.length >= 4 && String(mem.fact || '').includes(phrase)) s += 0.03;
    // 6) 心境一致：最多 +0.05（借鉴 dsh-emotion-memory 0.1 的 0.05 权重，不替换主公式）
    if (mood && mem.anchor_ground) {
      try {
        const ag = typeof mem.anchor_ground === 'string' ? JSON.parse(mem.anchor_ground) : mem.anchor_ground;
        if (ag && ag.affect && Number.isFinite(Number(ag.affect.P))) {
          const cur = Number(mood.P ?? mood.valence ?? 0);
          s += 0.05 * (1 - Math.min(1, Math.abs(cur - Number(ag.affect.P))));
        }
      } catch { /* 旧数据没有指纹则不加分 */ }
    }
    // 7) 假设语气不当事实：轻度降权（仍可召回，但排后面）
    if (h.mode === 'hypothetical' || (mem.anchor_ground && String(mem.anchor_ground).includes('hypothetical'))) {
      s *= 0.75; stats.demoted++;
    }
    // 8) 精确命中保底：不被任何重排压掉
    const exact = exactHit(q, mem);
    if (exact) { s = Math.max(s, 0.85); stats.exactProtected++; }
    return { ...h, score: Math.min(1.2, Math.max(0, s)), exact, rerank: 'pure' };
  });

  const rest = hits.slice(topN);
  const items = [...scored, ...rest].sort((a, b) => b.score - a.score).slice(0, keep);
  stats.kept = items.length;
  return { items, stats };
}

/**
 * 可选外部 rerank 融合（异步，在 index.mjs 调用；searchMemory 保持同步签名）。
 * @returns {{items, stats}} 失败时 items 与传入完全一致
 */
export async function rerankWithExternal(query, hits, opts = {}) {
  const stats = { external: 'off', fallback: 0, timeoutMs: opts.timeoutMs ?? 500, ms: 0 };
  const fn = opts.rerankFn;
  const pure = rerankHits(query, hits, opts);
  if (typeof fn !== 'function' || hits.length < 4) return { items: pure.items, stats: { ...pure.stats, ...stats } };
  if (opts.frozenUntil && Date.now() < opts.frozenUntil) {
    return { items: pure.items, stats: { ...pure.stats, ...stats, fallback: 1, reason: 'cooldown' } };
  }
  const topN = opts.topN ?? 20;
  const subset = hits.slice(0, topN);
  const t0 = Date.now();
  let scores = null;
  try {
    const payload = {
      query: String(query || ''),
      passages: subset.map(h => ({ id: String(h.mem?.id), text: `${h.mem?.fact || ''} ${h.mem?.tags || ''}`.slice(0, 700) })),
    };
    const res = await Promise.race([
      Promise.resolve(fn(payload)),
      new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), stats.timeoutMs)),
    ]);
    const arr = Array.isArray(res) ? res : (res?.scores || []);
    if (arr.length) {
      scores = new Map(arr.map(x => [String(x.id), clamp01(x.score)]));
      stats.external = 'on';
    }
  } catch { stats.fallback = 1; }
  stats.ms = Date.now() - t0;
  if (!scores) return { items: pure.items, stats: { ...pure.stats, ...stats } };

  const w = Math.max(0, Math.min(0.8, Number(opts.rerankWeight ?? 0.65)));
  const merged = hits.map((h) => {
    const rs = scores.get(String(h.mem?.id));
    if (rs == null) return h;
    const base = clamp01(h.score);
    let s = base * (1 - w + w * rs);
    if (rs < 0.05 && !exactHit(query, h.mem)) s = Math.min(s, base * 0.15);
    if (exactHit(query, h.mem)) s = Math.max(s, 0.85);   // 精确命中不被 rerank 压掉
    return { ...h, score: s, rerankScore: rs };
  }).sort((a, b) => b.score - a.score).slice(0, opts.keep ?? 6);
  return { items: merged, stats: { ...pure.stats, ...stats, kept: merged.length } };
}

/** 检索可观测：回退次数、vec 命中率、rerank 调用/降级、P95 延迟 —— 借图 S7-4「317 次回退」的口径 */
export function bumpStats(db, key, delta = 1) {
  if (!db) return null;
  try {
    const k = 'retrieval_stats:' + key;
    const row = db.prepare('SELECT v FROM kv WHERE k = ?').get(k);
    const cur = row ? JSON.parse(row.v) : { total: 0, last: 0 };
    cur.total += delta; cur.last = Date.now();
    db.prepare("INSERT INTO kv(k,v,updated_at) VALUES(?,?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v, updated_at=excluded.updated_at")
      .run(k, JSON.stringify(cur), Date.now());
    return cur;
  } catch { return null; }
}

export function readStats(db) {
  const out = {};
  try {
    for (const r of db.prepare("SELECT k, v FROM kv WHERE k LIKE 'retrieval_stats:%'").all()) {
      try { out[r.k.slice('retrieval_stats:'.length)] = JSON.parse(r.v); } catch { /* ignore */ }
    }
  } catch { /* ignore */ }
  return out;
}
