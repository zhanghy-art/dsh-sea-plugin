// src/memory/search.mjs — 六段检索（2.3.2 / 9.x）
// 0 分舱 → 1 受众过滤 → 2 双通道打分 → 3 回声闸 → 4 覆盖度重排 → 5 多样性
import { DEFAULTS } from '../kit/config.mjs';
import { normalizeScope, visibleScopes, scopeClause, SHARED } from '../kit/scope.mjs';
import { effWeight, passesGate, retrievalScore, injectable, beliefValue } from './weight.mjs';
import { dice, shingles } from './text.mjs';
import { route } from './region-router.mjs';
import { bm25Rank, bm25Candidates, ftsCandidates } from './bm25.mjs';
import { rerankHits, bumpStats } from './rerank.mjs';
import { reconsolidate } from '../life/affect-fingerprint.mjs';
import { shadowLog } from '../kit/shadow.mjs';

export function cosine(a, b) {
  if (!a || !b || a.length !== b.length) return 0;
  let dot = 0, na = 0, nb = 0;
  for (let i = 0; i < a.length; i++) { dot += a[i] * b[i]; na += a[i] * a[i]; nb += b[i] * b[i]; }
  if (!na || !nb) return 0;
  return dot / Math.sqrt(na * nb);
}

export function blobToVec(blob) {
  if (!blob) return null;
  try {
    const buf = Buffer.from(blob);
    return new Float32Array(buf.buffer, buf.byteOffset, buf.byteLength / 4);
  } catch { return null; }
}

export function textScore(query, fact) {
  return dice(query, fact);
}

/** 覆盖度：查询的 shingle 有多少被记忆覆盖（0–1） */
export function coverageOf(query, fact) {
  const Q = shingles(query), F = shingles(fact);
  if (!Q.size) return 0;
  let hit = 0;
  for (const q of Q) if (F.has(q)) hit++;
  return hit / Q.size;
}

/** 四路由软权重（豆包）：时间/因果/比较，总上限 0.10 */
const TIME_WORDS = ['昨天', '前天', '上周', '上个月', '去年', '之前', '刚才', '那天', '当时', '以前'];
const CAUSE_WORDS = ['因为', '所以', '结果', '导致', '为什么', '原因', '于是'];
const CMP_WORDS = ['比', '更', '最', '不如', '还是', '一样', '区别'];

export function routeBoost(query, mem) {
  const q = String(query || '');
  let b = 0;
  if (TIME_WORDS.some(w => q.includes(w)) && (mem.happened_at || mem.time_granularity !== 'vague')) b += 0.04;
  if (CAUSE_WORDS.some(w => q.includes(w)) && (mem.emotion || mem.category === 'event')) b += 0.03;
  if (CMP_WORDS.some(w => q.includes(w))) b += 0.03;
  return Math.min(b, DEFAULTS.retrieval.routeBoostMax);
}

/** 回声闸：近重复（jaccard≥0.80）或包含关系（长度比≥0.85）直接过滤 */
export function isEchoMemory(query, fact, cfg = DEFAULTS) {
  const r = cfg.retrieval;
  if (dice(query, fact) >= r.echoJaccard) return true;
  const a = String(query), b = String(fact);
  const [short, long] = a.length <= b.length ? [a, b] : [b, a];
  if (short.length / Math.max(1, long.length) >= r.lenRatio && long.includes(short)) return true;
  return false;
}

function cooldownSet(db, now, hours, ignoreIds = []) {
  if (!hours) return new Set(ignoreIds.map(String));
  const rows = db.prepare('SELECT DISTINCT memory_id FROM injection_log WHERE injected_at >= ?')
    .all(now - hours * 3600000);
  // v13.0：旧库 injection_log.memory_id 是 TEXT，mem.id 是 INTEGER，
  // 直接 Set.has 会永远为 false（冷却形同虚设）——统一按字符串比较。
  const s = new Set(rows.map(r => String(r.memory_id)));
  for (const id of ignoreIds) s.delete(String(id));
  return s;
}

/**
 * 检索主流程。
 * @returns {{items:Array, debug:object}}
 */
export function searchMemory(db, query, opts = {}) {
  const cfg = opts.cfg || DEFAULTS;
  const now = opts.now || Date.now();
  // D2：所有召回先约束 scope。
  // v13.0：不再默认 'chat:private'（旧库根本没有这个值，等于查空）；
  //        传入的 scope 一律归一成 private:<qq>/group:<id>，再加 shared 家族。
  const scope = opts.scope
    ? normalizeScope(opts.scope, { ownerQq: opts.ownerQq ?? cfg.ownerQq, groupId: opts.groupId })
    : null;
  const scopes = (opts.scopes && opts.scopes.length)
    ? opts.scopes
    : (scope ? visibleScopes(scope, { ownerQq: cfg.ownerQq }) : [SHARED, 'shared:%']);
  const sc = scopeClause(scopes);
  const scopePh = sc.sql;
  const scopeParams = sc.params;
  const r = cfg.retrieval;
  const qvec = opts.queryVec || null;
  const bm25On = opts.bm25 === true || (cfg.capabilities?.bm25 === true && cfg.capabilities?.ftsSearch !== false);
  const lexicalCandidateMode = bm25On && (
    opts.lexicalCandidates === true || String(query || '').trim().length >= 6
  );
  const bad = opts.ignoreCooldown ? new Set() : cooldownSet(db, now, opts.cooldownHours ?? cfg.memory.injectionCooldownHours, opts.ignoreIds || []);

  const debug = { route: null, scanned: 0, droppedGate: 0, droppedCooldown: 0, droppedBelief: 0, droppedEcho: 0, path3: 0 };
  const seen = new Map();

  const consider = (mem, lexical = 0) => {
    debug.scanned++;
    if (mem.invalid_reason || mem.cold) return;
    if (bad.has(String(mem.id))) { debug.droppedCooldown++; return; }
    if (beliefValue(mem) < r.beliefFloor) { debug.droppedBelief++; return; }
    const inj = injectable(mem);
    if (!inj.ok) { debug.droppedBelief++; return; }
    if (isEchoMemory(query, mem.fact, cfg)) { debug.droppedEcho++; return; }

    let eff;
    try { eff = effWeight(mem, now, cfg); } catch { return; }
    const rawTs = textScore(query, mem.fact);
    const ts = lexical > 0 ? Math.max(rawTs, lexical * 0.85) : rawTs;
    const cos = qvec ? cosine(qvec, blobToVec(mem.vec)) : 0;
    const cov = coverageOf(query, mem.fact);
    const rb = routeBoost(query, mem);
    if (!passesGate({ textScore: ts, cos, eff, belief: beliefValue(mem), coverage: cov, routeBoost: rb }, cfg)) {
      debug.droppedGate++; return;
    }
    const score = retrievalScore({ base: Math.max(ts, cos), eff, coverage: cov, routeBoost: rb });
    const prev = seen.get(mem.id);
    if (!prev || prev.score < score) seen.set(mem.id, { mem, score, ts, cos, eff, cov, rb, bm25: lexical, mode: inj.mode });
  };

  // 0 级：分舱（可关）
  const routed = opts.regions ? { regions: opts.regions, score: 1 } : route(query);
  debug.route = routed;
  const rowBag = new Map();
  const ftsScores = new Map();
  const addRows = (rows) => {
    for (const row of rows || []) {
      rowBag.set(row.id, row);
      if (Number(row._fts_score) > 0) ftsScores.set(row.id, Number(row._fts_score));
    }
    return rows?.length || 0;
  };
  let path1 = 0;
  const kwOn = cfg.capabilities?.routeKeyword !== false;
  if (kwOn && routed.score >= r.regionScoreFloor && routed.regions.length) {
    const ph = routed.regions.map(() => '?').join(',');
    const rows = db.prepare(
      `SELECT * FROM memories WHERE ${scopePh} AND region IN (${ph}) AND invalid_reason IS NULL AND cold = 0 ORDER BY created_at_ms DESC, created_at DESC LIMIT ?`
    ).all(...scopeParams, ...routed.regions, r.poolLimit);
    path1 = addRows(rows);
  }

  // 1–2 级：全库（分舱不足或关闭时）
  if (path1 < r.regionMinHits) {
    const rows = db.prepare(
      `SELECT * FROM memories WHERE ${scopePh} AND invalid_reason IS NULL AND cold = 0 ORDER BY created_at_ms DESC, created_at DESC LIMIT ?`
    ).all(...scopeParams, r.poolLimit);
    addRows(rows);
    debug.path3 = rows.length;
  }

  // v14 FTS/BM25 candidates supplement the recent pool. The LIKE fallback below
  // still remains the last-resort path for punctuation-heavy queries.
  let ftsRows = [];
  if (lexicalCandidateMode) {
    ftsRows = ftsCandidates(db, query, {
      scopes,
      limit: cfg.v14?.retrieval?.ftsCandidateLimit ?? 600,
    });
    addRows(ftsRows);
    debug.fts = ftsRows.length;
  }

  const allRows = [...rowBag.values()];
  let lexicalScores = new Map();
  if (lexicalCandidateMode && allRows.length) {
    lexicalScores = bm25Rank(query, allRows, {
      k1: cfg.v14?.bm25?.k1,
      b: cfg.v14?.bm25?.b,
      cooc: cfg.v14?.bm25?.cooc !== false,
    }).scores;
  }
  for (const row of allRows) {
    consider(row, Math.max(lexicalScores.get(row.id) || 0, ftsScores.get(row.id) || 0));
  }

  // 边扩展（只一跳，Top3）
  const top3 = [...seen.values()].sort((a, b) => b.score - a.score).slice(0, 3);
  for (const t of top3) {
    const edges = db.prepare('SELECT to_id, weight FROM edges WHERE from_id = ? ORDER BY weight DESC LIMIT 2').all(t.mem.id);
    for (const e of edges) {
      const mem = db.prepare(`SELECT * FROM memories WHERE id = ? AND ${scopePh} AND invalid_reason IS NULL AND cold = 0`).get(e.to_id, ...scopeParams);
      if (mem) consider(mem);
    }
  }

  // 3–5 级：排序 → 覆盖度加权已在 score 内 → 多样性去重（同 category 最多 2 条）
  let items = [...seen.values()].sort((a, b) => b.score - a.score);
  const perCat = new Map();
  const final = [];
  for (const it of items) {
    const c = it.mem.category;
    const n = perCat.get(c) || 0;
    if (n >= 2) { it.score -= r.diversityPenalty; continue; }
    perCat.set(c, n + 1);
    final.push(it);
  }
  items = final.sort((a, b) => b.score - a.score);

  // L0 保底：不足 2 条 → v13 的 LIKE 时间倒序（必须保留：含 # 等符号的查询
  // 在 shingle 分词下会整串不匹配，只有 LIKE 能兜住）。v14 的 BM25 只做「增补 + 打分」，
  // 绝不替换这条基线，否则会出现「开了新特性反而全漏」的回归。
  if (items.length < 2) {
    const like = '%' + String(query).slice(0, 20).replace(/[%_]/g, '') + '%';
    const rows = db.prepare(
      `SELECT * FROM memories WHERE ${scopePh} AND (fact LIKE ? OR tags LIKE ?) AND invalid_reason IS NULL AND cold = 0 ` +
      'ORDER BY created_at_ms DESC, created_at DESC LIMIT 3'
    ).all(...scopeParams, like, like);
    for (const mem of rows) {
      if (bad.has(String(mem.id))) { debug.droppedCooldown++; continue; }
      if (!seen.has(mem.id)) {
        let eff = 0;
        try { eff = effWeight(mem, now, cfg); } catch { /* 跳过脏数据 */ }
        final.push({ mem, score: retrievalScore({ base: 0.12, eff }), ts: 0, cos: 0, eff, cov: 0, rb: 0, mode: 'fallback' });
        seen.set(mem.id, true);
      }
    }
    // v14：BM25 相关性候选只增补，不删基线命中的任何一行
    if (bm25On) {
      const cands = bm25Candidates(db, query, { scopes, limit: 3, cfg });
      for (const c of cands) {
        if (seen.has(c.id)) continue;
        if (bad.has(String(c.id))) { debug.droppedCooldown++; continue; }
        const mem = db.prepare(
          `SELECT * FROM memories WHERE id = ? AND ${scopePh} AND invalid_reason IS NULL AND cold = 0`
        ).get(c.id, ...scopeParams);
        if (!mem) continue;
        let eff = 0;
        try { eff = effWeight(mem, now, cfg); } catch { /* 跳过脏数据 */ }
        final.push({ mem, score: retrievalScore({ base: c.score, eff }), ts: c.score, cos: 0, eff, cov: 0, rb: 0, mode: 'bm25-fallback' });
        seen.set(mem.id, true);
      }
      debug.bm25 = cands.length;
    }
    items = final.sort((a, b) => b.score - a.score);
  }

  // BM25 is already attached from the candidate pass. Do not recompute it on a
  // tiny truncated set, which would make the same document change score by path.
  if (bm25On && items.length && items.some((it) => !Number.isFinite(Number(it.bm25)))) {
    const local = bm25Rank(query, items.map((it) => ({
      id: it.mem.id, fact: it.mem.fact, tags: it.mem.tags,
    })), {
      k1: cfg.v14?.bm25?.k1,
      b: cfg.v14?.bm25?.b,
      cooc: cfg.v14?.bm25?.cooc !== false,
    }).scores;
    for (const it of items) {
      if (!Number.isFinite(Number(it.bm25))) it.bm25 = local.get(it.mem.id) ?? 0;
    }
  }

  // v14 轻量重排：top20 → 特征重排 → top6；只在显式开启时执行，不改 retrievalScore 主公式
  const rerankMode = opts.rerankMode || (opts.rerank === true ? 'on' : 'off');
  if (rerankMode === 'on' || rerankMode === 'shadow') {
    const rr = rerankHits(query, items, {
      cfg, now, query, mood: opts.mood,
      topN: opts.rerankTop ?? cfg.v14?.rerank?.top ?? 20,
      keep: opts.topK || r.topK,
    });
    debug.rerank = rr.stats;
    if (rerankMode === 'shadow') {
      shadowLog(db, 'rerank', {
        wouldTop: rr.items.slice(0, 5).map((x) => ({ id: x.mem?.id, score: x.score })),
        stats: rr.stats,
      }, now);
      debug.rerank.shadow = true;
    } else {
      items = rr.items;
    }
    bumpStats(db, 'rerank', 1);
  }
  if (bm25On) bumpStats(db, 'bm25', 1);
  if (!qvec) bumpStats(db, 'vec-miss', 1);
  return { items: items.slice(0, opts.topK || r.topK), debug };
}

export function logInjection(db, items, now = Date.now(), turnId = null, opts = {}) {
  if (!items?.length) return;
  // v11.1 的 injection_log 是 (id,turn_id,used_chars,dropped,by_kind,created_at)，没有 scope/kind，
  // 且 created_at 是 NOT NULL 无默认值。v13 新库才是 (memory_id,scope,kind,injected_at,turn_id)。
  // 老库升级后若按固定列名硬写，会报「no such column: scope」或「NOT NULL constraint failed」，
  // 异常被上层 catch 吞掉 → 注入日志永远 0 条，看着就像「记忆根本没注入」。
  // 所以这里按实际列集拼 SQL。
  const cols = new Set(db.prepare('PRAGMA table_info(injection_log)').all().map((c) => c.name));
  const has = (c) => cols.has(c);
  const names = ['memory_id'];
  if (has('scope')) names.push('scope');
  if (has('kind')) names.push('kind');
  names.push('injected_at');
  if (has('turn_id')) names.push('turn_id');
  if (has('created_at')) names.push('created_at');
  const st = db.prepare(`INSERT INTO injection_log(${names.join(',')}) VALUES(${names.map(() => '?').join(',')})`);
  for (const it of items) {
    const vals = [it.mem.id];
    if (has('scope')) vals.push(it.mem.scope);
    if (has('kind')) vals.push(it.mode || 'auto');
    vals.push(now);
    if (has('turn_id')) vals.push(turnId);
    if (has('created_at')) vals.push(now);
    st.run(...vals);
  }
  // v14：被想起时再巩固情感指纹（只更新 anchor_ground，绝不改写 fact 正文）
  if (opts.reconsolidate === true && opts.state) {
    try { reconsolidate(db, items, opts.state, { coef: opts.reconsolidateCoef ?? 0.15, now }); }
    catch { /* 指纹失败不影响注入日志 */ }
  }
}
