// src/memory/text.mjs — 文本相似工具（纯函数，无依赖）
// 中文按 2-gram 切，英文按词切；Jaccard 与 dice 都在此实现。

const PUNCT = /[，。！？、；：“”‘’（）《》\s,.!?;:"'()<>\[\]]/g;

export function normalizeText(s) {
  if (!s) return '';
  return String(s)
    .replace(/\u3000/g, ' ')
    .replace(/([\u4e00-\u9fa5])\s+(?=[\u4e00-\u9fa5])/g, '$1')
    .replace(/\s+/g, ' ')
    .replace(/^(今天|昨天|前天|刚才|刚刚)/, '')  // 时间词在写入前已被绝对化，这里兜底
    .trim()
    .slice(0, 500);
}

/** 生成 shingle 集合：中文 2-gram + 英文单词小写 */
export function shingles(s) {
  const t = normalizeText(s).replace(PUNCT, '|');
  const out = new Set();
  for (const seg of t.split('|')) {
    if (!seg) continue;
    if (/^[\u4e00-\u9fa5]+$/.test(seg)) {
      if (seg.length === 1) out.add(seg);
      for (let i = 0; i < seg.length - 1; i++) out.add(seg.slice(i, i + 2));
    } else {
      for (const w of seg.split(' ')) if (w) out.add(w.toLowerCase());
    }
  }
  return out;
}

export function jaccard(a, b) {
  const A = shingles(a), B = shingles(b);
  if (!A.size || !B.size) return 0;
  let inter = 0;
  for (const x of A) if (B.has(x)) inter++;
  return inter / (A.size + B.size - inter);
}

export function dice(a, b) {
  const A = shingles(a), B = shingles(b);
  if (!A.size || !B.size) return 0;
  let inter = 0;
  for (const x of A) if (B.has(x)) inter++;
  return (2 * inter) / (A.size + B.size);
}

/** 惊讶度 s = 1 - max_j Jaccard(text, m_j)，没有任何相似记忆时 s = 1 */
export function surprise(text, existingTexts) {
  let mx = 0;
  for (const t of existingTexts) {
    const j = jaccard(text, t);
    if (j > mx) mx = j;
    if (mx >= 0.999) break;
  }
  return Math.max(0, Math.min(1, 1 - mx));
}

export const NEG_WORDS = ['不', '别', '没', '无', '非', '取消', '算了', '不想', '不要', '不用'];

export function polarity(s) {
  const t = normalizeText(s);
  let n = 0;
  for (const w of NEG_WORDS) if (t.includes(w)) n++;
  return n % 2 === 0 ? 1 : -1;
}

export function sharesTag(tagsA, tagsB) {
  const A = new Set(String(tagsA || '').split(',').map(x => x.trim()).filter(Boolean));
  for (const t of String(tagsB || '').split(',').map(x => x.trim()).filter(Boolean)) if (A.has(t)) return true;
  return false;
}
