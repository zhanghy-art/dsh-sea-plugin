// src/memory/vec-local.mjs — 本地字符向量（v14 P0：修 v13.0 D4「vec 写入侧从不产出」）
// 默认零依赖、零联网：中文 1/2/3-gram + 英文整词 → 384 维 hash 向量 → L2 归一。
// 宿主提供 ctx.embed 时可异步覆盖为神经向量，失败/超时一律回退本地 hash（借鉴鱼生 v12 / Gitee memory2）。
// vec_model 记录来源，支持 reindex；cosine 支持任意维度，旧向量不清库即可并存。
export const VEC_DIM = 384;
export const LOCAL_MODEL = 'hash384';

const STOP = new Set(['的', '了', '是', '我', '你', '他', '她', '它', '在', '和', '就', '都', '也', '不', '吗', '呢', '啊', '吧', '这', '那', '有', '没']);

function fnv1a(s) {
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 0x01000193) >>> 0;
  }
  return h >>> 0;
}

/** 纯函数：文本 → 384 维 L2 归一化向量 */
export function localVec(text) {
  const v = new Float32Array(VEC_DIM);
  const s = String(text || '').toLowerCase();
  const grams = [];
  const cn = s.replace(/[^\u4e00-\u9fa5]/g, '');
  for (let n = 1; n <= 3; n++) {
    for (let i = 0; i + n <= cn.length; i++) {
      const g = cn.slice(i, i + n);
      if (n === 1 && STOP.has(g)) continue;
      if (n > 1 && STOP.has(g[0]) && STOP.has(g[g.length - 1])) continue;
      grams.push(g);
    }
  }
  for (const w of s.match(/[a-z0-9]{2,}/g) || []) grams.push(w);
  for (const g of grams) {
    const h = fnv1a(g);
    const idx = h % VEC_DIM;
    const sign = (h >>> 31) ? -1 : 1;               // 有符号哈希，降低碰撞偏置
    v[idx] += sign * (1 + Math.min(2, g.length - 1) * 0.15);
  }
  let norm = 0;
  for (let i = 0; i < VEC_DIM; i++) norm += v[i] * v[i];
  norm = Math.sqrt(norm);
  if (norm > 0) for (let i = 0; i < VEC_DIM; i++) v[i] /= norm;
  return v;
}

export function vecToBlob(v) {
  if (!v) return null;
  const f = v instanceof Float32Array ? v : Float32Array.from(v);
  return Buffer.from(new Uint8Array(f.buffer, f.byteOffset, f.byteLength));
}

export function blobToVec(blob) {
  if (!blob) return null;
  try {
    const b = Buffer.from(blob);
    return new Float32Array(b.buffer, b.byteOffset, b.byteLength / 4);
  } catch { return null; }
}

/**
 * 给缺向量的旧记忆补本地向量（只写 vec / vec_model，绝不碰 fact 正文与权重）。
 * @returns {{scanned:number, filled:number, skipped:number}}
 */
export function backfillVectors(db, { limit = 5000, force = false, model = LOCAL_MODEL } = {}) {
  let rows = [];
  try {
    rows = db.prepare(
      'SELECT id, fact, vec, vec_model FROM memories WHERE invalid_reason IS NULL ' +
      (force ? '' : 'AND (vec IS NULL OR vec_model IS NULL) ') +
      'ORDER BY COALESCE(confirmed_at_ms, created_at_ms) DESC LIMIT ?'
    ).all(limit);
  } catch {
    try { rows = db.prepare('SELECT id, fact FROM memories LIMIT ?').all(limit); } catch { return { scanned: 0, filled: 0, skipped: 0 }; }
  }
  let filled = 0, skipped = 0;
  const hasModel = (() => { try { return db.prepare('PRAGMA table_info(memories)').all().some(r => r.name === 'vec_model'); } catch { return false; } })();
  const st = hasModel
    ? db.prepare('UPDATE memories SET vec = ?, vec_model = ? WHERE id = ?')
    : db.prepare('UPDATE memories SET vec = ? WHERE id = ?');
  for (const r of rows) {
    if (!r.fact) { skipped++; continue; }
    const blob = vecToBlob(localVec(r.fact));
    try {
      if (hasModel) st.run(blob, model, r.id);
      else st.run(blob, r.id);
      filled++;
    } catch { skipped++; }
  }
  return { scanned: rows.length, filled, skipped, model };
}

/** 查询向量：优先宿主神经向量，失败回退本地 hash；返回 {vec, source} */
export async function queryVector(text, embed = null) {
  if (typeof embed === 'function') {
    try {
      const v = await embed(text);
      if (v && v.length) {
        const f = v instanceof Float32Array ? v : Float32Array.from(v);
        return { vec: f, source: 'host-embed' };
      }
    } catch { /* 回退本地 */ }
  }
  return { vec: localVec(text), source: LOCAL_MODEL };
}

export function recordVectorSource(db, k, v) {
  try {
    db.prepare("INSERT INTO kv(k,v,updated_at) VALUES(?,?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v, updated_at=excluded.updated_at")
      .run(k, String(v), Date.now());
  } catch { /* ignore */ }
}
