// src/memory/weight.mjs — 四轴 + effWeight + 保护层级 + 反刍/截断（2.4 / 2.21–2.26）
// 四轴：relevance（不持久，检索时算）/ importance（持久）/ belief（持久）/ activation（短周期）
// 禁止把四轴压成一个永久总分：谁高谁低必须回答不同问题。
import { DEFAULTS } from '../kit/config.mjs';
import { refMs, parseMs } from '../kit/time.mjs';

export const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));

/**
 * 参照时间（毫秒）。
 * v13.0：旧库的 confirmed_at/created_at 是 TEXT，直接 Number() 会得到 NaN；
 * 这里统一走 time.refMs —— 优先 *_ms 新列，回退 TEXT 解析（旧值不改写）。
 */
export function refTime(mem) {
  return refMs(mem);
}

export function daysSince(mem, now) {
  const t = refTime(mem);
  if (t == null) return null;
  return (now - t) / 86400000;
}

/** 旧列回退：任何地方要在 SQL 里按时间排序时用 COALESCE(created_at_ms, ...) */
export const msOf = parseMs;

/** 保护层级：ephemeral / normal / stable / core（2.22） */
export function tierOf(mem) {
  if (mem.protection_tier) return mem.protection_tier;
  if (mem.category === 'person' || mem.category === 'rule') return 'stable';
  return 'normal';
}

/**
 * effWeight = baseWeight * decay * (0.75 + 0.5*importance) * (1 + 0.35*emo + 0.25*rel)
 * - core：decay 用 1/4 速率（半衰期 ×4），不是永不衰减
 * - ephemeral：超 maxAgeDays 直接 0（强制截断）
 * - floor 仍按分类，core 额外抬到 0.45
 */
export function effWeight(mem, now, cfg = DEFAULTS) {
  const w = cfg.weight;
  const cat = mem.category in w.base ? mem.category : 'fact';
  const tier = tierOf(mem);
  const d = daysSince(mem, now);
  if (d == null) throw new Error('effWeight: confirmed_at 与 created_at 均为空');
  if (d < 0) throw new Error('effWeight: 未来时间，拒绝计算（decay>1）');

  // 强制截断：ephemeral 与超龄条目归零（2.26，来自 L小v/二号）
  const maxAge = w.maxAgeDays?.[cat] ?? 3650;
  if (tier === 'ephemeral' && d > (w.ephemeralMaxAgeDays ?? 7)) return 0;
  if (d > maxAge) return 0;

  // 反刍抑制：负面记忆命中过多，半衰期减半（只压负面，事实/关系豁免）
  let halfLife = w.halfLife[cat];
  if (tier === 'core') halfLife *= (w.coreHalfLifeFactor ?? 4);
  const rum = ruminationFactor(mem);
  if (rum !== 1) halfLife *= rum;

  const decay = Math.pow(0.5, d / halfLife);
  const imp = clamp(Number(mem.importance ?? 0.5), 0, 1);
  const emo = clamp(Number(mem.emotional_salience ?? 0), 0, 1);
  const rel = clamp(Number(mem.relationship_salience ?? 0), 0, 1);
  const v = (w.base[cat] ?? 1.0) * decay * (0.75 + 0.5 * imp) * (1 + 0.35 * emo + 0.25 * rel);

  const floor = Math.max(w.floor[cat] ?? 0, tier === 'core' ? (w.coreFloor ?? 0.45) : 0);
  return clamp(v, floor, 1);
}

/** 反刍系数：负面且 recall≥6 → 半衰期 ×0.5；正面/事实/关系 → 1 */
export function ruminationFactor(mem) {
  const neg = Number(mem.emotional_salience ?? 0) > 0.5 &&
    (mem.emotion === 'negative' || mem.emotion === 'sad' || mem.emotion === 'anger' || mem.emotion === 'fear');
  const hits = Number(mem.recall_count ?? 0);
  if (!neg || hits < 6) return 1;
  if (mem.category === 'fact' || mem.category === 'person' || mem.category === 'rule') return 1;
  return 0.5;
}

/**
 * v14 连续版反刍系数（Gitee mood.mjs：40 分钟内重复触发 → 半衰 ×(1+0.33·streak)，最多 +99%）。
 * 独立导出、不改 ruminationFactor 的旧行为；由调用方显式选用。
 */
export function ruminationHalfLifeV14(baseHalf, rum = {}, { now = Date.now(), windowMin = 40, step = 0.33, maxStreak = 3 } = {}) {
  const within = now - Number(rum.at || 0) < windowMin * 60000;
  const streak = within ? Math.min(maxStreak, Number(rum.streak || 0) + 1) : 0;
  return { halfLife: baseHalf * (1 + streak * step), streak, at: now };
}

/**
 * 检索总分（9.2，采纳 codex 的四项加权，含 route 上限）
 * retrievalScore = 0.60*base + 0.20*eff + 0.15*coverage + min(routeBoost, 0.10)
 */
export function retrievalScore({ base = 0, eff = 0, coverage = 0, routeBoost = 0 }) {
  return 0.60 * base + 0.20 * eff + 0.15 * clamp(coverage, 0, 1) + Math.min(routeBoost, 0.10);
}

/** 门槛：分数下限 + 双通道 + 可信度下限（belief 未传视为通过，兼容旧调用） */
export function passesGate({ textScore = 0, cos = 0, eff = 0, belief = null, coverage = 0, routeBoost = 0 }, cfg = DEFAULTS) {
  const r = cfg.retrieval;
  const base = Math.max(textScore, cos);
  const score = retrievalScore({ base, eff, coverage, routeBoost });
  if (!(score > r.scoreFloor)) return false;
  if (!(textScore >= r.textFloor || cos >= r.cosFloor)) return false;
  if (belief != null && belief < (r.beliefFloor ?? 0.35)) return false;
  return true;
}

/** 兼容旧名 */
export function scoreOf(base, eff, coverage = 0, routeBoost = 0) {
  return retrievalScore({ base, eff, coverage, routeBoost });
}

// ---------- 四轴取值 ----------
export function initImportance(category, s) {
  const adj = category === 'person' ? 0.05 : category === 'event' ? 0.10 : 0;
  return clamp(0.35 + 0.5 * s + adj, 0.35, 0.95);
}

export const BELIEF_BY_SRC = {
  owner: 0.95,
  user_confirm: 0.90,
  inferred: 0.55,
  model_inference: 0.40,
  tool_explicit: 0.65,        // 工具结果最多 0.65（工具隔离）
  audit_downgrade: 0.30,
};

/** 兼容 v12.0 的 β 命名：belief 与 beta 同义，读取以 belief 优先 */
export function beliefValue(mem) {
  return Number(mem.belief ?? mem.beta ?? 0.6);
}

export function initBeta(betaSrc) {
  return BELIEF_BY_SRC[betaSrc] ?? BELIEF_BY_SRC.inferred;
}

/** 注入资格：<0.55 不注入；0.55–0.85 加限定；≥0.85 直接陈述（2.12） */
export function injectable(mem) {
  const b = beliefValue(mem);
  if (b < 0.55) return { ok: false, mode: 'none' };
  // v14：假设语气打标的条目仍可召回，但必须带限定、不进 core、不作主动证据
  if (String(mem.anchor_ground || '').includes('hypothetical')) return { ok: true, mode: 'hypothetical' };
  if (b < 0.85) return { ok: true, mode: 'hedged' };
  return { ok: true, mode: 'fact' };
}

/** 是否允许转冷：core 不转冷；promise 不转冷；imp≥0.9 不转冷 */
export function shouldCold(mem, eff, cfg = DEFAULTS) {
  const tier = tierOf(mem);
  if (tier === 'core') return false;
  if (mem.category === 'person' || mem.category === 'rule' || mem.category === 'promise') return false;
  if (Number(mem.importance) >= 0.9) return false;
  return eff < cfg.memory.coldWeight;
}

// ---------- 核心准入 / 退出（2.22，采纳 codex 六条件）----------
export function coreEligible(mem, { independentEvidence = 0, userConfirm = false, unresolvedConflict = false, now = Date.now() } = {}) {
  if ((mem.audit_status || 'ok') !== 'ok') return { ok: false, reason: 'audit' };
  if (!['person', 'rule', 'promise', 'fact'].includes(mem.category)) return { ok: false, reason: 'category' };
  if (unresolvedConflict) return { ok: false, reason: 'conflict' };
  // v13.0：created_at 可能是 TEXT（旧库），必须解析后再算天数，否则 NaN < 7 恒为 false → 准入被误放行
  const bornMs = parseMs(mem.created_at_ms) ?? parseMs(mem.created_at) ?? now;
  const ageDays = (now - bornMs) / 86400000;
  if (ageDays < 7) return { ok: false, reason: 'too-young' };
  if (!(independentEvidence >= 2 || (userConfirm && independentEvidence >= 1))) {
    return { ok: false, reason: 'evidence' };
  }
  // 双路径：①可信度合格（codex）；②重要度极高（豆包）。两条都得有证据与时间。
  const byBelief = beliefValue(mem) >= 0.85;
  const byImportance = Number(mem.importance ?? 0) >= 0.90;
  if (!byBelief && !byImportance) return { ok: false, reason: 'belief-and-importance' };
  return { ok: true, path: byBelief ? 'belief' : 'importance' };
}

/** 退出 core：189→180 天未验证，且重要度已掉、无开放承诺（codex D.18 裁定） */
export function coreExit(mem, { now = Date.now(), hasOpenPromise = false } = {}) {
  if (tierOf(mem) !== 'core') return { ok: false, reason: 'not-core' };
  if ((mem.audit_status || 'ok') !== 'ok') return { ok: true, reason: 'audit' };
  if (mem.invalid_reason) return { ok: true, reason: 'invalid' };
  const idle = (now - Number(mem.last_recalled || mem.confirmed_at || mem.created_at)) / 86400000;
  const decayed = Number(mem.importance) < 0.6;
  if (idle > 180 && decayed && !hasOpenPromise) return { ok: true, reason: 'idle' };
  return { ok: false };
}

/** 层级配额：core ≤3%、stable ≤15%，超限按最后确认时间升序降级 */
export const TIER_QUOTA = { core: 0.03, stable: 0.15 };

/**
 * 对照实验（不参与运行，仅供 0.9.3 的裁定举证）：
 * 豆包方案 core 乘 3.0，我方方案 core 半衰期 ×4 + floor 0.45。
 * 结果：乘数在上界处饱和（一堆 core 全撞 1.0），半衰期不饱和（保留梯度）。
 */
export function compareTierStrategies(mem, now, { multiplier = 3.0, cfg = DEFAULTS } = {}) {
  const base = effWeight(mem, now, cfg);
  const mult = Math.min(1, base * multiplier);
  const halfLifeCore = { ...mem, protection_tier: 'core' };
  return { ours: effWeight(halfLifeCore, now, cfg), theirs: mult, base };
}
