// src/outlet/cleaner.mjs — 出口清洗器（17.3）+ 工具结果裁剪（18.7）+ 回声检测（3.9）
import { DEFAULTS } from '../kit/config.mjs';
import { jaccard } from '../memory/text.mjs';

// 只剥白名单内的注入标签，避免误伤用户自己的【】
export const INJECT_TAGS = [
  '当前时间', '此刻', '当前角色', '你的身份', '阶段背景', '记忆', '状态',
  '事实', '偏好', '片段', '摘要', '提醒', '关系', '承诺', '图片', '交接',
];

const RE_MEMID = /\bm[0-9a-f]{5,}\b/gi;
const RE_SESSION = /session-[0-9a-f-]{8,}/gi;
const RE_SHA = /sha256:[0-9a-f]{64}/gi;

function stripTags(text) {
  let out = text;
  for (const tag of INJECT_TAGS) {
    // 【标签】内容 → 内容；【标签·xxx】→ 内容
    const re = new RegExp(`【${tag}[^】]*】`, 'g');
    out = out.replace(re, '');
  }
  return out;
}

function looksJson(text) {
  const t = text.trim();
  if (!(t.startsWith('{') && t.endsWith('}')) && !(t.startsWith('[') && t.endsWith(']'))) return false;
  if (t.length > DEFAULTS.outlet.jsonMinLen) return true;
  const kvHits = (t.match(/"[^"]{1,30}"\s*:/g) || []).length;
  return kvHits >= 3;
}

/** 超长工具结果：保留头 4096 + 尾 1024 */
export function trimToolResult(text, cfg = DEFAULTS) {
  const o = cfg.outlet;
  const t = String(text ?? '');
  if (t.length <= o.trimAt) return t;
  const cut = t.length - o.trimHead - o.trimTail;
  return t.slice(0, o.trimHead) + `\n…（已裁剪 ${cut} 字符）\n` + t.slice(-o.trimTail);
}

/**
 * 主清洗：挂发送函数内，纯函数。
 * @returns {{text:string, removed:string[]}}
 */
export function cleanOutgoing(text, { inCodeBlock = false } = {}) {
  let t = String(text ?? '');
  const removed = [];
  if (!t) return { text: '', removed };

  t = t.replace(RE_MEMID, m => { removed.push('memid:' + m); return ''; });
  t = t.replace(RE_SESSION, m => { removed.push('session'); return ''; });
  t = t.replace(RE_SHA, () => { removed.push('hash'); return ''; });

  const beforeTag = t;
  t = stripTags(t);
  if (t !== beforeTag) removed.push('tag');

  // JSON 回显：整条丢弃（代码块内不触发）
  if (!inCodeBlock && looksJson(t)) {
    removed.push('json');
    t = '[已获取信息]';
  }

  // 收尾：中文之间的空格、标点后空白、连续空行
  t = t.replace(/([\u4e00-\u9fa5])\s+(?=[\u4e00-\u9fa5])/g, '$1')
       .replace(/\s+([，。！？；：、])/g, '$1')
       .replace(/([，。！？；：、])\s+/g, '$1')
       .replace(/[ \t]{2,}/g, ' ')
       .replace(/\n{3,}/g, '\n\n')
       .trim();

  return { text: t, removed };
}

/** 回声检测：10 分钟内说过的话，Jaccard > 0.75 视为回声 */
export function isEcho(candidate, recentSaid, cfg = DEFAULTS) {
  for (const s of recentSaid) {
    if (jaccard(candidate, s) >= cfg.outlet.echoJaccard) return true;
  }
  return false;
}

/** 从模型输出里剥掉 thinking / 工具调用帧（插件侧兜底，主责在客户端） */
export function stripFrames(text) {
  return String(text ?? '')
    .replace(/^\s*(思考|thinking)[:：].*$/gim, '')
    .replace(/^\s*(工具调用|tool_call)[:：].*$/gim, '')
    .trim();
}
