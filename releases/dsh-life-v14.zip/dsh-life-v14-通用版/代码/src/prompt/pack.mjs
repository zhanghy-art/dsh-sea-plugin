// Safe loader for the DSH prompt pack. Prompt text is data, but it is still
// validated for path traversal, size, ordering, and unresolved placeholders.
import { readFileSync } from 'node:fs';
import { dirname, isAbsolute, join, normalize, relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

export const DEFAULT_PROMPT_ROOT = fileURLToPath(new URL('../../prompts/', import.meta.url));

function assertSafeRelativePath(value) {
  const raw = String(value || '').trim();
  if (!raw || isAbsolute(raw) || /^[A-Za-z]:/.test(raw)) throw new Error('prompt path must be relative');
  const normalized = normalize(raw).replaceAll('\\', '/');
  if (normalized === '..' || normalized.startsWith('../') || normalized.includes('/../')) {
    throw new Error('prompt path escapes root');
  }
  return normalized;
}

export function validatePromptManifest(manifest, { root = DEFAULT_PROMPT_ROOT } = {}) {
  if (!manifest || typeof manifest !== 'object') throw new Error('manifest must be an object');
  if (!Array.isArray(manifest.order) || !Array.isArray(manifest.files)) throw new Error('manifest order/files required');
  const base = resolve(root);
  const ids = new Set();
  const byId = new Map();
  for (const entry of manifest.files) {
    const id = String(entry?.id || '').trim();
    if (!id || ids.has(id)) throw new Error('prompt ids must be unique');
    ids.add(id);
    const rel = assertSafeRelativePath(entry.path);
    const abs = resolve(base, rel);
    const within = relative(base, abs);
    if (within.startsWith('..') || isAbsolute(within)) throw new Error('prompt path escapes root');
    const maxChars = Number(entry.maxChars);
    if (!Number.isFinite(maxChars) || maxChars <= 0) throw new Error(`invalid maxChars for ${id}`);
    byId.set(id, { ...entry, id, path: rel, absolutePath: join(base, rel), maxChars });
  }
  for (const id of manifest.order) {
    if (!byId.has(id)) throw new Error(`order references missing prompt: ${id}`);
  }
  if (manifest.order.length !== byId.size) throw new Error('order must include every prompt exactly once');
  return manifest.order.map((id) => byId.get(id));
}

export function loadPromptPack({ root = DEFAULT_PROMPT_ROOT, ids = null, separator = '\n\n' } = {}) {
  const manifest = JSON.parse(readFileSync(join(root, 'manifest.json'), 'utf8'));
  const entries = validatePromptManifest(manifest, { root });
  const selected = ids?.length ? entries.filter((entry) => ids.includes(entry.id)) : entries;
  const sections = selected.map((entry) => {
    const text = readFileSync(entry.absolutePath, 'utf8').trim();
    if (!text) throw new Error(`empty prompt: ${entry.id}`);
    if (text.length > entry.maxChars) throw new Error(`prompt too long: ${entry.id}`);
    if (/\{\{[^}]+\}\}/.test(text)) throw new Error(`unresolved placeholder in ${entry.id}`);
    return { id: entry.id, scope: entry.scope, required: entry.required, text, chars: text.length };
  });
  const text = sections.map((section) => section.text).join(separator);
  return {
    version: manifest.version,
    root: dirname(join(root, 'manifest.json')),
    sections,
    text,
    chars: text.length,
  };
}
