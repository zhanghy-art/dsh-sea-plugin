// src/reflex/activation.mjs — 条件反射：激活度累积（3.3，替代 v11.1 的双阈值）
import { DEFAULTS } from '../kit/config.mjs';

export class ActivationBook {
  constructor(cfg = DEFAULTS) {
    this.cfg = cfg.reflex;
    this.map = new Map();       // id -> {activation, lastFiredAt, fireCount, dayKey, dayCount}
  }

  load(rows) {
    for (const r of rows) {
      this.map.set(r.id, {
        activation: Number(r.activation || 0),
        lastFiredAt: r.last_fired_at || 0,
        fireCount: Number(r.fire_count || 0),
        dayKey: '', dayCount: 0,
      });
    }
  }

  get(id) { return this.map.get(id) || { activation: 0, lastFiredAt: 0, fireCount: 0, dayKey: '', dayCount: 0 }; }

  /** 每轮：按相似度与是否词面命中累积 */
  bump(id, similarity, explicitHit, painLevel) {
    const st = this.get(id);
    const gain = explicitHit ? this.cfg.explicitGain
      : (this.cfg.semanticGain ?? 0.35) * Math.max(0, Math.min(1, similarity));
    st.activation += Math.max(0, Math.min(1, painLevel)) * gain;
    this.map.set(id, st);
    return st.activation;
  }

  /** 每 life-tick 衰减；支持不同 tick 间隔（豆包的 *0.95^(elapsed/15) 参数化） */
  decayAll(elapsedMin = 15) {
    const k = Math.pow(this.cfg.decayPerTick, Math.max(0, elapsedMin) / 15);
    for (const [, st] of this.map) {
      st.activation *= k;
      if (st.activation < this.cfg.zeroEps) st.activation = 0;
    }
  }

  /** 选 activation 最高且过阈值的一条；受每日总闸与单条 24h 限次 */
  pick(now = Date.now(), dayKey = '') {
    let best = null;
    for (const [id, st] of this.map) {
      if (st.activation < this.cfg.threshold) continue;
      if (st.fireCount > 0 && st.lastFiredAt && now - st.lastFiredAt < 86400000) continue; // 24h 同条一次
      if (st.dayKey !== dayKey) { st.dayKey = dayKey; st.dayCount = 0; }
      if (st.dayCount >= this.cfg.maxDaily) continue;
      if (!best || st.activation > best.st.activation) best = { id, st };
    }
    return best;
  }

  /** 触发后 activation 清零，painLevel 不动 */
  fire(id, now = Date.now(), dayKey = '') {
    const st = this.get(id);
    st.activation = 0;
    st.lastFiredAt = now;
    st.fireCount += 1;
    if (st.dayKey !== dayKey) { st.dayKey = dayKey; st.dayCount = 0; }
    st.dayCount += 1;
    this.map.set(id, st);
    return st;
  }

  /** 落盘：写回 reflexes 表 */
  persist(db) {
    const st = db.prepare('UPDATE reflexes SET activation = ?, last_fired_at = ?, fire_count = ? WHERE id = ?');
    for (const [id, s] of this.map) st.run(s.activation, s.lastFiredAt, s.fireCount, id);
  }
}
