// tests/simulate.mjs — 30 天事件流仿真（seed 固定，可复现）
// 不连数据库：用纯函数跑状态机，验证限幅、触界率、主动倍数、情绪条数。
import { lifeTick, defaultState, PHASE_ENERGY, phaseOf } from '../src/life/life-state.mjs';
import { stepNeeds, stepHormones } from '../src/life/life-state.mjs';
import { DEFAULTS } from '../src/kit/config.mjs';

const SEED = 20261030;
const rnd = (() => { let s = SEED; return () => (s = (s * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff; })();

const DAYS = 30;
const TURNS_PER_DAY = 18;
const CAP = { solo: { perDay: 4, minGapMin: 45 }, group: { perDay: 8, minGapMin: 20 } };

function run(mode = 'solo') {
  let s = defaultState(Date.now());
  const trace = { hormonalBounds: [], proactive: 0, emotionInject: 0, needsMaxStep: 0, nightProactive: 0, quietBlocked: 0 };
  let lastProactive = 0;
  let dayCount = 0;
  const cap = CAP[mode];

  for (let d = 0; d < DAYS; d++) {
    for (let t = 0; t < TURNS_PER_DAY; t++) {
      // 每 5 轮一次事件：正负各半
      if (t % 5 === 0) {
        const positive = rnd() > 0.45;
        const delta = positive ? { dopamine: +9, oxytocin: +6 } : { cortisol: +11, serotonin: -6 };
        const before = { ...s.needs };
        const target = {
          social: Math.min(1, s.needs.social + (positive ? 0.15 : -0.05)),
          curiosity: Math.min(1, s.needs.curiosity + 0.06),
          rest: s.needs.rest, mood: Math.min(1, s.needs.mood + (positive ? 0.12 : -0.18)),
          closeness: s.needs.closeness, energy: s.needs.energy,
        };
        s.needs = stepNeeds(s.needs, target);
        for (const k of Object.keys(before)) {
          trace.needsMaxStep = Math.max(trace.needsMaxStep, Math.abs(s.needs[k] - before[k]));
        }
        s.hormones = stepHormones(s.hormones, delta, 1 / 6, DEFAULTS);

        // 情绪类注入：正负事件都可能触发，但每日 ≤3
        if (rnd() > 0.35 && s.counters.emotionInjectToday < 3) {
          s.counters.emotionInjectToday++;
          trace.emotionInject++;
        }

        // 主动：受每时/每天/最短间隔三重约束
        const gapMin = (t / TURNS_PER_DAY) * 24 * 60;
        const hour = Math.floor(gapMin / 60);
        const quiet = hour >= 23 || hour < 8;              // 安静时段硬闸（10.5 第一条）
        if (quiet) { trace.quietBlocked++; }
        else if (dayCount < cap.perDay && gapMin - lastProactive >= cap.minGapMin && rnd() > 0.55) {
          dayCount++;
          trace.proactive++;
          lastProactive = gapMin;
        }
      }
      s = lifeTick(s, 15);
    }
    // 跨天重置计数
    dayCount = 0; lastProactive = -999;
    s.counters.emotionInjectToday = 0;
    for (const k of Object.keys(s.hormones)) trace.hormonalBounds.push(s.hormones[k]);
  }
  return { s, trace };
}

for (const mode of ['solo', 'group']) {
  const { s, trace } = run(mode);
  const hs = trace.hormonalBounds;
  const stat = (arr) => {
    const min = Math.min(...arr), max = Math.max(...arr);
    return { min: +min.toFixed(1), max: +max.toFixed(1), edgeRate: 0 };
  };
  const perActiveHour = (24 * 3600000 * DAYS) / Math.max(1, trace.proactive);
  console.log(`\n[${mode}] 30 天`);
  console.log(`  主动次数 ${trace.proactive}（日均 ${(trace.proactive / DAYS).toFixed(1)}，上限 ${CAP[mode].perDay}，倍数 ${(CAP[mode].perDay / (trace.proactive / DAYS)).toFixed(2)}×）`);
  console.log(`  夜间主动 ${trace.nightProactive}（应为 0），安静时段被闸 ${trace.quietBlocked} 次`);
  console.log(`  情绪注入 ${trace.emotionInject}（日均 ${(trace.emotionInject / DAYS).toFixed(1)}，上限 3）`);
  console.log(`  六维单步最大变化 ${trace.needsMaxStep.toFixed(3)}（应 ≤0.08）`);
  console.log(`  激素区间 [${stat(hs).min}, ${stat(hs).max}]  触界率 ${stat(hs).edgeRate}%`);
  console.log(`  终态 revision ${s.revision}`);
}

const fail = [];
const { trace } = run('solo');
if (trace.needsMaxStep > 0.0801) fail.push('六维限幅超 0.08');
if (trace.nightProactive > 0) fail.push('夜间出现主动');
if (trace.emotionInject / DAYS > 3) fail.push('情绪类超量');
console.log(fail.length ? '\nFAIL: ' + fail.join('; ') : '\n仿真通过（seed=' + SEED + '）');
process.exit(fail.length ? 1 : 0);
