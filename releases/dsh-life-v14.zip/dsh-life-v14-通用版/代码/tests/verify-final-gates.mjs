#!/usr/bin/env node
import { DatabaseSync } from 'node:sqlite';
import { inspectEdgesBasis, migrateEdgesBasis } from '../src/kit/optional-migrations.mjs';

let pass = 0;
let fail = 0;
const ok = (id, cond, got) => {
  if (cond) { pass++; console.log(`  PASS ${id}`); }
  else { fail++; console.log(`  FAIL ${id} got=${JSON.stringify(got)}`); }
};

console.log('\n== FG-A. Optional edges.basis migration ==');
{
  const db = new DatabaseSync(':memory:');
  db.exec(`
    CREATE TABLE edges(from_id INTEGER,to_id INTEGER,type TEXT,weight REAL,created_at INTEGER);
    CREATE TABLE kv(k TEXT PRIMARY KEY,v TEXT,updated_at INTEGER);
  `);
  const dry = migrateEdgesBasis(db);
  ok('A1 dry-run does not alter', dry.ok && dry.wouldAdd === true && !inspectEdgesBasis(db).hasBasis, dry);
  const applied = migrateEdgesBasis(db);
  ok('A2 dry-run remains idempotent', applied.wouldAdd === true && !inspectEdgesBasis(db).hasBasis, applied);
  const real = migrateEdgesBasis(db, { apply: true });
  ok('A3 explicit apply adds basis', real.ok && real.applied === true && inspectEdgesBasis(db).hasBasis, real);
  const again = migrateEdgesBasis(db, { apply: true });
  ok('A4 repeat apply is a no-op', again.ok && again.alreadyPresent === true, again);
  ok('A5 schema version is explicit', db.prepare("SELECT v FROM kv WHERE k='schema_version'").get()?.v === '14');
  db.close();
}

console.log(`\n结果（最终门禁）：PASS ${pass} / FAIL ${fail}`);
if (fail) process.exit(1);
