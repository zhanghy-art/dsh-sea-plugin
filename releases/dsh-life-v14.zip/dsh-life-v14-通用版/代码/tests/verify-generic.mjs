// tests/verify-generic.mjs — 通用版（profile: generic）冒烟验证
// 目标：证明同一套代码在「没有 DSH ctx」的宿主上也能跑通完整一轮：
// 启动 → 用户说话（检索/组装）→ 模型回复（出口清洗）→ 15 分钟 tick → 停止。
// 断言直接对应 src/host/generic.mjs 的四个回调契约，不新增业务维度。
import { DatabaseSync } from 'node:sqlite';
import { mkdtempSync, rmSync, existsSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import createPlugin from '../src/index.mjs';
import { createGenericHost } from '../src/host/generic.mjs';

let pass = 0, fail = 0;
const ok = (name, cond, detail = '') => {
  if (cond) { pass++; console.log(`  PASS ${name}${detail ? ' — ' + detail : ''}`); }
  else { fail++; console.log(`  FAIL ${name}${detail ? ' — ' + detail : ''}`); }
};

const dir = mkdtempSync(join(tmpdir(), 'dsh13-generic-'));
const dbPath = join(dir, 'mind.db');
const emitted = [];
const sectionsSeen = [];

const api = createGenericHost({
  log: { info() {}, warn() {}, error() {} },
  embed: null,                       // 宿主没有向量能力：引擎必须自动退到纯文本通道
  persona: () => '你叫小鱼，说话简短。',
  emit: (name, payload) => emitted.push({ name, payload }),
});

const plugin = createPlugin(api.ctx, { dbPath, profile: 'generic' });

console.log('\n== G1. 启动 ==');
await api.start();
{
  ok('G1-a 启动不抛错', true);
  ok('G1-b 库文件已建', existsSync(dbPath));
  const db = new DatabaseSync(dbPath, { readOnly: true });
  const uv = db.prepare('PRAGMA user_version').get().user_version;
  ok('G1-c user_version = 14', Number(uv) === 14, String(uv));
  const cols = db.prepare('PRAGMA table_info(memories)').all().map(r => r.name);
  ok('G1-d memories 已含 v13 列', cols.includes('protection_tier') && cols.includes('content_hash'));
  db.close();
}

console.log('\n== G2. 一轮用户输入 ==');
{
  const sections = await api.userMessage({ text: '我今天想吃面条', scope: 'private:10001', ownerQq: '10001' });
  sectionsSeen.push(...sections.keys());
  ok('G2-a 返回段落 Map', sections instanceof Map);
  ok('G2-b 有人格段', api.ctx.systemPrompt.persona().includes('小鱼'));
  ok('G2-c 段落键是 dsh-life.*', [...sections.keys()].every(k => k.startsWith('dsh-life.')), [...sections.keys()].join(','));
  ok('G2-d 没有向量也不报错', true);
}

console.log('\n== G3. 模型回复过出口 ==');
{
  const r1 = await api.reply({ text: '查到了：{"a":1,"b":2,"c":3}', message: { scope: 'private:10001', ownerQq: '10001' } });
  ok('G3-a 返回 {text, rewrite}', typeof r1.text === 'string' && 'rewrite' in r1);
  ok('G3-b 文本未被误折', r1.text.includes('查到了'));

  const r2 = await api.reply({ text: '{"a":1,"b":2,"c":3,"d":4,"e":5,"f":6,"g":7,"h":8,"i":9,"j":10,"k":11,"l":12,"m":13,"n":14,"o":15,"p":16,"q":17,"r":18,"s":19,"t":20}', message: { scope: 'private:10001' } });
  ok('G3-c 纯 JSON 被折叠成占位', r2.text.includes('[已获取信息]'));

  const r3 = await api.reply({ text: '嗯嗯，面条好呀', message: { scope: 'private:10001' } });
  const r4 = await api.reply({ text: '嗯嗯，面条好呀', message: { scope: 'private:10001' } });
  ok('G3-d 重复内容触发回声标记', r4.rewrite === true, String(r4.rewrite));
}

console.log('\n== G4. 群聊 scope 与隔离 ==');
{
  await api.userMessage({ text: '群里聊面条', scope: 'group:777', ownerQq: '10001', groupId: '777' });
  ok('G4-a 群聊不抛错', true);
  const r = await api.reply({ text: '收到', message: { scope: 'group:777', groupId: '777' } });
  ok('G4-b 群聊回复可清洗', typeof r.text === 'string');
}

console.log('\n== G5. 定时器与停止 ==');
{
  ok('G5-a 注册了 15 分钟 tick', api.ctx && typeof api.ctx.timer.every === 'function');
  ok('G5-b 工具位可注册', Array.isArray(api.tools));
  api.stop();
  ok('G5-c stop 后不抛错', true);
}

console.log('\n== G6. 复用 DSH 的同一套升级路径 ==');
{
  const db0 = new DatabaseSync(dbPath, { readOnly: true });
  const colsBefore = db0.prepare('PRAGMA table_info(memories)').all().length;
  db0.close();
  // 通用版允许旧库原地升级：再开一次 start() 不应重复迁移
  const api2 = createGenericHost({ log: { info() {}, warn() {}, error() {} }, persona: () => '' });
  createPlugin(api2.ctx, { dbPath, profile: 'generic' });
  await api2.start();
  const db = new DatabaseSync(dbPath, { readOnly: true });
  const colsAfter = db.prepare('PRAGMA table_info(memories)').all().length;
  const uv = db.prepare('PRAGMA user_version').get().user_version;
  ok('G6-a 二次启动不新增列', colsAfter === colsBefore, `${colsBefore} → ${colsAfter}`);
  ok('G6-b user_version 仍为 14', Number(uv) === 14, String(uv));
  db.close();
  api2.stop();
}

console.log(`\n结果（通用版）：PASS ${pass} / FAIL ${fail} / SKIP 0`);
try { rmSync(dir, { recursive: true, force: true }); } catch {}
process.exit(fail ? 1 : 0);
