#!/usr/bin/env node
import { mkdtempSync, readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { tmpdir } from 'node:os';
import { loadPromptPack, validatePromptManifest } from '../src/prompt/pack.mjs';
import { parseEvalDataset, runRetrievalEval } from '../src/eval/retrieval-eval.mjs';
import { createGenericHost } from '../src/host/generic.mjs';
import createPlugin from '../src/index.mjs';

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..');
let pass = 0;
let fail = 0;
const ok = (id, cond, got) => {
  if (cond) { pass++; console.log(`  PASS ${id}`); }
  else { fail++; console.log(`  FAIL ${id} got=${JSON.stringify(got)}`); }
};

console.log('\n== PE-A. Prompt pack ==');
{
  const pack = loadPromptPack({ root: join(ROOT, 'prompts') });
  ok('A1 prompt version', pack.version === '14.0', pack.version);
  ok('A2 stable order', pack.sections.map((x) => x.id).join(',') === 'system-core,tool-policy,memory-write,nightly-audit,handoff',
    pack.sections.map((x) => x.id));
  ok('A3 bounded size', pack.chars > 1000 && pack.chars < 7000, pack.chars);
  ok('A4 every section has a scope', pack.sections.every((x) => ['system', 'task'].includes(x.scope)),
    pack.sections.map((x) => [x.id, x.scope]));
  let traversalRejected = false;
  try {
    validatePromptManifest({
      order: ['bad'],
      files: [{ id: 'bad', path: '../outside.md', scope: 'system', required: true, maxChars: 10 }],
    }, { root: join(ROOT, 'prompts') });
  } catch { traversalRejected = true; }
  ok('A5 path traversal rejected', traversalRejected);
  const dir = mkdtempSync(join(tmpdir(), 'dsh-prompt-'));
  const host = createGenericHost({ log: { info() {}, warn() {}, error() {} }, persona: () => 'test', embed: async () => null });
  createPlugin(host.ctx, { dbPath: join(dir, 'mind.db'), capabilities: { v14: true } });
  await host.start();
  const injected = host.sections.get('dsh-life.policy') || '';
  ok('A6 prompt pack is injected at ready', injected.includes('系统核心约束') && injected.includes('工具使用策略'),
    injected.slice(0, 120));
  host.stop();
}

console.log('\n== PE-B. Chinese retrieval eval ==');
{
  const dataset = parseEvalDataset(readFileSync(join(ROOT, 'eval', 'zh-retrieval.json'), 'utf8'));
  const result = await runRetrievalEval(dataset, { root: ROOT });
  ok('B1 all cases executed', result.total === 12, result.total);
  ok('B2 recall@5 meets gate', result.recallAtK >= 0.95, result.recallAtK);
  ok('B3 MRR meets gate', result.mrr >= 0.90, result.mrr);
  ok('B4 no cross-scope leak', result.forbiddenLeaks === 0, result.forbiddenLeaks);
  ok('B5 long question covered', result.cases.find((x) => x.id === 'long_question')?.hit === true);
  ok('B6 FTS birthday regression covered', result.cases.find((x) => x.id === 'birthday')?.hit === true);
  const saved = JSON.parse(readFileSync(join(ROOT, 'eval', 'zh-retrieval.result.json'), 'utf8'));
  ok('B7 saved result matches the gate', saved.passed === true && saved.recallAtK === result.recallAtK
    && saved.forbiddenLeaks === 0, saved);
}

console.log(`\n结果（Prompt Pack + 中文检索评测）：PASS ${pass} / FAIL ${fail}`);
if (fail) process.exit(1);
