#!/usr/bin/env node
// tests/verify-upgrade.mjs — v11.1 原库直升级验证（codex v13.2 第 11 章的 30 项）
// 这不是「跑一遍不报错」，而是逐条钉住「旧数据一行都没变、新能力真的长出来了」。
// 用法：node tests/verify-upgrade.mjs [--keep]
//   --keep 保留临时库，便于人工检查（默认跑完删掉）
import { DatabaseSync } from 'node:sqlite';
import { mkdtempSync, existsSync, readdirSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { ensureSchema, openDb, legacyFingerprint, kvGet } from '../src/kit/db.mjs';
import { writeMemory, scanCold } from '../src/memory/engine.mjs';
import { searchMemory } from '../src/memory/search.mjs';
import { reviewCandidate } from '../src/memory/candidates.mjs';
import { recover, saveState, defaultState } from '../src/life/life-state.mjs';
import { DEFAULTS } from '../src/kit/config.mjs';

let pass = 0, fail = 0;
const failures = [];
const ok = (id, cond, got) => {
  if (cond) { pass++; console.log(`  PASS ${id}`); }
  else { fail++; failures.push(id); console.log(`  FAIL ${id}  got=${JSON.stringify(got)}`); }
};

// ---------- v11.1 的真实 DDL（照抄文档第十一章，CHECK 约束一个字都不能省） ----------
const V11_DDL = `
CREATE TABLE memories (
  id                    INTEGER PRIMARY KEY AUTOINCREMENT,
  scope                 TEXT NOT NULL,
  subject_qq            TEXT,
  category              TEXT NOT NULL,
  fact                  TEXT NOT NULL COLLATE NOCASE,
  tags                  TEXT,
  evidence              TEXT,
  evidence_kind         TEXT CHECK (evidence_kind IN
                         ('user_sentence','window_messages','model_inference','manual')),
  evidence_ref          TEXT,
  source_kind           TEXT,
  source_id             TEXT,
  raw                   TEXT,
  importance            REAL DEFAULT 0.5 CHECK (importance BETWEEN 0 AND 1),
  emotional_salience    REAL DEFAULT 0    CHECK (emotional_salience BETWEEN 0 AND 1),
  relationship_salience REAL DEFAULT 0    CHECK (relationship_salience BETWEEN 0 AND 1),
  happened_at           TEXT,
  time_granularity      TEXT CHECK (time_granularity IN ('day','week','month','uncertain')),
  created_at            TEXT NOT NULL,
  confirmed_at          TEXT,
  emotion               TEXT,
  emotion_intensity     REAL DEFAULT 0,
  bot_feeling           TEXT,
  bot_feeling_intensity REAL DEFAULT 0,
  perspective           TEXT,
  attr_key              TEXT,
  attr_value            TEXT,
  supersedes            INTEGER REFERENCES memories(id),
  invalid_reason        TEXT CHECK (invalid_reason IN
                         ('conflict','superseded','expired','manual','audit')),
  valid_to              TEXT,
  recall_count          INTEGER DEFAULT 0,
  last_recalled         TEXT,
  uses                  INTEGER DEFAULT 0,
  cold                  INTEGER DEFAULT 0,
  cold_reason           TEXT CHECK (cold_reason IN ('age','capacity')),
  cold_at               TEXT,
  audit_status          TEXT DEFAULT 'ok' CHECK (audit_status IN ('ok','suspect','unsupported')),
  vec                   BLOB,
  vec_model             TEXT
);
CREATE INDEX idx_mem_scope_cat   ON memories(scope, category, cold);
CREATE INDEX idx_mem_subject     ON memories(subject_qq, cold);
CREATE INDEX idx_mem_attr        ON memories(attr_key, scope);
CREATE INDEX idx_mem_confirmed   ON memories(confirmed_at);
CREATE VIRTUAL TABLE mem_fts USING fts5(
  fact, tags, content='memories', content_rowid='id', tokenize='trigram'
);
CREATE TABLE narratives (
  id INTEGER PRIMARY KEY AUTOINCREMENT, period TEXT, kind TEXT, text TEXT,
  audit_status TEXT DEFAULT 'ok', created_at TEXT
);
CREATE TABLE candidates (
  id INTEGER PRIMARY KEY AUTOINCREMENT, scope TEXT NOT NULL, text TEXT,
  kind TEXT, payload TEXT, evidence TEXT, status TEXT DEFAULT 'pending',
  created_at TEXT, expires_at TEXT
);
CREATE TABLE relationships (
  scope TEXT PRIMARY KEY, closeness REAL DEFAULT 0.5, trust REAL DEFAULT 0.5,
  stage TEXT DEFAULT 'normal', updated_at TEXT
);
CREATE TABLE promises (
  id INTEGER PRIMARY KEY AUTOINCREMENT, scope TEXT NOT NULL, direction TEXT,
  text TEXT, due_at TEXT, status TEXT DEFAULT 'pending', created_at TEXT
);
CREATE TABLE milestones (
  id INTEGER PRIMARY KEY AUTOINCREMENT, scope TEXT NOT NULL, text TEXT,
  happened_at TEXT, created_at TEXT
);
CREATE TABLE reflexes (
  id INTEGER PRIMARY KEY AUTOINCREMENT, scope TEXT NOT NULL, trigger TEXT,
  response TEXT, pain_level REAL DEFAULT 0.5, activation REAL DEFAULT 0,
  last_fired_at TEXT, fire_count INTEGER DEFAULT 0, created_at TEXT
);
CREATE TABLE injection_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT, memory_id TEXT NOT NULL, scope TEXT,
  kind TEXT, injected_at INTEGER NOT NULL, turn_id TEXT
);
CREATE TABLE edges (
  from_id TEXT NOT NULL, to_id TEXT NOT NULL, type TEXT NOT NULL,
  weight REAL DEFAULT 0.5, created_at INTEGER NOT NULL,
  PRIMARY KEY (from_id, to_id, type)
);
CREATE TABLE life_state (
  id         INTEGER PRIMARY KEY CHECK (id = 1),
  revision   INTEGER NOT NULL,
  state_json TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE life_events (
  event_id   TEXT PRIMARY KEY,
  event_type TEXT NOT NULL,
  event_json TEXT NOT NULL,
  created_at TEXT NOT NULL,
  applied_at TEXT
);
CREATE TABLE life_snapshots (
  revision      INTEGER PRIMARY KEY,
  snapshot_json TEXT NOT NULL,
  state_hash    TEXT NOT NULL,
  created_at    TEXT NOT NULL
);
CREATE TABLE action_proposals (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  kind       TEXT NOT NULL,
  reason     TEXT,
  utility    REAL,
  status     TEXT NOT NULL,
  expires_at TEXT
);
CREATE TABLE memories_archive (
  id INTEGER, archived_at TEXT, reason TEXT, payload TEXT
);
CREATE TABLE kv (k TEXT PRIMARY KEY, v TEXT, updated_at INTEGER);
`;

const OWNER = '10086';
const SCOPE = `private:${OWNER}`;
const DAY = 86400000;
const iso = (ms) => new Date(ms).toISOString().slice(0, 19).replace('T', ' ');

function seedV11(db, now, n = 30) {
  const ins = db.prepare(`INSERT INTO memories
    (scope, subject_qq, category, fact, tags, evidence, evidence_kind, evidence_ref,
     source_kind, source_id, raw, importance, emotional_salience, relationship_salience,
     happened_at, time_granularity, created_at, confirmed_at, emotion, perspective,
     attr_key, attr_value, cold, audit_status)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
  for (let i = 0; i < n; i++) {
    const t = now - (i + 1) * DAY;
    ins.run(
      SCOPE, OWNER,
      i % 5 === 0 ? 'person' : i % 3 === 0 ? 'promise' : 'fact',
      `旧库第${i}条记忆：主人的习惯条目${i}`,
      '["习惯","旧库"]',
      `原话片段 ${i}`,
      'user_sentence', `m${1000 + i}`,
      'user', OWNER,
      `这是第 ${i} 条记忆的原话全文，升级后必须原样保留`,
      0.5 + (i % 5) * 0.05, i % 3 === 0 ? 0.4 : 0, i % 4 === 0 ? 0.3 : 0,
      iso(t), 'day', iso(t), i % 2 === 0 ? iso(t) : null,
      i % 3 === 0 ? 'happy' : null, 'user',
      i % 4 === 0 ? 'food' : null, i % 4 === 0 ? `面条${i}` : null,
      0, 'ok'
    );
  }
  // 一条已废弃、一条已转冷：验证 CHECK 值与状态不被改写
  db.prepare(`UPDATE memories SET invalid_reason='superseded', valid_to=? WHERE id=2`).run(iso(now - 9 * DAY));
  db.prepare(`UPDATE memories SET cold=1, cold_reason='age', cold_at=? WHERE id=3`).run(iso(now - 8 * DAY));
  db.prepare(`INSERT INTO life_state(id, revision, state_json, updated_at) VALUES(1, 41, ?, ?)`)
    .run(JSON.stringify({
      schemaVersion: 12, revision: 41,
      needs: { social: 0.44, curiosity: 0.5, rest: 0.6, mood: 0.55, closeness: 0.5, energy: 0.7 },
      hormones: { cortisol: 30, dopamine: 50, oxytocin: 40, serotonin: 60 },   // 旧 0–100 标度
      energy: 0.7, phase: 'evening',
      social: { lastUserAt: 0, lastBotAt: 0, lastProactiveAt: 0, silentStreak: 0, proactiveBackoffMinutes: 120 },
      relationship: { closeness: 0.5, trust: 0.5, stage: 'normal' },
      counters: { proactiveToday: 0, proactiveThisHour: 0, emotionInjectToday: 0, dayKey: '2026-10-29', stateLineAt: 0 },
      flags: { safeMode: false, shadowMode: false, deepNight: false },
    }), iso(now - DAY));
  db.prepare(`INSERT INTO life_events(event_id, event_type, event_json, created_at, applied_at)
              VALUES('ev1','tick','{"n":1}',?,NULL)`).run(iso(now - DAY));
  db.prepare(`INSERT INTO injection_log(memory_id, scope, kind, injected_at, turn_id) VALUES('7',?, 'auto', ?, 't1')`)
    .run(SCOPE, now - 3600000);
}

const keep = process.argv.includes('--keep');
const dir = mkdtempSync(join(tmpdir(), 'dsh13-upgrade-'));
const dbPath = join(dir, 'mind.db');

console.log('\n== U1. 造一个 v11.1 原库（真实 DDL + 旧标度 + TEXT 时间）==');
{
  const raw = new DatabaseSync(dbPath);
  raw.exec('PRAGMA journal_mode=WAL;');
  raw.exec(V11_DDL);
  seedV11(raw, Date.now(), 30);
  const n = raw.prepare('SELECT COUNT(*) AS n FROM memories').get().n;
  ok('U1-a 旧库 30 行就位', n === 30, n);
  const c = raw.prepare("SELECT sql FROM sqlite_master WHERE name='memories'").get().sql;
  ok('U1-b 旧库仍是 v11.1 DDL（含 CHECK）', c.includes("'user_sentence'") && c.includes("'age','capacity'"));
  raw.close();
}

console.log('\n== U2. 原地升级（同一文件，不新建库）==');
const beforeCols = (() => {
  const d = new DatabaseSync(dbPath);
  const cols = d.prepare('PRAGMA table_info(memories)').all().map(r => r.name);
  d.close();
  return cols;
})();
const fpBefore = (() => {
  const d = new DatabaseSync(dbPath);
  d.exec('PRAGMA journal_mode=WAL;');
  const f = legacyFingerprint(d, 'memories', beforeCols, 'id');
  d.close();
  return f;
})();

let db, info;
{
  db = await openDb(dbPath);
  const t0 = Date.now();
  info = await ensureSchema(db, { dbPath, cfg: DEFAULTS });
  const ms = Date.now() - t0;
  ok('U2-a 识别为“需要升级”', info.upgraded === true && info.added > 0, { added: info.added });
  ok('U2-b 生成了备份文件', !!info.backupPath && existsSync(info.backupPath), info.backupPath);
  ok('U2-c 备份可打开且行数一致', (() => {
    try {
      const b = new DatabaseSync(info.backupPath, { readOnly: true });
      const n = b.prepare('SELECT COUNT(*) AS n FROM memories').get().n;
      b.close();
      return n === 30;
    } catch { return false; }
  })());
  ok('U2-d 指纹校验通过', info.fingerprintOk === true);
  ok('U2-e 升级耗时可接受（<3s / 30 行）', ms < 3000, ms);
}

console.log('\n== U3. 结构：新列长出来了，旧列一个没丢 ==');
{
  const cols = db.prepare('PRAGMA table_info(memories)').all().map(r => r.name);
  const need = ['valid_from_ms', 'created_at_ms', 'confirmed_at_ms', 'happened_at_ms',
    'valid_to_ms', 'last_recalled_ms', 'cold_at_ms', 'raw_kept', 'belief', 'protection_tier',
    'content_hash', 'origin_key', 'review_due_at', 'evidence_count', 'superseded_by'];
  const missing = need.filter(c => !cols.includes(c));
  ok('U3-a 15 个关键新列齐全', missing.length === 0, missing);
  ok('U3-b 旧列全部保留', beforeCols.every(c => cols.includes(c)), beforeCols.filter(c => !cols.includes(c)));
  ok('U3-c 主键仍是 INTEGER', (() => {
    const pk = db.prepare('PRAGMA table_info(memories)').all().find(c => c.pk === 1);
    return pk && String(pk.type).toUpperCase() === 'INTEGER';
  })());
  ok('U3-d 升级台账落库', (() => {
    const row = db.prepare('SELECT * FROM upgrade_manifest ORDER BY id DESC LIMIT 1').get();
    return !!row && row.verify_ok === 1 && row.added_columns > 0;
  })());
  ok('U3-e user_version = 14', db.prepare('PRAGMA user_version').get().user_version === 14);
  ok('U3-f kv schema_version = 14', kvGet(db, 'schema_version') === '14');
}

console.log('\n== U4. 旧数据：一行都没变 ==');
{
  globalThis.__fpAfterUpgrade = legacyFingerprint(db, 'memories', beforeCols, 'id');
  const fpAfter = globalThis.__fpAfterUpgrade;
  ok('U4-a 旧列指纹逐行一致', fpAfter.hash === fpBefore.hash && fpAfter.count === fpBefore.count,
    { before: fpBefore.hash.slice(0, 10), after: fpAfter.hash.slice(0, 10) });
  ok('U4-b 旧行 id 未变（1..30 连续）', (() => {
    const ids = db.prepare('SELECT id FROM memories ORDER BY id').all().map(r => r.id);
    return ids.length === 30 && ids[0] === 1 && ids[29] === 30;
  })());
  ok('U4-c raw 原话保留', (() => {
    const r = db.prepare('SELECT raw FROM memories WHERE id = 1').get();
    return String(r.raw).includes('原话全文');
  })());
  ok('U4-d scope 未被改写', db.prepare('SELECT DISTINCT scope FROM memories').all().every(r => r.scope === SCOPE));
  ok('U4-e 旧 CHECK 值未被改写', (() => {
    const a = db.prepare("SELECT COUNT(*) AS n FROM memories WHERE invalid_reason='superseded'").get().n;
    const b = db.prepare("SELECT COUNT(*) AS n FROM memories WHERE cold_reason='age'").get().n;
    return a === 1 && b === 1;
  })());
  const one = db.prepare('SELECT created_at, created_at_ms FROM memories WHERE id = 1').get();
  ok('U4-f TEXT 时间未改写', /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(one.created_at));
  ok('U4-g created_at_ms 回填正确（v11.1 TEXT 是 UTC 墙钟）', (() => {
    // v11.1 写库用 new Date(ms).toISOString().slice(0,19) —— 无 Z 的 UTC 墙钟；
    // SQLite strftime 也按 UTC 解析，两边口径一致。若按本地时区解析会差 8 小时（二次升级的经典 bug）。
    const expect = Date.parse(one.created_at.replace(' ', 'T') + 'Z');
    return Math.abs(Number(one.created_at_ms) - expect) < 2000;
  })(), one);
}

console.log('\n== U5. FTS：重建到位，不再 malformed ==');
{
  ok('U5-a FTS 可查中文三字', (() => {
    try { return db.prepare("SELECT COUNT(*) AS n FROM mem_fts WHERE mem_fts MATCH '习惯条目'").get().n > 0; }
    catch { return false; }
  })());
  ok('U5-b 旧库首次 UPDATE 不报 malformed', (() => {
    try {
      db.prepare('UPDATE memories SET uses = uses + 1 WHERE id = 1').run();
      return true;
    } catch (e) { return 'ERR:' + e.message; }
  })());
  ok('U5-c 新行 INSERT 后 FTS 同步', (() => {
    try {
      db.prepare("INSERT INTO memories(scope,category,fact,created_at,created_at_ms) VALUES(?,'fact','FTS 同步测试甲',?,?)")
        .run(SCOPE, iso(Date.now()), Date.now());
      const n = db.prepare("SELECT COUNT(*) AS n FROM mem_fts WHERE mem_fts MATCH '同步测试'").get().n;
      db.prepare("DELETE FROM memories WHERE fact='FTS 同步测试甲'").run();
      return n > 0;
    } catch (e) { return 'ERR:' + e.message; }
  })());
}

console.log('\n== U6. 检索：旧库能被搜到（v14.0 这里 recall=0）==');
{
  const hits = searchMemory(db, '主人的习惯条目3', { cfg: DEFAULTS, scope: SCOPE, now: Date.now() });
  ok('U6-a 私聊 scope 命中旧记忆', hits.items.length > 0, hits.debug);
  ok('U6-b 检索结果来自旧库行', hits.items.some(it => String(it.mem.fact).includes('旧库第')));
  const other = searchMemory(db, '主人的习惯条目3', { cfg: DEFAULTS, scope: 'private:999999', now: Date.now() });
  ok('U6-c 别人的 scope 搜不到（不泄漏）', other.items.length === 0, other.items.length);
  const grp = searchMemory(db, '主人的习惯条目3', { cfg: DEFAULTS, scope: 'group:12345', now: Date.now() });
  ok('U6-d 群聊 scope 搜不到私聊', grp.items.length === 0, grp.items.length);
}

console.log('\n== U7. 写入：新行走 INTEGER 自增，不撞旧 CHECK ==');
{
  const w1 = await writeMemory(db, {
    scope: SCOPE, fact: '升级后写入的第一条事实', category: 'fact',
    evidence: '用户原话', evidence_kind: 'user_sentence', confidence: 1, belief: 0.95,
  }, { cfg: DEFAULTS });
  ok('U7-a 新行写入成功且 id 为整数', w1.action === 'insert' && Number.isInteger(w1.id), w1);
  ok('U7-b 新 id 不复用旧 id', Number(w1.id) > 30, w1.id);
  ok('U7-c 读回三态 verified', w1.verify === 'verified', w1.verify);
  const w2 = await writeMemory(db, {
    scope: SCOPE, fact: '升级后写入的第一条事实', category: 'fact',
    evidence: '用户原话', evidence_kind: 'user_sentence', confidence: 1, belief: 0.95,
  }, { cfg: DEFAULTS });
  ok('U7-d 指纹去重（同 scope）', w2.action === 'duplicate' && String(w2.id) === String(w1.id), w2);
  const w3 = await writeMemory(db, {
    scope: 'private:999999', fact: '升级后写入的第一条事实', category: 'fact',
    evidence: '用户原话', evidence_kind: 'user_sentence', confidence: 1, belief: 0.95,
  }, { cfg: DEFAULTS });
  ok('U7-e 不同 scope 同句不误判去重', w3.action === 'insert' && String(w3.id) !== String(w1.id), w3);
}

console.log('\n== U8. 转冷 / 快照 / 状态核 兼容 ==');
{
  const cold = scanCold(db, Date.now(), DEFAULTS, (m) => 0.01);
  ok('U8-a 转冷写入不撞 cold_reason CHECK', (() => {
    try {
      const n = db.prepare("SELECT COUNT(*) AS n FROM memories WHERE cold=1 AND cold_reason IN ('age','capacity')").get().n;
      return n > 0;
    } catch { return false; }
  })(), cold.length);
  const rec = recover(db, DEFAULTS);
  ok('U8-b 旧状态可恢复', rec.safeMode === false, rec);
  ok('U8-c 激素 0–100 → 0–1 归一', (() => {
    const h = rec.state.hormones;
    return h.cortisol <= 1 && h.dopamine <= 1 && Math.abs(h.cortisol - 0.30) < 1e-6;
  })(), rec.state.hormones);
  const s = saveState(db, { ...rec.state, revision: 42 }, Date.now(), DEFAULTS);
  ok('U8-d 快照双列写入成功（旧库 snapshot_json NOT NULL）', s.revision === 42, s);
  ok('U8-e 快照两列都有值', (() => {
    const r = db.prepare('SELECT snapshot_json, state_json FROM life_snapshots WHERE revision = 42').get();
    return !!r && !!r.snapshot_json && !!r.state_json;
  })());
  ok('U8-f 事件双列 COALESCE 兼容', (() => {
    const r = db.prepare("SELECT event_type, type, payload FROM life_events WHERE event_id='ev1'").get();
    return !!r.event_type;
  })());
}

console.log('\n== U9. 候选 accept 真的重跑（D3）==');
{
  const cid = (() => {
    db.prepare(`INSERT INTO candidates(id, scope, text, kind, payload, category, status, created_at, expires_at, raw_text)
                VALUES(?,?,?,?,?,?, 'pending', ?, ?, ?)`)
      .run(901, SCOPE, '候选原文：主人喜欢在夜里写代码', 'fact', '{}', 'fact', Date.now(), Date.now() + DAY, '候选原文：主人喜欢在夜里写代码');
    return 901;
  })();
  const before = db.prepare('SELECT COUNT(*) AS n FROM memories').get().n;
  const r = await reviewCandidate(db, cid, { decision: 'accept', cfg: DEFAULTS });
  const after = db.prepare('SELECT COUNT(*) AS n FROM memories').get().n;
  ok('U9-a accept 真的写进了 memories', after === before + 1, { before, after, r });
  ok('U9-b 候选状态变 accepted 且带 memory_id', (() => {
    const row = db.prepare('SELECT status, memory_id FROM candidates WHERE id = 901').get();
    return row.status === 'accepted' && Number.isInteger(Number(row.memory_id));
  })(), r);
  ok('U9-c 人工确认的 belief 达 0.90', (() => {
    const m = db.prepare('SELECT belief FROM memories WHERE id = ?').get(r.memoryId);
    return m && Number(m.belief) >= 0.9;
  })());
}

console.log('\n== U10. 幂等：再启动一次什么都不做 ==');
{
  const again = await ensureSchema(db, { dbPath, cfg: DEFAULTS });
  ok('U10-a 二次升级 added=0 且不重建', again.added === 0, again);
  ok('U10-b 未二次备份', !again.backupPath, again.backupPath);
  ok('U10-c 升级后旧列指纹仍与升级前一致', (() => {
    // U7/U9 之后行数从 30 变 33，直接重算会包含新行；这里比的是「升级完成那一刻」的快照
    return legacyFingerprint(db, 'memories', beforeCols, 'id').count === 33 &&
           globalThis.__fpAfterUpgrade.hash === fpBefore.hash;
  })());
  ok('U10-d 总行数 = 30 + 新增 3 行（1 条 + 1 跨 scope + 1 候选）', (() => {
    const n = db.prepare('SELECT COUNT(*) AS n FROM memories').get().n;
    return n === 33;
  })(), db.prepare('SELECT COUNT(*) AS n FROM memories').get().n);
}

console.log(`\n结果（v11.1 原库直升级）：PASS ${pass} / FAIL ${fail}`);
if (keep) console.log(`临时库保留：${dbPath}`);
else { try { db.close(); } catch {} ; try { rmSync(dir, { recursive: true, force: true }); } catch {} }
if (fail) { console.log('失败项：\n  - ' + failures.join('\n  - ')); process.exit(1); }
