#!/usr/bin/env node
// Codex candidate regression tests: real elapsed time, single energy owner,
// persistent sleep queue, structured appraisal, non-deleting nightly, evidence quote,
// FTS/BM25 candidates and Windows-safe paths.
import { DatabaseSync } from 'node:sqlite';
import { readFileSync } from 'node:fs';
import { dirname, join, isAbsolute } from 'node:path';
import { fileURLToPath } from 'node:url';
import { DEFAULTS } from '../src/kit/config.mjs';
import { homeDir } from '../src/kit/paths.mjs';
import { defaultState, lifeTick } from '../src/life/life-state.mjs';
import { elapsedMinutes, advanceV14 } from '../src/life/clock.mjs';
import { appraiseEvent, applyAppraisal, recordAppraisal, recentAppraisals } from '../src/life/appraisal.mjs';
import { queueDelivery, pollDeliveries, ackDeliveries, isSleeping } from '../src/life/delivery.mjs';
import { writeMemory } from '../src/memory/engine.mjs';
import { searchMemory } from '../src/memory/search.mjs';
import { recallCards, recallDetail } from '../src/memory/recall-card.mjs';
import { addPromise, closePromise, addMilestone, addNarrative, upsertRelationship, lifebookSnapshot } from '../src/memory/lifebook.mjs';
import { runNightly } from '../src/maintenance/nightly.mjs';
import { suggestThought, recentDreams } from '../src/life/sleep-stage.mjs';

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..');
let pass = 0, fail = 0;
const ok = (id, cond, got) => {
  if (cond) { pass++; console.log(`  PASS ${id}`); }
  else { fail++; console.log(`  FAIL ${id} got=${JSON.stringify(got)}`); }
};
const mkDb = () => {
  const db = new DatabaseSync(':memory:');
  db.exec(readFileSync(join(ROOT, 'schema.sql'), 'utf8'));
  return db;
};
const add = (db, fact, extra = {}, now = Date.now()) => writeMemory(db, {
  fact, category: 'fact', confidence: 1, force_direct: true,
  scope: 'private:1', source_kind: 'owner', source_id: '1',
  evidence_kind: 'user_sentence', evidence_ref: `e:${fact}`, ...extra,
}, { cfg: DEFAULTS, now });

console.log('\n== CX-A. Windows path / real elapsed time ==');
{
  const oldHome = process.env.HOME;
  const oldProfile = process.env.USERPROFILE;
  process.env.HOME = '';
  process.env.USERPROFILE = `${process.env.SystemDrive || 'C:'}\\Users\\CodexTest`;
  ok('A1 homeDir is absolute and never undefined', isAbsolute(homeDir()) && !homeDir().includes('undefined'), homeDir());
  if (oldHome == null) delete process.env.HOME; else process.env.HOME = oldHome;
  if (oldProfile == null) delete process.env.USERPROFILE; else process.env.USERPROFILE = oldProfile;

  const start = new Date(2026, 10, 4, 23, 0, 0).getTime();
  const end = start + 8 * 3600000;
  const s = defaultState(start);
  s.energy = 0.2;
  s.counters.lastTickAt = start;
  const el = elapsedMinutes(s, end, { maxCatchUpHours: 168 });
  ok('A2 eight-hour absence is seen as ~480 minutes', Math.abs(el.minutes - 480) < 0.1, el);

  const adv = advanceV14(s, { now: end, minutes: el.minutes, cfg: DEFAULTS, dreamEnabled: false });
  ok('A3 recovery is segmented, not one 15-minute tick', adv.segments >= 16, adv.segments);
  ok('A4 eight hours actually recovers energy', adv.state.energy > 0.45, adv.state.energy);
  ok('A5 lastTickAt advances to now', adv.state.counters.lastTickAt === end, adv.state.counters.lastTickAt);
  ok('A6 long absence gets a visible flag', adv.state.flags.longAbsence === true, adv.state.flags);

  let legacy = { ...s };
  legacy = lifeTick(legacy, 15, end, DEFAULTS);
  ok('A7 managed path differs from legacy fixed-tick path', Math.abs(adv.state.energy - legacy.energy) > 0.05, { managed: adv.state.energy, legacy: legacy.energy });

  const dayStart = new Date(2026, 10, 4, 10, 0, 0).getTime();
  const dayState = defaultState(dayStart);
  dayState.energy = 0.82;
  dayState.counters.lastTickAt = dayStart;
  const dayAdv = advanceV14(dayState, {
    now: dayStart + 8 * 3600000, minutes: 480, cfg: DEFAULTS, dreamEnabled: false,
  });
  ok('A8 daytime inactivity does not masquerade as sleep', dayAdv.state.energy < 0.82, dayAdv.state.energy);
  ok('A9 awake time accumulates sleep debt', dayAdv.state.sleep.sleepDebt > 0, dayAdv.state.sleep);
}

console.log('\n== CX-B. Structured appraisal / PAD ==');
{
  const db = mkDb();
  const s = defaultState();
  const ap = appraiseEvent('你别烦我，滚', { state: s, now: Date.now(), maxNudge: 0.03 });
  const applied = applyAppraisal(s, ap, DEFAULTS);
  ok('B1 conflict event classified', ap.eventClass === 'conflict', ap.eventClass);
  ok('B2 appraisal has bounded explainable delta', Object.values(ap.delta).every(v => Math.abs(v) <= 0.03 + 1e-9), ap.delta);
  ok('B3 applying appraisal changes hormones and PAD', applied.changed && s.affect.pad.P !== 0.53, { applied, pad: s.affect.pad });
  const rec = recordAppraisal(db, ap, {
    scope: 'private:1', turnId: 't1', now: Date.now(), applied,
  });
  ok('B4 appraisal is persisted as an event', rec.ok && recentAppraisals(db, { scope: 'private:1' }).length === 1, rec);
  const hist = recentAppraisals(db, { scope: 'private:1' })[0];
  ok('B5 appraisal history keeps applied state, not only a proposal', hist?.applied?.changed === true && !!hist?.applied?.pad, hist);
  db.close();
}

console.log('\n== CX-C. Sleep delivery queue ==');
{
  const s = defaultState();
  s.sleep.stage = 'rem';
  ok('C1 rem counts as sleeping', isSleeping(s) === true, s.sleep.stage);
  const q = queueDelivery(s, { text: '醒来再回你', kind: 'reply', scope: 'private:1' });
  ok('C2 delivery is queued while asleep', q.ok && q.pending === 1, q);
  const blocked = pollDeliveries(s, { limit: 5 });
  ok('C3 asleep poll does not release normal items', blocked.sleeping && blocked.items.length === 0, blocked);
  s.sleep.stage = 'awake';
  const released = pollDeliveries(s, { limit: 5 });
  ok('C4 awake poll releases the item', !released.sleeping && released.items.length === 1, released);
  const ack = ackDeliveries(s, [released.items[0].id]);
  ok('C5 ack removes it from the queue', ack.acked === 1 && s.sleep.pendingDeliveries.length === 0, ack);
}

console.log('\n== CX-D. Evidence / FTS-BM25 / thought source ==');
{
  const db = mkDb();
  const w = await add(db, '主人喜欢在海边喝冰美式', {
    quote: '我说的原话：喜欢海边冰美式', msg_ids: ['m100'], asserted_at: 1700000000000,
  });
  const ev = db.prepare('SELECT quote, message_ids, asserted_at FROM memory_evidence WHERE memory_id = ?').get(w.id);
  ok('D1 evidence keeps the source quote', ev?.quote === '我说的原话：喜欢海边冰美式', ev);
  ok('D2 evidence keeps message id', ev?.message_ids === 'm100', ev);

  await add(db, '主人周末经常去海边散步');
  const hit = searchMemory(db, '海边 冰美式', { cfg: DEFAULTS, scope: 'private:1', topK: 6 });
  ok('D3 FTS/BM25 search finds a non-substring long query', hit.items.some(x => String(x.mem.fact).includes('冰美式')), hit.debug);
  ok('D4 candidate carries BM25 score without changing fact', hit.items.some(x => Number(x.bm25) > 0) && hit.items.every(x => x.mem.fact), hit.items.map(x => x.bm25));
  const cards = recallCards(db, '海边 冰美式', { scope: 'private:1', cfg: DEFAULTS, limit: 3 });
  ok('D5 first-layer recall returns compact cards', cards.ok && cards.cards.length > 0 && cards.cards.every(c => Object.keys(c).length >= 6), cards.cards);
  const detail = recallDetail(db, cards.cards[0].id, {
    scopes: ['private:1', 'shared', 'shared:%'], includeRaw: true,
  });
  ok('D6 second-layer recall returns evidence/raw by id', detail.ok && detail.evidence.length > 0 && detail.rawOmitted === false, detail);

  db.prepare("INSERT INTO gaps(scope,question,tension,created_at,resolved) VALUES('private:1','那天他到底想说什么',0.9,?,0)").run(Date.now());
  const thought = suggestThought(db, defaultState(), { now: Date.now() });
  ok('D7 thought seed comes from a real open gap', thought.includes('还没想明白'), thought);
  db.close();
}

console.log('\n== CX-E. Nightly preserves superseded/retracted rows ==');
{
  const db = mkDb();
  const a = await add(db, '他喜欢早起看日出');
  const b = await add(db, '项目部署时间改到周五下午');
  db.prepare("UPDATE memories SET invalid_reason='superseded' WHERE id=?").run(b.id);
  db.prepare("UPDATE memories SET invalid_reason='retracted', anchor_ground='{\"retractNote\":{\"reason\":\"test\"}}' WHERE id=?").run(b.id);
  const before = db.prepare('SELECT COUNT(*) AS n FROM memories').get().n;
  runNightly(db, { now: Date.now(), cfg: DEFAULTS, force: true });
  const after = db.prepare('SELECT COUNT(*) AS n FROM memories').get().n;
  const row = db.prepare('SELECT invalid_reason, cold FROM memories WHERE id=?').get(a.id);
  const rowB = db.prepare('SELECT invalid_reason, cold FROM memories WHERE id=?').get(b.id);
  ok('E1 nightly does not delete the rows', before === after, { before, after });
  ok('E2 retracted row remains explainable', rowB?.invalid_reason === 'retracted' && rowB?.cold === 1, rowB);
  ok('E3 active row is untouched', row?.cold === 0, row);
  db.close();
}

console.log('\n== CX-F. Lifebook structured tables ==');
{
  const db = mkDb();
  const promise = addPromise(db, { scope: 'private:1', text: '周末一起去书店', dueAt: Date.now() + 86400000 });
  const milestone = addMilestone(db, { scope: 'private:1', text: '第一次一起看展' });
  const narrative = addNarrative(db, { scope: 'private:1', period: 'week', text: '这一周一起做了三件事。' });
  upsertRelationship(db, { scope: 'private:1', closeness: 0.72, trust: 0.66, stage: 'familiar' });
  const snap = lifebookSnapshot(db, { scope: 'private:1' });
  ok('F1 promise is stored as a structured lifecycle item', promise.ok && snap.promises.some(x => x.id === promise.id), snap.promises);
  ok('F2 milestone is stored', milestone.ok && snap.milestones.some(x => x.id === milestone.id), snap.milestones);
  ok('F3 narrative is stored', narrative.ok && snap.narratives.some(x => x.id === narrative.id), snap.narratives);
  ok('F4 relationship snapshot is stored', snap.relationship?.closeness === 0.72 && snap.relationship?.trust === 0.66, snap.relationship);
  const done = closePromise(db, promise.id, { status: 'done' });
  ok('F5 promise can be closed without deleting it', done.ok && db.prepare('SELECT status FROM promises WHERE id=?').get(promise.id).status === 'done', done);
  db.close();
}

console.log('\n== CX-G. Long-lived dream/appraisal audit retention ==');
{
  const db = mkDb();
  const now = Date.now();
  const insertEvent = (id, type, at) => db.prepare(
    'INSERT INTO life_events(event_id,revision,event_type,event_json,type,payload,created_at,applied_at) VALUES(?,?,?,?,?,?,?,?)'
  ).run(id, 0, type, '{"ok":true}', type, '{"ok":true}', at, at);
  insertEvent('noise-old', 'tick-noise', now - 100 * 86400000);
  insertEvent('appr-old', 'appraisal', now - 100 * 86400000);
  insertEvent('dream-old', 'dream', now - 400 * 86400000);
  insertEvent('appr-expired', 'appraisal', now - 800 * 86400000);
  runNightly(db, { now, cfg: DEFAULTS, force: true });
  const ids = new Set(db.prepare('SELECT event_id FROM life_events').all().map(x => x.event_id));
  ok('G1 old operational noise is pruned', !ids.has('noise-old'), [...ids]);
  ok('G2 appraisal audit survives ordinary 90-day pruning', ids.has('appr-old'), [...ids]);
  ok('G3 dream audit survives ordinary 90-day pruning', ids.has('dream-old'), [...ids]);
  ok('G4 audit has its own two-year ceiling', !ids.has('appr-expired'), [...ids]);
  const idx = db.prepare("SELECT name FROM sqlite_master WHERE type='index' AND name='idx_events_type_time'").get();
  ok('G5 event-type/time query index exists', !!idx, idx);
  ok('G6 dream history is queryable', recentDreams(db, { limit: 5 }).some(x => x.createdAt === now - 400 * 86400000), recentDreams(db, { limit: 5 }));
  db.close();
}

console.log(`\n结果（Codex v14）：PASS ${pass} / FAIL ${fail}`);
if (fail) process.exit(1);
