#!/usr/bin/env node
// Second cross-validation round: IMA merged additions that survived review.
import { DatabaseSync } from 'node:sqlite';
import { readFileSync, mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
import { DEFAULTS, VERSION, SCHEMA_VERSION, v14Mode, v14On } from '../src/kit/config.mjs';
import { elapsedMinutes } from '../src/life/clock.mjs';
import { inShadow } from '../src/kit/shadow.mjs';
import { writeMemory } from '../src/memory/engine.mjs';
import { retract, STAMP_REASON } from '../src/memory/governance.mjs';
import { openGap } from '../src/memory/gaps.mjs';
import { maybeDream, recentDreams } from '../src/life/sleep-stage.mjs';
import { runNightly } from '../src/maintenance/nightly.mjs';
import { createGenericHost } from '../src/host/generic.mjs';
import createPlugin from '../src/index.mjs';

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..');
let pass = 0, fail = 0;
const ok = (id, cond, got) => {
  if (cond) { pass++; console.log(`  PASS ${id}`); }
  else { fail++; console.log(`  FAIL ${id} got=${JSON.stringify(got)}`); }
};
const mkDb = () => {
  const db = new DatabaseSync(':memory:');
  db.exec(readFileSync(join(ROOT, 'schema.sql'), 'utf8'));
  return db;
};
const add = (db, fact, extra = {}) => writeMemory(db, {
  fact, category: 'fact', confidence: 1, force_direct: true,
  scope: 'private:1', source_kind: 'owner', source_id: '1',
  evidence_kind: 'user_sentence', evidence_ref: `e:${fact}`, ...extra,
}, { cfg: DEFAULTS, now: Date.now() });

console.log('\n== Y. Version / three-state gate ==');
{
  ok('Y1 capability version is 14.1', VERSION === '14.1', VERSION);
  ok('Y2 schema version remains 14', SCHEMA_VERSION === 14, SCHEMA_VERSION);
  const cfg = (v, gate = true) => ({ capabilities: { v14: gate, demo: v } });
  ok('Y3 true => on', v14Mode(cfg(true), 'demo') === 'on');
  ok('Y4 false => off', v14Mode(cfg(false), 'demo') === 'off');
  ok('Y5 shadow => shadow', v14Mode(cfg('shadow'), 'demo') === 'shadow');
  ok('Y6 v14On treats shadow as not-on', v14On(cfg('shadow'), 'demo') === false);
  ok('Y7 total gate wins', v14Mode(cfg(true, false), 'demo') === 'off');
}

console.log('\n== Z. 72h catch-up policy ==');
{
  ok('Z1 default catch-up is 72h', DEFAULTS.v14.sleep.maxCatchUpHours === 72, DEFAULTS.v14.sleep.maxCatchUpHours);
  const now = Date.now();
  const r = elapsedMinutes({ counters: { lastTickAt: now - 500 * 3600000 } }, now);
  ok('Z2 500h absence is capped', r.minutes <= 72 * 60 + 1 && r.capped === true, r);
  const weekend = elapsedMinutes({ counters: { lastTickAt: now - 8 * 3600000 } }, now);
  ok('Z3 normal eight-hour sleep is not capped', Math.abs(weekend.minutes - 480) < 1 && weekend.capped === false, weekend);
}

console.log('\n== AA. Shadow rollback ==');
{
  const db = mkDb();
  const r = inShadow(db, 'unit', () => {
    db.prepare("INSERT INTO kv(k,v,updated_at) VALUES('shadow-insert','x',?)").run(Date.now());
    return { wouldWrite: true };
  }, Date.now());
  const kv = db.prepare("SELECT v FROM kv WHERE k='shadow-insert'").get();
  const audit = db.prepare("SELECT event_type,event_json FROM life_events WHERE event_type='shadow:unit'").get();
  ok('AA1 shadow reports would-write output', r.shadow && r.ok && r.would?.wouldWrite === true, r);
  ok('AA2 real write is rolled back', !kv, kv);
  ok('AA3 shadow audit remains', audit?.event_type === 'shadow:unit' && String(audit.event_json).includes('wouldWrite'), audit);
  db.close();
}

console.log('\n== AB. autoExtract shadow does not create candidates ==');
{
  const dir = mkdtempSync(join(tmpdir(), 'v14-shadow-'));
  const host = createGenericHost({ log: { info() {}, warn() {}, error() {} }, persona: () => 'test', embed: async () => null });
  createPlugin(host.ctx, {
    dbPath: join(dir, 'mind.db'), ownerQq: '10001',
    capabilities: { v14: true, autoExtract: 'shadow', thoughtStream: false, sleepStages: false },
  });
  await host.start();
  await host.userMessage({ text: '我叫顾晨，我生日是4月26日', scope: 'private:10001', ownerQq: '10001' });
  await host.reply({
    text: '记住了',
    message: { scope: 'private:10001', ownerQq: '10001', text: '我叫顾晨，我生日是4月26日' },
  });
  const db = new DatabaseSync(join(dir, 'mind.db'), { readOnly: true });
  const candidates = db.prepare('SELECT COUNT(*) AS n FROM candidates').get().n;
  const shadows = db.prepare("SELECT COUNT(*) AS n FROM life_events WHERE event_type='shadow:autoExtract'").get().n;
  ok('AB1 shadow extraction creates no candidates', candidates === 0, candidates);
  ok('AB2 shadow extraction is auditable', shadows >= 1, shadows);
  db.close();
  host.stop();
}

console.log('\n== AC. 180-day stamp window ==');
{
  const db = mkDb();
  const now = Date.now();
  const near = await add(db, '179 天前盖章的记忆');
  const old = await add(db, '181 天前盖章的记忆');
  db.prepare("UPDATE memories SET invalid_reason='manual',valid_to_ms=?,cold=1 WHERE id=?").run(now - 179 * 86400000, near.id);
  db.prepare("UPDATE memories SET invalid_reason='manual',valid_to_ms=?,cold=1 WHERE id=?").run(now - 181 * 86400000, old.id);
  runNightly(db, { now, cfg: DEFAULTS, force: true });
  const nearRow = db.prepare('SELECT id FROM memories WHERE id=?').get(near.id);
  const oldRow = db.prepare('SELECT id FROM memories WHERE id=?').get(old.id);
  const oldArchive = db.prepare('SELECT id FROM memories_archive WHERE id=?').get(old.id);
  ok('AC1 179-day stamp remains appealable', !!nearRow, nearRow);
  ok('AC2 181-day stamp leaves main table', !oldRow, oldRow);
  ok('AC3 181-day archive remains', !!oldArchive, oldArchive);
  ok('AC4 default retention is 180 days', DEFAULTS.v14.stamps.retainDays === 180, DEFAULTS.v14.stamps.retainDays);
  db.close();
}

console.log('\n== AD. v11.1 retract CHECK compatibility ==');
{
  const db = new DatabaseSync(':memory:');
  db.exec(`
    CREATE TABLE memories(
      id INTEGER PRIMARY KEY,
      fact TEXT NOT NULL,
      invalid_reason TEXT CHECK (invalid_reason IN
        ('conflict','superseded','expired','manual','audit')),
      valid_to TEXT,
      anchor_ground TEXT
    );
  `);
  db.prepare("INSERT INTO memories(id,fact,anchor_ground) VALUES(1,'旧库中的约定','{}')").run();
  const now = Date.now();
  const r = retract(db, 1, '用户改口了', { now });
  const row = db.prepare('SELECT invalid_reason,valid_to,anchor_ground FROM memories WHERE id=1').get();
  ok('AD1 legacy CHECK accepts retract', r.ok === true, r);
  ok('AD2 canonical stamp reason is manual', STAMP_REASON === 'manual' && r.stampedAs === 'manual', r);
  ok('AD3 row remains with explainable reason', row?.invalid_reason === 'manual'
    && JSON.parse(row.anchor_ground || '{}').retractNote?.reason === '用户改口了', row);
  db.close();
}

console.log('\n== AE. dream sources obey scope ==');
{
  const db = mkDb();
  const now = Date.now();
  const other = await add(db, '另一个人的私密秘密', { scope: 'private:2' });
  db.prepare('UPDATE memories SET emotional_salience=0.9 WHERE id=?').run(other.id);
  const otherGap = openGap(db, { question: '另一个人的私密问题', scope: 'private:2', tension: 0.9, now });
  db.prepare('INSERT INTO injection_log(memory_id,scope,kind,injected_at) VALUES(?,?,?,?)')
    .run(other.id, 'private:2', 'recall', now);
  const d1 = maybeDream(db, { energy: 0.7, sleep: { lastDreamAt: 0, dreamLog: [] } }, { now, scope: 'private:1' });
  ok('AE1 dream does not use another private scope', !d1.sources.gaps.includes(otherGap.id)
    && !d1.sources.memories.includes(other.id) && !d1.text.includes('私密秘密'), d1);
  const d2 = maybeDream(db, { energy: 0.7, sleep: { lastDreamAt: 0, dreamLog: [] } }, { now, scope: 'private:2' });
  ok('AE2 dream still uses the visible owner scope', d2.sources.gaps.includes(otherGap.id)
    && d2.sources.memories.includes(other.id), d2);
  const ownHistory = recentDreams(db, { limit: 5, scope: 'private:1' });
  ok('AE3 dream history is scope-filtered',
    ownHistory.every((x) => x.scope !== 'private:2')
    && recentDreams(db, { limit: 5, scope: 'private:2' }).some((x) => x.scope === 'private:2'),
    ownHistory);
  db.close();
}

console.log('\n== AF. tool IDs are bound to the current scope ==');
{
  const dir = mkdtempSync(join(tmpdir(), 'v14-tool-scope-'));
  const host = createGenericHost({ log: { info() {}, warn() {}, error() {} }, persona: () => 'test', embed: async () => null });
  createPlugin(host.ctx, {
    dbPath: join(dir, 'mind.db'), ownerQq: '10001',
    capabilities: { v14: true, autoExtract: false, thoughtStream: false },
  });
  await host.start();
  const tool = (name) => host.tools.find((x) => x.name === name);
  await host.userMessage({ text: '', scope: 'private:10001', ownerQq: '10001' });
  const seedDb = new DatabaseSync(join(dir, 'mind.db'));
  const remembered = await add(seedDb, '主人私聊里的秘密约定', { scope: 'private:10001', category: 'promise' });
  seedDb.close();
  const gap = await tool('life_gap').run({ action: 'open', question: '只属于主人的问题' });
  await host.userMessage({ text: '', scope: 'group:20002', ownerQq: '10001', groupId: '20002' });
  const gaps = await tool('life_gap').run({ action: 'list' });
  const forget = await tool('life_forget').run({ memory_id: remembered.id, reason: 'cross-scope' });
  ok('AF1 group cannot list another scope gap', gaps.gaps.length === 0, gaps);
  ok('AF2 group cannot forget another scope memory', forget.ok === false && forget.reason === 'scope-denied', forget);
  await host.userMessage({ text: '', scope: 'private:10001', ownerQq: '10001' });
  const ownGaps = await tool('life_gap').run({ action: 'list' });
  const ownForget = await tool('life_forget').run({ memory_id: remembered.id, reason: 'owner-requested' });
  ok('AF3 owner still sees own gap', ownGaps.gaps.some((x) => x.id === gap.id), ownGaps);
  ok('AF4 owner can still stamp own memory', ownForget.ok === true, ownForget);
  host.stop();
}

console.log('\n== AG. privacy gate ==');
{
  const r = spawnSync(process.execPath, ['scripts/privacy-scan.mjs', '.'], { cwd: ROOT, encoding: 'utf8' });
  ok('AG1 privacy scan exits 0', r.status === 0, { status: r.status, stdout: r.stdout, stderr: r.stderr });
  ok('AG2 privacy scan reports PASS', /PASS/.test(r.stdout || ''), r.stdout);
}

console.log(`\n结果（第二轮交叉验证）：PASS ${pass} / FAIL ${fail}`);
if (fail) process.exit(1);
