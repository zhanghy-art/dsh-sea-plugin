#!/usr/bin/env node
// tests/verify-v14-h.mjs — H 组深度沙盒发现的三个修复点的轻量回归
//
// 2026-11-06 沙盒 H 组（sandbox/scenarios/h-deep.mjs，7 场景 82 断言）发现并修复：
//   ① A–G 基线 G4「SIGKILL 后 database is locked」→ openDb 加 busy_timeout + tx 有限重试
//   ② 13 个工具 schema 占 ~1424 token/次唤醒 → v14.toolset 分级（默认 full 零变化）
//   ③ 定时空唤醒反复重算注入烧 token → v14.skipIdleTurn 复用上一轮段（默认关）
//   ④ 首轮即空唤醒被误判（size>0 当判据）→ 改成 lastSections.has('dsh-life.memory')
//   ⑤ 真库副本形状（event_id 可空 + 与 'v11-<seq>' 撞车）整表重建失败 →
//      UNIQUE constraint failed → no such column: event_type → relaxTable 确定性去重
// 本套件只跑纯函数与轻量运行时断言（不跑 SIGKILL/几万行等重场景，那些在 H 组里），
// 目的是让 `npm test` 也覆盖「五个修复点都还在、默认零行为变化」。
import { DatabaseSync } from 'node:sqlite';
import { readFileSync } from 'node:fs';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { DEFAULTS, VERSION, SCHEMA_VERSION, POLICY_VERSION } from '../src/kit/config.mjs';
import { openDb, tx } from '../src/kit/db.mjs';
import { relaxTable, diagnoseLegacyShape } from '../src/kit/legacy-shape.mjs';
import { createGenericHost } from '../src/host/generic.mjs';
import createPlugin from '../src/index.mjs';

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..');
let pass = 0, fail = 0;
const ok = (id, cond, got) => {
  if (cond) { pass++; console.log(`  PASS ${id}`); }
  else { fail++; console.log(`  FAIL ${id} got=${JSON.stringify(got)}`); }
};
const quietLog = { info() {}, warn() {}, error() {} };
const PERSONA = '你叫小鱼，是一条住在主人电脑里的小鲸鱼。';
const LITE = ['life_remember', 'life_propose', 'life_mark_sent', 'life_recall', 'life_status'];
const SCOPE = 'private:10086';

async function boot(extra = {}) {
  const d = mkdtempSync(join(tmpdir(), 'vh-'));
  const dbPath = join(d, 'mind.db');
  const host = createGenericHost({ log: quietLog, persona: () => PERSONA, embed: async () => null });
  const rt = createPlugin(host.ctx, { dbPath, ownerQq: '10086', scope: SCOPE, ...extra });
  await host.start();
  return { host, rt, cleanup: () => { try { host.stop(); } catch {} try { rmSync(d, { recursive: true, force: true }); } catch {} } };
}

// ---------- ① 默认零行为变化（配置层） ----------
ok('H-1 v14.toolset 默认 = full', DEFAULTS.v14.toolset === 'full', DEFAULTS.v14.toolset);
ok('H-2 v14.skipIdleTurn 默认 = false', DEFAULTS.v14.skipIdleTurn === false, DEFAULTS.v14.skipIdleTurn);
ok('H-3 budget 仍是受保护核心键（900/700 未被改动）',
  DEFAULTS.budget.private === 900 && DEFAULTS.budget.group === 700, DEFAULTS.budget);
ok('H-4 VERSION / SCHEMA_VERSION / POLICY_VERSION 未被本轮改动',
  VERSION === '14.1' && SCHEMA_VERSION === 14 && POLICY_VERSION === 'v14.0',
  { VERSION, SCHEMA_VERSION, POLICY_VERSION });

// ---------- ② db.mjs 的 G4 修复静态证据 ----------
const dbSrc = readFileSync(join(ROOT, 'src/kit/db.mjs'), 'utf8');
ok('H-5 openDb 设了 busy_timeout', /PRAGMA busy_timeout\s*=\s*\d+/.test(dbSrc), dbSrc.match(/PRAGMA busy_timeout[^;]*/)?.[0]);
ok('H-6 tx 定义了 BUSY 匹配正则', /TX_BUSY_RE\s*=/.test(dbSrc) && /database is locked/i.test(dbSrc), null);
ok('H-7 tx 定义了重试上限常量', /TX_MAX_RETRY\s*=/.test(dbSrc), dbSrc.match(/TX_MAX_RETRY\s*=\s*\d+/)?.[0]);
ok('H-8 tx 用 for 循环做有限重试', /export function tx\(db, fn\)\s*\{\s*for \(/.test(dbSrc), null);

// ---------- ③ tx 的 BUSY 重试行为（轻量、不启子进程） ----------
{
  const db = new DatabaseSync(':memory:');
  db.exec('CREATE TABLE t (id INTEGER PRIMARY KEY, v TEXT);');
  const r = tx(db, () => { db.prepare("INSERT INTO t(v) VALUES ('a')").run(); return 7; });
  ok('H-9 普通事务仍返回 fn 结果', r === 7, r);
  let thrown = null;
  try { tx(db, () => { throw new Error('H-业务异常'); }); } catch (e) { thrown = e; }
  ok('H-10 非 BUSY 业务异常原样抛出（不吞错）', thrown && /H-业务异常/.test(thrown.message), thrown && thrown.message);
  ok('H-11 业务异常后事务已回滚', db.prepare('SELECT COUNT(*) AS n FROM t').get().n === 1, null);
  let attempts = 0, busyErr = null;
  const fake = { exec(sql) { if (sql === 'BEGIN IMMEDIATE') { attempts++; throw new Error('database is locked'); } } };
  try { tx(fake, () => 'never'); } catch (e) { busyErr = e; }
  ok('H-12 持续 BUSY 最终抛出（不死循环）', busyErr && /locked/i.test(busyErr.message), busyErr && busyErr.message);
  ok('H-13 重试次数有上限（2..6）', attempts >= 2 && attempts <= 6, attempts);
  db.close();
}

// ---------- ④ openDb 的 busy_timeout 回读 ----------
{
  const d = mkdtempSync(join(tmpdir(), 'vh-busy-'));
  const p = join(d, 'm.db');
  const db = await openDb(p);
  const t = Number(db.prepare('PRAGMA busy_timeout').get()?.timeout ?? 0);
  ok('H-14 PRAGMA busy_timeout 回读 ≥1000ms', t >= 1000, t);
  db.close();
  rmSync(d, { recursive: true, force: true });
}

// ---------- ⑤ full / lite 工具分级（运行时） ----------
{
  const full = await boot({});
  ok('H-15 默认注册 13 个工具', full.host.tools.length === 13, full.host.tools.length);
  ok('H-16 默认 toolset.mode = full', full.rt.toolset.mode === 'full', full.rt.toolset.mode);
  ok('H-17 默认 dropped() = 0', full.rt.toolset.dropped() === 0, full.rt.toolset.dropped());
  const sec = await full.host.userMessage({ text: '还记得我住哪吗', scope: SCOPE, ownerQq: '10086' });
  ok('H-18 默认下 memory 段正常注入', (sec.get('dsh-life.memory') || '').length > 0, (sec.get('dsh-life.memory') || '').length);
  full.cleanup();

  const lite = await boot({ v14: { toolset: 'lite' } });
  const names = lite.host.tools.map((t) => t.name).sort();
  ok('H-19 lite 只注册 5 个工具', names.length === 5, names.length);
  ok('H-20 lite 注册的正是 5 个核心工具', JSON.stringify(names) === JSON.stringify([...LITE].sort()), names);
  ok('H-21 lite dropped() = 8', lite.rt.toolset.dropped() === 8, lite.rt.toolset.dropped());
  const sec2 = await lite.host.userMessage({ text: '还记得我住哪吗', scope: SCOPE, ownerQq: '10086' });
  ok('H-22 lite 下 memory 段仍正常注入', (sec2.get('dsh-life.memory') || '').length > 0, (sec2.get('dsh-life.memory') || '').length);
  lite.cleanup();

  const fallback = await boot({ v14: { toolset: 'typo' } });
  ok('H-23 未知 toolset 值回落 full（13 工具）', fallback.host.tools.length === 13, fallback.host.tools.length);
  fallback.cleanup();
}

// ---------- ⑥ skipIdleTurn 复用语义（运行时） ----------
{
  const b = await boot({ v14: { skipIdleTurn: true } });
  const s1 = await b.host.userMessage({ text: '上海今天要带伞吗', scope: SCOPE, ownerQq: '10086' });
  const mem1 = s1.get('dsh-life.memory') || '';
  const s2 = await b.host.userMessage({ text: '(检查有没有人回我)', scope: SCOPE, ownerQq: '10086', wakeReason: 'timeout' });
  ok('H-24 wakeReason=timeout 空轮逐字节复用上一轮', (s2.get('dsh-life.memory') || '') === mem1, (s2.get('dsh-life.memory') || '').slice(0, 60));
  ok('H-25 idleSkips 累计 ≥1', (b.rt.idleSkips || 0) >= 1, b.rt.idleSkips);
  const s3 = await b.host.userMessage({ text: '明天见', scope: SCOPE, ownerQq: '10086' });
  ok('H-26 新文本正常轮重新注入', (s3.get('dsh-life.memory') || '').length > 0, (s3.get('dsh-life.memory') || '').length);
  ok('H-27 正常轮不会缓存过期 reflex 段', !b.rt.lastSections.has('dsh-life.reflex'), [...b.rt.lastSections.keys()]);
  b.cleanup();

  const off = await boot({});
  await off.host.userMessage({ text: '上海今天要带伞吗', scope: SCOPE, ownerQq: '10086' });
  await off.host.userMessage({ text: '(检查)', scope: SCOPE, ownerQq: '10086', wakeReason: 'timeout' });
  ok('H-28 默认关闭时 idleSkips 恒为 0（零行为变化）', (off.rt.idleSkips || 0) === 0, off.rt.idleSkips);
  off.cleanup();
}

// ---------- ⑦ 首轮边界（H 组实测抓到的 bug） ----------
// onReady 阶段就 put 了常驻的 dsh-life.policy，lastSections.size 恒 ≥1；
// 曾用 size>0 当「跑过正常轮」的判据，导致首轮即空唤醒被误判为空轮、
// 只复用 policy 而丢掉 memory 段（H-29/H-30 FAIL）。正确判据是缓存里真的有
// dsh-life.memory。这两条断言就是为这个回归点而加。
{
  const b = await boot({ v14: { skipIdleTurn: true } });
  const s = await b.host.userMessage({ text: '首轮就是空唤醒', scope: SCOPE, ownerQq: '10086', wakeReason: 'timeout' });
  ok('H-29 首轮即空唤醒按正常轮处理（不拿到空注入）', (s.get('dsh-life.memory') || '').length > 0, (s.get('dsh-life.memory') || '').length);
  ok('H-30 首轮即空唤醒时 idleSkips = 0', (b.rt.idleSkips || 0) === 0, b.rt.idleSkips);
  ok('H-31 判据是缓存含 dsh-life.memory 而非仅 size>0', b.rt.lastSections.has('dsh-life.memory'), [...b.rt.lastSections.keys()]);
  b.cleanup();
}

// ---------- ⑧ 真库 event_id 撞车修复（H7 轻量回归） ----------
// 老库 life_events 的 event_id 可空、seq 才是主键；recipe 把 event_id 提升为
// TEXT PRIMARY KEY 并用 'v11-'||seq 补 NULL，恰好与存量 'v11-<N>' 撞车 →
// 重建报 UNIQUE constraint failed → 整表回滚 → 建索引时 no such column: event_type。
// H7 用模拟数据复刻，这里再守一次「确定性去重 + 老列/正常主键都不丢」。
{
  const db = new DatabaseSync(':memory:');
  db.exec(`CREATE TABLE life_events (
    seq INTEGER PRIMARY KEY AUTOINCREMENT, at TEXT NOT NULL, kind TEXT NOT NULL,
    payload TEXT, delta TEXT, revision INTEGER, applied_at TEXT, type TEXT,
    event_id TEXT, created_at TEXT);`);
  const t = '2026-11-06 12:00:00';
  const ins = db.prepare('INSERT INTO life_events(at,kind,payload,event_id) VALUES(?,?,?,?)');
  ins.run(t, 'tick', '{"a":1}', null);          // → 'v11-1'
  ins.run(t, 'tick', '{"a":2}', 'v11-1');       // 与上面撞车
  ins.run(t, 'tick', '{"a":3}', '');            // 空串同样走补值
  ins.run(t, 'tick', '{"a":4}', 'keep-me-unchanged');
  const naive = db.prepare(
    `SELECT COUNT(*) AS n, COUNT(DISTINCT COALESCE(NULLIF(event_id,''), 'v11-' || seq)) AS d FROM life_events`
  ).get();
  ok('H-32 复刻形状确实需要重建（缺 event_type）',
    diagnoseLegacyShape(db, {}).some(r => r.table === 'life_events' && r.needsRelax), null);
  ok('H-33 修复前 naive 补值必然产生重复主键', naive.n > naive.d, { rows: naive.n, distinct: naive.d });
  const r = relaxTable(db, 'life_events');
  ok('H-34 relaxTable 重建成功（不再 UNIQUE 报错）', r.rebuilt === true, r);
  const after = db.prepare('SELECT event_id, event_type, kind, seq FROM life_events ORDER BY seq').all();
  const ids = after.map(x => x.event_id);
  ok('H-35 4 行全部保留且 event_id 无 NULL/空/重复',
    after.length === 4 && ids.every(v => v !== null && v !== '') && new Set(ids).size === ids.length, ids);
  ok('H-36 未被卷入撞车的正常主键一字不改', ids.includes('keep-me-unchanged'), ids);
  ok('H-37 老列 kind/seq 仍在、新列 event_type 已就位',
    after.every(x => x.kind === 'tick' && typeof x.seq === 'number') &&
    db.prepare('PRAGMA table_info("life_events")').all().some(c => c.name === 'event_type'), null);
  ok('H-38 重建后不再需要二次宽松化',
    !diagnoseLegacyShape(db, {}).some(r => r.table === 'life_events' && r.needsRelax), null);
  const src = readFileSync(join(ROOT, 'src/kit/legacy-shape.mjs'), 'utf8');
  ok('H-39 修复段是 JS 确定性收集（不靠 UPDATE 子查询物化）',
    /const rows = db\.prepare\(`SELECT rowid AS rid/.test(src) && /st\.run\(prefix \+ rid, rid\)/.test(src), null);
  ok('H-40 补值前缀会避开现存主键（LIKE 前缀% 探测）',
    /LIKE \?/.test(src) && /options = \['relax-'/.test(src), null);
  db.close();
}

console.log(`\n== H 回归合计：PASS ${pass} / FAIL ${fail} ==`);
if (fail) process.exit(1);
