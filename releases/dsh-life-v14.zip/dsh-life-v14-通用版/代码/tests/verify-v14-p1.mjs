#!/usr/bin/env node
// tests/verify-v14-p1.mjs — P1 睡眠 / 梦境 / 情感叠加断言
// 覆盖：阶段机与分档回血、被叫醒的脾气、梦境绝不写 memories、念头流分寸、
//       词典法即时共情（只产 delta）、反刍、六欲联动、情感指纹与再巩固边界。
import { DatabaseSync } from 'node:sqlite';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { DEFAULTS } from '../src/kit/config.mjs';
import { defaultState } from '../src/life/life-state.mjs';
import { sleepStage, settleStages, maybeDream, dreamContext, think, currentThoughts, thoughtContext, fatigueConfidenceFactor, STAGES, THOUGHT_MAX } from '../src/life/sleep-stage.mjs';
import { detectImmediate, clampDelta, decayToward, softSaturation, ruminationHalfLife, desireMoodTick, isHypothetical, hasCredential } from '../src/life/lexicon.mjs';
import { makeFingerprint, attachFingerprint, reconsolidate, padFromHormones, moodCongruence } from '../src/life/affect-fingerprint.mjs';
import { compose, stateLine } from '../src/prompt/composer.mjs';
import { openGap, remFromGaps } from '../src/memory/gaps.mjs';

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..');
let pass = 0, fail = 0;
const failures = [];
const ok = (id, cond, got) => {
  if (cond) { pass++; console.log(`  PASS ${id}`); }
  else { fail++; failures.push(id); console.log(`  FAIL ${id}  got=${JSON.stringify(got)}`); }
};
const mk = () => {
  const db = new DatabaseSync(':memory:');
  db.exec(readFileSync(join(ROOT, 'schema.sql'), 'utf8'));
  return db;
};
// 固定「凌晨 2 点」用于夜间场景
const night = new Date('2026-11-04T02:00:00+08:00').getTime();
const noon = new Date('2026-11-04T12:00:00+08:00').getTime();

console.log('\n== P1-A. 睡眠阶段机与精力 ==');
{
  ok('A1 阶段枚举完整', STAGES.join(',') === 'awake,nrem_light,nrem_deep,rem');
  const s = defaultState(night); s.energy = 0.25;
  ok('A2 凌晨低精力进深睡', sleepStage(s, night, DEFAULTS) === 'nrem_deep');
  ok('A3 白天一律 awake', sleepStage(defaultState(noon), noon, DEFAULTS) === 'awake');
  const light = { ...defaultState(night), energy: 0.25 };
  const r1 = settleStages(light, { now: night, minutes: 60, cfg: DEFAULTS, db: null, dreamEnabled: false });
  ok('A4 睡着会回血', r1.state.energy > 0.25, r1.state.energy);
  ok('A5 阶段被记录', r1.state.sleep?.stage === 'nrem_deep', r1.state.sleep);
  const awake = settleStages({ ...defaultState(noon), energy: 0.8 }, { now: noon, minutes: 60, cfg: DEFAULTS, dreamEnabled: false });
  ok('A6 醒着精力缓降', awake.state.energy < 0.8, awake.state.energy);

  // 被叫醒的脾气：深睡 → awake
  const deep = defaultState(night); deep.energy = 0.3; deep.sleep = { stage: 'nrem_deep', stageSince: night - 3600000, sleepDebt: 0.4, dreamLog: [], lastDreamAt: 0 };
  const before = deep.hormones.cortisol;
  const woke = settleStages(deep, { now: noon, minutes: 15, cfg: DEFAULTS, dreamEnabled: false });
  ok('A7 深睡被叫醒皮质醇上扬', woke.state.hormones.cortisol > before, { before, after: woke.state.hormones.cortisol });
  ok('A8 单次限幅 ≤0.03', woke.state.hormones.cortisol - before <= 0.0301);
  ok('A9 记录 wokeFrom', woke.wokeFrom === 'nrem_deep', woke.wokeFrom);

  ok('A10 缺觉降低入库置信', fatigueConfidenceFactor({ energy: 0.1, sleep: { sleepDebt: 0.6 } }, DEFAULTS) < 1);
  ok('A11 精力正常不打折', fatigueConfidenceFactor({ energy: 0.8, sleep: { sleepDebt: 0 } }, DEFAULTS) === 1);
}

console.log('\n== P1-B. 梦境：只写日志，绝不写回记忆 ==');
{
  const db = mk();
  const before = db.prepare('SELECT COUNT(*) AS n FROM memories').get().n;
  openGap(db, { question: '他为什么没回消息', tension: 0.8, now: night });
  const s = defaultState(night);
  const d = maybeDream(db, s, { now: night, cfg: DEFAULTS });
  ok('B1 生成一场梦', !!d && typeof d.text === 'string');
  ok('B2 梦境写在 state.sleep.dreamLog', s.sleep.dreamLog.length === 1);
  ok('B3 显式标记未写 memories', d.wroteToMemories === false);
  ok('B4 memories 一行没多', db.prepare('SELECT COUNT(*) AS n FROM memories').get().n === before);
  ok('B5 素材来自真实缺口', d.sources.gaps.length === 1, d.sources);
  ok('B6 20 小时冷却', maybeDream(db, s, { now: night + 3600000, cfg: DEFAULTS }) === null);
  ok('B7 clear 是布尔（只记得一部分）', typeof d.clear === 'boolean');
  ok('B8 早上才提梦', dreamContext(s, new Date('2026-11-04T08:00:00+08:00').getTime(), DEFAULTS).includes('梦'));
  ok('B9 下午不提梦', dreamContext(s, new Date('2026-11-04T15:00:00+08:00').getTime(), DEFAULTS) === '');
  ok('B10 14 小时后不提', dreamContext(s, night + 15 * 3600000, DEFAULTS) === '');
  ok('B11 gap 文本可被 remFromGaps 取到', remFromGaps(db, { limit: 1, threshold: 0.3 }).length === 1);
  db.close();
}

console.log('\n== P1-C. 念头流 ==');
{
  const s = defaultState(noon);
  ok('C1 空状态无文案', thoughtContext(s, noon) === '');
  think(s, '不知道他今晚会不会梦到我呢', { now: noon });
  const t = thoughtContext(s, noon);
  ok('C2 文案带「不一定要说出来」', t.includes('不一定要说出来'), t);
  ok('C3 不报数值', !/\d/.test(t.replace(/\d{4}/g, '')), t);
  ok('C4 20 分钟同文去重', think(s, '不知道他今晚会不会梦到我呢', { now: noon + 60000 }) === null);
  for (let i = 0; i < 10; i++) think(s, '念头 ' + i, { now: noon + (i + 2) * 60000 });
  ok('C5 最多留 6 条', s.thoughtStream.length === THOUGHT_MAX, s.thoughtStream.length);
  ok('C6 只注入前 3 条', (thoughtContext(s, noon).match(/· /g) || []).length === 3);
  ok('C7 3 小时后自然淡掉', currentThoughts(s, noon + 4 * 3600000).length === 0);
}

console.log('\n== P1-D. 词典法即时共情（反应式） ==');
{
  ok('D1 夸奖命中并产 delta', (() => { const r = detectImmediate('你好厉害！', { now: noon }); return r && r.delta.dopamine > 0; })());
  ok('D2 被凶命中皮质醇', (() => { const r = detectImmediate('滚，别烦我', { now: noon }); return r && r.delta.cortisol > 0; })());
  ok('D3 无关文本返回 null', detectImmediate('今天天气不错', { now: noon }) === null);
  ok('D4 一条消息最多命中 2 条规则', (() => { const r = detectImmediate('你好厉害，我好喜欢你，还夸你可爱', { now: noon }); return r && r.matched.filter(x => !x.startsWith('gap')).length <= 2; })());
  ok('D5 限幅 ±0.03', Object.values(clampDelta({ cortisol: 1, dopamine: -1 }, 0.03)).every(v => Math.abs(v) <= 0.03));
  ok('D6 24h 间隔分级', detectImmediate('在吗', { gapMs: 25 * 3600000, now: noon }).matched.some(x => x.startsWith('gap:24h')));
  ok('D7 假设语气识别', isHypothetical('如果明天下雨就不去了').kind === 'hypothetical');
  ok('D8 凭据识别', hasCredential('sk-abcdefghijklmnop') === true);
  ok('D9 指数半衰衰减', Math.abs(decayToward(1, 0, 1000, 1000) - 0.5) < 1e-9);
  ok('D10 端点收缩不顶满', softSaturation(0.94, 0.5) < 1 && softSaturation(0.94, 0.5) > 0.94);
  const rum1 = ruminationHalfLife(8, { at: noon, streak: 0 }, noon + 60000);
  const rum2 = ruminationHalfLife(8, { at: rum1.at, streak: rum1.streak }, noon + 120000);
  const rum3 = ruminationHalfLife(8, { at: rum2.at, streak: rum2.streak }, noon + 180000);
  const rum4 = ruminationHalfLife(8, { at: rum3.at, streak: rum3.streak }, noon + 240000);
  ok('D11 反刍 40 分钟内 +33%', Math.abs(rum1.halfLife / 8 - 1.33) < 0.01, rum1);
  ok('D12 反刍最多 +99%', rum4.streak === 3 && Math.abs(rum4.halfLife / 8 - 1.99) < 0.01, rum4);
  const dm = desireMoodTick({ social: 0.1, curiosity: 0.1, rest: 0.1, mood: 0.1, closeness: 0.1, energy: 0.1 }, { counters: {} }, { now: noon });
  ok('D13 六欲低 → 联动产出', !!dm && dm.delta.cortisol > 0, dm);
  ok('D14 联动限幅 ±0.03', Object.values(dm.delta).every(v => Math.abs(v) <= 0.0301));
  ok('D15 25 分钟冷却', desireMoodTick({}, { counters: { desireMoodAt: noon - 60000 } }, { now: noon }) === null);
}

console.log('\n== P1-E. 情感指纹与再巩固 ==');
{
  const s = defaultState(noon);
  const fp = makeFingerprint(s, { now: noon });
  ok('E1 指纹含 PAD + 词 + 显著性', ['P', 'A', 'D', 'word', 'salience', 'at'].every(k => k in fp.affect), fp.affect);
  ok('E2 PAD 在 0–1', ['P', 'A', 'D'].every(k => fp.affect[k] >= 0 && fp.affect[k] <= 1));
  ok('E3 attach 不覆盖已有 anchor 键', attachFingerprint({ fact: 'x', anchor_ground: { kind: 'hypothetical' } }, s).anchor_ground.kind === 'hypothetical');
  ok('E4 padFromHormones 确定性', JSON.stringify(padFromHormones(s.hormones)) === JSON.stringify(padFromHormones(s.hormones)));

  const db = mk();
  db.prepare('INSERT INTO memories(id, scope, category, fact, created_at, created_at_ms, content_hash, anchor_ground) VALUES(?,?,?,?,?,?,?,?)')
    .run(1, 'private:1', 'fact', '他喜欢夜里写代码', '2026-11-04 12:00:00', noon, 'h1', JSON.stringify({ affect: fp.affect, kind: 'x' }));
  const beforeFact = db.prepare('SELECT fact FROM memories WHERE id=1').get().fact;
  const r = reconsolidate(db, [{ mem: { id: 1 } }], s, { now: noon });
  ok('E5 再巩固更新 1 条', r.updated === 1, r);
  ok('E6 绝不改写 fact 正文', db.prepare('SELECT fact FROM memories WHERE id=1').get().fact === beforeFact);
  const ag = JSON.parse(db.prepare('SELECT anchor_ground FROM memories WHERE id=1').get().anchor_ground);
  ok('E7 保留编码时的词', ag.affect.word === fp.affect.word);
  ok('E8 另记最近想起时的情绪', !!ag.affect.lastRecalledWord && ag.affect.hits === 1, ag.affect);
  ok('E9 保留其他 anchor 键', ag.kind === 'x');
  ok('E10 心境一致度 0–1', moodCongruence(ag, s) >= 0 && moodCongruence(ag, s) <= 1);
  db.close();
}

console.log('\n== P1-F. 注入层：触发卡 / 自我报告 ==');
{
  const s = defaultState(noon);
  const c = compose({ l1: '人格', facts: [{ line: '[事实] 他喜欢夜里写代码' }], triggerCards: [{ line: '【念头】还想着刚才那句' }], snippets: [{ line: '【梦】画面很淡' }] });
  ok('F1 触发卡进入同槽且不改预算', c.text.includes('念头') && c.usedChars <= 900, c.usedChars);
  ok('F2 原有 facts 仍在', c.text.includes('他喜欢夜里写代码'));
  const line = stateLine({ phase: 'night', energy: 0.4, hormones: s.hormones, stage: 'normal', selfReport: '有点烦', dominant: '绷着' });
  ok('F3 自我报告与主导情绪进状态行', line.includes('有点烦') && line.includes('绷着'), line);
  ok('F4 状态行仍不带数字', !/\d/.test(line), line);
  const base = stateLine({ phase: 'night', energy: 0.4, hormones: s.hormones, stage: 'normal' });
  ok('F5 不传时保持 v13 输出', !base.includes('有点烦') && !base.includes('绷着'), base);
}

console.log(`\n结果（v14 P1 睡眠与情感）：PASS ${pass} / FAIL ${fail}`);
if (fail) { console.log('失败项：' + failures.join(', ')); process.exit(1); }
