#!/usr/bin/env node
// tests/verify-v14-p2.mjs — P2 检索三段 + 记忆治理断言
// 覆盖：BM25 只增补不替换 LIKE 基线、rerank 精确命中保底与外部降级、
//       来源五档 / 同键 / 凭据 / 假设语气 / 自动提取 / 盖章作废 / 新会话重读。
import { DatabaseSync } from 'node:sqlite';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { DEFAULTS } from '../src/kit/config.mjs';
import { writeMemory } from '../src/memory/engine.mjs';
import { searchMemory } from '../src/memory/search.mjs';
import { bm25Rank, termsOf, buildCooc } from '../src/memory/bm25.mjs';
import { rerankHits, rerankWithExternal, exactHit, bumpStats, readStats } from '../src/memory/rerank.mjs';
import { preWrite, retract, extractFacts, reloadHighPriority, normalizeSource, SOURCE_TRUST } from '../src/memory/governance.mjs';
import { injectable } from '../src/memory/weight.mjs';
import { defaultState } from '../src/life/life-state.mjs';

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..');
let pass = 0, fail = 0;
const failures = [];
const ok = (id, cond, got) => {
  if (cond) { pass++; console.log(`  PASS ${id}`); }
  else { fail++; failures.push(id); console.log(`  FAIL ${id}  got=${JSON.stringify(got)}`); }
};
const mk = () => {
  const db = new DatabaseSync(':memory:');
  db.exec(readFileSync(join(ROOT, 'schema.sql'), 'utf8'));
  return db;
};
const now = Date.now();
const add = (db, fact, extra = {}) => writeMemory(db, {
  fact, category: 'fact', confidence: 1, force_direct: true, scope: 'private:1', ...extra,
}, { cfg: DEFAULTS, now });

console.log('\n== P2-A. BM25 与 LIKE 基线共存 ==');
{
  const db = mk();
  // 含 # 的暗号：shingle 分词会整串不匹配，只有 LIKE 保底能命中
  await add(db, '群1的暗号是海豚#1#');
  const base = searchMemory(db, '海豚#1#', { cfg: DEFAULTS, scope: 'private:1' });
  const bm = searchMemory(db, '海豚#1#', { cfg: DEFAULTS, scope: 'private:1', bm25: true, rerank: true });
  ok('A1 v13 LIKE 基线能命中', base.items.length >= 1, base.items.length);
  ok('A2 开 BM25 后不丢基线命中', bm.items.length >= 1, bm.items.length);
  ok('A3 BM25 分数已挂到 items', bm.items.some(x => typeof x.bm25 === 'number'), bm.items[0]);
  ok('A4 不泄漏别的 scope', bm.items.every(x => x.mem.scope === 'private:1'));

  const q = ['游戏段位偏好', '他喜欢打王者荣耀', '他讨厌早起'];
  const { scores } = bm25Rank('游戏 段位', q.map((fact, i) => ({ id: i, fact })), { cooc: true });
  ok('A5 BM25 产出 0–1 分数', [...scores.values()].every(v => v >= 0 && v <= 1), [...scores.entries()]);
  ok('A6 termsOf 过滤停用词', !termsOf('我的了是什么').includes('的'));
  ok('A7 共现表可构建', buildCooc([{ fact: '游戏段位' }, { fact: '游戏段位' }, { fact: '游戏排位' }]) instanceof Map);
  db.close();
}

console.log('\n== P2-B. 轻量 rerank 与降级 ==');
{
  const mkHits = () => [
    { mem: { id: 1, fact: '他喜欢夜里写代码', tags: '[]', anchor_ground: null }, score: 0.5, ts: 0.6, cos: 0.4, eff: 0.7, cov: 0.5, rb: 0, mode: 'fact' },
    { mem: { id: 2, fact: '今天天气不错', tags: '[]', anchor_ground: null }, score: 0.9, ts: 0.1, cos: 0.1, eff: 0.4, cov: 0.1, rb: 0, mode: 'fact' },
    { mem: { id: 3, fact: '如果明天下雨就不去了', tags: '[]', anchor_ground: '{"kind":"hypothetical"}' }, score: 0.8, ts: 0.7, cos: 0.6, eff: 0.8, cov: 0.8, rb: 0, mode: 'hypothetical' },
    { mem: { id: 4, fact: '他周末常去书店', tags: '[]', anchor_ground: null }, score: 0.4, ts: 0.3, cos: 0.3, eff: 0.5, cov: 0.3, rb: 0, mode: 'fact' },
    { mem: { id: 5, fact: '他养了一只猫', tags: '[]', anchor_ground: null }, score: 0.3, ts: 0.2, cos: 0.2, eff: 0.4, cov: 0.2, rb: 0, mode: 'fact' },
  ];
  const r = rerankHits('他喜欢夜里写代码', mkHits(), { cfg: DEFAULTS, now, topN: 20, keep: 3 });
  ok('B1 重排返回 topK', r.items.length === 3, r.items.length);
  ok('B2 精确命中保底 0.85', exactHit('他喜欢夜里写代码', { fact: '他喜欢夜里写代码' }) === true);
  ok('B3 精确命中项不被压到 0.85 以下', r.items.find(x => x.mem.id === 1)?.score >= 0.85, r.items.map(x => [x.mem.id, x.score]));
  ok('B4 假设语气被降权', r.stats.demoted >= 1, r.stats);
  ok('B5 统计记账', r.stats.called === 1 && typeof r.stats.kept === 'number');

  const timeout = await rerankWithExternal('查询', mkHits(), {
    rerankFn: () => new Promise(() => {}), timeoutMs: 20, cfg: DEFAULTS, now,
  });
  ok('B6 外部 rerank 超时回落', timeout.stats.fallback === 1 || timeout.stats.external === 'off', timeout.stats);
  ok('B7 超时仍返回完整 items', timeout.items.length >= 3, timeout.items.length);
  const external = await rerankWithExternal('他喜欢夜里写代码', mkHits(), {
    rerankFn: async ({ passages }) => passages.map(p => ({ id: p.id, score: p.id === '2' ? 0.01 : 0.9 })),
    timeoutMs: 200, cfg: DEFAULTS, now,
  });
  ok('B8 外部分数可用', external.stats.external === 'on', external.stats);
  ok('B9 明确无关被降权', external.items.find(x => x.mem.id === 2)?.score < 0.5, external.items.map(x => [x.mem.id, x.score]));

  const db = mk();
  bumpStats(db, 'fallback', 3); bumpStats(db, 'fallback', 1);
  ok('B10 回退次数可观测', readStats(db).fallback.total === 4, readStats(db));
  db.close();
}

console.log('\n== P2-C. 来源五档与写入前治理 ==');
{
  ok('C1 别名归一', normalizeSource('user_sentence') === 'owner' && normalizeSource('world') === 'evidence');
  ok('C2 信任排序', SOURCE_TRUST.owner > SOURCE_TRUST.self && SOURCE_TRUST.tool > SOURCE_TRUST.inferred);
  const db = mk();
  const g1 = preWrite(db, { fact: '他叫顾晨', scope: 'private:1', source_kind: 'inferred', belief: 0.95 }, { cfg: DEFAULTS });
  ok('C3 inferred 的 belief 被压到 0.55', g1.input.belief === 0.55, g1.input.belief);
  const g2 = preWrite(db, { fact: '我的密钥是 sk-abcdefghijklmnop1234' }, { cfg: DEFAULTS });
  ok('C4 凭据被拒', g2.rejected === true && g2.reason === 'credential', g2);
  const g3 = preWrite(db, { fact: '如果明天下雨就不去了', scope: 'private:1', source_kind: 'owner' }, { cfg: DEFAULTS });
  ok('C5 假设语气打标', g3.hypothetical === true && g3.input.anchor_ground.kind === 'hypothetical', g3.input.anchor_ground);
  ok('C6 假设条目降置信进候选', g3.input.confidence <= 0.55, g3.input.confidence);
  const g4 = preWrite(db, { fact: '他喜欢夜里写代码', subject: '顾晨', scope: 'private:1', source_kind: 'owner' }, { cfg: DEFAULTS });
  ok('C7 subject 映射到 attr_key（复用第 9 步）', g4.input.attr_key === 'subject:顾晨', g4.input.attr_key);

  // inferred 撞明确来源 → 合并，不新增
  await add(db, '他喜欢夜里写代码', { source_kind: 'user_sentence' });
  const g5 = preWrite(db, { fact: '他喜欢夜里写代码', scope: 'private:1', source_kind: 'inferred' }, { cfg: DEFAULTS });
  ok('C8 inferred 撞明确来源被合并', g5.rejected === true && g5.reason === 'inferred-merged', g5);
  ok('C9 合并后不新增记忆', db.prepare('SELECT COUNT(*) AS n FROM memories').get().n === 1);
  // 缺觉降置信
  const tired = defaultState(now); tired.energy = 0.05; tired.sleep = { sleepDebt: 0.8 };
  const g6 = preWrite(db, { fact: '他周二有考试', scope: 'private:1', source_kind: 'owner', confidence: 0.9 }, { cfg: DEFAULTS, state: tired });
  ok('C10 缺觉降 confidence', g6.input.confidence < 0.9, g6.input.confidence);
  ok('C11 治理钩子不改 fact 正文', g6.input.fact === '他周二有考试');
  db.close();
}

console.log('\n== P2-D. 假设语气注入资格 / 自动提取 / 盖章作废 ==');
{
  ok('D1 hypothetical 可召回但带限定', injectable({ belief: 0.9, anchor_ground: '{"kind":"hypothetical"}' }).mode === 'hypothetical');
  ok('D2 普通事实仍是 fact', injectable({ belief: 0.9, anchor_ground: null }).mode === 'fact');
  const f = extractFacts('我叫顾晨，我生日是4月26日', { cfg: DEFAULTS, scope: 'private:1', now });
  ok('D3 自动提取产出候选', f.length >= 1, f);
  ok('D4 低置信一律 <0.6（不直写）', f.every(x => x.confidence < 0.6), f.map(x => x.confidence));
  ok('D5 空话不提取', extractFacts('嗯', { cfg: DEFAULTS }).length === 0);
  ok('D6 媒体占位不提取', extractFacts('[图片] 我叫张三', { cfg: DEFAULTS }).length === 0);

  const db = mk();
  const r = await add(db, '他答应周末陪我去书店');
  const id = r.id;
  const before = db.prepare('SELECT COUNT(*) AS n FROM memories').get().n;
  const rr = retract(db, id, '用户改口了');
  ok('D7 盖章作废成功', rr.ok === true && rr.deleted === false, rr);
  ok('D8 行还在（不物理删除）', db.prepare('SELECT COUNT(*) AS n FROM memories').get().n === before);
  const row = db.prepare('SELECT invalid_reason, anchor_ground FROM memories WHERE id = ?').get(id);
  ok('D9 标了旧库白名单内的 invalid_reason', row.invalid_reason === 'manual' && rr.stampedAs === 'manual', { row, rr });
  ok('D10 记了 retractNote', JSON.parse(row.anchor_ground || '{}').retractNote?.reason === '用户改口了', row.anchor_ground);
  ok('D11 正文未被改写', db.prepare('SELECT fact FROM memories WHERE id = ?').get(id).fact === '他答应周末陪我去书店');
  db.close();
}

console.log('\n== P2-E. 新会话重读高权重记忆 ==');
{
  const db = mk();
  await add(db, '他叫顾晨', { importance: 0.95, category: 'person' });
  await add(db, '今天午饭吃了面', { importance: 0.35 });
  const rows = reloadHighPriority(db, { scopes: ['private:1'], limit: 4, now, cfg: DEFAULTS });
  ok('E1 只挑高权重 / 核心类别', rows.some(x => x.fact === '他叫顾晨') && !rows.some(x => x.fact === '今天午饭吃了面'), rows.map(x => x.fact));
  ok('E2 只读不写', db.prepare('SELECT COUNT(*) AS n FROM memories').get().n === 2);
  ok('E3 别人的 scope 读不到', reloadHighPriority(db, { scopes: ['private:2'], limit: 4, cfg: DEFAULTS }).length === 0);
  db.close();
}

console.log(`\n结果（v14 P2 检索与治理）：PASS ${pass} / FAIL ${fail}`);
if (fail) { console.log('失败项：' + failures.join(', ')); process.exit(1); }
