#!/usr/bin/env node
// tests/verify-v14-p3.mjs — P3 信念 / 印记 / 一致性 / 总闸回退 / 模块自检
// 对应仿生人偶文档四阶段排期的阶段 3–4：「冲突信念隔离」「不可逆印记由调度层硬编码控制」。
import { DatabaseSync } from 'node:sqlite';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';
import { DEFAULTS, mergeConfig } from '../src/kit/config.mjs';
import { detectConflicts, listConflicts, resolveConflict, generateImprint, negativeAlerts, consistencySample } from '../src/memory/belief-pool.mjs';
import { createGenericHost } from '../src/host/generic.mjs';
import createPlugin from '../src/index.mjs';
import { writeMemory } from '../src/memory/engine.mjs';
import { defaultState } from '../src/life/life-state.mjs';

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..');
let pass = 0, fail = 0;
const failures = [];
const ok = (id, cond, got) => {
  if (cond) { pass++; console.log(`  PASS ${id}`); }
  else { fail++; failures.push(id); console.log(`  FAIL ${id}  got=${JSON.stringify(got)}`); }
};
const mk = () => {
  const db = new DatabaseSync(':memory:');
  db.exec(readFileSync(join(ROOT, 'schema.sql'), 'utf8'));
  return db;
};
const now = Date.now();
const insert = (db, fact, extra = {}) => {
  const id = 1 + (db.prepare('SELECT COUNT(*) AS n FROM memories').get().n);
  db.prepare('INSERT INTO memories(id, scope, category, fact, tags, importance, created_at, created_at_ms, content_hash, audit_status, anchor_ground) VALUES(?,?,?,?,?,?,?,?,?,?,?)')
    .run(id, 'private:1', extra.category || 'fact', fact, extra.tags || '', extra.importance ?? 0.6,
      '2026-11-01 12:00:00', now, 'h' + id, 'ok', extra.anchor_ground || null);
  return id;
};

console.log('\n== P3-A. 信念校验池：只隔离，不自动删 ==');
{
  const db = mk();
  const a = insert(db, '他喜欢早起', { tags: '作息', importance: 0.7 });
  const b = insert(db, '他不喜欢早起', { tags: '作息', importance: 0.6 });
  const before = db.prepare('SELECT COUNT(*) AS n FROM memories').get().n;
  const r = detectConflicts(db, { now, cfg: DEFAULTS });
  ok('A1 检出极性冲突', r.found.length >= 1, r.found);
  ok('A2 只隔离 weaker 一方', r.isolated === 1, r.isolated);
  ok('A3 一行都没删', db.prepare('SELECT COUNT(*) AS n FROM memories').get().n === before);
  ok('A4 列表可查（留给人工终审）', listConflicts(db).length >= 1);
  const factA = db.prepare('SELECT fact FROM memories WHERE id=?').get(a).fact;
  const factB = db.prepare('SELECT fact FROM memories WHERE id=?').get(b).fact;
  ok('A5 冲突双方正文都未被改写', factA === '他喜欢早起' && factB === '他不喜欢早起');
  const target = listConflicts(db)[0].id;
  ok('A6 人工终审可解除隔离', resolveConflict(db, target, { verdict: 'ok', now }).ok === true);
  ok('A7 解除后列表为空', listConflicts(db).length === 0);
  db.close();
  const clean = mk();
  insert(clean, '他喜欢早起', { tags: '作息' });
  insert(clean, '他周末去书店', { tags: '出行' });
  ok('A8 无冲突不误报', detectConflicts(clean, { now, cfg: DEFAULTS }).found.length === 0);
  clean.close();
}

console.log('\n== P3-B. 不可逆印记：调度层硬编码闸门 ==');
{
  const db = mk();
  const weak = { id: 1, importance: 0.4, category: 'fact' };
  ok('B1 重要度不够被拒', generateImprint(db, weak, { now, independentEvidence: 2 }).reason === 'gate');
  const hypo = { id: 2, importance: 0.95, category: 'promise', anchor_ground: '{"kind":"hypothetical"}' };
  ok('B2 假设语气不得留印记', generateImprint(db, hypo, { now, independentEvidence: 2 }).reason === 'gate');
  ok('B3 独立证据不足被拒', generateImprint(db, { id: 3, importance: 0.95, category: 'promise' }, { now, independentEvidence: 1 }).reason === 'gate');
  const strong = { id: 4, importance: 0.95, category: 'promise' };
  const first = generateImprint(db, strong, { now, independentEvidence: 2 });
  ok('B4 全部条件满足才生成', first.ok === true, first);
  ok('B5 标记 LLM 无权写入', first.imprint.llmWritable === false && first.imprint.source === 'scheduler-hardcoded');
  ok('B6 只影响表达倾向', first.imprint.effect === 'expression-bias-only');
  ok('B7 冷却期内不再生成', generateImprint(db, strong, { now: now + 86400000, independentEvidence: 2 }).reason === 'cooldown');
  ok('B8 印记写进 life_events 而非 memories', db.prepare("SELECT COUNT(*) AS n FROM life_events WHERE event_type='imprint'").get().n === 1);
  db.close();
}

console.log('\n== P3-C. 负向异常告警与一致性抽样 ==');
{
  const db = mk();
  const bad = defaultState(now); bad.hormones.cortisol = 1.8;
  const alerts = negativeAlerts(db, bad, { now, cfg: DEFAULTS });
  ok('C1 状态越界被告警', alerts.some(a => a.kind === 'hormone-out-of-range'), alerts);
  ok('C2 空 edges 被告警（死链回潮可感知）', alerts.some(a => a.kind === 'edges-empty'), alerts);
  const clean = defaultState(now);
  ok('C3 正常状态无高危告警', !negativeAlerts(db, clean, { now, cfg: DEFAULTS }).some(a => a.level === 'high'));
  for (let i = 0; i < 3; i++) insert(db, '偏好条目 ' + i, { category: 'preference', importance: 0.8 });
  const cs = consistencySample(db, { now });
  ok('C4 一致性抽样可读', cs.sampled >= 3 && cs.target === 30, cs);
  ok('C5 只读不写', db.prepare('SELECT COUNT(*) AS n FROM memories').get().n === 3);
  db.close();
}

console.log('\n== P3-D. 总闸回退：v14=false 与 v13.0 行为一致 ==');
{
  const { mkdtempSync } = await import('node:fs');
  const { tmpdir } = await import('node:os');
  const dir = mkdtempSync(join(tmpdir(), 'v14rollback-'));
  const quietLog = { info() {}, warn() {}, error() {} };
  const run = async (v14) => {
    const host = createGenericHost({ log: quietLog, persona: () => '你叫小鱼。', embed: async () => null });
    const extra = v14 ? {} : { capabilities: { v14: false } };
    const p = createPlugin(host.ctx, { dbPath: join(dir, `m-${v14}.db`), ownerQq: '10086', ...extra });
    await host.start();
    // 走插件注册的真实工具（rememberDeps 会注入本地向量），而不是绕过装配直调 writeMemory
    const remember = host.tools.find(t => t.name === 'life_remember');
    await remember.run({ fact: '他叫顾晨', category: 'person', confidence: 1 });
    const sec = await host.userMessage({ text: '他叫什么', scope: 'private:10086' });
    const qv = await p.cache.getOrCompute('他叫什么');
    const state = { section: sec.get('dsh-life.memory'), hormoneSource: p.state.hormoneSource || null,
      sleep: !!p.state.sleep, thoughts: !!p.state.thoughtStream,
      vec: p.db.prepare('SELECT COUNT(*) AS n FROM memories WHERE vec IS NOT NULL').get().n,
      queryVecLen: qv ? qv.length : 0 };
    host.stop();
    return state;
  };
  const on = await run(true);
  const off = await run(false);
  ok('D1 关总闸后不写睡眠状态', off.sleep === false, off);
  ok('D2 关总闸后不写念头流', off.thoughts === false, off);
  ok('D3 关总闸后激素无 data-driven 标记', off.hormoneSource === null, off);
  ok('D4 关总闸后写入不产 vec', off.vec === 0, off);
  ok('D5 开总闸时工具写入产 vec（P0 生效）', on.vec >= 1, on);
  ok('D6 开总闸时查询向量为本地 384 维', on.queryVecLen === 384 && off.queryVecLen === 0, { on: on.queryVecLen, off: off.queryVecLen });
  ok('D7 两种模式都还能召回事实', on.section.includes('顾晨') && off.section.includes('顾晨'), { on: on.section, off: off.section });
  const cfgOff = mergeConfig(DEFAULTS, { capabilities: { v14: false } });
  ok('D8 合并配置不污染 DEFAULTS', DEFAULTS.capabilities.v14 === true && cfgOff.capabilities.v14 === false);
}

console.log('\n== P3-E. 启动自检：语法 / 缺失导入 / 循环 / 孤儿 ==');
{
  let out = '';
  try { out = execFileSync(process.execPath, [join(ROOT, 'scripts/check-modules.mjs')], { encoding: 'utf8' }); }
  catch (e) { out = String(e.stdout || '') + String(e.stderr || ''); }
  ok('E1 自检通过', out.includes('✓ 模块自检通过'), out.slice(-200));
  ok('E2 0 循环', /循环 0/.test(out), out.slice(0, 120));
  ok('E3 0 孤儿', /孤儿 0/.test(out), out.slice(0, 120));
  ok('E4 无缺失导入', !out.includes('缺失导入'), out.slice(0, 200));
}

console.log(`\n结果（v14 P3 信念与一致性）：PASS ${pass} / FAIL ${fail}`);
if (fail) { console.log('失败项：' + failures.join(', ')); process.exit(1); }
