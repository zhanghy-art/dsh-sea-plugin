#!/usr/bin/env node
// tests/verify-v14-p4.mjs — 合并版专项断言（P4：三态 / 72h / 180d / 隐私门禁 / 版本口径）
// 说明：本文件只依赖纯函数与子进程，不碰 node:sqlite，可在任何 Node ≥18 上跑。
//       涉及数据库的断言在 verify-v14-p0~p3 与 sandbox 场景里，不重复。
import { spawnSync } from 'node:child_process';
import { readFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { DEFAULTS, v14Mode, v14On, VERSION, SCHEMA_VERSION } from '../src/kit/config.mjs';
import { elapsedMinutes, advanceV14 } from '../src/life/clock.mjs';
import { settleStages } from '../src/life/sleep-stage.mjs';
import { shadowLog, inShadow } from '../src/kit/shadow.mjs';

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..');

let pass = 0, fail = 0;
const failures = [];
const ok = (id, cond, got) => {
  if (cond) { pass++; console.log(`  PASS ${id}`); }
  else { fail++; failures.push(id); console.log(`  FAIL ${id}  got=${JSON.stringify(got)}`); }
};

console.log('\n== X1. 版本口径（R8 改判）==');
{
  ok('X1-1 VERSION 是 14.x 能力版本', /^14\./.test(String(VERSION)), VERSION);
  ok('X1-2 SCHEMA_VERSION = 14（Q1/Q10：edges.basis + dreams 表）', SCHEMA_VERSION === 14, SCHEMA_VERSION);
  ok('X1-3 两者不同是刻意的，回滚判断以 SCHEMA_VERSION 为准', VERSION !== String(SCHEMA_VERSION));
}

console.log('\n== X2. 三态判定（R7）==');
{
  const on = { capabilities: { v14: true, autoExtract: true } };
  const off = { capabilities: { v14: true, autoExtract: false } };
  const sh = { capabilities: { v14: true, autoExtract: 'shadow' } };
  const gate = { capabilities: { v14: false, autoExtract: true } };
  const miss = { capabilities: { v14: true } };
  ok('X2-1 true => on', v14Mode(on, 'autoExtract') === 'on');
  ok('X2-2 false => off', v14Mode(off, 'autoExtract') === 'off');
  ok('X2-3 "shadow" => shadow', v14Mode(sh, 'autoExtract') === 'shadow');
  ok('X2-4 总闸关 => off（哪怕子开关是 true）', v14Mode(gate, 'autoExtract') === 'off');
  ok('X2-5 未登记的子开关 => off', v14Mode(miss, 'autoExtract') === 'off');
  ok('X2-6 不传 cap 且总闸开 => on', v14Mode(on, undefined) === 'on');
  ok('X2-7 v14On 对 shadow 返回 false（shadow ≠ 生效）', v14On(sh, 'autoExtract') === false);
  ok('X2-8 v14On 对 on 返回 true', v14On(on, 'autoExtract') === true);
  ok('X2-9 无 cfg 安全降级', v14Mode(undefined, 'autoExtract') === 'off');
  // 四项高风险能力必须登记
  for (const cap of ['autoExtract', 'beliefPool', 'imprint', 'rerank']) {
    ok(`X2-10 能力已登记: ${cap}`, Object.prototype.hasOwnProperty.call(DEFAULTS.capabilities, cap));
  }
  // 默认值约定：高风险默认关，低风险默认开
  ok('X2-11 autoExtract 默认关', DEFAULTS.capabilities.autoExtract !== true, DEFAULTS.capabilities.autoExtract);
  ok('X2-12 beliefPool 默认关', DEFAULTS.capabilities.beliefPool !== true, DEFAULTS.capabilities.beliefPool);
  ok('X2-13 imprint 默认关', DEFAULTS.capabilities.imprint !== true, DEFAULTS.capabilities.imprint);
}

console.log('\n== X3. 时间追赶上限 72h（N2）==');
{
  ok('X3-1 默认 maxCatchUpHours = 72', DEFAULTS.v14.sleep.maxCatchUpHours === 72, DEFAULTS.v14.sleep.maxCatchUpHours);
  const st = { counters: { lastTickAt: 0 } };
  const now = Date.now();
  const cap = elapsedMinutes(st, now, { maxCatchUpHours: 72 });
  ok('X3-2 空 lastTickAt 不炸，返回结构化结果', Number.isFinite(cap.minutes) && cap.minutes >= 0, cap);
  const st2 = { counters: { lastTickAt: now - 8 * 3600 * 1000 } };
  const m8 = elapsedMinutes(st2, now, { maxCatchUpHours: 72 });
  ok('X3-3 合盖 8 小时能追回 ~480 分钟', Math.abs(m8.minutes - 480) <= 2, m8);
  const st3 = { counters: { lastTickAt: now - 500 * 3600 * 1000 } };
  const capped = elapsedMinutes(st3, now, { maxCatchUpHours: 72 });
  ok('X3-4 500 小时被压到 72h 以内并标 capped', capped.minutes <= 72 * 60 + 2 && capped.capped === true, capped);
  // 注：15 是「追赶上限的下限」，不是 elapsed 的下限
  const floor15 = elapsedMinutes({ counters: { lastTickAt: now - 86400000 } }, now, { maxCatchUpHours: 0 });
  ok('X3-5 追赶上限自身有 15 分钟地板', floor15.minutes === 15 && floor15.capped === true, floor15);
}

console.log('\n== X4. 盖章行保留 180 天（N1）==');
{
  ok('X4-1 retainDays = 180', DEFAULTS.v14.stamps.retainDays === 180, DEFAULTS.v14.stamps.retainDays);
  ok('X4-2 retainDays 是正数且 > 90', DEFAULTS.v14.stamps.retainDays > 90);
}

console.log('\n== X5. shadow 执行器存在且可降级 ==');
{
  ok('X5-1 shadowLog 是函数', typeof shadowLog === 'function');
  ok('X5-2 inShadow 是函数', typeof inShadow === 'function');
  // 假 db：exec 记录调用、prepare 返回 run
  const calls = [];
  const fakeDb = {
    exec(sql) { calls.push(sql); },
    prepare() { return { run() { return { changes: 1 }; } }; },
  };
  const r = inShadow(fakeDb, 'unit', () => 42, 1);
  ok('X5-3 inShadow 返回 shadow:true', r.shadow === true, r.shadow);
  ok('X5-4 inShadow 回放 fn 的结果', r.would === 42, r.would);
  ok('X5-5 用了 SAVEPOINT', calls.some((s) => /SAVEPOINT v14_shadow/.test(s)), calls);
  ok('X5-6 一定回滚（ROLLBACK TO）', calls.some((s) => /ROLLBACK TO v14_shadow/.test(s)), calls);
  ok('X5-7 一定释放（RELEASE）', calls.some((s) => /RELEASE v14_shadow/.test(s)), calls);
  const thrown = inShadow(fakeDb, 'unit2', () => { throw new Error('boom'); }, 2);
  ok('X5-8 fn 抛错也不外溢', thrown.ok === false && /boom/.test(thrown.error || ''), thrown);
  ok('X5-9 db.exec 缺失也不炸', (() => { try { inShadow({ prepare: () => ({ run() {} }) }, 'u3', () => 1, 3); return true; } catch { return false; } })());
}

console.log('\n== X7. 精力上限与单一写入口（v14.2 合入 WB）==');
{
  // 睡着只能涨到 sleepEnergyCap；v14.1 的真 bug：0.90 深睡 4 小时会冲到 1.0
  const nite = new Date(2026, 10, 5, 2, 30, 0).getTime();
  const noon = new Date(2026, 10, 5, 13, 0, 0).getTime();
  const mk = (energy) => ({
    needs: { social: 0.5, curiosity: 0.5, rest: 0.5 }, energy,
    hormones: { dopamine: 0.5, cortisol: 0.3, oxytocin: 0.5, serotonin: 0.5 },
    phase: 'night', revision: 1, sleep: {},
  });
  const deep = settleStages(mk(0.90), { now: nite, minutes: 240, cfg: DEFAULTS, dreamEnabled: false });
  ok('X7-1 深睡 4 小时不冲破 sleepEnergyCap', deep.state.energy <= 0.95 + 1e-9, deep.state.energy);
  ok('X7-2 深睡确实能涨到上限附近', deep.state.energy >= 0.94, deep.state.energy);
  const low = settleStages(mk(0.20), { now: nite, minutes: 480, cfg: DEFAULTS, dreamEnabled: false });
  ok('X7-3 睡 8 小时可以超过 v13 的 0.60 封顶', low.state.energy > 0.60, low.state.energy);
  const aw = settleStages(mk(0.80), { now: noon, minutes: 120, cfg: DEFAULTS, dreamEnabled: false });
  ok('X7-4 醒着只降不涨', aw.state.energy < 0.80, aw.state.energy);
  ok('X7-5 sleepEnergyCap 配置项 = 0.95', DEFAULTS.v14.sleep.sleepEnergyCap === 0.95, DEFAULTS.v14.sleep.sleepEnergyCap);
  ok('X7-6 maxOfflineMinutes 配置项 = 720', DEFAULTS.v14.sleep.maxOfflineMinutes === 720, DEFAULTS.v14.sleep.maxOfflineMinutes);
  const tight = { ...DEFAULTS, v14: { ...DEFAULTS.v14, sleep: { ...DEFAULTS.v14.sleep, sleepEnergyCap: 0.70 } } };
  ok('X7-7 上限可被配置覆盖（不硬编码）',
    settleStages(mk(0.20), { now: nite, minutes: 480, cfg: tight, dreamEnabled: false }).state.energy <= 0.70 + 1e-9);

  // advanceV14：分段结算 + manageEnergy:false，energy 只由 settleStages 写
  const adv = advanceV14(mk(0.50), { now: nite + 8 * 3600 * 1000, minutes: 480, cfg: DEFAULTS, dreamEnabled: false, stepMinutes: 30 });
  ok('X7-8 advanceV14 分段数 = 480/30', adv.segments === 16, adv.segments);
  ok('X7-9 advanceV14 不破上限', adv.state.energy <= 0.95 + 1e-9, adv.state.energy);
  ok('X7-10 advanceV14 落了 lastTickAt',
    Math.abs(Number(adv.state.counters?.lastTickAt) - (nite + 8 * 3600 * 1000)) < 1000, adv.state.counters);
  ok('X7-11 8 小时以上标 longAbsence', adv.state.flags?.longAbsence === true, adv.state.flags);
}

console.log('\n== X8. 包名 / 入口三处一致（装了不跑的三根因）==');
{
  const pkg = JSON.parse(readFileSync(join(ROOT, 'package.json'), 'utf8'));
  ok('X8-1 package.json 名是 dsh-life-v14', pkg.name === 'dsh-life-v14', pkg.name);
  ok('X8-2 host 入口导出的 name 一致', /export const name = 'dsh-life-v14'/.test(readFileSync(join(ROOT, 'src/host/dsh.mjs'), 'utf8')));
  const yml = readFileSync(join(ROOT, 'cordis.patch.yml'), 'utf8');
  ok('X8-3 cordis.patch.yml 的 id/name 一致', /id: life-v14/.test(yml) && /name: 'dsh-life-v14'/.test(yml));
  ok('X8-4 main 指向 src/host/dsh.mjs', pkg.main === './src/host/dsh.mjs', pkg.main);
}

console.log('\n== X6. 打包期隐私门禁 ==');
{
  const r = spawnSync(process.execPath, ['scripts/privacy-scan.mjs', '.'], { encoding: 'utf8', cwd: ROOT });
  ok('X6-1 本包自身扫描通过（exit 0）', r.status === 0, r.status);
  ok('X6-2 输出含 PASS', /PASS/.test(r.stdout || ''), (r.stdout || '').slice(0, 80));
}

console.log(`\n== P4 合计：PASS ${pass} / FAIL ${fail} ==`);
if (fail) { console.log('failed:', failures.join(', ')); process.exit(1); }
