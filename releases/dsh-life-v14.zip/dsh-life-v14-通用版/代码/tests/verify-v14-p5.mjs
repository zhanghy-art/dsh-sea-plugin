#!/usr/bin/env node
// tests/verify-v14-p5.mjs — 十条裁决的落地断言（Q1–Q10）
// 全部走纯函数 / 假 db，不依赖 node:sqlite，可在任意 Node ≥18 上跑。
import { readFileSync } from 'node:fs';
import { DEFAULTS, v14Mode, SCHEMA_VERSION, VERSION } from '../src/kit/config.mjs';
import { sleepWindow, inSleepWindow, archiveDreams } from '../src/life/sleep-stage.mjs';
import { classifySleepReply, sleepShortReply } from '../src/life/delivery.mjs';
import { retrievalScore } from '../src/memory/weight.mjs';
import { recallDetail } from '../src/memory/recall-card.mjs';
import { buildPersonaDiff, applyPersonaDiff, personaSnapshot } from '../src/life/persona-drift.mjs';

let pass = 0, fail = 0; const failures = [];
const ok = (id, cond, got) => {
  if (cond) { pass++; console.log(`  PASS ${id}`); }
  else { fail++; failures.push(id); console.log(`  FAIL ${id}  got=${JSON.stringify(got)}`); }
};
const src = (p) => readFileSync(new URL('../' + p, import.meta.url), 'utf8');
const one = (re, s) => (String(s).match(re) || []).length;

// 假 db：按 SQL 分派，够 runNightly / recallDetail / persona 用
function fakeDb(rows = {}, capture = []) {
  return {
    exec() {},
    prepare(sql) {
      return {
        all: (...a) => (typeof rows.all === 'function' ? rows.all(sql, a) : (rows.all || [])),
        get: (...a) => {
          if (rows.get) { const r = rows.get(sql, a); if (r !== undefined) return r; }
          if (/FROM memories WHERE id/.test(sql)) return rows.memory || null;
          if (/FROM life_events/.test(sql)) return rows.event || null;
          return rows.one || null;
        },
        run: (...a) => { capture.push({ sql, args: a }); return { changes: 1 }; },
      };
    },
  };
}

console.log('\n== Q1 / Q10  schema 升 14 + edges.basis ==');
{
  ok('Q1-1 SCHEMA_VERSION = 14', SCHEMA_VERSION === 14, SCHEMA_VERSION);
  ok('Q1-2 VERSION 是 14.x', /^14\./.test(String(VERSION)), VERSION);
  const cols = JSON.parse(src('migrations/columns.json'));
  ok('Q1-3 columns.json target_version = 14', cols.target_version === 14, cols.target_version);
  ok('Q1-4 columns.json 含 edges.basis',
    (cols.table_column_patches || []).some((x) => x.table === 'edges' && x.column === 'basis'),
    (cols.table_column_patches || []).length);
  ok('Q1-5 schema.sql 的 edges 有 basis 列', /basis\s+TEXT/.test(src('schema.sql')));
  ok('Q1-6 tables.sql 的 edges 有 basis 列', /basis\s+TEXT/.test(src('migrations/tables.sql')));
  ok('Q1-7 迁移清单与 schema 版本一致（不再 13）', cols.target_label === '14.0', cols.target_label);
}

console.log('\n== Q5  dreams 表存在，但只有触发才写 ==');
{
  ok('Q5-1 schema.sql 建了 dreams 表', /CREATE TABLE IF NOT EXISTS dreams/.test(src('schema.sql')));
  ok('Q5-2 tables.sql 也建了（升级路径）', /CREATE TABLE IF NOT EXISTS dreams/.test(src('migrations/tables.sql')));
  ok('Q5-3 dreams 有 night 索引', /idx_dreams_night/.test(src('schema.sql')));
  const cap = [];
  const st = { sleep: { dreamLog: [{ text: 'a', at: 1 }, { text: 'b', at: 2 }] } };
  const r1 = archiveDreams(fakeDb({}, cap), st, { cfg: DEFAULTS, now: 5 });
  ok('Q5-4 未超 softLimit 不归档（skipped）', r1.skipped === true && r1.archived === 0, r1);
  ok('Q5-5 未归档时 dreamLog 原样保留', st.sleep.dreamLog.length === 2, st.sleep.dreamLog.length);
  const r2 = archiveDreams(fakeDb({}, cap), st, { cfg: DEFAULTS, now: 5, force: true });
  ok('Q5-6 force 时逐条搬运', r2.archived === 2 && cap.length === 2, { r2, n: cap.length });
  ok('Q5-7 搬运后清空 dreamLog', st.sleep.dreamLog.length === 0, st.sleep.dreamLog.length);
  ok('Q5-8 落库 SQL 指向 dreams 表', /INSERT INTO dreams/.test(cap[0]?.sql || ''), cap[0]?.sql?.slice(0, 40));
}

console.log('\n== Q2  睡眠窗口：quietHours 推导 + 可覆盖 ==');
{
  ok('Q2-1 auto 取 quietHours', JSON.stringify(sleepWindow(DEFAULTS)) === JSON.stringify(DEFAULTS.quietHours),
    sleepWindow(DEFAULTS));
  const explicit = { ...DEFAULTS, sleep: { ...DEFAULTS.sleep, window: { start: 1, end: 5 } } };
  ok('Q2-2 显式 window 覆盖 quietHours', JSON.stringify(sleepWindow(explicit)) === '[1,5]', sleepWindow(explicit));
  const at = (h) => new Date(2026, 0, 1, h, 0, 0).getTime();
  ok('Q2-3 23 点在窗口内', inSleepWindow(at(23), { ...DEFAULTS, quietHours: [23, 8] }) === true);
  ok('Q2-4 12 点不在窗口内', inSleepWindow(at(12), { ...DEFAULTS, quietHours: [23, 8] }) === false);
  ok('Q2-5 跨零点窗口正确（1 点）', inSleepWindow(at(1), explicit) === true);
  ok('Q2-6 跨零点窗口正确（6 点）', inSleepWindow(at(6), explicit) === false);
}

console.log('\n== Q3  睡眠回复三级 ==');
{
  const cfg = DEFAULTS;
  const owner = '10001';
  ok('Q3-1 群聊 → drop',
    classifySleepReply({ userText: '在吗', scope: 'group:123', ownerQq: owner, cfg }) === 'drop');
  ok('Q3-2 他人私聊 → drop',
    classifySleepReply({ userText: '在吗', scope: 'private:20002', ownerQq: owner, cfg }) === 'drop');
  ok('Q3-3 主人普通消息 → queue',
    classifySleepReply({ userText: '今天好累', scope: `private:${owner}`, ownerQq: owner, cfg }) === 'queue');
  ok('Q3-4 主人 + 紧急词 → reply-short',
    classifySleepReply({ userText: '我发烧了', scope: `private:${owner}`, ownerQq: owner, cfg }) === 'reply-short');
  ok('Q3-5 紧急词「医院」命中',
    classifySleepReply({ userText: '去医院了', scope: `private:${owner}`, ownerQq: owner, cfg }) === 'reply-short');
  ok('Q3-6 短回复文案来自配置', sleepShortReply(cfg) === cfg.sleep.shortReply, sleepShortReply(cfg));
  ok('Q3-7 无 ownerQq 时按 private: 前缀判主', classifySleepReply({ userText: '急', scope: 'private:1', ownerQq: null, cfg }) === 'reply-short');
}

console.log('\n== Q4  发送回执只由宿主写 ==');
{
  const idx = src('src/index.mjs');
  ok('Q4-1 只有一处把 status 写成 sent', one(/status\s*=\s*'sent'/g, idx) === 1, one(/status\s*=\s*'sent'/g, idx));
  ok('Q4-2 该处属于 life_mark_sent', /name: 'life_mark_sent'/.test(idx));
  ok('Q4-3 插件侧没有「伪造已发送」的分支', !/sent:\s*true/.test(idx.split("name: 'life_mark_sent'")[0]));
}

console.log('\n== Q6  BM25 不进主公式 ==');
{
  const base = 0.6, eff = 0.8, cov = 0.5, route = 0.04;
  const got = retrievalScore({ base, eff, coverage: cov, routeBoost: route });
  const want = 0.60 * base + 0.20 * eff + 0.15 * cov + route;
  ok('Q6-1 主公式仍是 0.60/0.20/0.15', Math.abs(got - want) < 1e-9, { got, want });
  const w = src('src/memory/weight.mjs');
  ok('Q6-2 公式里没有 bm25 项', !/retrievalScore[\s\S]{0,200}bm25/i.test(w));
}

console.log('\n== Q7  4 项高风险默认 shadow ==');
{
  for (const cap of ['autoExtract', 'beliefPool', 'imprint', 'rerank']) {
    ok(`Q7 默认 shadow: ${cap}`, DEFAULTS.capabilities[cap] === 'shadow', DEFAULTS.capabilities[cap]);
    ok(`Q7 判定为 shadow: ${cap}`, v14Mode(DEFAULTS, cap) === 'shadow', v14Mode(DEFAULTS, cap));
  }
  const on = { capabilities: { ...DEFAULTS.capabilities, autoExtract: true } };
  ok('Q7 显式 true 仍可开', v14Mode(on, 'autoExtract') === 'on');
  const gate = { capabilities: { ...DEFAULTS.capabilities, v14: false } };
  ok('Q7 总闸关优先', v14Mode(gate, 'autoExtract') === 'off');
}

console.log('\n== Q8  人格 diff：只出候选，owner 终审 ==');
{
  const rows = [
    { id: 11, category: 'preference', fact: '不喜欢被叫全名', attr_key: 'nick', attr_value: '阿野', importance: 0.9, source_kind: 'user' },
    { id: 12, category: 'person', fact: '主人的猫叫团子', attr_key: null, attr_value: null, importance: 0.8, source_kind: 'self' },
    { id: 13, category: 'preference', fact: '推断出来的偏好', attr_key: 'x', attr_value: 'y', importance: 0.95, source_kind: 'inferred' },
  ];
  const cap = [];
  const db = fakeDb({ all: () => rows, get: (sql) => (sql.includes('FROM life_events') ? null : null) }, cap);
  const d = buildPersonaDiff(db, { cfg: DEFAULTS, now: 1000 });
  ok('Q8-1 生成 diff 成功', d.ok === true && !!d.eventId, d);
  ok('Q8-2 只收 owner/self 来源（inferred 被排除）', d.items.every((i) => i.memoryId !== 13), d.items.map((i) => i.memoryId));
  ok('Q8-3 首次全部是 add', d.added === 2 && d.changed === 0, d);
  ok('Q8-4 只写 life_events，不写 memories', cap.every((c) => /life_events/.test(c.sql)), cap.map((c) => c.sql.slice(0, 30)));
  // apply：拿同一 db 写入 kv
  const cap2 = [];
  const db2 = fakeDb({
    get: (sql) => (sql.includes('FROM life_events') ? { event_json: JSON.stringify({ items: d.items, removed: [] }) } : null),
  }, cap2);
  const a = applyPersonaDiff(db2, d.eventId, { cfg: DEFAULTS, now: 2000 });
  ok('Q8-5 owner apply 才落快照', a.ok === true && a.keys === 2, a);
  ok('Q8-6 apply 写 kv 与审计', cap2.some((c) => /kv/.test(c.sql)) && cap2.some((c) => /persona:applied/.test(String(c.args))), cap2.length);
  ok('Q8-7 未 apply 前快照为空', Object.keys(personaSnapshot(fakeDb({ get: () => null }))).length === 0);
}

console.log('\n== Q9  raw 只允许 owner 私聊 ==');
{
  const mem = { id: 7, scope: 'private:10001', fact: '精简事实', raw: '完整原话全文', category: 'fact', tags: '[]', importance: 0.5 };
  const db = fakeDb({ memory: mem });
  const blocked = recallDetail(db, 7, { scopes: ['private:10001'], includeRaw: true, allowRaw: false });
  ok('Q9-1 非 owner 场景不给 raw', blocked.raw === undefined, blocked.raw);
  ok('Q9-2 显式标记被拒', blocked.rawDenied === true, blocked.rawDenied);
  const allowed = recallDetail(db, 7, { scopes: ['private:10001'], includeRaw: true, allowRaw: true });
  ok('Q9-3 owner 场景给 raw', typeof allowed.raw === 'string' && allowed.raw.length > 0, allowed.raw);
  ok('Q9-4 默认 allowRaw=true 保持旧行为', recallDetail(db, 7, { includeRaw: true }).raw === '完整原话全文');
}

console.log(`\n== P5 合计：PASS ${pass} / FAIL ${fail} ==`);
if (fail) { console.log('failed:', failures.join(', ')); process.exit(1); }
