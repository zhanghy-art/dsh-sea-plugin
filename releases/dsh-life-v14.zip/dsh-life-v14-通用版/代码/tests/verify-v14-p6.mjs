#!/usr/bin/env node
// tests/verify-v14-p6.mjs — 交付补丁 01 的回归断言（U5：盖章行最长保留 180 天）
//
// 背景：WorkBuddy 终版 U5.2 实测指出 v14 的 runNightly 会把
//   source_kind='owner'、年纪很老的盖章行删掉，违反主人 2026-10-26 定的规矩
//   「涉及不可逆删除必须先出清单给他看、他同意了才执行」。
// 本套件既验证「owner 原话受保护」，也验证「非 owner 的超龄盖章行仍按 180 天清理」，
// 防止把补丁写成「一律不删」（那会与 v14 自带 cross2 AC2 冲突、让库无限膨胀）。

import { DatabaseSync } from 'node:sqlite';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { DEFAULTS } from '../src/kit/config.mjs';
import { runNightly } from '../src/maintenance/nightly.mjs';

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..');
let pass = 0, fail = 0;
const ok = (id, cond, got) => {
  if (cond) { pass++; console.log(`  PASS ${id}`); }
  else { fail++; console.log(`  FAIL ${id} got=${JSON.stringify(got)}`); }
};

const mk = () => {
  const db = new DatabaseSync(':memory:');
  db.exec(readFileSync(join(ROOT, 'schema.sql'), 'utf8'));
  return db;
};

const now = Date.now();
{
  const db = mk();
  // 四个盖章场景：旧+owner / 旧+非owner / 新+非owner / 无时间列
  db.prepare(`INSERT INTO memories(id,scope,category,fact,invalid_reason,source_kind,created_at_ms)
    VALUES (1,'s','c','A','conflict','owner',${now - 200 * 86400000})`).run();
  db.prepare(`INSERT INTO memories(id,scope,category,fact,invalid_reason,source_kind,created_at_ms)
    VALUES (2,'s','c','B','manual','bot',${now - 200 * 86400000})`).run();
  db.prepare(`INSERT INTO memories(id,scope,category,fact,invalid_reason,source_kind,created_at_ms)
    VALUES (3,'s','c','C','expired','bot',${now - 10 * 86400000})`).run();
  db.prepare(`INSERT INTO memories(id,scope,category,fact,invalid_reason,source_kind,created_at_ms)
    VALUES (4,'s','c','D','conflict','bot',NULL)`).run();

  const r = runNightly(db, { now, cfg: DEFAULTS, force: true });
  const alive = db.prepare('SELECT id FROM memories ORDER BY id').all().map((x) => x.id);
  ok('P6-1 旧+非owner 被清（180 天剪除仍生效）', !alive.includes(2), alive);
  ok('P6-2 旧+owner 原话保留（补丁核心）', alive.includes(1), alive);
  ok('P6-3 新+非owner 保留', alive.includes(3), alive);
  ok('P6-4 无时间列保留', alive.includes(4), alive);
  ok('P6-5 report.stampsPruned = 1', r.stampsPruned === 1, r.stampsPruned);
  ok('P6-6 report.stampsKept 可出清单给主人过目', r.stampsKept === 3, r.stampsKept);
  ok('P6-7 被清的行仍留归档副本', !!db.prepare('SELECT id FROM memories_archive WHERE id=2').get(), null);
  db.close();
}

{
  const db = mk();
  // 边界：明确盖章作废很久（valid_to_ms 很老）的 owner 行，仍按 180 天清理
  db.prepare(`INSERT INTO memories(id,scope,category,fact,invalid_reason,source_kind,created_at_ms,valid_to_ms,cold)
    VALUES (5,'s','c','E','manual','owner',${now - 200 * 86400000},${now - 200 * 86400000},1)`).run();
  const r = runNightly(db, { now, cfg: DEFAULTS, force: true });
  ok('P6-8 已明确作废超 180 天的 owner 行仍可清（不与 cross2 AC2 冲突）',
    !db.prepare('SELECT id FROM memories WHERE id=5').get(), r);
  db.close();
}

console.log(`\n== P6 合计：PASS ${pass} / FAIL ${fail} ==`);
if (fail) process.exit(1);
