#!/usr/bin/env node
// tests/verify13.mjs — v13.0 收敛断言（T61–T80，20 项）
// 主题：升级安全默认值、标度边界、speakWeight 软化、tier 策略对照、core 双路径
import { DEFAULTS } from '../src/kit/config.mjs';
import { compareTierStrategies, coreEligible } from '../src/memory/weight.mjs';
import { h01, hDisplay, nDisplay, nFromDisplay, assertUnitConsistent, HORMONE_SCALE } from '../src/kit/units.mjs';
import { speakWeight, speakBonus, canSpeak, utilityWithSpeak } from '../src/action/speak.mjs';
import { stabilityDays } from '../src/memory/fsrs.mjs';
import { SessionLifecycle } from '../src/session/lifecycle.mjs';

let pass = 0, fail = 0;
const failures = [];
const ok = (id, cond, got) => {
  if (cond) { pass++; console.log(`  PASS ${id}`); }
  else { fail++; failures.push(id); console.log(`  FAIL ${id}  got=${JSON.stringify(got)}`); }
};
const near = (a, b, eps = 1e-6) => Math.abs(a - b) <= eps;

console.log('\n== V. 升级安全默认值（D7）==');
{
  ok('T61 默认不自动归档', DEFAULTS.capabilities.autoArchive === false);
  ok('T62 archiveTurns 默认 0', DEFAULTS.lifecycle.archiveTurns === 0);
  ok('T63 关键词分舱默认开', DEFAULTS.capabilities.routeKeyword === true);
  ok('T64 质心分舱默认关', DEFAULTS.capabilities.routeCentroid === false);
  const lc = new SessionLifecycle(null, { cfg: DEFAULTS, root: '/tmp/none' });
  lc.turns = 999;
  ok('T65 关着的时候怎么都不清空', lc.shouldArchive(0.99) === false);
  const on = { ...DEFAULTS, capabilities: { ...DEFAULTS.capabilities, autoArchive: true }, lifecycle: { ...DEFAULTS.lifecycle, archiveTurns: 20 } };
  const lc2 = new SessionLifecycle(null, { cfg: on, root: '/tmp/none' });
  lc2.turns = 20;
  ok('T66 开了之后 20 轮生效', lc2.shouldArchive(0.1) === true);
}

console.log('\n== W. 标度边界（不再混用 0–1 与 0–100）==');
{
  ok('T67-a 激素 0–1 归一化', near(h01(30), 0.3) && near(h01(100), 1));
  ok('T67-b 面板显示整数', hDisplay(32.6) === 33 && nDisplay(0.71) === 71);
  ok('T67-c 面板输入回 0–1', near(nFromDisplay(71), 0.71));
  ok('T67-d 越界即抛（防百倍误差）', (() => { try { assertUnitConsistent('energy', 71, 'need'); return false; } catch { return true; } })());
  ok('T67-e 合法值放行', assertUnitConsistent('cortisol', 32.6, 'hormone') === 32.6);
  ok('T67-f 常量', HORMONE_SCALE === 100);
}

console.log('\n== X. speakWeight 软化（从硬闸降为加项）==');
{
  ok('T68-a 低六维 → 零加成但不禁言', speakBonus({ social: 0.1, rest: 0.1 }) === 0 && canSpeak({ social: 0.1, rest: 0.1 }).soft === true);
  ok('T68-b 高六维 → 有加成', speakBonus({ social: 0.9, rest: 0.9 }) > 0);
  ok('T68-c 加成封顶 0.12', speakBonus({ social: 1, rest: 1 }) <= 0.1201);
  ok('T68-d utility 合成不越界', utilityWithSpeak(0.95, { social: 1, rest: 1 }) <= 1);
  ok('T68-e 硬闸模式仍可开', canSpeak({ social: 0.1, rest: 0.1 }, { ...DEFAULTS, speak: { ...DEFAULTS.speak, hardGate: true } }).ok === false);
  ok('T68-f 单调性', speakBonus({ social: 0.8, rest: 0.8 }) > speakBonus({ social: 0.5, rest: 0.5 }));
}

console.log('\n== Y. core 双路径 ==');
{
  const now = Date.now();
  const base = { category: 'person', audit_status: 'ok', created_at: now - 30 * 86400000, importance: 0.8, belief: 0.9 };
  ok('T69-a belief 路径', coreEligible(base, { independentEvidence: 2, now }).path === 'belief');
  ok('T69-b importance 路径', coreEligible({ ...base, belief: 0.7, importance: 0.95 }, { independentEvidence: 2, now }).path === 'importance');
  ok('T69-c 两条都不满足则拒', coreEligible({ ...base, belief: 0.8, importance: 0.8 }, { independentEvidence: 2, now }).ok === false);
  ok('T69-d importance 路径也要双证据', coreEligible({ ...base, belief: 0.7, importance: 0.95 }, { independentEvidence: 1, now }).ok === false);
}

console.log('\n== Z. tier 策略对照（为什么不用 ×3.0）==');
{
  const now = Date.now();
  const mem = { category: 'fact', importance: 0.6, emotional_salience: 0, relationship_salience: 0, confirmed_at: now - 100 * 86400000 };
  const r = compareTierStrategies(mem, now);
  ok('T70-a 乘数方案在此饱和到 1.0', near(r.theirs, 1), r);
  ok('T70-b 半衰期方案保留梯度（<1）', r.ours < 0.999 && r.ours > 0.8, r.ours);
  const strong = { ...mem, importance: 0.95, emotional_salience: 0.9 };
  const r2 = compareTierStrategies(strong, now);
  ok('T70-c 乘数方案无法区分“重要”与“极重要”（都撞 1）', near(r.theirs, 1) && near(r2.theirs, 1));
  ok('T70-d 半衰期方案仍能区分', r2.ours > r.ours);
}

console.log('\n== AA. FSRS 边界 ==');
{
  ok('T71 0 次命中 stability=1 天', stabilityDays(0) === 1);
  ok('T72 封顶 180', stabilityDays(30) === 180);
  ok('T73 单调递增', stabilityDays(3) > stabilityDays(2));
}

console.log(`\n结果（v13.0 收敛）：PASS ${pass} / FAIL ${fail}`);
if (fail) { console.log('失败项：' + failures.join(', ')); process.exit(1); }
