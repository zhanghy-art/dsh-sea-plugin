#!/usr/bin/env node
// 补丁 01 的独立验证脚本（可移植版）
//
// 用法（在本文件所在目录执行即可，无需任何绝对路径）：
//   node 验证-U5.mjs
//
// 它按相对路径找交付包里的 `代码/`：本文件位于
//   <包>/解决方案/补丁01-夜间剪除保护owner原话/验证-U5.mjs
// 所以 `../../代码` 就是交付代码根目录。
// 需要 Node >= 22.5（node:sqlite）；不依赖任何第三方包。
//
// 验证内容：WorkBuddy 交付稿里的 U5 五条断言 + stampsKept 计数。
// 期望输出：6 条全 PASS，幸存 id = [1,3,4]。

import { DatabaseSync } from 'node:sqlite';
import { readFileSync } from 'node:fs';
import { fileURLToPath, pathToFileURL } from 'node:url';
import path from 'node:path';

const here = path.dirname(fileURLToPath(import.meta.url));
const codeRoot = path.resolve(here, '..', '..', '代码');
const url = p => pathToFileURL(path.join(codeRoot, p)).href;

const { runNightly } = await import(url('src/maintenance/nightly.mjs'));
const { DEFAULTS } = await import(url('src/kit/config.mjs'));

const now = Date.now();
const db = new DatabaseSync(':memory:');
db.exec(readFileSync(path.join(codeRoot, 'schema.sql'), 'utf8'));

const ins = (id, reason, kind, ms) => db.prepare(
  `INSERT INTO memories(id,scope,category,fact,invalid_reason,source_kind,created_at_ms)
   VALUES (?,?,?,?,?,?,?)`
).run(id, 's', 'c', 'X' + id, reason, kind, ms);

ins(1, 'conflict', 'owner', now - 200 * 86400000); // 旧 + 主人原话 → 必须保留
ins(2, 'manual', 'bot',   now - 200 * 86400000); // 旧 + 非主人   → 应被清
ins(3, 'expired', 'bot',  now - 10 * 86400000);  // 新           → 保留
ins(4, 'conflict', 'bot', null);                  // 无时间列     → 保留

const r = runNightly(db, { now, cfg: DEFAULTS, force: true });
const alive = db.prepare('SELECT id FROM memories ORDER BY id').all().map(x => x.id);

console.log('stampsPruned =', r.stampsPruned, ' stampsKept =', r.stampsKept, ' archive =', r.archive);
console.log('幸存 id =', JSON.stringify(alive));

const checks = [
  ['U5.1 旧+非owner 被清', !alive.includes(2)],
  ['U5.2 旧+owner 保留', alive.includes(1)],
  ['U5.3 新+非owner 保留', alive.includes(3)],
  ['U5.4 无时间列保留', alive.includes(4)],
  ['U5.5 stampsPurged=1', r.stampsPruned === 1],
  ['stampsKept=3 (id=2 已清)', r.stampsKept === 3],
];
let fail = 0;
for (const [n, ok] of checks) { console.log((ok ? 'PASS' : 'FAIL'), n); if (!ok) fail++; }
db.close();
process.exit(fail ? 1 : 0);
