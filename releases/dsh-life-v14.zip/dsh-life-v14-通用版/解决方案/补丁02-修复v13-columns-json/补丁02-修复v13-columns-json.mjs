#!/usr/bin/env node
// 补丁 02：修复「v13 运行目录 migrations/columns.json 被改坏」导致插件起不来的问题
//
// 症状（实测）：
//   <插件目录>/dsh-life-v13/src/kit/db.mjs:194 执行
//     db.exec(`ALTER TABLE memories ADD COLUMN ${c.name} ${c.def}`)
//   时抛 Error: duplicate column name: undefined（errcode 1 / SQL logic error），
//   ready-fail 后降级到 3 个工具，v13 在这台机器上一直没真正跑起来。
//
// 根因（实测）：
//   运行目录那份 columns.json 的 `columns` 数组有 33 条，最后 4 条是
//     {"table":"reflexes","column":"subject_qq","def":"TEXT"}
//     {"table":"reflexes","column":"response","def":"TEXT"}
//     {"table":"reflexes","column":"fire_count","def":"INTEGER DEFAULT 0"}
//     {"table":"memories_archive","column":"payload","def":"TEXT"}
//   它们是「给别的表补列」的条目，本该放在 `table_column_patches`，
//   却被误塞进 `columns`（只有 table/column/def，没有 name）。
//   db.mjs:127 `plan.columns.filter(c => !memCols.has(c.name))` 取到 undefined，
//   拼出 `ADD COLUMN undefined ...`。
//   zip 原版 v13/migrations/columns.json 是 29 条、0 条无 name —— 对照证明是运行目录被改坏。
//
// 修法（幂等、可逆、不删任何有效配置）：
//   把这 4 条从 columns 移到 table_column_patches（按 table+column 去重），
//   columns 回到 29 条，每条都有 name。原本就合理的 `reflexes.scope` 补丁保留。
//
// 用法：
//   node 补丁02-修复v13-columns-json.mjs <目标 columns.json 路径> [--dry-run]
//   不加 --dry-run 才真正写回；写回前会先把原文件复制成 .bak-<时间戳>。
//
// 重要：本脚本只改你显式传入的那一份文件。它不会碰运行环境、不会碰 brain.sqlite。
//   要不要应用到 <插件目录>/dsh-life-v13/ 由你自己决定。

import { readFileSync, writeFileSync, copyFileSync, existsSync } from 'node:fs';

const target = process.argv[2];
const dry = process.argv.includes('--dry-run');
if (!target) {
  console.error('用法: node 补丁02-修复v13-columns-json.mjs <目标 columns.json> [--dry-run]');
  process.exit(2);
}
if (!existsSync(target)) {
  console.error('找不到文件:', target);
  process.exit(2);
}

const raw = readFileSync(target, 'utf8');
const plan = JSON.parse(raw);
const before = {
  columns: (plan.columns || []).length,
  patches: (plan.table_column_patches || []).length,
  noName: (plan.columns || []).filter((c) => !('name' in c)).length,
};

// 把误塞的条目从 columns 里挑出来
const misplaced = (plan.columns || []).filter((c) => !('name' in c) && c.table && c.column && c.def);
const kept = (plan.columns || []).filter((c) => 'name' in c);

// 转进 patches，按 table+column 去重（已存在就跳过，绝不重复添加）
const patches = (plan.table_column_patches || []).slice();
const seen = new Set(patches.map((p) => `${p.table}\u0000${p.column}`));
const added = [];
for (const c of misplaced) {
  const key = `${c.table}\u0000${c.column}`;
  if (seen.has(key)) continue;
  patches.push({ table: c.table, column: c.column, def: c.def });
  seen.add(key);
  added.push(`${c.table}.${c.column}`);
}

const after = { columns: kept.length, patches: patches.length, noName: 0 };
console.log('修复前:', JSON.stringify(before));
console.log('误塞条目:', JSON.stringify(misplaced, null, 2));
console.log('转入 patches:', JSON.stringify(added));
console.log('修复后:', JSON.stringify(after));

if (dry) {
  console.log('\n--dry-run：未写回任何文件。');
  process.exit(0);
}
if (misplaced.length === 0) {
  console.log('\n没有需要修复的条目（幂等 no-op），未改文件。');
  process.exit(0);
}

const bak = `${target}.bak-${new Date().toISOString().replace(/[:.]/g, '-')}`;
copyFileSync(target, bak);
console.log('\n已备份原文件 ->', bak);

plan.columns = kept;
plan.table_column_patches = patches;
writeFileSync(target, JSON.stringify(plan, null, 2) + '\n', 'utf8');
console.log('已写回 ->', target);
console.log('请重新跑一次本脚本确认幂等（应输出「没有需要修复的条目」）。');
