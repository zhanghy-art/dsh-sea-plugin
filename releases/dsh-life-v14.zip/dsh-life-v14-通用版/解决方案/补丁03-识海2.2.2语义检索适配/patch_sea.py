# -*- coding: utf-8 -*-
"""把对识海 2.2.1 的 6 处改造重新落到 2.2.2 原版上（可移植版）。

用法：
    python patch_sea.py <2.2.2副本的sea目录> <已改造的2.2.1参照版sea目录>

  · 第 1 个参数 = 待打补丁的 2.2.2 原版副本（脚本会就地修改它的三个文件）
  · 第 2 个参数 = 已含语义检索实现的参照版 sea 目录（只读取，用于搬运语义段/路由段）
  · 两个参数都必须是实际存在的目录，脚本不写死任何本机绝对路径
  · 脚本自带锚点校验：缺失或重复都会直接 SystemExit，不会瞎改

示例（目录名仅示意，请换成你自己的）：
    python patch_sea.py ./dsh-sea-2.2.2/sea ./dsh-sea-2.2.1-patched/sea
"""
import io, os, re, sys

if len(sys.argv) != 3:
    raise SystemExit("用法: python patch_sea.py <2.2.2副本sea目录> <2.2.1参照版sea目录>")
BASE = sys.argv[1]   # 待打补丁的 2.2.2 副本
SRC  = sys.argv[2]   # 已改造的参照版（语义检索来源）
for _p in (BASE, SRC):
    if not os.path.isdir(_p):
        raise SystemExit("目录不存在: " + _p)

def read(p):
    with io.open(p, "r", encoding="utf-8", newline="") as f:
        return f.read()

def write(p, s):
    with io.open(p, "w", encoding="utf-8", newline="") as f:
        f.write(s)

def sub_once(text, old, new, tag):
    if old not in text:
        raise SystemExit("锚点未命中: " + tag)
    if text.count(old) != 1:
        raise SystemExit("锚点重复(%d): %s" % (text.count(old), tag))
    return text.replace(old, new, 1)

# ── 1. db-adapter.mjs ───────────────────────────────────────────
p = os.path.join(BASE, "db-adapter.mjs")
t = read(p)

t = sub_once(t,
    "  const hasTable = t => cols(t).length > 0;\n",
    "  const hasTable = t => cols(t).length > 0;\n"
    "  /** 列声明类型（用来判断一列到底是不是 TEXT —— 光看列名会误判） */\n"
    "  const colType = (t, name) => {\n"
    "    try {\n"
    "      const r = db.prepare(`PRAGMA table_info(\"${t}\")`).all().find(x => String(x.name) === String(name));\n"
    "      return r ? String(r.type || '').toUpperCase() : '';\n"
    "    } catch { return ''; }\n"
    "  };\n",
    "db-adapter colType")

t = sub_once(t,
    "    const cRaw = pick(T, 'raw', 'is_raw');\n",
    "    const cRaw = pick(T, 'raw', 'is_raw');\n"
    "    // 本库用 status 区分 active / archived / conflicted / superseded。\n"
    "    // 不过滤的话，已经归档的记忆照样会被画成星点 —— 识海看着满，其实一半是坟。\n"
    "    const cStatus = pick(T, 'status');\n",
    "db-adapter cStatus")

t = sub_once(t,
    "    if (cRaw) where.push(`(${cRaw} IS NULL OR ${cRaw} = 0)`);\n",
    "    // 原来无条件按「raw 是 0/1 标志位」过滤。v13 迁移给 memories 加了 raw 列，\n"
    "    // 语义是「用户原话」（TEXT），一过滤就全被剔掉 —— 识海会变成 0 条、面板全空。\n"
    "    if (cRaw && !/TEXT|CHAR|CLOB/.test(colType(T, cRaw))) where.push(`(${cRaw} IS NULL OR ${cRaw} = 0)`);\n"
    "    if (cStatus) where.push(`(${cStatus} IS NULL OR ${cStatus} = 'active')`);\n",
    "db-adapter raw/status where")

t = sub_once(t,
    "    try { return Number(db.prepare('SELECT count(*) AS c FROM memories').get().c) || 0; }\n",
    "    try {\n"
    "      const cStatus = pick('memories', 'status');\n"
    "      const w = cStatus ? ` WHERE (${cStatus} IS NULL OR ${cStatus} = 'active')` : '';\n"
    "      return Number(db.prepare(`SELECT count(*) AS c FROM memories${w}`).get().c) || 0;\n"
    "    }\n",
    "db-adapter total")

t = sub_once(t,
    "              ...(s.hormones || {}),\n",
    "              // v13 起激素存的是 0–1（JSON 里的 hormones），而面板/前端统一按 0–100 渲染；\n"
    "              // 不换算的话 0.239 会被 Math.round 成 0，看上去就像「激素全没更新」。\n"
    "              ...h100,\n",
    "db-adapter h100 spread")

# h100 的定义要插在 return { 之前
anchor = "            const s = typeof row.j === 'string' ? JSON.parse(row.j) : row.j;\n            return {\n"
t = sub_once(t, anchor,
    "            const s = typeof row.j === 'string' ? JSON.parse(row.j) : row.j;\n"
    "            const rawH = s.hormones || {};\n"
    "            const h100 = {};\n"
    "            for (const k of ['cortisol', 'dopamine', 'oxytocin', 'serotonin']) {\n"
    "              const v = Number(rawH[k]);\n"
    "              if (Number.isFinite(v)) h100[k] = v <= 1.5 ? Math.round(v * 1000) / 10 : v;\n"
    "            }\n"
    "            return {\n",
    "db-adapter h100 def")

write(p, t)
print("OK db-adapter.mjs")

# ── 2. sea-server.mjs ───────────────────────────────────────────
src_srv = read(os.path.join(SRC, "sea-server.mjs"))
lines = src_srv.split("\n")
# 332..459 是语义检索整段（1-based，含注释头到 HTTP 段之前）
start = next(i for i, l in enumerate(lines) if l.startswith("// ── 语义检索：bge-m3"))
end   = next(i for i, l in enumerate(lines) if l.startswith("// ── HTTP ──"))
semantic_block = "\n".join(lines[start:end]).rstrip() + "\n"
# 路由段：从「  // 语义检索（按意思找」到该 if 块结束的「  }」+ 空行
r_start = next(i for i, l in enumerate(lines) if "// 语义检索（按意思找" in l)
r_end   = next(i for i, l in enumerate(lines) if l.strip() == "if (p === '/api/sea/semantic') {")
depth = 0
j = r_end
while True:
    depth += lines[j].count("{") - lines[j].count("}")
    if depth == 0:
        break
    j += 1
route_block = "\n".join(lines[r_start:j + 1]).rstrip() + "\n"
print("语义段行数=%d  路由段行数=%d" % (semantic_block.count("\n"), route_block.count("\n")))

p = os.path.join(BASE, "sea-server.mjs")
t = read(p)

t = sub_once(t,
    "// ── HTTP ───────────────────────────────────────────────────────\n",
    semantic_block + "\n// ── HTTP ───────────────────────────────────────────────────────\n",
    "server semantic block")

t = sub_once(t,
    "  if (p === '/api/sea/search') {\n"
    "    const q = (url.searchParams.get('q') || '').trim();\n"
    "    const nodes = queryNodes(100000).filter(n => q && n.fact.includes(q));\n"
    "    return json(res, { nodes });\n"
    "  }\n\n",
    "  if (p === '/api/sea/search') {\n"
    "    const q = (url.searchParams.get('q') || '').trim();\n"
    "    const nodes = queryNodes(100000).filter(n => q && n.fact.includes(q));\n"
    "    return json(res, { nodes });\n"
    "  }\n\n" + route_block + "\n",
    "server semantic route")

t = sub_once(t,
    "  if (p === '/api/why') {\n"
    "    const id = Number(url.searchParams.get('id'));\n"
    "    const n = queryNodes(100000).find(x => x.id === id);\n",
    "  if (p === '/api/why') {\n"
    "    // 本库主键是 TEXT（mem_20261026_038），Number() 会变 NaN 永远查不到\n"
    "    const idRaw = (url.searchParams.get('id') || '').trim();\n"
    "    const id = Number.isNaN(Number(idRaw)) ? idRaw : Number(idRaw);\n"
    "    const n = queryNodes(100000).find(x => String(x.id) === String(id));\n",
    "server why id")

write(p, t)
print("OK sea-server.mjs")

# ── 3. neural-sea.html ──────────────────────────────────────────
p = os.path.join(BASE, "neural-sea.html")
t = read(p)

t = sub_once(t,
    "const NEEDCN = { social: '社交', curiosity: '好奇', play: '玩乐',\n"
    "  achievement: '成就', recognition: '认可', rest: '休息' };\n",
    "// v13 的 needs 实际是这六项（social/curiosity/rest/mood/closeness/energy）。\n"
    "// 旧版写的 play/achievement/recognition 在 v13 里没有对应字段，\n"
    "// 用它们取值永远是 undefined → 图上六维全 0，看着像「没更新」。\n"
    "const NEEDCN = { social: '社交', curiosity: '好奇', mood: '心情',\n"
    "  closeness: '亲密', energy: '精力', rest: '休息' };\n",
    "html NEEDCN")

n = t.count("n.fact.includes(q)")
if n != 4:
    raise SystemExit("includes 出现 %d 次，期望 4" % n)
t = t.replace("if (q && !n.fact.includes(q)) continue;", "if (q && !isHit(n, q)) continue;")
t = t.replace("|| (q && n.fact.includes(q));", "|| isHit(n, q);")
t = t.replace("const hit = q && n.fact.includes(q);", "const hit = isHit(n, q);")
t = t.replace("!n.valid_to && n.fact.includes(q)", "!n.valid_to && isHit(n, q)")
assert "n.fact.includes(q)" not in t, "还有残留 includes"

# S.sem 状态位
t = sub_once(t, "  hover: null, sel: null, query: '', dragNode: null, energy: 0,",
    "  hover: null, sel: null, query: '', dragNode: null, energy: 0,\n"
    "  sem: null,                 // 语义命中：Map(String(id) → 余弦)，由 loadSemantic 填",
    "html S.sem")

# focusHits 换成 isHit / loadSemantic / 异步 focusHits
old_focus = ("function focusHits(q) {\n"
             "  if (!q || q.length < 1) return;\n"
             "  const hits = S.nodes.filter(n => !n.valid_to && isHit(n, q));\n")
new_focus = (
    "// 一次命中判断：字面（includes）∪ 语义（后端 bge-m3 余弦）\n"
    "// 只靠字面时，「那个香喷喷的米饭」永远找不到「蛋炒饭」。\n"
    "function isHit(n, q) {\n"
    "  if (!q) return false;\n"
    "  if (n.fact.includes(q)) return true;\n"
    "  return !!(S.sem && S.sem.has(String(n.id)));\n"
    "}\n\n"
    "async function loadSemantic(q) {\n"
    "  // minSim=0.45 是工程折中：bge-m3 在中文短句上的余弦普遍偏高（不相关也常有 0.5），\n"
    "  // 阈值取太高会漏掉「香喷喷的米饭 → 蛋炒饭」这种换了说法的命中，取太低又满屏亮。\n"
    "  const r = await fetch('/api/sea/semantic?q=' + encodeURIComponent(q) + '&k=20&minSim=0.45', { cache: 'no-store' });\n"
    "  const d = await r.json();\n"
    "  if (!d.ok) throw new Error(d.error || 'semantic failed');\n"
    "  const m = new Map();\n"
    "  for (const it of (d.items || [])) m.set(String(it.id), it.sim);\n"
    "  return m;\n"
    "}\n\n"
    "async function focusHits(q) {\n"
    "  if (!q || q.length < 1) return;\n"
    "  if (q.length >= 2) {\n"
    "    try {\n"
    "      const sem = await loadSemantic(q);\n"
    "      if (S.query.trim() !== q) return;   // 输入已经变了，丢掉这次结果\n"
    "      S.sem = sem;\n"
    "    } catch (e) {\n"
    "      S.sem = null;                      // 语义挂了就只按字面，不报错打断\n"
    "    }\n"
    "  } else {\n"
    "    S.sem = null;                        // 单字没必要调向量，太贵也太宽\n"
    "  }\n"
    "  const hits = S.nodes.filter(n => !n.valid_to && isHit(n, q));\n")
t = sub_once(t, old_focus, new_focus, "html focusHits->async")

# 输入框清空时同步清掉语义命中（2.2.2 没有 clearFocus，是内联的 S.hits = null）
t = sub_once(t, "  S.query = e.target.value.trim();\n  S.hits = null;\n",
    "  S.query = e.target.value.trim();\n  S.hits = null;\n  S.sem = null;\n",
    "html clear sem")

write(p, t)
print("OK neural-sea.html (includes→isHit + sem)")
