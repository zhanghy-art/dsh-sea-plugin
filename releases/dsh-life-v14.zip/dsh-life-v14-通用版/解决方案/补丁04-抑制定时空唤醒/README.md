# 补丁04：抑制定时空唤醒

> 一句话：**设了「几点醒」的闹钟，就不该在到点之前被 replyCheck 拉一次、被主动机会拉一次——每次都是一整轮上下文，一条消息没发，token 照烧。**
> 这个补丁只改 qq-bridge，不动 dsh-life 插件。

## 1. 问题（主人原话，2026-11-06）

> 「她每次会给自己设置个到几点醒的闹钟，但是现版本总是莫名其妙让她提前起来，比如说要六点起，但是她在三点到六点一直被唤醒，虽然没发消息，但是依然消耗很大。」

> 「而且我说的3-6点不是只让你做3-6点，是**只要我休息或忙的时候都算**」

> 「说了很多次了3-6点只是举例不是让你写进去的，**休息是只要我说了我要睡觉，或者休息就算**」

> 「**30分钟太短**，有时候我醒着在做东西，改成只要休息时吧，然后**我说在忙事情后可以稍微延长，但不能直接全部压掉**」

这是**宿主侧**的问题：插件（dsh-life）只负责「被叫醒之后注入什么」，决定不了「什么时候被叫醒」。被叫醒的频率由 `qq-bridge` 控制。

### 三条设计约束（直接来自上面的话）

1. **不许按钟点判休息**。「3–6 点」只是举例。休息的唯一判据是主人**明说**「我要睡了 / 我休息了」。
2. **不许用「多久没说话」推断走开**。他说过他「醒着在做东西」——沉默不等于休息。
3. **在忙只许拉长间隔，不许全压掉**。到点照样要能主动找他。

## 2. 根因（全部有源码行号，实测 v13 现行）

| # | 位置 | 行为 | 后果 |
|---|---|---|---|
| 1 | `src/bridge.js:11044` | `st.wakeConfig.sleepUntil = null;` **每次唤醒都清空闹钟** | 「六点的闹钟」被三点那次唤醒清掉 |
| 2 | `src/bridge.js:11071-11077`、`:11094-11098` | `restoreFiniteSleep()` 只在**投递失败/被拒**时恢复 | 投递成功反而永久丢失闹钟 |
| 3 | `src/bridge.js:11111` `scheduleReplyCheckV2` | 发完消息 30s（`autoReplyCheckMs:30000`）拉起 `replyCheck` | 每次说话都多一次定时唤醒 |
| 4 | `src/bridge.js:11410` `scheduleProactiveCheckV2` | 30–90 分钟随机 + `probability 0.3` | 白天持续有人敲门 |
| 5 | `state/social-v2.json` 实测 | `triggers.probability: 0.2` | 普通消息 20% 概率唤醒（推荐值 0.05） |
| 6 | `src/bridge.js:11211` `holdTimerWakeInQuiet` | 只在夜间静默 23:30–07:30 拦定时类 | **白天完全没保护** |
| 7 | `src/bridge.js:11011-11023` | 限频命中 → `rateLimitRetryTimer` 重试而非丢弃 | 限频反而制造「排队补唤醒」 |

合起来：**闹钟还没到，任何一次概率/检查唤醒都会把闹钟清掉并把她拉起来。**

## 3. 修法（最小侵入，只加不改）

在 `sendWakePromptV2` 里、夜间静默判断**之后**加一段守卫。判定函数在 `wake-guard.mjs`（纯函数、零依赖、可单测）。

```js
const _wgResting = readDeclaredFlag('owner-resting.json', _wgNow);  // 他明说要睡了
const _wgBusy    = readDeclaredFlag('owner-busy.json', _wgNow);     // 他明说在忙
const _wg = shouldSuppressWake({
  wakeConfig: st.wakeConfig, reason,
  unreadCount: Array.isArray(st.unread) ? st.unread.length : 0,
  now: _wgNow,
  lastWakeAt: _wgTimes.length ? Number(_wgTimes[_wgTimes.length - 1]) || 0 : 0,
  resting: _wgResting,
  ownerBusy: _wgBusy,
});
if (_wg.suppress) {
  log(`[reserved2] 抑制空唤醒 ${key}（${reason}）：${_wg.why}`);
  if (wakeBaseReason(reason) === 'timeout' && !st.sleepTimer) setupSleepTimerV2(key);
  return;
}
```

判定顺序（`wake-guard.mjs` 的 `shouldSuppressWake`）：

| # | 条件 | 结果 | why |
|---|---|---|---|
| 0 | 不是定时类原因（真人找她） | **放行** | `not-timer-reason` |
| 0' | 有未读真人消息 | **放行** | `has-unread` |
| 1 | 有限潜水且闹钟未到 | 抑制 | `before-alarm` |
| 1' | 有限潜水且已到点 | **放行** | `alarm-due` |
| 2 | **主人明说要睡/休息** + 定时类 | 抑制（`bootstrap`/`admin` 除外） | `resting` |
| 3 | `replyCheck` 且没人接话 | 抑制 | `reply-check-nobody-replied` |
| 4 | `proactiveCheck` 且主人在忙且 <60min | 抑制 | `busy-too-soon` |
| 5 | 其余定时类 | **放行** | `other-timer` |

**默认不节流 proactive**：`proactiveMinGapMs: 0`。qq-bridge 自己就是 30–90 分钟随机，再加一道闸等于把「她会主动找他」砍掉一半——那是减功能。

### 为什么这是「只优化、不减少功能」

| 场景 | 旧行为 | 补丁后 |
|---|---|---|
| 闹钟未到，replyCheck 触发 | 唤醒 → 闹钟被清 → 起来空转 | **不唤醒，闹钟保留** |
| 闹钟未到，proactiveCheck 触发 | 唤醒 → 空转 | **不唤醒；下一次主动机会照常排** |
| 他明说要睡，任何定时唤醒 | 唤醒 → 空转 | **不唤醒**（真人说话照常醒） |
| 他明说在忙，主动机会 | 30–90 分钟一敲 | **间隔拉到 60 分钟**（到点照样放行） |
| 他没说要睡（哪怕凌晨） | 唤醒 | **照常**（严禁按钟点判） |
| 真人 @ / 提问 / 拍一拍 / 关键词 / 说话 | 唤醒 | **照常唤醒** |
| 有未读消息 | 唤醒 | **照常唤醒** |
| 闹钟到点 | 唤醒 | **照常唤醒** |
| 无限潜水（没设闹钟） | 定时唤醒 | **照常**（只受 replyCheck / busy 两条约束） |

> `scheduleProactiveCheckV2` / `scheduleReplyCheckV2` 的**排程一行没改** —— 主动机会、回复检查这两个能力都还在，只是「不该吵的时候先别插队」。

## 4. 怎么用

### 4.1 打补丁（三步，默认只写副本）

```bash
cd 解决方案/补丁04-抑制定时空唤醒

# ① 体检：锚点能不能命中、依赖符号齐不齐（不改任何文件）
python 打补丁.py --check --src <你的 qq-bridge>/src/bridge.js

# ② 打到副本上，自己 diff 看
python 打补丁.py --src <你的 qq-bridge>/src/bridge.js --dst /tmp/bridge.patched.js

# ③ 确认无误再原地打（自动备份 .bak-<时间>）
python 打补丁.py --apply --src <你的 qq-bridge>/src/bridge.js
```

打补丁做了什么：**只新增行，绝不删除或改写原有行**（脚本用 `difflib` 校验删除行数必须为 0）。实测在本机 v13 的 `bridge.js` 上：

```
新增 54 行 / 删除 0 行
node --check: OK
sha256: 8645821f4b07bdea → 6d7c13e97cd602bc
```

同时要把 `wake-guard.mjs` 复制到 `<qq-bridge>/src/wake-guard.mjs`（打补丁脚本不负责复制文件）。

### 4.2 使用标记（这才是让「休息/忙」生效的方式）

补丁不猜，只认主人明说。所以配了一个小工具：

```bash
# 他说「我去睡了」→ 写到起床时间（或给个时长）
node 标记.mjs rest 8h
node 标记.mjs rest --until 2026-11-07T07:30:00+08:00

# 他说「我在忙，忙一会儿」→ 主动机会间隔拉长到 60 分钟
node 标记.mjs busy 2h

# 他醒了 / 不忙了
node 标记.mjs clear rest
node 标记.mjs clear busy
node 标记.mjs clear all

# 看当前状态
node 标记.mjs show
```

输出示例：

```
qq-bridge: <你的 qq-bridge 目录>
  rest  ✅ 生效中  until=2026/11/7 05:30:41  （主人说他要去睡/休息）
  busy  —（无标记）
```

标记文件格式（也可以手写）：

```json
{ "active": true, "until": "2026-11-07T07:30:00+08:00", "note": "主人说他要去睡/休息" }
```

- `until` 省略 = 不限时，直到被 `clear`。
- `active: false` 或缺文件 = 不生效（**保守放行**，绝不因为读不到状态就不说话）。

### 4.3 让她自己写标记

想让小鱼在听到「我去睡了」时自动写标记，把这三句加进她的系统提示或工具说明：

> 主人说「我要睡了 / 我去休息了 / 晚安」时，跑 `node <qq-bridge>/标记.mjs rest <他到点的时间>`
> 主人说「我在忙 / 忙一会儿」时，跑 `node <qq-bridge>/标记.mjs busy <时长>`
> 主人说「我醒了 / 不忙了」时，跑 `node <qq-bridge>/标记.mjs clear all`

## 5. 验证

```bash
# 判定表（56 条纯函数断言，不依赖 qq-bridge）
node 自检.mjs

# 沙盒 H8 场景（28 项，跑在沙盒里，不碰任何真实数据）
cd ../../代码 && node sandbox/run.mjs
```

实测结果：

| 验证项 | 结果 |
|---|---|
| `自检.mjs` 判定表 | **PASS 56 / FAIL 0** |
| 沙盒 H8 | **28 项全过**（H 组合计 8 场景 / 110 断言 / 110 PASS） |
| 真机结构核查 `materials/verify-patch04-live.mjs` | **PASS 16 / FAIL 0** |
| 副本试打 | 新增 54 行 / 删除 0 行 / `node --check: OK` |

## 6. 回滚

```bash
cp <qq-bridge>/src/bridge.js.bak-<时间> <qq-bridge>/src/bridge.js
rm <qq-bridge>/src/wake-guard.mjs
rm <qq-bridge>/state/owner-resting.json <qq-bridge>/state/owner-busy.json
# 重启 bridge
```

补丁只在「投递前」多一道判断，回滚零残留。

## 7. 文件清单

| 文件 | 作用 |
|---|---|
| `wake-guard.mjs` | 纯函数判定表（`shouldSuppressWake` / `baseReason` / `isTimerWakeReason`），零依赖 |
| `打补丁.py` | 对副本打补丁：`--check` / `--dst` / `--apply`，四道闸（幂等、锚点唯一、`node --check`、零删除） |
| `标记.mjs` | 写/清/看 `state/owner-resting.json` 与 `state/owner-busy.json` |
| `自检.mjs` | 56 条判定表断言，不需要 qq-bridge 就能跑 |
| `README.md` | 本文件 |

## 8. 已知边界

- **不能拦住宿主自身的唤醒**：如果 DSH 那边有别的东西直接触发一轮 turn，qq-bridge 这道闸管不到。插件侧的 `skipIdleTurn` 负责兜住「已经醒了但没实质输入」的那一轮。
- **`bootstrap` / `admin` 永远放行**：防止休息标记写错导致永眠。
- **标记文件过期不会自动删**：到点后 `readDeclaredFlag` 返回 false，行为等同于没有标记；但文件会一直留着，`clear` 一下更干净。
- **只在本机 v13 现行版本上验证过**（`bridge.js` 732176B / 2026-11-06 19:16）。上游改了 `sendWakePromptV2` 要先跑 `--check`。
