// wake-guard.mjs — 潜水/休息期抑制「定时空唤醒」的判定函数（v3）
//
// 为什么需要它（2026-11-06 实测 qq-bridge v13）：
//   主人设了「六点起」的闹钟，但 3 点到 6 点之间她会反复被拉起：虽然一条消息都没发，
//   但每拉起一次都是一整轮完整上下文，token 就这么被烧掉了。
//
//   但**不只是 3–6 点**。主人的原话是「只要我休息或忙的时候都算」，
//   随后又补了两条重要修正：
//     · 「有时候我醒着在做东西」→ **不能**用「多久没说话」推断他走开了。
//     · 「我说在忙事情后可以稍微延长，但不能直接全部压掉」
//       → 明确说忙只**延长间隔**，永远保留兜底频率，不许全静音。
//
//   所以判据分三层，优先级从高到低：
//     ① 有限潜水（设了闹钟）：闹钟是唯一放行点，闹钟前一律不投递。
//     ② 休息态：**只由主人明说**「我要睡了 / 我休息了」触发（调用方传 resting）。
//        不看钟点、不看沉默时长——他醒着做东西时不该被误伤，他 22 点说不睡也不能算睡。
//     ③ 主人明确说过「在忙」：只把主动机会间隔拉长，**不禁止**。
//   真人找她（@/名字/提问/拍一拍/关键词/普通新消息/有未读）在任何一层都放行。
//
//   根因在 qq-bridge/src/bridge.js 的唤醒链路，与 dsh-life 插件无关：
//     · sendWakePromptV2 每次唤醒都执行 `st.wakeConfig.sleepUntil = null`（:11044），
//       把「六点的闹钟」直接清掉；只有投递失败/被拒时才 restoreFiniteSleep() 恢复
//       （:11079-11084、:11094-11098），投递成功不恢复。
//     · replyCheck（发完消息后 autoReplyCheckMs 到点）不看「有没有人接话」，
//       没人回也照查一遍 → 每发一条消息就白烧一轮。
//     · proactiveCheck（30~90 分钟随机）不分昼夜、不管主人在不在。
//     · 夜间静默（23:30–07:30）只护夜里，白天他忙到炸也不管。
//     · 限频命中不丢弃而是 rateLimitRetryTimer 重试，限频反而制造排队补唤醒。
//
// 本模块只做一件事：判断「这一次唤醒该不该被抑制」。
//   · 抑制 = 不投递 prompt、不动 sleepUntil、不重排定时器（闹钟原样保留）。
//   · 刻意做成纯函数、零依赖：既给 qq-bridge 补丁调用，也能被沙盒直接单测。

/** 与 bridge.js:11193 保持一致的定时类唤醒原因 */
export const TIMER_WAKE_REASONS = new Set(['timeout', 'replyCheck', 'proactiveCheck', 'bootstrap', 'admin']);

/** 默认阈值（都可被 cfg 覆盖） */
export const DEFAULTS = {
  // 主动机会检查两次之间的最小间隔（毫秒）。**默认 0 = 不节流**。
  // 为什么是 0：qq-bridge 自己的排程就是 30~90 分钟随机，本来就够稀疏；
  // 再加一道 90 分钟的闸，等于把「她会主动找主人说话」的频率整体砍掉一半——
  // 那是减功能，不是优化。这里只在主人明确说「在忙」时才起作用。
  proactiveMinGapMs: 0,
  // 主人明说「在忙」时改成这个间隔。默认 60 分钟。
  // 主人的原话是「可以稍微延长，但不能直接全部压掉」——所以是拉长，不是禁止：
  // 到点照样会主动找他，真人说话更是任何时候都放行。
  busyMinGapMs: 60 * 60 * 1000,
  // 无限潜水时，replyCheck 在没人接话的情况下是否抑制。默认开。
  // 这条不减功能：replyCheck 的用途是「看看对方有没有接话」，没人接话时查了也白查。
  suppressIdleReplyCheck: true,
};

/**
 * 'replyCheck@seq88' → 'replyCheck'；也兼容 'replyCheck:xx' 这种冒号形态。
 * 注意 qq-bridge 自己用的是 `String(reason).split(':')[0]`，吃不下 `@seq` 后缀
 * （实测 notifyPendingWakeReasonV2 会拼出 `atMention@seq194`），这里一并兜住。
 */
export function baseReason(reason) {
  return String(reason ?? '').trim().replace(/@seq\d+$/i, '').split(':')[0];
}

export function isTimerWakeReason(reason) {
  return TIMER_WAKE_REASONS.has(baseReason(reason));
}

/**
 * 这次唤醒要不要抑制？
 * 返回 { suppress, why, until?, remainingMs? }
 *
 * @param {object} o
 * @param {object} o.wakeConfig    qq-bridge 的 st.wakeConfig（mode / infinite / sleepUntil）
 * @param {string} o.reason        唤醒原因，可带 @seq 后缀
 * @param {number} o.unreadCount   当前未读条数（真人消息）
 * @param {number} [o.now]         判定时刻，默认 Date.now()
 * @param {number} [o.lastWakeAt]  上一次唤醒的时间戳（st.wakeTimes 最后一项）
 * @param {boolean} [o.ownerBusy]  主人是否明确说过「在忙」（调用方按自己的判定传入）
 * @param {boolean} [o.resting]    主人是否**明说**了要睡/休息（调用方读标记文件判定；
 *                                 不要用钟点或沉默时长推断）
 * @param {object} [o.cfg]         覆盖 DEFAULTS 的阈值
 */
export function shouldSuppressWake({
  wakeConfig = null,
  reason = '',
  unreadCount = 0,
  now = Date.now(),
  lastWakeAt = 0,
  ownerBusy = false,
  resting = false,
  cfg = null,
} = {}) {
  const wc = wakeConfig && typeof wakeConfig === 'object' ? wakeConfig : {};
  const opt = { ...DEFAULTS, ...(cfg && typeof cfg === 'object' ? cfg : {}) };

  // 0) 真人找她：永远放行（优先级最高，任何状态都不拦）
  if (!isTimerWakeReason(reason)) return { suppress: false, why: 'not-timer-reason' };
  // 0') 有未读真人消息：永远放行，不能把人吊着
  if (Number(unreadCount) > 0) return { suppress: false, why: 'has-unread' };

  const base = baseReason(reason);
  const until = Date.parse(wc.sleepUntil ?? '');
  const finite = wc.infinite !== true && Number.isFinite(until);

  // ① 有限潜水（设了闹钟）：闹钟是唯一放行点，之前一律不投递
  if (finite) {
    if (until <= Number(now)) return { suppress: false, why: 'alarm-due' };
    return { suppress: true, why: 'before-alarm', until, remainingMs: until - Number(now) };
  }

  // ② 休息态（夜里 / 她自己睡着）：定时类全部压到休息结束
  if (resting === true && base !== 'bootstrap' && base !== 'admin') {
    return { suppress: true, why: 'resting' };
  }

  // ③ 无限潜水 + replyCheck：刚回过、没人接话，再查一遍纯烧 token
  if (opt.suppressIdleReplyCheck === true && base === 'replyCheck') {
    return { suppress: true, why: 'reply-check-nobody-replied' };
  }

  // ④ 无限潜水 + proactiveCheck：按「间隔」节流。
  //    主人明说在忙 → 间隔拉长到 busyMinGapMs，但**到点照样放行**，不全部压掉。
  if (base === 'proactiveCheck') {
    const minGap = ownerBusy === true
      ? Number(opt.busyMinGapMs)
      : Number(opt.proactiveMinGapMs);
    const lastWake = Number(lastWakeAt);
    if (minGap > 0 && Number.isFinite(lastWake) && lastWake > 0) {
      const gap = Number(now) - lastWake;
      if (gap >= 0 && gap < minGap) {
        return {
          suppress: true,
          why: ownerBusy === true ? 'busy-too-soon' : 'proactive-too-soon',
          remainingMs: minGap - gap,
        };
      }
    }
    return { suppress: false, why: ownerBusy === true ? 'busy-gap-reached' : 'proactive-ok' };
  }

  // ⑤ 其余定时类（timeout / bootstrap / admin）在无限潜水下照旧
  return { suppress: false, why: 'other-timer' };
}

export default shouldSuppressWake;
