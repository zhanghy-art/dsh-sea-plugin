# -*- coding: utf-8 -*-
"""
补丁04：抑制定时空唤醒（把「设了闹钟、到点前反复被拉起」堵在源头）

只改 qq-bridge，不改 dsh-life 插件。默认对**副本**运行，绝不直接写运行目录：

    python 打补丁.py --check                             # 只体检，看锚点能不能命中
    python 打补丁.py --src <bridge.js> --dst <out.js>    # 打到副本上
    python 打补丁.py --apply --src <bridge.js>           # 原地打（先自动备份 .bak-<时间>）

改动只有三处，最小侵入：
  1) 顶部 import 一行：从同目录 wake-guard.mjs 取判定函数
  2) sendWakePromptV2 里、夜间静默判断之后加守卫块（约 20 行）
  3) 同文件加一个 readDeclaredFlag() 小工具（读「他说了在休息/在忙」的标记）

为什么只在这几处（对应主人三条修正）：
  · 不动 scheduleReplyCheckV2 / scheduleProactiveCheckV2 的排程——
    主动机会（proactive）属于「她会主动找主人说话」的能力，减少排程＝减少功能，
    主人明确要求「只能优化不能减少」。这里只是「闹钟没到时先不打断」，
    定时器照常重排，到点后一切照旧。
  · 「休息是只要我说了我要睡觉，或者休息就算」
    → 休息态只认 `state/owner-resting.json`（他说了要睡/休息时写），
      以及她自己 life_sleep 设的 sleepUntil。**不看钟点、不看沉默时长**。
  · 「30 分钟太短，有时候我醒着在做东西」
    → **不**用「多久没说话」推断走开（v2 的 ownerIdleMs 已删）。
  · 「我说在忙事情后可以稍微延长，但不能直接全部压掉」
    → 忙只认 `state/owner-busy.json`，把主动机会间隔拉长到 60min，
      到点照样放行；真人说话永远放行。
  · 真人找她（@/名字/提问/拍一拍/关键词/指定成员/普通新消息）完全不拦。
  · 闹钟到期（timeout 且 sleepUntil 已过）完全不拦。
  · timeout 被意外提前触发而抑制时，会重新挂回 sleepTimer，不会把会话挂死。
"""
import argparse
import difflib
import hashlib
import os
import shutil
import subprocess
import sys
import tempfile
import time

ANCHOR_IMPORT = "import { inQuietHours as quietInNow, nextQuietEnd as quietNextEnd, describe as quietDescribe } from './quiet-hours.js';"
ADD_IMPORT = ANCHOR_IMPORT + "\nimport { shouldSuppressWake, baseReason as wakeBaseReason } from './wake-guard.mjs';"

# 守卫块插在「夜间静默判断之后」。st 与 cfg 在此作用域内都已存在（见函数开头）。
# 声明式标记读取：主人明说「要睡/休息」或「在忙」时由外部写 state/*.json。
# 文件不存在/坏了/已过期 → false（保守放行，绝不因为读不到状态就不说话）。
ANCHOR_HELPER = "  function quietCfg() {"

ADD_HELPER = """  /**
   * 读「主人显式声明」的状态标记（state/<file>）。
   * 只认 { until: <ISO 或 毫秒> }；未写 until 视为有效直到被清掉。
   * 读不到就当没有——保守放行，绝不因为缺状态而误伤。
   */
  function readDeclaredFlag(file, nowMs = Date.now()) {
    try {
      const p = path.join(process.cwd(), 'state', file);
      if (!fs.existsSync(p)) return false;
      const o = JSON.parse(fs.readFileSync(p, 'utf8'));
      if (!o || typeof o !== 'object') return false;
      if (o.active === false) return false;
      if (o.until === undefined || o.until === null || o.until === '') return true;
      const u = typeof o.until === 'string' ? Date.parse(o.until) : Number(o.until);
      return Number.isFinite(u) ? u > nowMs : true;
    } catch {
      return false;
    }
  }

  function quietCfg() {"""

ANCHOR_GUARD = """    const st = getSocialV2State(key);
    // 夜间静默：定时类唤醒不投递，推迟到静默结束（真人在窗口内说话照常唤醒）
    if (holdTimerWakeInQuiet(key, reason, st)) return;
"""

ADD_GUARD = ANCHOR_GUARD + """    // 补丁04：主人说了「要睡/休息」、或她自己设了闹钟的时候，定时类空唤醒不投递。
    // 旧行为是每次唤醒都 `st.wakeConfig.sleepUntil = null`（见下方 sendWakePromptV2
    // 中段），把「设了几点醒」的闹钟清掉——这正是「设了六点、三点到六点一直被拉起」
    // 的根因；投递成功还不恢复，闹钟就此消失。
    // 判据全是显式声明：休息只看 owner-resting.json 或 sleepUntil，不看钟点、不看沉默时长。
    // 不减少任何能力——排程一行没改，真人找她走不到这里，闹钟到点照常放行。
    {
      const _wgNow = Date.now();
      // 「休息 / 在忙」都只认主人**明说**的标记，不猜钟点、不猜沉默时长：
      //   state/owner-resting.json  ← 他说了「我要睡了 / 我休息了」
      //   state/owner-busy.json     ← 他说了「在忙」
      // 文件不存在/坏了/过期 → false，保守放行，绝不因为读不到状态就不说话。
      const _wgResting = readDeclaredFlag('owner-resting.json', _wgNow);
      const _wgBusy = readDeclaredFlag('owner-busy.json', _wgNow);
      const _wgTimes = Array.isArray(st.wakeTimes) ? st.wakeTimes : [];
      const _wg = shouldSuppressWake({
        wakeConfig: st.wakeConfig,
        reason,
        unreadCount: Array.isArray(st.unread) ? st.unread.length : 0,
        now: _wgNow,
        lastWakeAt: _wgTimes.length ? Number(_wgTimes[_wgTimes.length - 1]) || 0 : 0,
        resting: _wgResting,
        ownerBusy: _wgBusy,
      });
      if (_wg.suppress) {
        log(`[reserved2] 抑制空唤醒 ${key}（${reason}）：${_wg.why}` +
          (_wg.until ? `，闹钟保持到 ${new Date(_wg.until).toLocaleString('zh-CN', { hour12: false })}（剩 ${Math.round(_wg.remainingMs / 1000)}s）` : '') +
          (_wg.why === 'busy-too-soon' || _wg.why === 'proactive-too-soon' ? `，${Math.round(_wg.remainingMs / 60000)} 分钟后再考虑` : ''));
        // timeout 被提前触发时 sleepTimer 已被消费，必须挂回去，否则会话会挂死。
        if (wakeBaseReason(reason) === 'timeout' && !st.sleepTimer) setupSleepTimerV2(key);
        return;
      }
    }
"""


def sha(p):
    h = hashlib.sha256()
    with open(p, 'rb') as f:
        for b in iter(lambda: f.read(65536), b''):
            h.update(b)
    return h.hexdigest()[:16]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--src', default=os.path.join(os.path.dirname(__file__), '..', '..', 'src', 'bridge.js'))
    ap.add_argument('--dst', default=None, help='输出副本路径；不给就写 <src>.patched.js')
    ap.add_argument('--apply', action='store_true', help='原地改（自动 .bak-时间 备份）')
    ap.add_argument('--check', action='store_true', help='只体检锚点，不写任何文件')
    args = ap.parse_args()

    src = os.path.abspath(args.src)
    if not os.path.isfile(src):
        print('找不到 bridge.js: ' + src)
        return 2
    text = open(src, 'r', encoding='utf-8').read()
    before_sha = sha(src)

    # 闸1：幂等
    if 'shouldSuppressWake' in text and 'wake-guard.mjs' in text:
        print('已打过补丁（检测到 shouldSuppressWake），不重复打。sha256=' + before_sha)
        return 0

    # 闸2：锚点各命中 1 次
    miss = []
    if text.count(ANCHOR_IMPORT) != 1:
        miss.append('import 锚点命中 %d 次（应为 1）' % text.count(ANCHOR_IMPORT))
    if text.count(ANCHOR_GUARD) != 1:
        miss.append('sendWakePromptV2 守卫锚点命中 %d 次（应为 1）' % text.count(ANCHOR_GUARD))
    if text.count(ANCHOR_HELPER) != 1:
        miss.append('helper 锚点命中 %d 次（应为 1）' % text.count(ANCHOR_HELPER))
    # 守卫块依赖的作用域内符号必须都在
    for sym in ['function quietOn(', 'setupSleepTimerV2(', 'function getSocialV2State(', 'st.wakeTimes', 'cfg.socialV2?.wake', "from 'node:fs';", "from 'node:path';"]:
        if sym not in text:
            miss.append('缺少依赖符号: ' + sym)
    if miss:
        print('锚点不匹配，拒绝打补丁：')
        for m in miss:
            print('  - ' + m)
        return 3

    out = (text
           .replace(ANCHOR_IMPORT, ADD_IMPORT, 1)
           .replace(ANCHOR_HELPER, ADD_HELPER, 1)
           .replace(ANCHOR_GUARD, ADD_GUARD, 1))
    print('体检通过：三个锚点各命中 1 次、依赖符号齐全；原文件 sha256=' + before_sha)
    if args.check:
        print('--check 模式，不写文件。')
        return 0

    if args.apply:
        dst = src
        bak = src + '.bak-' + time.strftime('%Y%m%dT%H%M%S')
        shutil.copy2(src, bak)
        print('已备份: ' + bak)
    else:
        dst = os.path.abspath(args.dst or (src + '.patched.js'))

    # 闸3：语法校验（复制成 .mjs 再 node --check，不依赖 package.json type）
    tmpdir = tempfile.mkdtemp(prefix='pb04-')
    try:
        chk = os.path.join(tmpdir, 'bridge.check.mjs')
        open(chk, 'w', encoding='utf-8', newline='').write(out)
        r = subprocess.run(['node', '--check', chk], capture_output=True, text=True,
                           encoding='utf-8', errors='replace')
        if r.returncode != 0:
            print('node --check 失败，未写入：')
            print((r.stderr or r.stdout)[:2000])
            return 4
        print('node --check: OK')

        # 闸4：只新增行，不改不删原有行
        added = [l for l in difflib.ndiff(text.splitlines(), out.splitlines()) if l.startswith('+ ')]
        removed = [l for l in difflib.ndiff(text.splitlines(), out.splitlines()) if l.startswith('- ')]
        print('新增 %d 行 / 删除 %d 行（删除必须为 0）' % (len(added), len(removed)))
        if removed:
            print('出现删除行，拒绝写入：')
            for l in removed[:10]:
                print('  ' + l)
            return 5

        open(dst, 'w', encoding='utf-8', newline='').write(out)
        print('已写入: ' + dst)
        print('打补丁后 sha256=' + sha(dst))
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)
    return 0


if __name__ == '__main__':
    sys.exit(main())
