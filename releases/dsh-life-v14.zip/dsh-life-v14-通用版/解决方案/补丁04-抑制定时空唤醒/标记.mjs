#!/usr/bin/env node
// 标记.mjs — 给补丁04 写「主人明说了要睡/休息」或「主人明说在忙」的标记
//
// 补丁04 不猜钟点、不猜沉默时长，只认这两个文件：
//   <qq-bridge>/state/owner-resting.json   主人说了「我要睡了 / 我休息了」
//   <qq-bridge>/state/owner-busy.json      主人说了「在忙 / 忙一会儿」
//
// 用法（在 qq-bridge 目录下，或传 --dir 指定）：
//   node 标记.mjs rest 8h          # 从现在起 8 小时内算休息（到点自动失效）
//   node 标记.mjs rest             # 不限时，直到手动 clear
//   node 标记.mjs rest --until 2026-11-07T07:30:00+08:00
//   node 标记.mjs busy 2h          # 2 小时内算在忙（主动机会间隔拉长到 60min）
//   node 标记.mjs clear rest       # 清掉休息标记（他醒了）
//   node 标记.mjs clear busy
//   node 标记.mjs clear all
//   node 标记.mjs show             # 看当前两个标记
//
// 为什么需要它：主人说「我要睡了」时，小鱼调用它写一次标记；
// 之后到点前的定时唤醒都会被抑制，直到他到点或被 clear。
// 这是「只优化不减少」——排程一点没动，只是不再空转。

import fs from 'node:fs';
import path from 'node:path';

const FILES = { rest: 'owner-resting.json', busy: 'owner-busy.json' };
// 默认目录：优先环境变量 QQ_BRIDGE_DIR，其次当前工作目录下的 qq-bridge。
// 换机器/换路径时不必改代码，`--dir <你的 qq-bridge 绝对路径>` 或设环境变量即可。
const DEFAULT_DIR = process.env.QQ_BRIDGE_DIR || path.resolve(process.cwd(), 'qq-bridge');

function parseDir(argv) {
  const i = argv.indexOf('--dir');
  if (i >= 0 && argv[i + 1]) return argv[i + 1];
  return DEFAULT_DIR;
}

function parseDuration(s) {
  const m = String(s || '').trim().match(/^(\d+(?:\.\d+)?)\s*([smhd])$/i);
  if (!m) return null;
  const n = Number(m[1]);
  const unit = m[2].toLowerCase();
  const mult = { s: 1000, m: 60000, h: 3600000, d: 86400000 }[unit];
  return Math.round(n * mult);
}

function readFlag(file) {
  try {
    if (!fs.existsSync(file)) return null;
    const o = JSON.parse(fs.readFileSync(file, 'utf8'));
    return o && typeof o === 'object' ? o : null;
  } catch { return null; }
}

function isActive(o, now = Date.now()) {
  if (!o) return false;
  if (o.active === false) return false;
  if (o.until === undefined || o.until === null || o.until === '') return true;
  const u = typeof o.until === 'string' ? Date.parse(o.until) : Number(o.until);
  return Number.isFinite(u) ? u > now : true;
}

function main() {
  const argv = process.argv.slice(2);
  const dir = parseDir(argv);
  const stateDir = path.join(dir, 'state');
  const cmd = (argv.find(a => !a.startsWith('--') && !/^\d/.test(a)) || '').toLowerCase();

  if (!fs.existsSync(stateDir)) {
    console.log('找不到 state 目录: ' + stateDir + '（用 --dir 指定 qq-bridge 目录）');
    process.exit(2);
  }

  if (cmd === 'show' || cmd === '') {
    console.log('qq-bridge: ' + dir);
    for (const [k, f] of Object.entries(FILES)) {
      const p = path.join(stateDir, f);
      const o = readFlag(p);
      if (!o) { console.log(`  ${k.padEnd(5)} —（无标记）`); continue; }
      const act = isActive(o);
      const until = o.until ? new Date(typeof o.until === 'string' ? o.until : Number(o.until)).toLocaleString('zh-CN', { hour12: false }) : '不限时';
      console.log(`  ${k.padEnd(5)} ${act ? '✅ 生效中' : '⏹ 已失效'}  until=${until}  ${o.note ? '（' + o.note + '）' : ''}`);
    }
    return;
  }

  if (cmd === 'clear') {
    const which = (argv.find(a => ['rest', 'busy', 'all', 'resting'].includes(a)) || 'all').toLowerCase();
    const targets = which === 'all' ? Object.values(FILES) : [FILES[which === 'resting' ? 'rest' : which]].filter(Boolean);
    if (!targets.length) { console.log('clear 后面要跟 rest / busy / all'); process.exit(2); }
    for (const f of targets) {
      const p = path.join(stateDir, f);
      if (fs.existsSync(p)) { fs.unlinkSync(p); console.log('已清除: ' + f); }
      else console.log('本来就没有: ' + f);
    }
    return;
  }

  if (cmd !== 'rest' && cmd !== 'busy') {
    console.log('用法: node 标记.mjs rest|busy|clear|show [时长如 8h] [--until ISO] [--dir <qq-bridge>]');
    process.exit(2);
  }

  const key = cmd === 'rest' ? 'rest' : 'busy';
  const file = path.join(stateDir, FILES[key]);

  // --until 优先
  let until = null;
  const ui = argv.indexOf('--until');
  if (ui >= 0 && argv[ui + 1]) {
    const u = Date.parse(argv[ui + 1]);
    if (!Number.isFinite(u)) { console.log('--until 解析不了: ' + argv[ui + 1]); process.exit(2); }
    until = new Date(u).toISOString();
  } else {
    // 位置参数里的时长（如 8h / 90m / 2d）
    for (const a of argv) {
      const ms = parseDuration(a);
      if (ms) { until = new Date(Date.now() + ms).toISOString(); break; }
    }
  }

  const payload = { active: true, setAt: new Date().toISOString() };
  if (until) payload.until = until;
  const note = key === 'rest' ? '主人说他要去睡/休息' : '主人说他在忙';
  payload.note = note;

  fs.writeFileSync(file, JSON.stringify(payload, null, 2), 'utf8');
  console.log(`已写入 ${FILES[key]}：`);
  console.log(`  ${until ? '有效至 ' + new Date(until).toLocaleString('zh-CN', { hour12: false }) : '不限时（直到 clear）'}`);
  console.log(`  作用：${key === 'rest'
    ? '休息期间定时类空唤醒一律不投递（真人找她照常醒）'
    : '主动机会间隔拉长到 60 分钟（不会全压掉，到点照样找）'}`);
}

main();
