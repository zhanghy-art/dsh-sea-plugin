// 自检.mjs — 补丁04 判定表（纯函数级验证，不依赖 qq-bridge）
//
// 覆盖：
//   ① 有限潜水（设了闹钟）：闹钟前一律抑制、到点放行、真人/未读永远放行
//   ② 休息态（夜里 / 她自己睡着）：定时类压到休息结束
//   ③ 无限潜水日常：replyCheck 没人回就抑制
//   ④ proactiveCheck 默认**不节流**（不能砍主动性）
//   ⑤ 主人明说「在忙」：只拉长到 60min，**到点照样放行**（不全压掉）
//   ⑥ 边界与垃圾值：不抛、保守放行

import { shouldSuppressWake, baseReason, isTimerWakeReason, DEFAULTS } from './wake-guard.mjs';

let pass = 0, fail = 0;
const T = (name, actual, expected) => {
  const ok = JSON.stringify(actual) === JSON.stringify(expected);
  if (ok) { pass++; console.log(`  PASS  ${name}`); }
  else { fail++; console.log(`  FAIL  ${name}\n        期望 ${JSON.stringify(expected)}\n        实际 ${JSON.stringify(actual)}`); }
};

const NOW = Date.parse('2026-11-06T03:00:00+00:00');
const AT_6 = '2026-11-06T06:00:00+00:00';
const finiteAt6 = { mode: 'diving', infinite: false, sleepUntil: AT_6 };
const infinite = { mode: 'diving', infinite: true, sleepUntil: null };

console.log('\n【① 有限潜水（闹钟 06:00，现在 03:00）】');
T('timeout 在闹钟前 → 抑制', shouldSuppressWake({ wakeConfig: finiteAt6, reason: 'timeout', now: NOW }).why, 'before-alarm');
T('剩余时长 = 3 小时', shouldSuppressWake({ wakeConfig: finiteAt6, reason: 'timeout', now: NOW }).remainingMs, 3 * 3600000);
T('带 @seq 后缀也认', shouldSuppressWake({ wakeConfig: finiteAt6, reason: 'timeout@seq42', now: NOW }).why, 'before-alarm');
T('replyCheck 在闹钟前 → 抑制', shouldSuppressWake({ wakeConfig: finiteAt6, reason: 'replyCheck', now: NOW }).why, 'before-alarm');
T('proactiveCheck 在闹钟前 → 抑制', shouldSuppressWake({ wakeConfig: finiteAt6, reason: 'proactiveCheck', now: NOW }).why, 'before-alarm');
T('闹钟到点 → 放行', shouldSuppressWake({ wakeConfig: finiteAt6, reason: 'timeout', now: Date.parse(AT_6) }).why, 'alarm-due');
T('闹钟过后 → 放行', shouldSuppressWake({ wakeConfig: finiteAt6, reason: 'timeout', now: Date.parse(AT_6) + 1000 }).why, 'alarm-due');
T('到期前 1ms → 仍抑制', shouldSuppressWake({ wakeConfig: finiteAt6, reason: 'timeout', now: Date.parse(AT_6) - 1 }).why, 'before-alarm');
T('有未读 → 放行（人不吊着）', shouldSuppressWake({ wakeConfig: finiteAt6, reason: 'timeout', unreadCount: 1, now: NOW }).why, 'has-unread');

console.log('\n【② 真人找她：一律放行，任何状态都不拦】');
for (const r of ['atMention', 'nameMention', 'keyword', 'question', 'poke', 'speaker', 'anyMessage', 'private']) {
  T(`${r} → 放行`, shouldSuppressWake({ wakeConfig: finiteAt6, reason: r, now: NOW }).why, 'not-timer-reason');
}
T('atMention@seq194 → 放行', shouldSuppressWake({ wakeConfig: finiteAt6, reason: 'atMention@seq194', now: NOW }).why, 'not-timer-reason');
T('他说了要睡、但真人说话 → 放行', shouldSuppressWake({ wakeConfig: infinite, reason: 'atMention', resting: true, now: NOW }).why, 'not-timer-reason');
T('忙状态下真人说话也放行', shouldSuppressWake({ wakeConfig: infinite, reason: 'question', ownerBusy: true, now: NOW }).why, 'not-timer-reason');

console.log('\n【③ 休息态（夜里 / 她自己睡着）：定时类压到休息结束】');
T('他说了要睡 + timeout → 抑制', shouldSuppressWake({ wakeConfig: infinite, reason: 'timeout', resting: true, now: NOW }).why, 'resting');
T('他说了要睡 + replyCheck → 抑制', shouldSuppressWake({ wakeConfig: infinite, reason: 'replyCheck', resting: true, now: NOW }).why, 'resting');
T('他说了要睡 + proactiveCheck → 抑制', shouldSuppressWake({ wakeConfig: infinite, reason: 'proactiveCheck', resting: true, now: NOW }).why, 'resting');
T('他说了要睡 + 有未读 → 放行', shouldSuppressWake({ wakeConfig: infinite, reason: 'timeout', resting: true, unreadCount: 1, now: NOW }).why, 'has-unread');
T('他说了要睡 + bootstrap → 放行（不许永眠）', shouldSuppressWake({ wakeConfig: infinite, reason: 'bootstrap', resting: true, now: NOW }).why, 'other-timer');
T('没说要睡（哪怕凌晨三点）+ timeout → 放行（不按钟点判）', shouldSuppressWake({ wakeConfig: infinite, reason: 'timeout', resting: false, now: NOW }).why, 'other-timer');

console.log('\n【④ 无限潜水日常：replyCheck 节流（不减功能）】');
T('replyCheck 无人接话 → 抑制', shouldSuppressWake({ wakeConfig: infinite, reason: 'replyCheck', now: NOW }).why, 'reply-check-nobody-replied');
T('replyCheck 有未读 → 放行', shouldSuppressWake({ wakeConfig: infinite, reason: 'replyCheck', unreadCount: 1, now: NOW }).why, 'has-unread');
T('开关关掉 → 放行', shouldSuppressWake({ wakeConfig: infinite, reason: 'replyCheck', now: NOW, cfg: { suppressIdleReplyCheck: false } }).why, 'other-timer');

console.log('\n【⑤ proactiveCheck：默认不节流（不砍主动性）】');
T('默认 proactiveMinGapMs = 0（不节流）', DEFAULTS.proactiveMinGapMs, 0);
T('刚 1 分钟前醒过 → 放行', shouldSuppressWake({ wakeConfig: infinite, reason: 'proactiveCheck', now: NOW, lastWakeAt: NOW - 60000 }).why, 'proactive-ok');
T('30 分钟前醒过 → 放行', shouldSuppressWake({ wakeConfig: infinite, reason: 'proactiveCheck', now: NOW, lastWakeAt: NOW - 30 * 60000 }).why, 'proactive-ok');
T('没记录 lastWakeAt → 放行（不因缺数据就不说话）', shouldSuppressWake({ wakeConfig: infinite, reason: 'proactiveCheck', now: NOW, lastWakeAt: 0 }).why, 'proactive-ok');
T('显式配 90min 时才会节流（可选项，默认不开）',
  shouldSuppressWake({ wakeConfig: infinite, reason: 'proactiveCheck', now: NOW, lastWakeAt: NOW - 30 * 60000, cfg: { proactiveMinGapMs: 90 * 60000 } }).why,
  'proactive-too-soon');

console.log('\n【⑥ 主人明说「在忙」：只拉长到 60min，不全压掉】');
T('默认 busyMinGapMs = 60min', DEFAULTS.busyMinGapMs, 60 * 60 * 1000);
T('忙 + 30 分钟前醒过 → 抑制（<60min）', shouldSuppressWake({ wakeConfig: infinite, reason: 'proactiveCheck', now: NOW, ownerBusy: true, lastWakeAt: NOW - 30 * 60000 }).why, 'busy-too-soon');
T('忙 + 50 分钟前 → 仍抑制', shouldSuppressWake({ wakeConfig: infinite, reason: 'proactiveCheck', now: NOW, ownerBusy: true, lastWakeAt: NOW - 50 * 60000 }).why, 'busy-too-soon');
T('忙 + 60 分钟整 → 放行（到点照样找他）', shouldSuppressWake({ wakeConfig: infinite, reason: 'proactiveCheck', now: NOW, ownerBusy: true, lastWakeAt: NOW - 60 * 60000 }).why, 'busy-gap-reached');
T('忙 + 200 分钟 → 放行', shouldSuppressWake({ wakeConfig: infinite, reason: 'proactiveCheck', now: NOW, ownerBusy: true, lastWakeAt: NOW - 200 * 60000 }).why, 'busy-gap-reached');
T('同样 30 分钟：不忙放行、忙抑制（阈值只在忙时生效）', [
  shouldSuppressWake({ wakeConfig: infinite, reason: 'proactiveCheck', now: NOW, ownerBusy: false, lastWakeAt: NOW - 30 * 60000 }).suppress,
  shouldSuppressWake({ wakeConfig: infinite, reason: 'proactiveCheck', now: NOW, ownerBusy: true, lastWakeAt: NOW - 30 * 60000 }).suppress,
], [false, true]);
T('忙状态下 replyCheck 仍按普通规则（无人接话就压）', shouldSuppressWake({ wakeConfig: infinite, reason: 'replyCheck', ownerBusy: true, now: NOW }).why, 'reply-check-nobody-replied');
T('忙状态下 timeout 照旧放行', shouldSuppressWake({ wakeConfig: infinite, reason: 'timeout', ownerBusy: true, now: NOW }).why, 'other-timer');

console.log('\n【⑦ 边界与垃圾值（一律保守放行、不抛）】');
T('wakeConfig=null', shouldSuppressWake({ wakeConfig: null, reason: 'timeout', now: NOW }).suppress, false);
T('wakeConfig={} ', shouldSuppressWake({ wakeConfig: {}, reason: 'timeout', now: NOW }).suppress, false);
T('sleepUntil 垃圾值', shouldSuppressWake({ wakeConfig: { infinite: false, sleepUntil: 'pizza' }, reason: 'timeout', now: NOW }).why, 'other-timer');
T('reason=undefined', shouldSuppressWake({ wakeConfig: finiteAt6, reason: undefined, now: NOW }).why, 'not-timer-reason');
T('reason="" ', shouldSuppressWake({ wakeConfig: finiteAt6, reason: '', now: NOW }).why, 'not-timer-reason');
T('reason="timeout:xx" 冒号形态也认', shouldSuppressWake({ wakeConfig: finiteAt6, reason: 'timeout:xx', now: NOW }).why, 'before-alarm');
T('不传 now 也不抛', typeof shouldSuppressWake({ wakeConfig: infinite, reason: 'timeout' }).suppress, 'boolean');

console.log('\n【⑧ 辅助函数与默认值】');
T('baseReason 去 @seq', baseReason('replyCheck@seq88'), 'replyCheck');
T('baseReason 去冒号', baseReason('atMention:xx'), 'atMention');
T('isTimerWakeReason timeout', isTimerWakeReason('timeout'), true);
T('isTimerWakeReason atMention', isTimerWakeReason('atMention'), false);
T('DEFAULTS.proactiveMinGapMs = 0（不砍主动性）', DEFAULTS.proactiveMinGapMs, 0);
T('DEFAULTS.busyMinGapMs = 60min', DEFAULTS.busyMinGapMs, 60 * 60 * 1000);
T('DEFAULTS 里没有 ownerIdleMs（不再靠沉默推断走开）', 'ownerIdleMs' in DEFAULTS, false);

console.log(`\n===== PASS ${pass} / FAIL ${fail} =====`);
process.exit(fail === 0 ? 0 : 1);
