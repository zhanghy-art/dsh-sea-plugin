# dsh-sea

DSH 双层一生感架构 **v11.1** 的神经识海面板 —— 星云版。只有一套实现。

![识海](docs/screenshots/01-nebula.png)

## 与 11.1 的对应

| 11.1 | 这里 |
|---|---|
| §4.1 只读旁路 | 不启动不加载，崩了不影响对话 |
| §4.2 唯一实现 | 单文件后端 + 单文件前端，零第三方依赖（Node ≥ 22） |
| §4.3 API 契约 | 四个端点全部实现，字段名一致（`kind` / `color` 都认） |
| §4.4 前端规范 | 15 秒刷新 · 演示模式标注 · 点击侧栏 · 四激素仪表盘 |
| §4.5 功能清单 | 中心光球 / 节点配色 / 同簇连线 / 呼吸闪烁 / 拖拽缩放搜索 |
| §17.4.2 状态行 | 纯文字、不带数字、激素名不进提示词 |

**一处偏离**：§4.2 砍掉了 D3 力导向图，理由是「好看，但与『她像个人』无关，维护成本高」。
这一版把它做回来了——3D 体积布局 + 关联引力 + 云点相变。维护成本确实更高，
但记忆终于有质感了。既然只保留一套，就是这套。

## 跑起来

```bash
node sea/sea-server.mjs                 # 接真实库（readOnly 打开）
cd sea && python3 -m http.server 8080   # 只看演示数据（2421 条模拟记忆）
```

识海 `/neural-sea.html`　进化中枢 `/evolution.html`

## 目录

```
sea/     neural-sea.html · evolution.html · sea-server.mjs · demo/
tools/   模拟库生成 + 六张预览图的 Python 脚本
tests/   render.test.mjs（渲染 5 项断言）· evolution.test.mjs
docs/    design-notes.md（为什么这么做）+ 截图
```

## 三条不能破的

1. **只读**——数据库 readOnly 打开，任何写语句抛异常
2. **不占上下文**——面板不参与对话，激素数值不进提示词（§3.1.6）
3. **不装也能用**——不启动时开销为 0

## 测试

```bash
npm test          # 渲染 5 项断言 + 进化中枢断言
npm run preview   # 重出六张预览图（会先 dump 一次布局）
```

## License

MIT
