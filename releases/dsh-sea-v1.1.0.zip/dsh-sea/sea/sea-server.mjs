// sea-server.mjs —— 识海只读后端（v11.0 适配版）
// 兼容 v11.0 正文 4.3 契约 与 附录 A 两套路径；Node 22+ 直连 SQLite，否则进演示模式。
// 用法：node sea-server.mjs [--port=8765] [--db=~/.dsh/life/memory.db]

import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const argPort = (process.argv.find(a => a.startsWith('--port=')) || '').split('=')[1];
const argDb = (process.argv.find(a => a.startsWith('--db=')) || '').split('=')[1];
const PORT = Number(process.env.PORT || argPort || 8765);
const DB_PATH = (argDb || process.env.DSH_DB || path.join(os.homedir(), '.dsh', 'life', 'memory.db'))
  .replace(/^~/, os.homedir());

// ── 载入数据库（失败即演示模式） ───────────────────────────────
let db = null, dbErr = '';
try {
  const { DatabaseSync } = await import('node:sqlite');
  if (fs.existsSync(DB_PATH)) {
    db = new DatabaseSync(DB_PATH, { readOnly: true });
    db.prepare('SELECT count(*) FROM memories').get();
  } else {
    dbErr = `未找到 ${DB_PATH}`;
  }
} catch (e) {
  dbErr = `node:sqlite 不可用（需 Node ≥ 22）或打开失败：${e.message}`;
}

// ── effWeight（v11.0 修正版：空值回退 + 未来时间拒绝） ──────────
const HALF = { '人物': 180, '事实': 180, '群规': 180, '偏好': 90, '约定': 90, '事件': 60, '梗': 120 };
const FLOOR = { '人物': 0.35, '群规': 0.35 };
function effWeight(m, now = Date.now()) {
  const c = m.confirmed_at ?? m.created_at;
  if (!c || c > now) return 0;
  const days = (now - c) / 86400000;
  const half = HALF[m.category] ?? 90;
  const imp = 0.75 + 0.5 * (m.importance ?? 0.5);
  const sal = 1 + 0.35 * (m.emotional_salience ?? 0) + 0.25 * (m.relationship_salience ?? 0);
  const raw = 1.0 * Math.pow(0.5, days / half) * imp * sal;
  return Math.min(1, Math.max(FLOOR[m.category] ?? 0, raw));
}

// ── 演示数据：模拟两年的真实使用（2000–3000 条） ────────────
const P = ['小林', '阿哲', '你妈', '同事老周', '大学室友', '表姐', '前台姑娘', '房东'];
const T = ['上周三', '上个月', '前天', '去年冬天', '今年春天', '前几天', '上周末', '清明节那会儿'];
const L = ['公司楼下', '地铁上', '家里', '医院', '天台', '便利店', '会议室', '楼道'];
const TOPIC = ['加班', '答辩', '面试', '搬家', '发烧', '年终奖', '养猫', '健身', '失眠', '换工作',
  '相亲', '考驾照', '买电脑', '修水管', '同学聚会', '看牙', '裁员', '涨房租'];

const pickOne = (rnd, arr) => arr[Math.floor(rnd() * arr.length)];

function makeFact(rnd, category) {
  const p = pickOne(rnd, P), t = pickOne(rnd, T), l = pickOne(rnd, L), k = pickOne(rnd, TOPIC);
  switch (category) {
    case '人物': return pickOne(rnd, [
      `${p}是你${pickOne(rnd, ['发小', '表哥', '前同事', '邻居'])}，最近${pickOne(rnd, ['结婚了', '换工作了', '搬走了', '生病了'])}`,
      `你叫${pickOne(rnd, ['林深', '陈默', '周野'])}，做${pickOne(rnd, ['后端', '前端', '算法', '运维'])}`,
      `${p}有个孩子在上${pickOne(rnd, ['幼儿园', '小学', '初中'])}`,
    ]);
    case '事实': return pickOne(rnd, [
      `你住在${pickOne(rnd, ['杭州滨江', '杭州西湖区', '上海浦东', '深圳南山'])}`,
      `你${pickOne(rnd, ['每天通勤 40 分钟', '公司在 12 楼', '工位靠窗', '最近在学 Rust'])}`,
      `${t}你提到自己${pickOne(rnd, ['不吃香菜', '对芒果过敏', '左撇子', '近视 500 度'])}`,
    ]);
    case '偏好': return pickOne(rnd, [
      `你喜欢在${pickOne(rnd, ['深夜', '清晨', '午后'])}${pickOne(rnd, ['写代码', '看书', '发呆', '散步'])}`,
      `你${pickOne(rnd, ['喝美式不加糖', '讨厌空调直吹', '喜欢雨天', '受不了噪音'])}`,
      `你不喜欢${pickOne(rnd, ['别人迟到', '临时改需求', '电话沟通', '被催进度'])}`,
    ]);
    case '约定': return pickOne(rnd, [
      `说好${pickOne(rnd, ['每周日晚上', '每个月第一个周末'])}一起${pickOne(rnd, ['看一部电影', '吃顿好的', '复盘一次'])}`,
      `你答应过${pickOne(rnd, ['这个月早睡', '少喝咖啡', '把那本书看完'])}`,
      `${t}说好等${k}的事有结果，第一个告诉她`,
    ]);
    case '事件': return pickOne(rnd, [
      `${t}在${l}，你因为${k}发了很大的火`,
      `${t}你${k}到凌晨，说了一句「算了」就下线了`,
      `${t}在${l}聊到${p}，你沉默了很久`,
      `${t}${k}那件事终于有结果了，你连着发了好多条`,
      `${t}你在${l}哭了，说不想让任何人知道`,
    ]);
    case '梗': return pickOne(rnd, [
      `「${pickOne(rnd, ['再刷五分钟就睡', '这条 bug 一定是环境问题', '先睡，明天再说', '最后一次'])}」——你每次都这么说`,
      `你把${pickOne(rnd, ['猫', '键盘', '咖啡', '耳机'])}称为「${pickOne(rnd, ['命根子', '战友', '亲儿子'])}」`,
      `「${k}」这个词你说出口就想笑`,
    ]);
    case '群规': return '群里不许发广告、不许拉人、不许深夜刷屏';
    default: return `${t}提到${k}`;
  }
}

function seedRand(seed) {
  let s = seed;
  return () => (s = (s * 1103515245 + 12345) % 2147483648) / 2147483648;
}

function buildMock(n = 2400) {
  const rnd = seedRand(20261029);
  const now = Date.now();
  const DAYS = 730;
  const times = [];
  // 时间分布：越近越密（指数增长），5% 的日子是「聊了很多」的爆发日
  for (let d = DAYS; d >= 0 && times.length < n; d--) {
    const recency = Math.pow(1 - d / DAYS, 2.4);
    const burst = rnd() < 0.05;
    const c = burst ? 12 + Math.floor(rnd() * 22) : Math.floor(rnd() * 7 * recency);
    for (let k = 0; k < c && times.length < n; k++) {
      times.push(now - d * 86400000 - Math.floor(rnd() * 86400000));
    }
  }
  // 补足
  while (times.length < n) times.push(now - Math.floor(rnd() * DAYS) * 86400000);
  times.sort((a, b) => a - b);

  const CATS = [['事件', 34], ['事实', 20], ['偏好', 16], ['梗', 12], ['人物', 10], ['约定', 6], ['群规', 2]];
  const catPool = [];
  CATS.forEach(([c, w]) => { for (let i = 0; i < w; i++) catPool.push(c); });

  const out = [];
  for (let i = 0; i < n; i++) {
    const created = times[i];
    const ageDays = (now - created) / 86400000;
    const category = pickOne(rnd, catPool);
    const kind = category === '约定' ? 'promise' : (category === '事件' ? 'episode' : 'fact');

    // 召回：越新越可能被想起；老的偶发
    const recallP = Math.max(0.05, Math.exp(-ageDays / 220));
    const everRecalled = rnd() < recallP * 0.9;
    const lastRecalled = everRecalled
      ? created + Math.floor(rnd() * Math.min(ageDays, 60) * 86400000)
      : null;

    const baseSal = kind === 'episode' ? 0.55 : 0.32;
    const salience = Math.min(1, Math.max(0, baseSal + (rnd() - 0.5) * 0.7));
    const importance = Math.min(1, Math.max(0.2, (kind === 'episode' ? 0.5 : 0.55) + (rnd() - 0.5) * 0.6));

    const m = {
      id: 1000 + i,
      category,
      fact: makeFact(rnd, category),
      memory_kind: kind,
      importance,
      emotional_salience: salience,
      relationship_salience: rnd() * 0.6,
      recall_count: everRecalled ? 1 + Math.floor(rnd() * 8) : 0,
      created_at: created,
      confirmed_at: lastRecalled ?? created,
      last_recalled: lastRecalled,
      cold: 0,
      valid_to: null,
      subject_qq: 'owner',
    };
    m.effWeight = effWeight(m, now);

    // 时间转冷（人物/群规/高重要度豁免）
    if (category !== '人物' && category !== '群规' && importance < 0.9 && m.effWeight < 0.2) m.cold = 1;

    // 失效：只保留 90 天内的（更早的按归档规则已删除）
    if (ageDays < 90 && rnd() < 0.10) {
      m.valid_to = now - Math.floor(rnd() * Math.max(1, ageDays) * 86400000);
      if (m.valid_to <= created) m.valid_to = created + 86400000;
    }
    out.push(m);
  }
  return out;
}
const MOCK_N = Number(process.env.SEA_N || 2400);
const MOCK = buildMock(MOCK_N);

// ── 查询 ───────────────────────────────────────────────────────
function queryNodes(limit = 300, asOf = 0) {
  const now = asOf || Date.now();
  if (!db) {
    // 时间旅行：把「未来」的记忆过滤掉，其余按该时刻算权重
    const cut = MOCK.filter(m => m.created_at <= now).slice(0, limit);
    return cut.map(m => {
      const w = effWeight(m, now);
      const cold = (!m.valid_to && m.category !== '人物' && m.category !== '群规'
                    && (m.importance ?? 0.5) < 0.9 && w < 0.2) ? 1 : 0;
      const gone = m.valid_to && m.valid_to <= now;
      return { ...m, effWeight: w, cold, valid_to: gone ? m.valid_to : null };
    });
  }
  const rows = db.prepare(`
    SELECT id, category, fact, memory_kind, importance, emotional_salience,
           relationship_salience, recall_count, created_at, confirmed_at,
           last_recalled, cold, valid_to, subject_qq
    FROM memories
    WHERE raw = 0
    ORDER BY id DESC LIMIT ?`).all(limit);
  return rows.map(m => ({ ...m, effWeight: effWeight(m, now) }));
}
function ringOf(n) {
  if (n.valid_to) return 4;
  if (n.cold) return 3;
  if (n.effWeight >= 0.5) return (n.last_recalled && Date.now() - n.last_recalled < 7 * 86400000) ? 0 : 1;
  return 2;
}
let statCache = { at: 0, val: null };
function queryStats() {
  if (Date.now() - statCache.at < 5000 && statCache.val) return statCache.val;
  const nodes = queryNodes(100000);
  const now = Date.now();
  const rings = [0, 0, 0, 0, 0];
  const colors = { blue: 0, warm: 0, hot: 0, green: 0, cold: 0, ghost: 0 };
  let effSum = 0, oldest = 0;
  nodes.forEach(n => {
    rings[ringOf(n)]++;
    effSum += n.effWeight;
    if (!oldest || n.created_at < oldest) oldest = n.created_at;
    if (n.valid_to) colors.ghost++;
    else if (n.cold) colors.cold++;
    else if (n.emotional_salience > 0.6) colors.hot++;
    else if (n.emotional_salience > 0.35) colors.warm++;
    else if (n.memory_kind === 'promise') colors.green++;
    else colors.blue++;
  });
  const _out = {
    rings, colors,
    avgEff: nodes.length ? +(effSum / nodes.length).toFixed(3) : 0,
    spanDays: oldest ? Math.round((now - oldest) / 86400000) : 0,
    total: nodes.length,
    active: nodes.filter(n => !n.cold && !n.valid_to).length,
    cold: nodes.filter(n => n.cold && !n.valid_to).length,
    invalid: nodes.filter(n => n.valid_to).length,
    candidates: 0,
    narratives: 0,
  };
  statCache = { at: Date.now(), val: _out };
  return _out;
}
function queryHormones() {
  if (db) {
    try {
      const row = db.prepare('SELECT state_json FROM life_state WHERE id = 1').get();
      if (row) {
        const s = JSON.parse(row.state_json);
        return { ...s.hormones, needs: s.needs, energy: s.energy, phase: s.phase,
                 relationship: s.relationship, preset: s.flags?.preset, ts: Date.now() };
      }
    } catch { /* 落回默认 */ }
  }
  // 演示：缓慢漂移，让面板看起来是活的
  const t = Date.now() / 1000;
  const w = (base, amp, per, ph) => Math.round(base + amp * Math.sin(t / per + ph));
  return {
    cortisol: w(34, 6, 47, 0),
    dopamine: w(56, 8, 31, 1.7),
    oxytocin: w(44, 7, 61, 3.1),
    serotonin: w(57, 5, 89, 0.6),
    needs: {
      social: 0.42 + 0.05 * Math.sin(t / 53),
      curiosity: 0.51 + 0.04 * Math.sin(t / 41 + 1),
      play: 0.47 + 0.06 * Math.sin(t / 37 + 2),
      achievement: 0.55 + 0.03 * Math.sin(t / 61 + 3),
      recognition: 0.38 + 0.05 * Math.sin(t / 43 + 4),
      rest: 0.33 + 0.04 * Math.sin(t / 71 + 5),
    },
    energy: 0.72 + 0.1 * Math.sin(t / 120),
    phase: phaseOf(new Date()),
    relationship: { subjectId: 'owner', closeness: 0.68, trust: 0.74, stage: '熟悉' },
    preset: 'solo-qq',
    ts: Date.now(),
  };
}
function phaseOf(d) {
  const h = d.getHours();
  if (h >= 6 && h < 9) return 'morning';
  if (h >= 9 && h < 14) return 'peak';
  if (h >= 14 && h < 17) return 'afternoon';
  if (h >= 17 && h < 23) return 'evening';
  return 'night';
}

// ── HTTP ───────────────────────────────────────────────────────
const json = (res, data, code = 200) => {
  const body = JSON.stringify(data);
  res.writeHead(code, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'Access-Control-Allow-Origin': '*',
  });
  res.end(body);
};

const server = http.createServer((req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const p = url.pathname;

  // v11.0 正文 4.3 契约
  if (p === '/api/sea/nodes') {
    const limit = Math.min(5000, Number(url.searchParams.get('limit') || 300));
    const asOf = Number(url.searchParams.get('asOf') || 0);
    return json(res, { nodes: queryNodes(limit, asOf), ts: Date.now(), asOf });
  }
  if (p === '/api/sea/hormones') return json(res, queryHormones());
  if (p === '/api/sea/stats') return json(res, { ...queryStats(), mode: db ? 'live' : 'demo', dbErr });
  if (p === '/api/sea/search') {
    const q = (url.searchParams.get('q') || '').trim();
    const nodes = queryNodes(100000).filter(n => q && n.fact.includes(q));
    return json(res, { nodes });
  }

  // v11.0 附录 A 路径（别名，避免文档两套对不上）
  if (p === '/api/state') return json(res, queryHormones());
  if (p === '/api/memories') {
    const limit = Math.min(1000, Number(url.searchParams.get('limit') || 300));
    return json(res, { items: queryNodes(limit), total: queryStats().total });
  }
  if (p === '/api/events') {
    const nodes = queryNodes(100000)
      .filter(n => n.last_recalled && Date.now() - n.last_recalled < 86400000)
      .sort((a, b) => b.last_recalled - a.last_recalled).slice(0, 50);
    return json(res, { events: nodes.map(n => ({ at: n.last_recalled, id: n.id, fact: n.fact })) });
  }
  if (p === '/api/why') {
    const id = Number(url.searchParams.get('id'));
    const n = queryNodes(100000).find(x => x.id === id);
    if (!n) return json(res, { error: 'not_found' }, 404);
    const c = n.confirmed_at ?? n.created_at;
    const days = (Date.now() - c) / 86400000;
    return json(res, {
      id, effWeight: n.effWeight, days: Math.round(days),
      halfLife: HALF[n.category] ?? 90,
      importanceFactor: 0.75 + 0.5 * n.importance,
      salienceFactor: 1 + 0.35 * n.emotional_salience + 0.25 * n.relationship_salience,
      cold: n.cold, valid_to: n.valid_to,
    });
  }
  // 进化中枢：24h 状态曲线（48 个采样点）
  if (p === '/api/sea/timeline') {
    const h = queryHormones();
    const now = Date.now();
    const STEP = 30 * 60 * 1000;
    const N = 48;
    // 用当前值做锚点，往回推一条有起伏的曲线；真库有 history 表时应改为读表
    const seed = (i) => { let x = i * 9301 + 49297; x = (x * 233) % 233280; return x / 233280; };
    const pts = [];
    for (let i = N - 1; i >= 0; i--) {
      const t = now - i * STEP;
      const hour = new Date(t).getHours();
      const dayK = Math.sin((hour - 6) / 24 * Math.PI * 2) * 0.5 + 0.5;   // 昼夜
      const drift = 1 - i / N;                                            // 越早越接近基线
      const wave = (k) => {
        const base = { cortisol: 30, dopamine: 50, oxytocin: 40, serotonin: 60 }[k];
        const cur = h[k] ?? base;
        const amp = { cortisol: 9, dopamine: 12, oxytocin: 8, serotonin: 7 }[k];
        const v = base + (cur - base) * drift
          + Math.sin(i * 0.42 + k.length) * amp * 0.45 * (1 - drift * 0.5)
          + (seed(i + k.length * 7) - 0.5) * amp * 0.7;
        return Math.round(Math.max(5, Math.min(100, v)));
      };
      pts.push({
        t,
        cortisol: wave('cortisol'), dopamine: wave('dopamine'),
        oxytocin: wave('oxytocin'), serotonin: wave('serotonin'),
        energy: Math.round(20 + 70 * dayK + (seed(i) - 0.5) * 12),
      });
    }
    return json(res, { points: pts, ts: now });
  }

  // 进化中枢用：整库 + 统计（字段名对齐 library.json 的 items/text）
  if (p === '/api/sea/dump') {
    const nodes = queryNodes(5000);
    return json(res, {
      items: nodes.map(n => ({ ...n, text: n.fact })),
      stats: queryStats(),
      generated_at: Date.now(),
      mode: db ? 'live' : 'demo',
    });
  }

  // 一次性拿全（前端首屏用，省三次往返）
  if (p === '/api/sea/all') {
    const asOf = Number(url.searchParams.get('asOf') || 0);
    return json(res, {
      nodes: queryNodes(5000, asOf), hormones: queryHormones(), stats: queryStats(), asOf,
      mode: db ? 'live' : 'demo', dbErr, ts: Date.now(),
    });
  }

  // 静态文件
  let file = p === '/' ? '/neural-sea.html' : p;
  const full = path.join(__dirname, path.normalize(file).replace(/^(\.\.[/\\])+/, ''));
  if (fs.existsSync(full) && fs.statSync(full).isFile()) {
    const ext = path.extname(full);
    const type = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
                   '.css': 'text/css; charset=utf-8', '.png': 'image/png', '.svg': 'image/svg+xml' }[ext] || 'application/octet-stream';
    res.writeHead(200, { 'Content-Type': type, 'Cache-Control': 'no-store' });
    return fs.createReadStream(full).pipe(res);
  }
  res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
  res.end('404');
});

server.listen(PORT, '127.0.0.1', () => {
  console.log(`识海 · http://127.0.0.1:${PORT}`);
  console.log(`数据源：${db ? 'LIVE ' + DB_PATH : 'DEMO（' + dbErr + '）'}`);
});
