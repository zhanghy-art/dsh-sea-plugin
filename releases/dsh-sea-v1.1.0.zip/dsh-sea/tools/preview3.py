#!/usr/bin/env python3
import os
# preview3.py —— 用前端导出的真实布局出静态预览
# 对齐 v7 的三件事：不规则纤维星云 / 颜色随缩放切换 / LOD 文字
import json, math, os
import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

REG = '/usr/local/share/fonts/custom/NotoSansSC-Regular.ttf'
F = lambda s: ImageFont.truetype(REG, s)
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'docs', 'screenshots') + '/'
BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'sea', 'demo') + '/'
LIB = json.load(open(BASE + 'library.json'))
ITEMS = {m['id']: m for m in LIB['items']}


def load(name):
    return json.load(open(BASE + name))


def hsv2rgb(h, s, l):
    import colorsys
    r, g, b = colorsys.hls_to_rgb((h % 360) / 360.0, max(0, min(1, l / 100)), max(0, min(1, s / 100)))
    return np.array([r, g, b], np.float32)


# ══ 噪声：与前端同一套约定（256 网格 + 双线性 + 取模平铺）═════
rng = np.random.default_rng(11)
GSIZE = 256
_G = None


def _grid():
    global _G
    if _G is None:
        _G = rng.random((GSIZE, GSIZE)).astype(np.float32)
    return _G


def nval(x, y):
    g = _grid()
    xi = np.floor(x)
    yi = np.floor(y)
    xf = x - xi
    yf = y - yi
    i0 = xi.astype(np.int64) % GSIZE
    j0 = yi.astype(np.int64) % GSIZE
    i1 = (i0 + 1) % GSIZE
    j1 = (j0 + 1) % GSIZE
    v00 = g[j0, i0]; v10 = g[j0, i1]
    v01 = g[j1, i0]; v11 = g[j1, i1]
    u = xf * xf * (3 - 2 * xf)
    v = yf * yf * (3 - 2 * yf)
    return (v00 * (1 - u) + v10 * u) * (1 - v) + (v01 * (1 - u) + v11 * u) * v


def fbm(x, y, oct_=4):
    amp, f, acc, norm = 0.5, 1.0, 0.0, 0.0
    for _ in range(oct_):
        acc = acc + amp * nval(x * f, y * f)
        norm += amp
        f *= 2.03
        amp *= 0.5
    return acc / norm


def ridged(x, y, oct_=4):
    amp, f, acc, norm = 0.5, 1.0, 0.0, 0.0
    for _ in range(oct_):
        v = nval(x * f, y * f)
        acc = acc + amp * (1 - np.abs(v * 2 - 1))
        norm += amp
        f *= 2.07
        amp *= 0.52
    return acc / norm


# ══ 气体层：不规则纤维 + 暗尘埃带（表达式与 buildGas 一一对应）═══
def smoothstep(a, b, x):
    t = np.clip((x - a) / (b - a), 0, 1)
    return t * t * (3 - 2 * t)


def build_gas(sz=720):
    yy, xx = np.mgrid[0:sz, 0:sz].astype(np.float32)
    c, rad = sz / 2, sz * 0.47
    dx = (xx - c) / rad
    dy = (yy - c) / rad
    rr = np.hypot(dx, dy)
    A = 0.62
    ca, sa = math.cos(A), math.sin(A)

    w1 = fbm(dx * 1.6 + 11.3, dy * 1.6 + 4.7, 3) - 0.5
    w2 = fbm(dx * 1.6 + 3.1, dy * 1.6 + 19.4, 3) - 0.5
    bx = dx + w1 * 0.52
    by = dy + w2 * 0.52

    rx = bx * ca + by * sa
    ry = -bx * sa + by * ca

    fil1 = ridged(rx * 3.4 + 1.7, ry * 11.0 + 8.9, 5)
    fil2 = ridged(rx * 8.5 + 13.1, ry * 24.0 + 4.4, 4)
    fil4 = ridged(rx * 18.0 + 3.7, ry * 40.0 + 6.1, 3)
    big = fbm(bx * 2.0 + 5.1, by * 2.0 + 2.3, 4)

    dens = big * 0.30 + fil1 * 0.42 + fil2 * 0.28
    dens = np.power(np.clip(dens, 0, 1), 1.15) * 2.15
    dens *= (0.62 + 0.44 * fil4)

    lv = fbm(rx * 2.6 + 31.7, ry * 6.0 + 7.2, 5)
    dens *= (1 - (1 - smoothstep(0.010, 0.072, np.abs(lv - 0.5))) * 0.97)
    lv2 = fbm(rx * 7.5 + 9.9, ry * 12.0 + 21.1, 4)
    dens *= (1 - (1 - smoothstep(0.004, 0.030, np.abs(lv2 - 0.5))) * 0.72)

    th = np.arctan2(dy, dx)
    wob = fbm(np.cos(th) * 1.7 + 7.1, np.sin(th) * 1.7 + 3.4, 4)
    rEdge = 1.05 + (wob - 0.5) * 0.78
    dens *= np.power(np.clip(1 - rr / rEdge, 0, 1), 0.38)
    dens += np.power(np.clip(1 - rr / 0.19, 0, 1), 3.2) * 0.44
    dens = np.clip(dens, 0, 1.35)

    t = np.clip(dens, 0, 1)
    e = np.power(t, 0.78)
    hm = fbm(bx * 2.2 + 50.3, by * 2.2 + 20.7, 3)
    mag = np.clip((hm - 0.44) * 2.8, 0, 1)
    warm = np.clip((0.18 - rr) * 5.6, 0, 1)
    rim = np.clip((rr - 0.58) * 2.2, 0, 1)

    r = 14 + 104 * np.power(e, 2.00) + mag * 118 * e + warm * 74 * e - rim * 24 * e
    g = 16 + 46 * np.power(e, 1.75) + mag * 18 * e + warm * 40 * e + rim * 20 * e
    b = 56 + 168 * np.power(e, 0.78) + mag * 34 * e - warm * 26 * e + rim * 32 * e
    a = np.power(t, 0.42) * 248 * smoothstep(1.34, 0.62, rr)
    rgba = np.dstack([np.clip(r, 0, 255), np.clip(g, 0, 255),
                      np.clip(b, 0, 255), np.clip(a, 0, 255)]).astype(np.uint8)
    dens_field = None
    return Image.fromarray(rgba, 'RGBA'), np.clip(t, 0, 1)


print('build gas…')
GAS, GASD = build_gas()


def build_particles(n=9000):
    r2 = np.random.default_rng(31)
    M = n * 26
    u = r2.uniform(-1, 1, M)
    th = r2.uniform(0, 2 * np.pi, M)
    sr = np.cbrt(r2.uniform(0, 1, M)) * 0.97
    rr = np.sqrt(np.clip(1 - u * u, 0, 1))
    nx = rr * np.cos(th) * sr
    ny = u * sr * 0.80
    nz = rr * np.sin(th) * sr * 0.92
    h, w = GASD.shape
    gx = np.clip(((nx * 0.5 + 0.5) * w).astype(int), 0, w - 1)
    gy = np.clip(((ny * 0.5 + 0.5) * h).astype(int), 0, h - 1)
    dens = GASD[gy, gx]
    keep = r2.uniform(0, 1, M) <= dens * 1.25 + 0.04
    idx = np.where(keep)[0][:n]
    sz = 0.55 + r2.uniform(0, 1, len(idx)) * 1.05
    br = 0.16 + r2.uniform(0, 1, len(idx)) * 0.62
    ph = r2.uniform(0, 2 * np.pi, len(idx))
    return np.stack([nx[idx], ny[idx], nz[idx], sz, br, ph], 1).astype(np.float32)


PARTS = build_particles()


def density_at(nx, ny):
    h, w = GASD.shape
    gx = int(min(w - 1, max(0, (nx * 0.5 + 0.5) * w)))
    gy = int(min(h - 1, max(0, (ny * 0.5 + 0.5) * h)))
    return float(GASD[gy, gx])


def gauss_kernel(rad):
    r = int(rad)
    y, x = np.mgrid[-r:r + 1, -r:r + 1].astype(np.float32)
    d2 = (x * x + y * y) / (r * r + 1e-6)
    k = np.exp(-d2 * 2.2)
    return k / k.max()


KERNELS = {r: gauss_kernel(r) for r in range(1, 18)}


def node_rgb(n, k):
    h1, s1, l1 = n['nh'], n['nsa'], n['nl']
    h2, s2, l2 = n['h'], n['sa'], n['l']
    dh = ((h2 - h1 + 540) % 360) - 180
    h = h1 + dh * k
    s = s1 + (s2 - s1) * k
    l = l1 + (l2 - l1) * k
    if n['inv']:
        s *= 0.12; l *= 0.70
    elif n['cold']:
        s *= 0.52; l *= 0.74
    return hsv2rgb(h, max(0, s), max(0, l))


def render(cam_s, labels=False, focus=None, lay=None, gas_k=1.0):
    """节点坐标直接取前端投影结果（sx/sy/kk/z），这里只补缩放与合成"""
    L = lay or load('layout.json')
    W, H, R, CX, CY = L['W'], L['H'], L['R'], L['cx'], L['cy']
    NODES, EDGES = L['nodes'], L['edges']
    YAW, PITCH = L.get('yaw', 0.34), L.get('pitch', 0.22)
    k = max(0.0, min(1.0, (cam_s - 1.10) / 0.55))
    cp = max(0.34, math.cos(PITCH))

    img = Image.new('RGB', (W, H), (2, 4, 8))

    # ① 气体：三层视差，各自压扁 + 错位
    layers = [(1.34, 0.38, 0.06, 0.04, 0.0), (1.10, 0.46, 0.14, 0.09, 2.1),
              (0.96, 0.72, 0.24, 0.15, 4.2), (0.78, 0.40, 0.36, 0.22, 1.1),
              (0.62, 0.26, 0.48, 0.30, 3.3)]
    gas_acc = np.zeros((H, W, 3), np.float32)
    for sc, a, px, py, ph in layers:
        gw = int(R * 2.06 * cam_s * sc)
        g = GAS.resize((gw, gw), Image.BILINEAR)
        sx0 = (math.sin(YAW + ph) - math.sin(ph)) * R * px * 2.4 * cam_s
        sy0 = (math.sin(PITCH + ph) - math.sin(ph)) * R * py * 3.0 * cam_s
        dx = int(CX + sx0 - gw / 2)
        dy = int(CY - sy0 - gw / 2)
        lay_img = Image.new('RGB', (W, H), (0, 0, 0))
        lay_img.paste(g.convert('RGB'), (dx, dy), g.split()[3])
        gas_acc += np.asarray(lay_img, np.float32) * a
    gas_acc *= 0.92 * (1 - 0.62 * k) * gas_k
    img = Image.fromarray(np.clip(np.asarray(img, np.float32) + np.clip(gas_acc, 0, 400), 0, 255).astype(np.uint8))

    # ②' 星云微尘：放大时云散成点
    if k > 0.03 and len(PARTS):
        cyw, syw = math.cos(YAW), math.sin(YAW)
        cpt, spt = math.cos(PITCH), math.sin(PITCH)
        X1 = PARTS[:, 0] * cyw - PARTS[:, 2] * syw
        Z1 = PARTS[:, 0] * syw + PARTS[:, 2] * cyw
        Y2 = PARTS[:, 1] * cpt - Z1 * spt
        Z2 = PARTS[:, 1] * spt + Z1 * cpt
        KK = 1000 / np.maximum(120, 960 + Z2 * R) * cam_s
        PXp = CX + X1 * R * KK
        PYp = CY + Y2 * R * KK
        SZp = np.maximum(0.5, PARTS[:, 3] * KK * 1.4)
        ok = (PXp > -20) & (PXp < W + 20) & (PYp > -20) & (PYp < H + 20)
        part = Image.new('RGBA', (W, H), (0, 0, 0, 0))
        pd = ImageDraw.Draw(part)
        a0 = int(255 * k * 0.50)
        for tier, lo, hi in ((0, 0.0, 0.30), (1, 0.30, 0.52), (2, 0.52, 1.0)):
            m = ok & (PARTS[:, 4] >= lo) & (PARTS[:, 4] < hi)
            col = (int(190 * (0.6 + tier * 0.2)), int(150 * (0.6 + tier * 0.2)), 255, int(a0 * (0.45 + tier * 0.32)))
            for i in np.where(m)[0]:
                z_ = SZp[i]
                pd.ellipse([PXp[i] - z_ / 2, PYp[i] - z_ / 2, PXp[i] + z_ / 2, PYp[i] + z_ / 2], fill=col)
        img = Image.fromarray(np.clip(np.asarray(img, np.float32) +
                             np.asarray(part.convert('RGB'), np.float32) * (k * 0.6), 0, 255).astype(np.uint8))

    # ③ 星点：按深度分三段
    def px_of(n):
        return CX + (n['sx'] - CX) * cam_s, CY + (n['sy'] - CY) * cam_s

    vis = []
    for n in NODES:
        sx, sy = px_of(n)
        if sx < -40 or sx > W + 40 or sy < -40 or sy > H + 40:
            continue
        if n['inv'] and cam_s < 1.2:
            continue
        vis.append((n, sx, sy))
    vis.sort(key=lambda p: p[0]['z'])

    SEGS = 5
    seg = max(1, math.ceil(len(vis) / SEGS))
    for sgi in range(SEGS):
        part = vis[sgi * seg:(sgi + 1) * seg]
        if not part:
            continue
        al = [0.34, 0.52, 0.70, 0.88, 1.05][sgi] * (1 - 0.30 * k)
        sc2 = [0.72, 0.86, 1.0, 1.14, 1.30][sgi]
        dots = Image.new('RGBA', (W, H), (0, 0, 0, 0))
        dd = ImageDraw.Draw(dots)
        for n, sx, sy in part:
            rgb = node_rgb(n, k)
            dens = density_at(n['x'] / R, n['y'] / R)
            shade = 0.30 + 0.70 * dens
            wgt = min(1.0, n['w'])
            rad = max(0.7, n['s'] * n['kk'] * cam_s * 0.40 * sc2
                      * (0.40 + 0.74 * wgt ** 0.85) * shade)
            a = int(255 * al * (0.92 if not n['inv'] else 0.35))
            if focus is not None and n['id'] != focus:
                a = int(a * 0.14)
            dd.ellipse([sx - rad, sy - rad, sx + rad, sy + rad],
                       fill=tuple(int(c * 255) for c in rgb) + (a,))
        img = Image.alpha_composite(img.convert('RGBA'), dots).convert('RGB')

    # ④ 亮星：光晕 + 星芒
    acc = np.zeros((H, W, 3), np.float32)
    ov2 = Image.new('RGBA', (W, H), (0, 0, 0, 0))
    od2 = ImageDraw.Draw(ov2)
    for n, sx, sy in vis:
        if n['w'] < 0.62:
            continue
        if focus is not None and n['id'] != focus:
            continue
        rgb = node_rgb(n, k)
        dens = density_at(n['x'] / R, n['y'] / R)
        shade = 0.35 + 0.65 * dens
        rad = max(2, int(n['s'] * n['kk'] * cam_s * 2.6))
        kk = KERNELS[min(16, rad)]
        r0 = kk.shape[0] // 2
        x0, y0 = int(sx) - r0, int(sy) - r0
        if 0 <= x0 and 0 <= y0 and x0 + kk.shape[1] <= W and y0 + kk.shape[0] <= H:
            acc[y0:y0 + kk.shape[0], x0:x0 + kk.shape[1]] += kk[..., None] * rgb * (min(0.85, (n['w'] - 0.55) * 1.4) * shade)
        if n['top'] or n['w'] > 0.78:
            L1 = max(2, n['s'] * n['kk'] * cam_s * 1.6)
            L2 = L1 * 3.0
            c = (255, 252, 240, 110)
            od2.line([(sx - L1, sy), (sx - L2, sy)], fill=c, width=1)
            od2.line([(sx + L1, sy), (sx + L2, sy)], fill=c, width=1)
            od2.line([(sx, sy - L1), (sx, sy - L2)], fill=c, width=1)
            od2.line([(sx, sy + L1), (sx, sy + L2)], fill=c, width=1)
    if focus is not None:
        for n, sx, sy in vis:
            if n['id'] != focus:
                continue
            rgb = node_rgb(n, 1.0)
            rad = max(2, min(16, int(max(3.0, n['s'] * 1.4) * 2.2)))
            kk = KERNELS[rad]
            r0 = kk.shape[0] // 2
            x0, y0 = int(sx) - r0, int(sy) - r0
            if 0 <= x0 and 0 <= y0 and x0 + kk.shape[1] <= W and y0 + kk.shape[0] <= H:
                acc[y0:y0 + kk.shape[0], x0:x0 + kk.shape[1]] += kk[..., None] * rgb * 1.5
    img = Image.alpha_composite(img.convert('RGBA'), ov2).convert('RGB')

    # ⑤ 弧线
    arcK = (1 - 0.55 * k)
    line = Image.new('L', (W, H), 0)
    ld = ImageDraw.Draw(line)
    glow = Image.new('L', (W, H), 0)
    gd = ImageDraw.Draw(glow)
    flow = Image.new('RGB', (W, H), (0, 0, 0))
    fd = ImageDraw.Draw(flow)
    for e in EDGES:
        ax = CX + (e['ax'] - CX) * cam_s
        ay = CY + (e['ay'] - CY) * cam_s
        bx = CX + (e['bx'] - CX) * cam_s
        by = CY + (e['by'] - CY) * cam_s
        dx, dy = bx - ax, by - ay
        ln = math.hypot(dx, dy) or 1
        bend = min(ln * 0.22, 34 * cam_s)
        ccx, ccy = (ax + bx) / 2 - dy / ln * bend, (ay + by) / 2 + dx / ln * bend
        pts = []
        for i in range(25):
            t = i / 24
            u = 1 - t
            pts.append((u * u * ax + 2 * u * t * ccx + t * t * bx,
                        u * u * ay + 2 * u * t * ccy + t * t * by))
        ld.line(pts, fill=int(90 * arcK), width=1)
        gd.line(pts, fill=int(64 * arcK), width=3)

        t = (e['ph'] * 0.83 + 0.31) % 1.0
        for kk in range(4, 0, -1):
            q = t - 0.045 * kk
            if q < 0 or q > 1:
                continue
            u = 1 - q
            qx = u * u * ax + 2 * u * q * ccx + q * q * bx
            qy = u * u * ay + 2 * u * q * ccy + q * q * by
            v = int(70 - kk * 12)
            fd.ellipse([qx - 1.6, qy - 1.6, qx + 1.6, qy + 1.6], fill=(v + 90, v + 130, v + 160))
        u = 1 - t
        hx = u * u * ax + 2 * u * t * ccx + t * t * bx
        hy = u * u * ay + 2 * u * t * ccy + t * t * by
        fd.ellipse([hx - 3.2, hy - 3.2, hx + 3.2, hy + 3.2], fill=(60, 96, 130))
        fd.ellipse([hx - 1.5, hy - 1.5, hx + 1.5, hy + 1.5], fill=(255, 255, 255))

    glow = glow.filter(ImageFilter.GaussianBlur(2.2))
    acc += (np.asarray(line, np.float32) / 255)[..., None] * np.array([0.80, 0.90, 1.0], np.float32) * 0.28
    acc += (np.asarray(glow, np.float32) / 255)[..., None] * np.array([0.55, 0.75, 1.0], np.float32) * 0.13
    acc += np.asarray(flow, np.float32) * 0.85 * arcK

    # ⑥ 中心核
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
    d = np.hypot(xx - CX, yy - CY)
    fade_core = max(0.0, min(1.0, 1.75 - 0.48 * cam_s))
    if fade_core > 0.01:
        shrink = cam_s ** -0.62
        core = np.exp(-np.power(d / (11 * cam_s * shrink + 6), 1.6)) * 0.78 * fade_core
        halo = np.exp(-np.power(d / (66 * cam_s * shrink + 18), 1.2)) * 0.34 * fade_core
        for ch, va in enumerate((1.0, 0.93, 0.80)):
            acc[..., ch] += (core * va + halo * va * 0.8) * 255

    out = Image.fromarray(np.clip(np.asarray(img, np.float32) + np.clip(acc, 0, 255), 0, 255).astype(np.uint8))
    vg = np.clip((np.hypot(xx - CX, yy - CY) / (max(W, H) * 0.62)) ** 2.2, 0, 1) * 0.56
    out = Image.fromarray((np.asarray(out, np.float32) * (1 - vg[..., None])).astype(np.uint8))

    # ⑦ LOD 文字
    if labels:
        d2 = ImageDraw.Draw(out)
        occ = set()
        span = min(W, H) * 0.42
        cand = [(n, sx, sy) for n, sx, sy in vis if math.hypot(sx - CX, sy - CY) <= span]
        buckets = {}
        for item in cand:
            key = (int(item[1] / 132), int(item[2] / 58))
            cur = buckets.get(key)
            if cur is None or item[0]['w'] > cur[0]['w']:
                buckets[key] = item
        cand = sorted(buckets.values(), key=lambda p: -p[0]['w'])[:26]
        CW, CH = 118, 26
        for n, sx, sy in cand:
            it = ITEMS.get(n['id'], {})
            full_txt = it.get('text', '')
            txt = full_txt[:5] + ('…' if len(full_txt) > 5 else '')
            r = n['s'] * n['kk'] * cam_s + 6
            tx, ty = sx + r, sy
            key = (int(tx / CW), int(ty / CH))
            if key in occ:
                continue
            occ.add(key)
            a = 0.34 + 0.52 * min(1, n['w'] * 1.4)
            rgb = node_rgb(n, 1.0)
            d2.text((tx, ty), txt, font=F(11.5),
                    fill=tuple(int(c * 255) for c in rgb) + (int(a * 255),),
                    anchor='lm', stroke_width=2, stroke_fill=(2, 4, 8, int(a * 190)))

    return out


def spaced(d, xy, text, font, fill, sp=6):
    x, y = xy
    for ch in text:
        d.text((x, y), ch, font=font, fill=fill, anchor='lm')
        x += font.getbbox(ch)[2] + sp


def hud(img, zoom, counts=(2421, 1088, 1186, 49)):
    W, H = img.size
    d = ImageDraw.Draw(img, 'RGBA')
    spaced(d, (26, 34), '识 海', F(15), (234, 245, 255))
    d.text((26, 58), 'solo-qq', font=F(10), fill=(107, 127, 148))
    hs = [('皮质醇', 46, (255, 77, 109)), ('多巴胺', 61, (255, 209, 102)),
          ('催产素', 68, (74, 222, 128)), ('血清素', 55, (110, 198, 255))]
    for i, (k, v, c) in enumerate(hs):
        x = 26 + i * 72
        d.text((x, 92), k, font=F(9), fill=(107, 127, 148))
        d.text((x, 112), str(v), font=F(19), fill=c)
        d.line([(x, 138), (x + 56, 138)], fill=(255, 255, 255, 18))
        d.line([(x, 138), (x + 56 * v / 100, 138)], fill=c + (140,))

    for i, (v, k) in enumerate(zip(counts, ('记忆', '活跃', '冷存', '失效'))):
        x = W - 26 - (3 - i) * 78
        d.text((x, 44), str(v), font=F(17), fill=(207, 227, 245), anchor='ra')
        d.text((x, 66), k, font=F(9), fill=(107, 127, 148), anchor='ra')

    leg = [('人物', (268, 64, 68)), ('事实', (205, 64, 68)), ('偏好', (168, 58, 62)),
           ('约定', (45, 72, 64)), ('事件', (342, 66, 64)), ('梗', (92, 54, 58)),
           ('群规', (190, 52, 56))]
    d.text((26, 690), '放大后：颜色 = 类型 × 情绪', font=F(9), fill=(78, 95, 112))
    for i, (k, (h, s, l)) in enumerate(leg):
        c = tuple(int(v * 255) for v in hsv2rgb(h, s, l))
        y = 710 + i * 17
        d.ellipse([26, y - 3, 32, y + 3], fill=c)
        d.text((42, y), k, font=F(9), fill=(78, 95, 112))
    d.text((26, 838), '缩小后：点用星云本色，看的是整体形状', font=F(9), fill=(57, 72, 90))
    d.text((26, 856), '半径越外，记得越浅', font=F(9), fill=(57, 72, 90))

    d.text((W - 26, 856), '拖拽 平移 · 滚轮 缩放 · 点击 展开 · 双击 复位', font=F(10), fill=(78, 95, 112), anchor='ra')
    d.text((W - 26, 874), f'演示数据 · 2421 节点 · {zoom}', font=F(10), fill=(78, 95, 112), anchor='ra')
    d.rectangle([26, 818, 256, 846], outline=(120, 190, 255, 34))
    d.text((38, 832), '搜索记忆…', font=F(11), fill=(65, 80, 95), anchor='lm')
    return img


if __name__ == '__main__':
    print('render 缩小态…')
    a = hud(render(1.0, labels=False), '1.00× · 星云本色')
    a.save(OUT + '01-nebula.png')

    print('render 放大态…')
    b = hud(render(2.6, labels=True), '2.60× · 编码色')
    b.save(OUT + '02-zoom.png')
    print('done')
