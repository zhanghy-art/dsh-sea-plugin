#!/usr/bin/env python3
import os
# state_card_preview.py —— 「她此刻」状态卡的静态预览
import math, os
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import numpy as np

REG = '/usr/local/share/fonts/custom/NotoSansSC-Regular.ttf'
F = lambda s: ImageFont.truetype(REG, s)
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'docs', 'screenshots') + '/'
BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'sea', 'demo') + '/'

W, H = 540, 700
img = Image.new('RGB', (W, H), (4, 6, 11))

yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
arr = np.asarray(img, np.float32).copy()
for (cx, cy, rx, ry, col, a) in [(W*0.5, 40, 420, 260, (120, 80, 200), 0.22),
                                  (W*0.2, H*0.9, 320, 240, (60, 90, 180), 0.12)]:
    dd = np.sqrt(((xx-cx)/rx)**2 + ((yy-cy)/ry)**2)
    mm = np.clip(1 - dd, 0, 1) ** 2
    for i in range(3):
        arr[..., i] += mm * col[i] * a
img = Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8))

CW, CH = 356, 452
CX0, CY0 = (W - CW) // 2, 92

glow = Image.new('RGBA', (CW + 60, CH + 60), (0, 0, 0, 0))
gd = ImageDraw.Draw(glow)
gd.rounded_rectangle([30, 30, CW + 30, CH + 30], radius=14, outline=(140, 120, 255, 48), width=12)
glow = glow.filter(ImageFilter.GaussianBlur(15))
gcanvas = Image.new('RGB', (W, H), (0, 0, 0))
gcanvas.paste(glow.convert('RGB'), (CX0 - 30, CY0 - 30), glow)
img = Image.fromarray(np.clip(np.asarray(img, np.float32) +
                              np.asarray(gcanvas, np.float32) * 0.55, 0, 255).astype(np.uint8))

card = Image.new('RGBA', (CW, CH), (0, 0, 0, 0))
cd = ImageDraw.Draw(card)
for y in range(CH):
    t = y / CH
    cd.line([(0, y), (CW, y)],
            fill=(int(16 * (1 - t) + 6 * t), int(21 * (1 - t) + 9 * t),
                  int(31 * (1 - t) + 14 * t), 250))
cd.rounded_rectangle([0, 0, CW - 1, CH - 1], radius=10, outline=(150, 195, 255, 52), width=1)
for i in range(CW):
    a = int(130 * max(0, 1 - abs(i - CW * 0.35) / (CW * 0.55)) ** 2)
    cd.line([(i, 0), (i, 1)], fill=(190, 170, 255, a))
img.paste(card, (CX0, CY0), card)

d = ImageDraw.Draw(img, 'RGBA')
X = CX0 + 24
y = CY0 + 24

d.text((X, y), '她 此 刻', font=F(10), fill=(91, 112, 133))
d.text((CX0 + CW - 24, y), 'EVENING', font=F(9), fill=(126, 150, 176), anchor='ra')
y += 22
d.text((X, y), '傍晚，有点提不起劲，心里踏实', font=F(10.5), fill=(157, 178, 198))
y += 22
d.line([(X, y), (CX0 + CW - 24, y)], fill=(255, 255, 255, 16))
y += 18

ROWS = [
    ('精力', 0.80, '80', (251, 146, 60), (180, 83, 9)),
    ('皮质醇', 0.35, '35', (251, 113, 133), (220, 38, 38)),
    ('多巴胺', 0.55, '55', (251, 191, 36), (180, 83, 9)),
    ('催产素', 0.41, '41', (249, 168, 212), (251, 207, 232)),
    ('血清素', 0.42, '42', (147, 197, 253), (56, 189, 248)),
]
BARX = X + 52
BARW = 190
for name, v, txt, c1, c2 in ROWS:
    d.text((X, y + 6), name, font=F(11), fill=(157, 178, 198), anchor='lm')
    d.rounded_rectangle([BARX, y + 3, BARX + BARW, y + 8], radius=3, fill=(255, 255, 255, 16))
    fw = max(4, int(BARW * v))
    for i in range(fw):
        t = i / max(1, fw - 1)
        col = tuple(int(c1[k] * (1 - t) + c2[k] * t) for k in range(3))
        d.line([(BARX + i, y + 3), (BARX + i, y + 8)], fill=col + (238,))
    base = {'精力': None, '皮质醇': 0.30, '多巴胺': 0.50, '催产素': 0.40, '血清素': 0.60}[name]
    if base is not None:
        bx = BARX + BARW * base
        d.line([(bx, y + 1), (bx, y + 10)], fill=(255, 255, 255, 178), width=1)
    d.text((CX0 + CW - 24, y + 6), txt, font=F(11), fill=(207, 223, 238), anchor='rm')
    y += 27

y += 8
d.line([(X, y), (CX0 + CW - 24, y)], fill=(255, 255, 255, 16))
y += 17

NEEDS = [('社交', 0.62), ('好奇', 0.48), ('玩乐', 0.34), ('成就', 0.55), ('认可', 0.41), ('休息', 0.72)]
cw = (CW - 48) / 6
for i, (nm, v) in enumerate(NEEDS):
    nx = X + i * cw
    d.rounded_rectangle([nx + 4, y, nx + cw - 8, y + 3], radius=2, fill=(255, 255, 255, 16))
    fw = max(2, int((cw - 12) * v))
    for k in range(fw):
        t = k / max(1, fw - 1)
        col = (int(167 * (1 - t) + 196 * t), int(139 * (1 - t) + 181 * t), 253)
        d.line([(nx + 4 + k, y), (nx + 4 + k, y + 3)], fill=col + (235,))
    d.text((nx + cw / 2, y + 15), nm, font=F(8), fill=(82, 99, 116), anchor='mm')

y += 40

pills = [('阶段', '深度信任', (232, 217, 174)), ('亲密度', '0.82', (207, 223, 238)),
         ('信任', '0.74', (207, 223, 238))]
pw = (CW - 48 - 12) / 3
for i, (k, v, c) in enumerate(pills):
    px = X + i * (pw + 6)
    hi = (i == 0)
    d.rounded_rectangle([px, y, px + pw, y + 36], radius=10,
                        fill=(255, 209, 102, 36) if hi else (255, 255, 255, 6),
                        outline=(255, 205, 120, 118) if hi else (150, 195, 255, 34))
    d.text((px + pw / 2, y + 12), k, font=F(7.5), fill=(78, 95, 112), anchor='mm')
    d.text((px + pw / 2, y + 24), v, font=F(10.5), fill=c, anchor='mm')

# 图底说明
d.text((CX0, H - 96), '11.0 里有的：精力 energy · 四激素 · 六维需求 · 关系三元（closeness / trust / stage）',
       font=F(8.5), fill=(64, 80, 96))
d.text((CX0, H - 78), '11.0 里没有的：心情 mood、耐心 patience —— 六维需求承担了「心情」，needs.rest 近似「耐心」',
       font=F(8.5), fill=(64, 80, 96))
d.text((CX0, H - 60), '激素条右端的小刻度是基线（30 / 50 / 40 / 60）：越过它才算「今天偏高」',
       font=F(8.5), fill=(64, 80, 96))

img.save(OUT + '06-state-card.png')
print('saved preview-statecard.png', img.size)
