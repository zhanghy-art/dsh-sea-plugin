# 变更记录

## 2.2.2

本版只做修复，不改架构、不加依赖，全部向后兼容：**没有对应列 / 表 / 端点时自动回落**，demo 模式不受影响。

### 1. 「被想起 N 次」永远不动

**文件**：`sea/db-adapter.mjs`

有些记忆库把「真去检索命中」（recall_count）和「每轮被注入到嘴边」（inject_count）分成两列记。
本版把两者相加作为展示值：

```js
(cRecall && cInject) ? `(COALESCE(${cRecall},0) + COALESCE(${cInject},0)) AS _recall`
  : cRecall ? `${cRecall} AS _recall`
  : cInject ? `${cInject} AS _recall` : '0 AS _recall',
```

只有其中一列时按一列算，都没有时为 0。

### 2. 「最近 N 天前」一直为空

**文件**：`sea/db-adapter.mjs`

列名探测顺序里只写了 `last_access`，漏了带 ed 的 `last_accessed`，于是 `_last` 恒为 NULL，
前端「最近 N 天前」和冷热判定全都拿不到值。

探测顺序改为：

```js
const cLast = pick(T, 'last_accessed', 'last_recalled', 'last_used', 'last_access');
```

### 3. 情绪剖面一直是空的

**文件**：`sea/sea-server.mjs`

`emotion_profile` 原本只有静态演示数据（`sea/demo/library.json`，由 `tools/tag-demo.mjs` 生成）里带，
服务端的两条查询分支 —— 真实库（走 `db-adapter`）和演示模式（`buildMock()` 现造）—— 都不产出该字段，
所以详情面板里那段「情绪剖面」永远是空的。

本版用包内自带的 `tagHeuristic` 现场补算，不写库：

- 缓存 key = `id|正文长度|情绪显著度|关系显著度|冷热`，超过 4000 条整体清空；
- 大部分记忆正文里没有情绪词，启发式会全落默认值（看起来还是「没有剖面」），
  所以再用记忆自身特征做二次微调：

| 条件 | 微调 |
| --- | --- |
| 情绪显著度 > 0.6 | joy +0.18、close +0.10 |
| 情绪显著度 > 0.35 | joy +0.08 |
| 关系显著度 > 0.3 | close +0.22 |
| 类型是约定（promise） | proud +0.15、close +0.06 |
| 已转冷（cold） | tired +0.22、sad +0.10 |

全部 `Math.min(1, ...)` 封顶，不会溢出。

真实库分支和演示模式（`buildMock()`）都会走这个函数，所以两种模式下剖面都能显示。

### 4. 点中心核没反应

**文件**：`sea/neural-sea.html`

`pointerup` 里打开状态卡之后，**同一次点击的 `click` 事件会继续冒泡到 document**，
被「点外面就关」的监听器立刻关掉 —— 表现就是「点了一下什么都没发生」。

`pointerup` 和 `click` 是两个独立事件，`stopPropagation` 拦不住这条链路，所以用时间戳挡：

```js
let _selfOpenedAt = 0;
// openSelf() 里
_selfOpenedAt = Date.now();
// document click 监听器里
if (Date.now() - _selfOpenedAt < 400) return;
```

### 5. 进化中枢的数字对不上

**文件**：`sea/evolution.html`

状态行原本是一组写死的示例值（`energy 0.80 / cortisol 35 / dopamine 55 / oxytocin 41 / serotonin 42`），
只有 `phase` 按小时算，所以永远和库里的真实状态对不上。

改为向只读后端要当前值，后端没起才回落基线：

```js
const raw = await fetch('/api/sea/hormones', { cache: 'no-store' });
```

同时：

- `phaseCN` 补上 `peak`（上午），未知值回落「此刻」；
- 关系用词改成按 `stage` 映射：`deep/familiar → 心里踏实`、`acquaintance → 在熟起来`、`stranger → 有点小心`（原来是硬写死一个词）。

### 6. 情绪雷达一个点都没有

**文件**：`sea/evolution.html`

`const emos = cnt(items, m => m.emotion);` 在真实库上恒为空（没有 `emotion` 这一列），雷达图全空。

改为按八种基调取主导情绪：

```js
const EMO_MAP = { close: 'intimate', uneasy: 'anxious' };
function dominantEmotion(m) {
  if (m.emotion && EMO[m.emotion]) return m.emotion;
  const p = m.emotion_profile;
  if (!p) return 'calm';
  let best = 'calm', bv = -1;
  for (const raw of Object.keys(p)) {
    const k = EMO_MAP[raw] || raw;
    const v = p[raw] || 0;
    if (EMO[k] && v > bv) { bv = v; best = k; }
  }
  return best;
}
```

---

## 兼容性说明

| 情况 | 行为 |
| --- | --- |
| 没有 `inject_count` 列 | 按 `recall_count` 显示 |
| 没有 `emotion_profile` | 前端回落 `calm` |
| `/api/sea/hormones` 取不到 | 状态行用基线值，页面不报错 |
| demo 模式（`library.json`） | 不受影响 |
| Node 版本 | ≥ 22 |

## 升级方式

直接覆盖 `sea/` 目录下的四个文件即可，不用改配置、不用迁移数据：

```
sea/db-adapter.mjs
sea/sea-server.mjs
sea/neural-sea.html
sea/evolution.html
```
