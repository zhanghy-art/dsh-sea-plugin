/**
 * db-adapter.mjs —— 把任何形状的 DSH 记忆库接到识海的数据契约上
 *
 * 为什么需要这一层：
 *   识海按 v11.0 §4.3 的字段名读数据（category / fact / memory_kind / …）。
 *   但现有的 DSH 部署用的是另一套（type / content / protection_level / …）。
 *   两边都不该改：契约是契约，用户的库是他的数据。
 *   所以中间加一层映射 —— 只读、无副作用、字段对不上就退回默认值。
 *
 * 三条铁律：
 *   1. 任何一次探测/查询失败都返回空，绝不抛到调用方。
 *   2. 字段名靠"候选列表"匹配，不假设任何具体 schema。
 *   3. 数值和时间戳要归一化 —— protection_level 可能是 1..5，时间可能是秒。
 */

/* 英文/各种写法 → 识海的七类 */
const CAT_MAP = {
  fact: '事实', facts: '事实', knowledge: '事实', info: '事实',
  person: '人物', people: '人物', character: '人物', relation: '人物',
  event: '事件', episode: '事件', episodes: '事件', incident: '事件',
  prefer: '偏好', preference: '偏好', preferences: '偏好', like: '偏好',
  promise: '约定', agreement: '约定', plan: '约定', todo: '约定',
  meme: '梗', joke: '梗', funny: '梗',
  rule: '群规', group_rule: '群规', regulation: '群规',
  人物: '人物', 事实: '事实', 偏好: '偏好', 约定: '约定',
  事件: '事件', 梗: '梗', 群规: '群规',
};

const KIND_MAP = {
  fact: 'fact', facts: 'fact', knowledge: 'fact',
  episode: 'episode', event: 'episode', events: 'episode',
  promise: 'promise', agreement: 'promise', plan: 'promise',
  raw: 'raw', quote: 'raw', original: 'raw',
  事实: 'fact', 片段: 'episode', 事件: 'episode', 约定: 'promise', 原话: 'raw',
};

function toCategory(v, fallback = '事实') {
  if (v == null) return fallback;
  const s = String(v).trim();
  if (CAT_MAP[s]) return CAT_MAP[s];
  const low = s.toLowerCase();
  return CAT_MAP[low] || fallback;
}

function toKind(v, cat) {
  if (v != null) {
    const s = String(v).trim();
    if (KIND_MAP[s]) return KIND_MAP[s];
    if (KIND_MAP[s.toLowerCase()]) return KIND_MAP[s.toLowerCase()];
  }
  if (cat === '约定') return 'promise';
  if (cat === '事件') return 'episode';
  return 'fact';
}

/** 时间戳归一化：秒 / 毫秒 / ISO 字符串 → 毫秒 */
function toMs(v) {
  if (v == null) return null;
  if (typeof v === 'number') return v < 1e12 ? Math.round(v * 1000) : Math.round(v);
  const n = Date.parse(String(v));
  return Number.isFinite(n) ? n : null;
}

/** 0..1 归一化。protection_level 常见是 1..5 或 0..3 */
function toUnit(v, def = 0.5) {
  if (v == null) return def;
  const n = Number(v);
  if (!Number.isFinite(n)) return def;
  if (n > 1) return Math.max(0, Math.min(1, n / (n <= 5 ? 5 : 10)));
  return Math.max(0, Math.min(1, n));
}

export function makeAdapter(db) {
  const colCache = new Map();
  function cols(table) {
    if (colCache.has(table)) return colCache.get(table);
    let list = [];
    try {
      list = db.prepare(`PRAGMA table_info("${table}")`).all().map(r => String(r.name));
    } catch { list = []; }
    colCache.set(table, list);
    return list;
  }
  const hasTable = t => cols(t).length > 0;
  /** 在候选列名里找第一个真实存在的 */
  const pick = (t, ...names) => {
    const c = cols(t);
    return names.find(n => c.includes(n)) || null;
  };

  /* ── 记忆 ─────────────────────────────────────────── */
  function nodes(limit = 300, asOf = 0) {
    const now = asOf || Date.now();
    if (!hasTable('memories')) return [];
    const T = 'memories';
    const cId = pick(T, 'id', 'memory_id', 'uid', 'rowid');
    const cCat = pick(T, 'category', 'type', 'kind', 'mem_type');
    const cText = pick(T, 'fact', 'content', 'text', 'memory', 'body', 'summary');
    const cKind = pick(T, 'memory_kind', 'kind', 'type', 'mem_type');
    const cImp = pick(T, 'importance', 'protection_level', 'weight', 'score', 'priority');
    const cBase = pick(T, 'base_weight', 'base', 'seed_weight', 'strength');
    const cEmo = pick(T, 'emotional_salience', 'emotional', 'emotion', 'emotion_score', 'valence');
    const cRel = pick(T, 'relationship_salience', 'relationship', 'relational');
    const cRecall = pick(T, 'recall_count', 'recalls', 'hit_count', 'access_count', 'use_count');
    const cInject = pick(T, 'inject_count', 'injections', 'inject_hits');
    const cCreated = pick(T, 'created_at', 'created', 'ts', 'timestamp', 'mtime', 'time');
    const cConfirm = pick(T, 'confirmed_at', 'confirmed', 'last_confirmed');
    // 本库的列名是 last_accessed（带 ed）。以前只写了 last_access，结果一直匹配不上，
    // 前端「最近 N 天前」和冷热判定全是空的。
    const cLast = pick(T, 'last_accessed', 'last_recalled', 'last_used', 'last_access');
    const cCold = pick(T, 'cold', 'is_cold', 'archived');
    const cValid = pick(T, 'valid_to', 'invalid_at', 'expired_at', 'deleted_at');
    const cSubj = pick(T, 'subject_qq', 'subject', 'owner', 'user_id');
    const cRaw = pick(T, 'raw', 'is_raw');

    if (!cText) return [];   // 连正文列都找不到，说明不是记忆表

    const sel = [
      cId ? `${cId} AS id` : 'rowid AS id',
      cCat ? `${cCat} AS _cat` : `NULL AS _cat`,
      `${cText} AS _text`,
      cKind ? `${cKind} AS _kind` : 'NULL AS _kind',
      cImp ? `${cImp} AS _imp` : 'NULL AS _imp',
      cBase ? `${cBase} AS _base` : 'NULL AS _base',
      cEmo ? `${cEmo} AS _emo` : 'NULL AS _emo',
      cRel ? `${cRel} AS _rel` : 'NULL AS _rel',
      // 「被想起」= 真去检索命中 + 每轮被注入到嘴边。只算前者的话，
      // 天天提醒主人的那几条会永远显示「被想起 1 次」。
      (cRecall && cInject) ? `(COALESCE(${cRecall},0) + COALESCE(${cInject},0)) AS _recall`
        : cRecall ? `${cRecall} AS _recall`
        : cInject ? `${cInject} AS _recall` : '0 AS _recall',
      cCreated ? `${cCreated} AS _created` : 'NULL AS _created',
      cConfirm ? `${cConfirm} AS _confirm` : 'NULL AS _confirm',
      cLast ? `${cLast} AS _last` : 'NULL AS _last',
      cCold ? `${cCold} AS _cold` : '0 AS _cold',
      cValid ? `${cValid} AS _valid` : 'NULL AS _valid',
      cSubj ? `${cSubj} AS _subj` : 'NULL AS _subj',
      cRaw ? `${cRaw} AS _raw` : 'NULL AS _raw',
    ].join(', ');

    let sql = `SELECT ${sel} FROM ${T}`;
    const where = [];
    if (cRaw) where.push(`(${cRaw} IS NULL OR ${cRaw} = 0)`);
    if (where.length) sql += ' WHERE ' + where.join(' AND ');
    if (cId) sql += ` ORDER BY ${cId} DESC`;
    sql += ' LIMIT ?';

    let rows = [];
    try { rows = db.prepare(sql).all(Math.max(1, Math.min(200000, limit))); }
    catch (e) { logOnce('nodes', e); return []; }

    const out = [];
    let _seq = 0;
    for (const r of rows) {
      const cat = toCategory(r._cat);
      const created = toMs(r._created) ?? now;
      const confirm = toMs(r._confirm) ?? toMs(r._last) ?? created;
      const valid = toMs(r._valid);
      const m = {
        // id 必须非空且唯一。字符串主键（mem_20261029_001）要原样透传 ——
        // 用序号兜底会导致每次请求重新编号，刷新/时间旅行后"同一条记忆"换了 id。
        id: r.id == null || r.id === ''
          ? `n${_seq}`
          : (Number.isNaN(Number(r.id)) ? String(r.id) : Number(r.id)),
        category: cat,
        fact: String(r._text ?? ''),
        memory_kind: toKind(r._kind, cat),
        importance: toUnit(r._imp, 0.5),
        base_weight: r._base == null ? null : (Number(r._base) > 1 ? Number(r._base) / 100 : Number(r._base)),
        emotional_salience: toUnit(r._emo, 0),
        relationship_salience: toUnit(r._rel, 0),
        recall_count: Number(r._recall) || 0,
        created_at: created,
        confirmed_at: confirm,
        last_recalled: toMs(r._last),
        cold: Number(r._cold) ? 1 : 0,
        valid_to: valid,
        subject_qq: r._subj ?? 'owner',
      };
      _seq++;
      out.push(m);
    }
    return out;
  }

  /* ── 总数（stats 用，不受 limit 影响） ─────────────── */
  function total() {
    if (!hasTable('memories')) return 0;
    try { return Number(db.prepare('SELECT count(*) AS c FROM memories').get().c) || 0; }
    catch (e) { logOnce('total', e); return 0; }
  }

  /* ── 激素 / 需求 / 关系：兼容 JSON 一列 与 列式两张表 ── */
  function hormones(defaults) {
    // 形态 A：life_state 有一列 state_json
    if (hasTable('life_state')) {
      const cJson = pick('life_state', 'state_json', 'json', 'state');
      if (cJson) {
        try {
          const row = db.prepare(`SELECT ${cJson} AS j FROM life_state WHERE rowid = 1`).get();
          if (row && row.j) {
            const s = typeof row.j === 'string' ? JSON.parse(row.j) : row.j;
            return {
              ...(s.hormones || {}),
              needs: s.needs, energy: s.energy, phase: s.phase,
              relationship: s.relationship,
              name: s.aiName || s.flags?.aiName || defaults.name,
            };
          }
        } catch (e) { logOnce('hormones-json', e); }
      }
      // 形态 B：life_state 是列式（social / curiosity / rest …）
      const nCols = ['social', 'curiosity', 'play', 'achievement', 'recognition', 'rest']
        .filter(k => cols('life_state').includes(k));
      if (nCols.length >= 3) {
        try {
          const row = db.prepare(`SELECT * FROM life_state WHERE rowid = 1`).get() || {};
          const needs = {};
          for (const k of nCols) needs[k] = toUnit(row[k], 0.4);
          const out = { needs };
          if (cols('life_state').includes('energy')) out.energy = toUnit(row.energy, 0.7);
          if (cols('life_state').includes('phase')) out.phase = row.phase;
          Object.assign(out, hormonesFromTables(defaults));
          return out;
        } catch (e) { logOnce('hormones-cols', e); }
      }
    }
    return hormonesFromTables(defaults);
  }

  function hormonesFromTables(defaults) {
    const out = {};
    // 激素：一张表四行，或一行四列
    if (hasTable('life_hormones')) {
      const c = cols('life_hormones');
      const cName = pick('life_hormones', 'name', 'key', 'kind', 'hormone');
      const cVal = pick('life_hormones', 'value', 'val', 'level', 'amount');
      if (cName && cVal) {
        try {
          for (const r of db.prepare(`SELECT ${cName} AS k, ${cVal} AS v FROM life_hormones`).all()) {
            const k = String(r.k || '').toLowerCase();
            if (['cortisol', 'dopamine', 'oxytocin', 'serotonin'].includes(k)) out[k] = Number(r.v);
          }
        } catch (e) { logOnce('hormones-table', e); }
      } else if (c.includes('cortisol')) {
        try {
          const row = db.prepare('SELECT * FROM life_hormones WHERE rowid = 1').get() || {};
          for (const k of ['cortisol', 'dopamine', 'oxytocin', 'serotonin']) {
            if (row[k] != null) out[k] = Number(row[k]);
          }
        } catch (e) { logOnce('hormones-wide', e); }
      }
    }
    // 关系
    if (hasTable('life_relationship')) {
      try {
        const row = db.prepare('SELECT * FROM life_relationship WHERE rowid = 1').get() || {};
        const c = cols('life_relationship');
        out.relationship = {
          subjectId: row.subject_id ?? row.subject ?? 'owner',
          closeness: toUnit(row.closeness, 0.5),
          trust: toUnit(row.trust, 0.5),
          stage: row.stage ?? (toUnit(row.closeness, 0.5) > 0.8 && toUnit(row.trust, 0.5) > 0.7
            ? '深度信任' : '熟悉'),
        };
      } catch (e) { logOnce('relationship', e); }
    }
    return out;
  }

  const seen = new Set();
  function logOnce(tag, e) {
    if (seen.has(tag)) return;
    seen.add(tag);
    console.warn(`[sea] ${tag} 查询失败（已降级，不影响服务）：${e && e.message ? e.message : e}`);
  }

  return {
    nodes, total, hormones,
    schema: () => ({
      memories: cols('memories'),
      life_state: cols('life_state'),
      life_hormones: cols('life_hormones'),
      life_relationship: cols('life_relationship'),
    }),
  };
}
