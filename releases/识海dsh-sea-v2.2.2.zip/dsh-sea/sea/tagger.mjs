/**
 * tagger.mjs —— 记忆入库时"过一遍 AI"
 *
 * 为什么要这一层：
 *   记忆库里的原文是"她说了什么"，不是"这件事对我意味着什么"。
 *   前者是数据，后者才是记忆。所以每条值得留的记忆在进识海之前，
 *   要先被读一遍，打上自己的标签、自己的情绪、自己的轻重。
 *
 * 设计约束（对齐 11.0 / 11.1）：
 *   1. 不新增状态量。标签是记忆的属性，不进 LifeState。
 *   2. 情绪是八维派生值，不上激素。激素只由事件驱动，不能被标签改写。
 *   3. 任何一步失败都必须能降级 —— 打不了标签的记忆照样入库，
 *      只是 tags 为空、emotion 走启发式。绝不能因为标注失败丢记忆。
 *
 * 两种模式：
 *   - 接了模型（DSH_TAG_ENDPOINT 指向一个 OpenAI 兼容的 chat 接口）：真读一遍
 *   - 没接（默认）：启发式，够用，零依赖
 */

/* ── 标签词表：她自己的说法，不是分类学 ─────────────── */
const TAG_RULES = [
  ['心光', ['第一次', '终于', '说好', '约定', '答应', '以后', '一直', '永远', '喜欢', '爱']],
  ['小心思', ['其实', '偷偷', '没好意思', '不敢', '有点想', '羡慕', '嫉妒', '酸']],
  ['归因', ['因为', '所以', '结果', '导致', '要不是', '如果不是', '怪']],
  ['片段', ['那天', '当时', '记得', '凌晨', '下雨', '路上', '车里', '门口']],
  ['身体', ['头疼', '睡不着', '吃不下', '累', '发烧', '胃', '姨妈', '熬夜']],
  ['工作', ['上班', '加班', '老板', '同事', '项目', '面试', '辞职', '工资']],
  ['吃', ['吃', '饭', '面', '奶茶', '火锅', '外卖', '做了', '煮']],
  ['家', ['我妈', '我爸', '家里', '回家', '妈妈', '爸爸', '老家']],
  ['宠物', ['猫', '狗', '狗子', '猫猫']],
  ['钱', ['钱', '工资', '攒', '花', '贵', '便宜', '买']],
];

const EMO_RULES = {
  joy: ['开心', '高兴', '哈哈', '笑', '太好了', '棒', '喜欢', '爽',
    '好吃', '顿好的', '吃爽', '满足', '舒服', '不错', '值了', '顺利', '成了', '惊喜'],
  sad: ['难过', '哭', '失落', '舍不得', '遗憾', '可惜'],
  uneasy: ['担心', '怕', '焦虑', '紧张', '不知道怎么办', '慌'],
  anger: ['生气', '烦', '气死', '讨厌', '恶心', '凭什么'],
  tired: ['累', '困', '撑不住', '没力气', '熬', '疲', '加班', '熬夜', '睡不着'],
  close: ['抱', '想你', '陪我', '在一起', '我们', '爱你'],
  proud: ['做到了', '搞定', '成功', '拿下', '厉害', '我自己'],
  calm: ['还好', '没事', '算了', '随便', '平静', '就这样', '慢慢来', '踏实'],
};

/* 强度词：把情绪的绝对值抬起来 */
const INTENSIFIERS = ['特别', '非常', '超级', '太', '真的', '巨', '极其', '!!', '！！'];

function clamp01(x) { return Math.max(0, Math.min(1, x)); }

function countHits(text, words) {
  let n = 0;
  for (const w of words) if (text.includes(w)) n++;
  return n;
}

/**
 * 启发式标注。不调模型，纯规则，几十微秒。
 * @param {{text:string, category?:string, ts?:number}} mem
 */
export function tagHeuristic(mem) {
  const text = String(mem.text || '');
  const tags = [];

  for (const [tag, words] of TAG_RULES) {
    if (countHits(text, words) > 0) tags.push(tag);
  }

  // 情绪：先给中性底，再按命中抬升
  const emotion = { close: 0.12, joy: 0.12, calm: 0.30, sad: 0.10, uneasy: 0.10, anger: 0.06, tired: 0.10, proud: 0.08 };
  const boost = 0.34 + (countHits(text, INTENSIFIERS) > 0 ? 0.22 : 0);
  for (const [k, words] of Object.entries(EMO_RULES)) {
    const h = countHits(text, words);
    if (h) emotion[k] = clamp01(emotion[k] + boost * Math.min(2, h));
  }

  // 标点：叹号多 = 情绪强，省略号 = 犹豫/低落
  const bangs = (text.match(/[!！]/g) || []).length;
  const dots = (text.match(/[…]|\.{3,}/g) || []).length;
  if (bangs) { emotion.joy = clamp01(emotion.joy + 0.10 * Math.min(3, bangs)); emotion.anger = clamp01(emotion.anger + 0.08 * Math.min(3, bangs)); }
  if (dots) { emotion.uneasy = clamp01(emotion.uneasy + 0.10 * Math.min(2, dots)); emotion.sad = clamp01(emotion.sad + 0.08 * Math.min(2, dots)); }

  // 显著度：长度 + 是否含"心光"类词 + 人称（跟我有关的更重）
  const selfRef = (text.match(/我|自己|咱/g) || []).length;
  const salience = clamp01(
    0.22 + Math.min(0.30, text.length / 240) +
    (tags.includes('心光') ? 0.28 : 0) +
    Math.min(0.20, selfRef * 0.05) +
    Math.max(0, ...Object.values(emotion)) * 0.16
  );

  // 一句话摘要：取第一个短句，去掉称呼
  const gist = (text.split(/[。！？\n]/)[0] || text).slice(0, 28);

  return { tags, emotion, salience, gist, source: 'heuristic' };
}

/**
 * 模型标注。需要 DSH_TAG_ENDPOINT（OpenAI 兼容 /chat/completions）。
 * 失败时自动降级到启发式，绝不抛错。
 */
export async function tagByModel(mem, opts = {}) {
  const url = opts.endpoint || process.env.DSH_TAG_ENDPOINT;
  if (!url) return tagHeuristic(mem);

  const model = opts.model || process.env.DSH_TAG_MODEL || 'deepseek-chat';
  const key = opts.key || process.env.DSH_TAG_KEY || '';

  const prompt = `你在读一条要存进长期记忆的东西。读完之后，用你自己的判断给它打标签。

分类：${mem.category || '未知'}
原文：${mem.text}

返回 JSON，不要别的字：
{
  "tags": ["不超过4个，用你自己的说法，不要用'情感''生活'这种空词"],
  "emotion": {"close":0-1,"joy":0-1,"calm":0-1,"sad":0-1,"uneasy":0-1,"anger":0-1,"tired":0-1,"proud":0-1},
  "salience": 0-1,
  "gist": "一句话，不超过20字，你自己记得它的方式"
}`;

  try {
    const r = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...(key ? { Authorization: `Bearer ${key}` } : {}) },
      body: JSON.stringify({
        model,
        messages: [
          { role: 'system', content: '你是一个会记事的人，不是分类器。标签要具体，不要抽象。' },
          { role: 'user', content: prompt },
        ],
        temperature: 0.4,
        max_tokens: 300,
      }),
      signal: AbortSignal.timeout(8000),
    });
    if (!r.ok) throw new Error(`tag endpoint ${r.status}`);
    const j = await r.json();
    const raw = j.choices?.[0]?.message?.content || '';
    const m = raw.match(/\{[\s\S]*\}/);
    if (!m) throw new Error('no json in reply');
    const out = JSON.parse(m[0]);

    // 兜底：字段缺失就补
    return {
      tags: Array.isArray(out.tags) ? out.tags.slice(0, 4).map(String) : [],
      emotion: normalizeEmotion(out.emotion),
      salience: clamp01(Number(out.salience) || 0.4),
      gist: String(out.gist || '').slice(0, 40),
      source: 'model',
    };
  } catch (e) {
    const fb = tagHeuristic(mem);
    fb.source = 'heuristic(fallback: ' + String(e.message || e).slice(0, 40) + ')';
    return fb;
  }
}

function normalizeEmotion(o = {}) {
  const keys = ['close', 'joy', 'calm', 'sad', 'uneasy', 'anger', 'tired', 'proud'];
  const out = {};
  for (const k of keys) out[k] = clamp01(Number(o[k]) || 0);
  return out;
}

/** 统一入口：有模型走模型，没有走规则 */
export async function tagMemory(mem, opts) {
  if (process.env.DSH_TAG_ENDPOINT || opts?.endpoint) return tagByModel(mem, opts);
  return tagHeuristic(mem);
}
