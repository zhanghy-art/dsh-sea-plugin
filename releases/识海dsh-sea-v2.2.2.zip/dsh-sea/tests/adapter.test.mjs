// adapter.test.mjs —— 验证 db-adapter 能吃下"别人的 schema"
// 不需要真的 sqlite：用一个鸭子类型的假 db 模拟 PRAGMA 与 SELECT。
import assert from 'node:assert';
import { makeAdapter } from '../sea/db-adapter.mjs';

/**
 * 假 db：支持 PRAGMA table_info("t") 和 SELECT ... AS _x ... FROM t
 * 故意只实现 adapter 用到的那点语法，够用就行。
 */
function fakeDb(tables, opts = {}) {
  return {
    prepare(sql) {
      if (opts.throwOn && sql.includes(opts.throwOn)) {
        throw new Error('simulated: no such column');
      }
      const pm = sql.match(/PRAGMA table_info\("(.+?)"\)/);
      if (pm) {
        const t = tables[pm[1]];
        return { all: () => (t && t.length ? Object.keys(t[0]).map(name => ({ name })) : []), get: () => undefined };
      }
      const fm = sql.match(/FROM\s+"?(\w+)"?/i);
      const rows = (fm && tables[fm[1]]) || [];

      // 把 SELECT 里的 `expr AS alias` 抠出来，按别名重映射
      const selPart = sql.slice(6, sql.toUpperCase().indexOf(' FROM '));
      const maps = [];
      const re = /(?:(\w+)|'([^']*)')?\s*AS\s+(\w+)/gi;
      let m;
      while ((m = re.exec(selPart))) {
        maps.push({ src: m[1], lit: m[2], alias: m[3] });
      }
      // count(*) 特例
      if (/count\(\*\)/i.test(sql)) return { all: () => [{ c: rows.length }], get: () => ({ c: rows.length }) };
      const out = rows.map(r => {
        if (!maps.length) return { ...r };
        const o = {};
        for (const { src, lit, alias } of maps) {
          o[alias] = src ? r[src] : (lit !== undefined ? lit : null);
        }
        return o;
      });
      return { all: () => out, get: () => out[0] };
    },
  };
}

/* ── 场景 1：用户那套 schema（type / content / protection_level / emotional，秒级时间戳）── */
{
  const t0 = 1793255760;          // 秒
  const db = fakeDb({
    memories: [
      { id: 1, type: 'fact', content: '她说好周末陪我看展', protection_level: 4, emotional: 0.7, created_at: t0, recall_count: 3 },
      { id: 2, type: 'event', content: '我妈住院了', protection_level: 5, emotional: 0.9, created_at: t0 - 86400, recall_count: 0 },
      { id: 3, type: 'prefer', content: '喜欢喝冰美式', protection_level: 2, emotional: 0.2, created_at: t0 - 86400 * 30, recall_count: 7 },
    ],
  });
  const a = makeAdapter(db);
  const ns = a.nodes(100, t0 * 1000);
  assert.equal(ns.length, 3, '三条都要读出来');
  assert.equal(ns[0].category, '事实', 'type:fact → 事实');
  assert.equal(ns[1].category, '事件', 'type:event → 事件');
  assert.equal(ns[2].category, '偏好', 'type:prefer → 偏好');
  assert.equal(ns[0].fact, '她说好周末陪我看展', 'content → fact');
  assert.equal(ns[0].importance, 0.8, 'protection_level 4/5 → 0.8');
  assert.equal(ns[0].emotional_salience, 0.7, 'emotional → emotional_salience');
  assert.equal(ns[0].created_at, t0 * 1000, '秒级时间戳要 ×1000');
  assert.equal(ns[1].memory_kind, 'episode', '事件 → episode');
  assert.equal(a.total(), 3, 'total 走 count(*)');
  console.log('schema 映射（type/content/protection_level）  ✓');
}

/* ── 场景 2：标准 v11.0 schema 原样通过 ─────────────── */
{
  const now = Date.now();
  const db = fakeDb({
    memories: [
      { id: 9, category: '约定', fact: '周五一起吃饭', memory_kind: 'promise', importance: 0.66,
        emotional_salience: 0.4, relationship_salience: 0.3, recall_count: 2,
        created_at: now, confirmed_at: now, last_recalled: now, cold: 0, valid_to: null, subject_qq: 'owner', raw: 0 },
    ],
  });
  const ns = makeAdapter(db).nodes(10, now);
  assert.equal(ns.length, 1);
  assert.equal(ns[0].category, '约定');
  assert.equal(ns[0].memory_kind, 'promise');
  assert.equal(ns[0].importance, 0.66, '已经是 0..1 就不要动');
  assert.equal(ns[0].created_at, now);
  console.log('标准 schema 不动值                        ✓');
}

/* ── 场景 3：表不存在 / 查询报错 → 空数组，绝不抛 ─────── */
{
  assert.deepEqual(makeAdapter(fakeDb({})).nodes(10), [], '没有 memories 表 → []');
  assert.equal(makeAdapter(fakeDb({})).total(), 0, '没有表 → total 0');
  const boom = makeAdapter(fakeDb({ memories: [{ id: 1, content: 'x' }] }, { throwOn: 'FROM memories' }));
  assert.deepEqual(boom.nodes(10), [], '查询抛错 → []');
  console.log('缺表 / 报错 → 空数组，不抛             ✓');
}

/* ── 场景 4：激素三种形态 ───────────────────────────── */
{
  // A. state_json 一列
  const a1 = makeAdapter(fakeDb({
    life_state: [{ state_json: JSON.stringify({ hormones: { cortisol: 41, dopamine: 63 }, needs: { social: 0.5 }, energy: 0.8, phase: 'afternoon' }) }],
  }));
  const h1 = a1.hormones({ name: '小鱼' });
  assert.equal(h1.cortisol, 41);
  assert.equal(h1.energy, 0.8);

  // B. 列式（social / curiosity / …）+ 独立激素表 + 关系表
  const a2 = makeAdapter(fakeDb({
    life_state: [{ social: 0.4, curiosity: 0.6, rest: 0.3, energy: 0.7 }],
    life_hormones: [{ name: 'cortisol', value: 33 }, { name: 'dopamine', value: 58 },
                    { name: 'oxytocin', value: 47 }, { name: 'serotonin', value: 61 }],
    life_relationship: [{ subject_id: 'owner', closeness: 0.82, trust: 0.74, stage: '深度信任' }],
  }));
  const h2 = a2.hormones({ name: '小鱼' });
  assert.equal(h2.cortisol, 33, '行式激素表');
  assert.equal(h2.needs.social, 0.4, '列式需求');
  assert.equal(h2.relationship.closeness, 0.82);
  assert.equal(h2.relationship.stage, '深度信任');
  console.log('激素：state_json / 列式三表 都能读        ✓');
}

/* ── 场景 5：id 全是 NULL 的库（真实事故）─────────────────
   前端用 `S.sel === n.id` 判选中，S.sel 初值也是 null，
   于是 null === null 对每个节点恒真：全部绕过阈值、全部画出来，
   叠在中心的那一个还被画成选中靶心 —— 就是那块米黄盘。 */
{
  const now = Date.now();
  const db = fakeDb({
    memories: [
      { id: null, type: 'fact', content: 'a', protection_level: 3, emotional: 0.2, created_at: now },
      { id: null, type: 'fact', content: 'b', protection_level: 3, emotional: 0.2, created_at: now },
      { id: '',   type: 'fact', content: 'c', protection_level: 3, emotional: 0.2, created_at: now },
    ],
  });
  const ns = makeAdapter(db).nodes(10, now);
  assert.equal(ns.length, 3);
  for (const n of ns) {
    assert.ok(n.id != null && n.id !== '', `id 不能是空值，实际是 ${JSON.stringify(n.id)}`);
  }
  assert.equal(new Set(ns.map(n => n.id)).size, 3, 'id 必须唯一');
  console.log('id 为 NULL 时自动兜底为唯一值        ✓');
}

console.log('RESULT: PASS');
