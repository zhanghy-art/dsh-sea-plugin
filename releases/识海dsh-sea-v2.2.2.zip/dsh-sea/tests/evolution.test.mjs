// evo-test.mjs —— 无浏览器跑一遍进化中枢，抓运行时错误
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { fileURLToPath, pathToFileURL } from 'node:url';
const DIR = path.dirname(fileURLToPath(import.meta.url));

const CALLS = new Map();
function makeCtx() {
  const grad = { addColorStop() {} };
  return new Proxy({}, {
    get(_, k) {
      if (k === 'createRadialGradient' || k === 'createLinearGradient') return () => grad;
      if (k === 'createImageData') return (w, h) => ({ data: new Uint8ClampedArray(w * h * 4) });
      if (k === 'canvas') return { width: 800, height: 300 };
      if (k === 'measureText') return () => ({ width: 40 });
      return () => { CALLS.set(k, (CALLS.get(k) || 0) + 1); };
    },
    set() { return true; },
  });
}
const els = new Map();
const el = (id) => ({
  id, classList: { add() {}, remove() {}, toggle() {} },
  style: new Proxy({}, { get: () => '', set: () => true }),
  addEventListener() {}, set innerHTML(v) { this._h = v; }, get innerHTML() { return this._h || ''; },
  textContent: '', dataset: {}, clientWidth: 800, width: 800, height: 300,
  getContext: () => makeCtx(), onclick: null,
});
globalThis.document = {
  getElementById(id) { if (!els.has(id)) els.set(id, el(id)); return els.get(id); },
  querySelectorAll() { return { forEach() {} }; },
  querySelector() { return el('x'); },
  addEventListener() {},
};
globalThis.window = { innerWidth: 1440, innerHeight: 900, devicePixelRatio: 1, addEventListener() {} };
globalThis.location = { href: '', search: '' };
globalThis.fetch = async (u) => {
  const f = path.join(DIR, '..', 'sea', 'demo', String(u).replace(/^.*\//, ''));
  return { ok: true, json: async () => JSON.parse(fs.readFileSync(f, 'utf-8')) };
};

const html = fs.readFileSync(path.join(DIR, '..', 'sea', 'evolution.html'), 'utf-8');
const m = /<script type="module">([\s\S]*?)<\/script>/.exec(html);
if (!m) { console.log('NO SCRIPT'); process.exit(1); }
const src = m[1]
  .replace(/^const lib = await/m, 'const lib = await');
const TMP = path.join(os.tmpdir(), 'evo_mod.mjs');
fs.writeFileSync(TMP, src);
try {
  await import(pathToFileURL(TMP).href);
} catch (e) {
  console.log('IMPORT FAIL:', e.message);
  String(e.stack).split('\n').slice(1, 6).forEach(l => console.log('  ' + l.slice(0, 120)));
  process.exit(1);
}
await new Promise(r => setTimeout(r, 600));
const E = globalThis.window.__EVO;
if (!E) { console.log('NO __EVO — 脚本没跑完'); process.exit(1); }
const arcs = CALLS.get('arc') || 0, fills = CALLS.get('fill') || 0, texts = CALLS.get('fillText') || 0;
console.log('items=', E.items.length, ' rings=', JSON.stringify(E.rings));
console.log('types=', Object.keys(E.types).length, ' emos=', Object.keys(E.emos).length, ' avgW=', E.avgW.toFixed(3));
console.log('canvas ops: arc', arcs, ' fill', fills, ' fillText', texts);
console.log('quads html len=', (els.get('quads')?.innerHTML || '').length);
console.log('toplist rows=', ((els.get('toplist')?.innerHTML || '').match(/class="row"/g) || []).length);
console.log('statusline=', (els.get('statusline')?.textContent || '').slice(0, 60));
console.log('whyChain len=', (els.get('whyChain')?.innerHTML || '').length,
            ' whyTitle=', (els.get('whyTitle')?.textContent || '').slice(0, 20));
console.log('RESULT:', E.items.length > 0 && texts > 10 ? 'PASS' : 'CHECK');
