// headless.mjs —— 无浏览器跑真实渲染循环，验证「缩小无字 / 放大出字」与弧线
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { fileURLToPath, pathToFileURL } from 'node:url';

const DIR = path.dirname(fileURLToPath(import.meta.url));

function makeCtx(store) {
  const grad = { addColorStop() {} };
  return new Proxy({}, {
    get(_, k) {
      if (k === 'createRadialGradient' || k === 'createLinearGradient') return () => grad;
      if (k === 'createImageData') return (w, h) => ({ data: new Uint8ClampedArray(w * h * 4), width: w, height: h });
      if (k === 'canvas') return { width: 1440, height: 900 };
      return (...a) => { store.set(k, (store.get(k) || 0) + 1); };
    },
    set() { return true; },
  });
}
const CALLS = new Map();
const DUST = new Map();
const CTX = makeCtx(CALLS);
const DCTX = makeCtx(DUST);

function el(id) {
  return {
    id,
    classList: { add() {}, remove() {}, toggle() {} },
    style: new Proxy({}, { get: () => '', set: () => true }),
    addEventListener() {},
    set innerHTML(v) { this._h = v; },
    get innerHTML() { return this._h || ''; },
    textContent: '',
    value: 0,
    width: 300, height: 64, clientWidth: 330, clientHeight: 64,
    getContext: () => CTX,
    setPointerCapture() {},
    onclick: null,
    dataset: {},
  };
}
const els = new Map();
globalThis.document = {
  getElementById(id) { if (!els.has(id)) els.set(id, el(id)); return els.get(id); },
  createElement() { return { width: 900, height: 900, getContext: () => DCTX }; },
  querySelectorAll() { return { forEach() {} }; },
  addEventListener() {},
};
globalThis.window = {
  innerWidth: 1440, innerHeight: 900, devicePixelRatio: 1,
  addEventListener() {},
};
globalThis.location = { search: '', href: '' };
globalThis.fetch = async (u) => {
  const f = path.join(DIR, '..', 'sea', 'demo', String(u).replace(/^.*\//, ''));
  const txt = fs.readFileSync(f, 'utf-8');
  return { ok: true, json: async () => JSON.parse(txt) };
};
let pending = null;
globalThis.requestAnimationFrame = (fn) => { pending = fn; return 1; };
globalThis.setInterval = () => 0;

// 直接从 index.html 抽 <script type="module">，避免读到过期的临时文件
const html = fs.readFileSync(path.join(DIR, '..', 'sea', 'neural-sea.html'), 'utf-8');
const mm = /<script type="module">([\s\S]*?)<\/script>/.exec(html);
if (!mm) { console.log('NO SCRIPT IN index.html'); process.exit(1); }
const src = mm[1];
const TMP = path.join(os.tmpdir(), 'sea_mod.mjs');
fs.writeFileSync(TMP, src);
const mod = pathToFileURL(TMP).href;
try { await import(mod); } catch (e) {
  console.log('IMPORT FAIL:', e.message); console.log(String(e.stack).split('\n').slice(0,6).join('\n'));
  process.exit(1);
}

const S = globalThis.window.__SEA;
const sleep = ms => new Promise(r => setTimeout(r, ms));
await sleep(900);                                   // 等 load()
const tick = async (n = 4) => {
  for (let i = 0; i < n; i++) {
    const fn = pending; pending = null;
    if (!fn) throw new Error('no frame scheduled');
    fn(performance.now() + i * 16);
    await sleep(4);
  }
};
const cnt = k => CALLS.get(k) || 0;

await tick(8);                                      // 入场、稳定
if (!S || !S.nodes.length) { console.log('NO NODES', S?.err); process.exit(1); }

const report = [];
report.push(`nodes=${S.nodes.length}  edges=${(S.edges || []).length}`);
report.push(`cam.s=${S.cam.s.toFixed(2)}`);

// ① 缩小态：必须零文字
S.cam.ts = 1.0; S.cam.s = 1.0;
await tick(3);
const zoomOutFill = cnt('fillText');
report.push(`缩小态 fillText=${zoomOutFill}  ${zoomOutFill === 0 ? '✓ 星图无字' : '✗ 有字漏出'}`);

// ② 放大态：必须出字
S.cam.ts = 2.6; S.cam.s = 2.6; S.cam.x = 720; S.cam.y = 450;
await tick(3);
const zoomInFill = cnt('fillText') - zoomOutFill;
report.push(`放大态 fillText=${zoomInFill}  ${zoomInFill >= 20 ? '✓ 标签浮现' : '✗ 字太少'}`);

// ③ 弧线：quadraticCurveTo 必须被大量调用
const quad = cnt('quadraticCurveTo');
report.push(`弧线 quadraticCurveTo/帧=${Math.round(quad / 11)}  ${quad > 200 ? '✓' : '✗'}`);

// ④ 颜色多样性：复合色实际产生多少种
const hues = new Map();
for (const n of S.nodes) {
  const [h, s, l] = globalThis.window.__SEA.nodes.length ? (n._hsl || []) : [];
  if (n._hsl) hues.set(n._hsl.join('/'), (hues.get(n._hsl.join('/')) || 0) + 1);
}
report.push(`复合色种类=${hues.size}`);

// ⑤ 卡片：点开一条
const pickNode = S.nodes.slice().sort((a, b) => b.effWeight - a.effWeight)[3];
globalThis.window.__SEA.sel = pickNode.id;
try {
  const body = els.get('dBody');
  report.push(`卡片 HTML 长度=${(body.innerHTML || '').length}`);
} catch (e) { report.push('卡片渲染失败 ' + e.message); }

console.log(report.join('\n'));
console.log('RESULT:', zoomOutFill === 0 && zoomInFill >= 20 ? 'PASS' : 'CHECK');

// ⑥ 时间旅行：必须真的重排（环分布变化 + 点真的动了）
if (globalThis.window.__timeTravel) {
  const pos0 = new Map(S.nodes.map(n => [n.id, [n.px, n.py]]));
  const ring0 = S.nodes.reduce((a, n) => (a[n.ring] = (a[n.ring] || 0) + 1, a), {});
  globalThis.window.__timeTravel(180);
  await tick(3);
  const ring1 = S.nodes.reduce((a, n) => (a[n.ring] = (a[n.ring] || 0) + 1, a), {});
  let moved = 0, sum = 0;
  for (const n of S.nodes) {
    const p = pos0.get(n.id);
    if (!p) continue;
    const d = Math.hypot(n.px - p[0], n.py - p[1]);
    sum += d; if (d > 8) moved++;
  }
  console.log(`时间旅行 +180d：环分布 ${JSON.stringify(ring0)} → ${JSON.stringify(ring1)}`);
  console.log(`  重排位移 平均 ${(sum / S.nodes.length).toFixed(1)}px，移动超过 8px 的 ${moved} 条 ${moved > 200 ? '✓ 真重排' : '✗ 没动'}`);
  globalThis.window.__timeTravel(0);
  await tick(2);
}

// ── 可选：导出前端真实布局，给 Python 出预览图 ──
if (process.argv.includes('--dump')) {
  const W = 1440, H = 900, R = Math.min(W, H) * 0.40;
  S.cam.s = 1; S.cam.ts = 1; S.cam.x = W / 2; S.cam.y = H / 2;
  S.intro = 1;
  await tick(2);
  const edges = (S.edges || []).map(e => ({
    ax: +e.a._sx.toFixed(1), ay: +e.a._sy.toFixed(1),
    bx: +e.b._sx.toFixed(1), by: +e.b._sy.toFixed(1), ph: +e.ph.toFixed(4),
    w: +(e.w || 0).toFixed(3),
  }));
  const dumpNodes = () => S.nodes.map(n => ({
    id: n.id, x: +n.px.toFixed(2), y: +n.py.toFixed(2), s: +n.size.toFixed(2),
    h: n._hsl ? n._hsl[0] : 200, sa: n._hsl ? n._hsl[1] : 40, l: n._hsl ? n._hsl[2] : 60,
    nh: n._neb ? Math.round(n._neb[0]) : 260,
    nsa: n._neb ? Math.round(n._neb[1]) : 45,
    nl: n._neb ? Math.round(n._neb[2]) : 40,
    ring: n.ring, cold: n.cold ? 1 : 0, inv: n.valid_to ? 1 : 0,
    w: +n.effWeight.toFixed(3), cat: n.category,
    tiny: n.tiny, short: n.short, top: n.top ? 1 : 0,
    sx: +n._sx.toFixed(1), sy: +n._sy.toFixed(1), kk: +(n._k || 1).toFixed(3),
    z: +(n._z || 0).toFixed(1),
  }));
  fs.writeFileSync(path.join(DIR, '..', 'sea', 'demo', 'layout.json'),
    JSON.stringify({ W, H, R, cx: W / 2, cy: H / 2, yaw: S.cam.yaw, pitch: S.cam.pitch, nodes: dumpNodes(), edges }));
  console.log(`dumped layout-v7.json nodes=${S.nodes.length} edges=${edges.length}`);

  // 时间旅行快照：+180 天后（真的重排过）
  if (globalThis.window.__timeTravel) {
    globalThis.window.__timeTravel(180);
    // 物理跑 400 步让它收敛到新位置
    for (let i = 0; i < 400; i++) {
      const fn = pending; pending = null;
      if (fn) fn(performance.now());
    }
    fs.writeFileSync(path.join(DIR, '..', 'sea', 'demo', 'layout-180d.json'),
      JSON.stringify({ W, H, R, cx: W / 2, cy: H / 2, yaw: S.cam.yaw, pitch: S.cam.pitch, nodes: dumpNodes(), edges }));
    console.log('dumped layout-v7-180d.json');
    globalThis.window.__timeTravel(0);
  }
}
