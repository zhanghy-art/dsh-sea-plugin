// visible.test.mjs —— 回归测试：屏幕上"能看见几个点"
// v1.8/v1.9 的两个事故都出在这个盲区：之前所有断言都在测半径和连线，
// 没人测"可见点数"，于是 9600 条时屏幕上只剩 5 个点也没被拦住。
import assert from 'node:assert';

/** 复刻 neural-sea.html 里的分位数阈值逻辑 */
export function keyThreshold(weights) {
  const ws = [...weights].sort((a, b) => b - a);
  return ws.length ? Math.max(0.05, ws[Math.min(ws.length - 1, Math.floor(ws.length * 0.35))]) : 0.05;
}

/** 复刻 key 判定 */
function visibleCount(weights, zoom = 1.0) {
  const thr0 = keyThreshold(weights);
  const kz = Math.max(0, Math.min(1, (zoom - 1.10) / 0.55));
  const thr = thr0 * (1 - 0.70 * kz);
  return weights.filter(w => w >= thr).length;
}

/** 造一批像真实库的权重：指数衰减尾 + 冷存塌陷 */
function makeWeights(n, { coldRatio = 0.45, coldLevel = 0.03, seedShift = 1 } = {}) {
  const out = [];
  for (let i = 0; i < n; i++) {
    const r = ((i * 9301 + 49297) % 233280) / 233280;
    const isCold = r < coldRatio;
    out.push(isCold
      ? coldLevel * (0.4 + r * 2)                       // 冷存：0.012 ~ 0.06
      : 0.09 + Math.pow(1 - r, 2.2) * 0.91 * seedShift); // 活着的：0.09 ~ 1.0
  }
  return out;
}

console.log('N       阈值    可见(1.0×)  占比    可见(2.6×)  占比');
for (const n of [339, 800, 2400, 5000, 9600, 30000, 60000]) {
  const w = makeWeights(n);
  const v1 = visibleCount(w, 1.0);
  const v2 = visibleCount(w, 2.6);
  const thr = keyThreshold(w);
  console.log(
    String(n).padEnd(7),
    thr.toFixed(3).padStart(6),
    String(v1).padStart(9),
    (v1 / n * 100).toFixed(1).padStart(6) + '%',
    String(v2).padStart(11),
    (v2 / n * 100).toFixed(1).padStart(6) + '%'
  );
}

/* ── 断言 ─────────────────────────────────────────────── */
for (const n of [339, 2400, 9600, 60000]) {
  const w = makeWeights(n);
  const v = visibleCount(w, 1.0);
  const ratio = v / n;
  assert.ok(ratio >= 0.25 && ratio <= 0.48,
    `${n} 条时全局可见占比 ${(ratio * 100).toFixed(1)}% 应在 25%~48% 之间（分位数阈值保证密度恒定）`);
  assert.ok(v >= Math.min(n, 30),
    `${n} 条时只有 ${v} 个点可见，太少 —— 用户会以为记忆丢了`);
}
console.log('不同规模下可见占比都在 25%~48%       ✓');

/* 绝对阈值会怎样：证明旧写法为什么坏 */
{
  const w = makeWeights(9600);
  const oldVisible = w.filter(x => x > 0.45).length;
  const newVisible = visibleCount(w, 1.0);
  console.log(`对照：绝对阈值 0.45 时可见 ${oldVisible} 个，分位数阈值时 ${newVisible} 个`);
  assert.ok(newVisible > oldVisible * 3, '分位数阈值必须显著优于绝对阈值');
}

/* 小库不能糊成一坨：半径 + 点尺寸都要跟着缩 */
{
  const g = n => Math.min(2.8, Math.max(0.55, Math.pow(n / 2400, 1 / 3)));
  const scale = n => Math.min(1, Math.max(0.32, Math.sqrt(n / 2400)));
  const R339 = 405 * g(339), s339 = scale(339);
  const R2400 = 405 * g(2400), s2400 = scale(2400);
  assert.ok(R339 < R2400 * 0.62, '339 条时星云半径应明显小于 2421 条');
  assert.ok(s339 < 0.45 && s339 >= 0.32, '小库的点要缩到 0.32~0.45 之间');
  assert.ok(s2400 === 1, '2400 条时点尺寸不缩放');
  console.log(`小库自适应：R ${R339.toFixed(0)} / 点 ×${s339.toFixed(2)}  ✓`);
}

console.log('RESULT: PASS');
