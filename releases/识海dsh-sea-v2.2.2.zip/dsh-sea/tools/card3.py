#!/usr/bin/env python3
import os
# card3.py —— 出「点开一条记忆」的卡片预览：星图暗化 + 右侧卡片 + 指向线
import time
import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont
import json
from preview3 import render, hsv2rgb, node_rgb, ITEMS, F

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'docs', 'screenshots') + '/'
BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'sea', 'demo') + '/'
_L = json.load(open(BASE + 'layout.json'))
W, H, R_, CX, CY = _L['W'], _L['H'], _L['R'], _L['cx'], _L['cy']
NODES, EDGES = _L['nodes'], _L['edges']

# 选一条：有引号、权重大、坤坤线
pick = None
for n in NODES:
    it = ITEMS.get(n['id'], {})
    t = it.get('text', '')
    if ('「' in t and '」' in t and 0.42 < n['w'] < 0.86 and (n['x']**2 + n['y']**2) ** 0.5 / 360 > 0.34
            and '坤坤' in ' '.join(it.get('people', []))
            and len(it.get('links', [])) >= 2 and len(t) > 16):
        pick = (n, it); break
if pick is None:
    for n in NODES:
        it = ITEMS.get(n['id'], {})
        if '「' in it.get('text', '') and n['w'] > 0.5:
            pick = (n, it); break
n, it = pick
print('card node:', n['id'], it['text'][:30], n['w'])

base = render(1.0, labels=False, focus=n['id'])

sx, sy = CX + (n['sx'] - CX), CY + (n['sy'] - CY)
sel = Image.new('RGBA', (W, H), (0, 0, 0, 0))
sd = ImageDraw.Draw(sel)
col = tuple(int(c * 255) for c in hsv2rgb(n['h'], min(90, n['sa'] + 10), min(92, n['l'] + 14)))
GLOW = (255, 200, 110)
for rr, a, wd in ((72, 16, 1), (50, 26, 1), (34, 46, 1), (22, 92, 1), (14, 180, 2), (8, 245, 2)):
    sd.ellipse([sx - rr, sy - rr, sx + rr, sy + rr], outline=GLOW + (a,), width=wd)
sd.ellipse([sx - 3.2, sy - 3.2, sx + 3.2, sy + 3.2], fill=(255, 255, 255, 255))
# 十字星芒
for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
    sd.line([(sx + dx * 9, sy + dy * 9), (sx + dx * 26, sy + dy * 26)], fill=GLOW + (200,), width=2)
base = Image.alpha_composite(base.convert('RGBA'), sel.filter(ImageFilter.GaussianBlur(0.6))).convert('RGB')

CW = 400
canvas = Image.new('RGB', (W, H), (2, 3, 6))
canvas.paste(base, (0, 0))

# 右侧星图压暗
sh = np.zeros((H, W - CW + 40, 4), np.uint8)
for x in range(W - CW + 40):
    sh[:, x, 3] = int(150 * min(1, x / 220))
shimg = Image.fromarray(sh, 'RGBA')
canvas.paste(shimg, (W - CW - 40, 0), shimg)

# ── 卡片 ───────────────────────────────────────────────
card = Image.new('RGBA', (CW, H), (0, 0, 0, 0))
cd = ImageDraw.Draw(card)
for yy in range(H):
    t = yy / H
    cd.line([(0, yy), (CW, yy)],
            fill=(int(11 * (1 - t) + 3 * t), int(15 * (1 - t) + 5 * t), int(22 * (1 - t) + 9 * t), 242))
cd.line([(0, 0), (0, H)], fill=(150, 195, 255, 26))
bright = tuple(int(c * 255) for c in hsv2rgb(n['h'], min(96, n['sa'] + 8), min(96, n['l'] + 18)))
for i in range(CW):
    a = int(240 * max(0.0, 1 - i / (CW * 0.95)) ** 0.7)
    cd.line([(i, 0), (i, 2)], fill=bright + (a,))

X = 30
y = 30

cat = it.get('category', '')
kind = {'fact': '事实', 'episode': '片段', 'promise': '约定', 'raw': '原话'}.get(it.get('memory_kind'), '记忆')
emo_cn = {'calm': '平静', 'joy': '开心', 'sad': '难过', 'anxious': '不安',
          'intimate': '亲密', 'anger': '生气', 'tired': '疲惫', 'proud': '得意'}.get(it.get('emotion'), '')
state = '已失效' if n['inv'] else ('转冷' if n['cold'] else ('稳定' if n['w'] >= 0.5 else '衰减中'))
chips = [(cat, col, True), (kind, (147, 168, 188), False), (emo_cn, col, True), (state, (126, 168, 201), False)]
cx0 = X
for txt, c, dot in chips:
    f = F(10)
    w = int(f.getbbox(txt)[2]) + (18 if dot else 12)
    cd.rounded_rectangle([cx0, y, cx0 + w, y + 22], radius=11, outline=(150, 195, 255, 34))
    tx = cx0 + 8
    if dot:
        cd.ellipse([tx, y + 9, tx + 4, y + 13], fill=c)
        tx += 9
    cd.text((tx, y + 11), txt, font=f, fill=c if dot else (147, 168, 188), anchor='lm')
    cx0 += w + 7
y += 44

text = it.get('text', '')
q = ''
if '「' in text and '」' in text:
    a = text.index('「'); b = text.index('」')
    q = text[a + 1:b]
    text = (text[:a] + '——' + text[b + 1:]).replace('，——', '，').replace('——，', '——')


def wrap(d, txt, font, maxw):
    lines, cur = [], ''
    for ch in txt:
        if d.textlength(cur + ch, font=font) > maxw:
            lines.append(cur); cur = ch
        else:
            cur += ch
    if cur:
        lines.append(cur)
    return lines


fbody = F(17)
for ln in wrap(cd, text, fbody, CW - X * 2 - 4):
    cd.text((X, y), ln, font=fbody, fill=(234, 243, 251))
    y += 30
y += 8

if q:
    cd.line([(X, y), (X, y + 34)], fill=(255, 209, 102, 90), width=1)
    cd.text((X + 14, y + 17), f'「{q}」', font=F(14), fill=(232, 217, 174), anchor='lm')
    y += 50

y += 2
cd.text((X, y), '记忆权重', font=F(9), fill=(63, 79, 96))
y += 22
cd.text((X, y), f"{n['w']:.3f}", font=F(30), fill=col, anchor='la')
bx = X + 100
by = y + 20
cd.rectangle([bx, by, CW - X, by + 3], fill=(255, 255, 255, 22))
cd.rectangle([bx, by, bx + (CW - X - bx) * n['w'], by + 3], fill=bright + (230,))
y += 46

# 衰减曲线
chh, cw_ = 60, CW - X * 2
created = it['created_at']
end = 1761722182000
span = max(1, end - created)
half = {'人物': 180, '事实': 180, '群规': 180, '偏好': 90, '约定': 90, '事件': 60, '梗': 120}.get(it.get('category'), 90)
imp = 0.75 + 0.5 * it.get('importance', 0.5)
sal = 1 + 0.35 * it.get('emotional_salience', 0) + 0.25 * it.get('relationship_salience', 0)
pts = []
for i in range(120):
    t = created + span * i / 119
    d_ = (t - created) / 86400000
    v = min(1, (0.5 ** (d_ / half)) * imp * sal)
    pts.append((X + cw_ * i / 119, y + chh - 4 - v * (chh - 12)))
cd.line(pts, fill=col + (160,), width=2)
y += chh + 18

rows = [
    ('写入', time.strftime('%Y-%m-%d', time.localtime(created / 1000))),
    ('被想起', f"{it.get('recall_count', 0)} 次"),
    ('场景', it.get('scene', '—')),
    ('涉及', '、'.join(it.get('people', [])) or '只有我自己'),
    ('重要度 / 情绪', f"{it.get('importance', 0):.2f} / {it.get('emotional_salience', 0):.2f}"),
]
cd.text((X, y), '这条记忆', font=F(9), fill=(63, 79, 96))
y += 20
for k, v in rows:
    cd.text((X, y), k, font=F(12), fill=(126, 147, 167))
    cd.text((CW - X, y), v, font=F(12), fill=(207, 223, 238), anchor='ra')
    y += 26
    cd.line([(X, y - 8), (CW - X, y - 8)], fill=(255, 255, 255, 12))
y += 10

links = [ITEMS.get(i) for i in it.get('links', [])][:3]
links = [x for x in links if x]
if links:
    cd.text((X, y), '连着她', font=F(9), fill=(63, 79, 96))
    y += 18
    for o in links:
        on = next((x for x in NODES if x['id'] == o['id']), None)
        c2 = tuple(int(v * 255) for v in hsv2rgb(on['h'], min(90, on['sa']), min(90, on['l'] + 12))) if on else (150, 170, 190)
        cd.rectangle([X, y, CW - X, y + 36], outline=(150, 195, 255, 24))
        c2b = tuple(int(v * 255) for v in hsv2rgb(on['h'], min(96, on['sa'] + 10), min(96, on['l'] + 22))) if on else (200, 215, 230)
        cd.ellipse([X + 10, y + 15, X + 16, y + 21], fill=c2b)
        t2 = o['text'][:18] + ('…' if len(o['text']) > 18 else '')
        cd.text((X + 24, y + 18), t2, font=F(12), fill=(157, 178, 198), anchor='lm')
        y += 40
    y += 6

note = it.get('ai_note', '')
if note:
    cd.line([(X, y), (X, y + 24)], fill=(150, 195, 255, 50), width=1)
    cd.text((X + 12, y + 12), note, font=F(12), fill=(125, 147, 168), anchor='lm')

cd.text((X, H - 44), f"#{it['id']}", font=F(9), fill=(75, 91, 107))
cd.text((X, H - 28), "每一次被想起，她都会从外环往里挪一点", font=F(9), fill=(60, 74, 88))

card = card.filter(ImageFilter.GaussianBlur(0.2))
canvas.paste(card, (W - CW, 0), card)

# 指向线
d = ImageDraw.Draw(canvas, 'RGBA')
d.line([(sx + 20, sy), (W - CW - 16, sy - 40)], fill=GLOW + (70,), width=1)
d.line([(W - CW - 40, sy), (W - CW, sy)], fill=GLOW + (150,), width=1)

canvas.save(OUT + '03-card.png')
print('saved 03-card.png')
