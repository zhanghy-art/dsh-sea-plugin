#!/usr/bin/env python3
import os
# evo_preview.py —— 进化中枢的静态预览（与 evolution.html 同一套数据与布局）
import json, math, os, time as _t
from PIL import Image, ImageDraw, ImageFont
import numpy as np

REG = '/usr/local/share/fonts/custom/NotoSansSC-Regular.ttf'
F = lambda s: ImageFont.truetype(REG, s)
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'docs', 'screenshots') + '/'
BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'sea', 'demo') + '/'
LIB = json.load(open(BASE + 'library.json'))
ITEMS = LIB['items']

W, H = 1440, 1230
BG = (5, 7, 12)
DIM = (107, 127, 148)
FAINT = (63, 79, 96)
PANEL = (11, 15, 22)

C = {'人物': (167, 139, 250), '事实': (96, 165, 250), '偏好': (52, 211, 153),
     '约定': (251, 191, 36), '事件': (244, 114, 182), '梗': (163, 230, 53),
     '群规': (34, 211, 238)}
EMO = {'intimate': ('亲密', (244, 114, 182)), 'joy': ('开心', (251, 191, 36)),
       'calm': ('平静', (96, 165, 250)), 'sad': ('难过', (129, 140, 248)),
       'anxious': ('不安', (192, 132, 252)), 'anger': ('生气', (251, 113, 133)),
       'tired': ('疲惫', (148, 163, 184)), 'proud': ('得意', (252, 211, 77))}
RING = [('今天想起', (147, 197, 253)), ('稳定', (129, 140, 248)), ('衰减中', (99, 102, 241)),
        ('转冷', (71, 85, 105)), ('已失效', (43, 52, 64))]

now = 1793255760000   # 2026-10-29T06:36Z，与 mock-lib 的 NOW 对齐
ring_of = lambda m: 4 if m.get('valid_to') else (3 if m.get('cold') else (1 if m['effWeight'] >= 0.5 else 2))
rings = [0] * 5
types, emos = {}, {}
for m in ITEMS:
    rings[ring_of(m)] += 1
    types[m['category']] = types.get(m['category'], 0) + 1
    emos[m['emotion']] = emos.get(m['emotion'], 0) + 1

avgW = sum(m['effWeight'] for m in ITEMS) / len(ITEMS)
active = sum(1 for m in ITEMS if not m.get('cold') and not m.get('valid_to'))
span = (now - min(m['created_at'] for m in ITEMS)) / 86400000
links = sum(len(m.get('links', [])) for m in ITEMS)

img = Image.new('RGB', (W, H), BG)
yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
arr = np.asarray(img, np.float32).copy()
for (cx, cy, rx, ry, col, a) in [(W/2, 60, 520, 300, (120, 80, 200), 0.16),
                                  (120, H*0.9, 420, 300, (60, 90, 180), 0.10),
                                  (W*0.9, H*0.8, 360, 260, (180, 70, 140), 0.08)]:
    dd = np.sqrt(((xx-cx)/rx)**2 + ((yy-cy)/ry)**2)
    mm = np.clip(1 - dd, 0, 1) ** 2
    for i in range(3):
        arr[..., i] += mm * col[i] * a
img = Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8))

d = ImageDraw.Draw(img, 'RGBA')
X0, X1 = 26, W - 26


def spaced(x, y, text, font, fill, sp=6):
    for ch in text:
        d.text((x, y), ch, font=font, fill=fill, anchor='lm')
        x += font.getbbox(ch)[2] + sp


def panel(x, y, w, h, accent=None):
    d.rectangle([x, y, x + w, y + h], fill=PANEL + (230,), outline=(150, 195, 255, 26))
    if accent:
        d.rectangle([x, y, x + 2, y + h], fill=accent + (150,))


spaced(X0, 44, '进化中枢', F(15), (234, 245, 255))
d.text((X0 + 140, 44), 'EVOLUTION CORE', font=F(10), fill=DIM, anchor='lm')
d.text((X1, 40), '21:58', font=F(10), fill=DIM, anchor='rm')
d.rectangle([X1 - 96, 52, X1, 74], outline=(150, 195, 255, 30))
d.text((X1 - 48, 63), '← 返回识海', font=F(9), fill=(107, 127, 148), anchor='mm')
d.line([(X0, 88), (X1, 88)], fill=(150, 195, 255, 26))

# ── 状态行（11.0 §3.5）──
BASE_H = {'cortisol': 30, 'dopamine': 50, 'oxytocin': 40, 'serotonin': 60}
CUR_H = {'cortisol': 35, 'dopamine': 55, 'oxytocin': 41, 'serotonin': 42}
# v11.1 §17.4.2：纯文字、不带数字、激素名不进提示词
moods = []
if CUR_H['dopamine'] > 58:
    moods.append('心情不错')
elif CUR_H['serotonin'] < 50:
    moods.append('有点提不起劲')
else:
    moods.append('还算平静')
if 0.80 > 0.90:
    moods.append('精神挺好')
elif 0.80 < 0.50:
    moods.append('有点累')
line_txt = '[状态] 下午，' + '，'.join(moods) + '，心里踏实'

d.rectangle([X0, 96, X1, 128], fill=(11, 15, 22, 140), outline=(150, 195, 255, 26))
d.text((X0 + 16, 106), '注入给她的那一行 · 消费者是模型', font=F(8), fill=FAINT)
d.text((X0 + 16, 120), line_txt, font=F(11), fill=(159, 180, 200), anchor='lm')
d.text((X1 - 16, 106), '面板读数 · 只给人看', font=F(8), fill=FAINT, anchor='ra')
d.text((X1 - 16, 120),
       '精力 0.80　皮质醇 35↑　多巴胺 55　催产素 41　血清素 42↓　深度信任',
       font=F(9.5), fill=(125, 147, 168), anchor='rm')

quads = [('总记忆', str(len(ITEMS)), f'跨 {round(span/30)} 个月', (167, 139, 250)),
         ('活跃', str(active), f'{active/len(ITEMS)*100:.0f}% 还在被想起', (52, 211, 153)),
         ('平均权重', f'{avgW:.3f}', 'effWeight 全库', (251, 191, 36)),
         ('关联边', str(links), f'{links/len(ITEMS):.1f} 条 / 记忆', (244, 114, 182))]
qw = (X1 - X0 - 42) / 4
for i, (k, v, s, c) in enumerate(quads):
    x = X0 + i * (qw + 14)
    panel(x, 144, qw, 86, c)
    d.text((x + 18, 162), k, font=F(9), fill=FAINT)
    d.text((x + 18, 180), v, font=F(30), fill=c)
    d.text((x + 18, 216), s, font=F(10), fill=DIM)

TY = 246
CARD_H = 268
c1w = (X1 - X0 - 28) * 0.365
c2w = (X1 - X0 - 28) * 0.30
c3w = (X1 - X0 - 28) * 0.335

panel(X0, TY, c1w, CARD_H)
d.text((X0 + 20, TY + 22), '生命周期', font=F(10), fill=FAINT)
d.text((X0 + c1w - 20, TY + 22), '越靠外，记得越浅', font=F(10), fill=(84, 103, 122), anchor='ra')
bx, by, bw = X0 + 20, TY + 44, c1w - 40
cx_ = bx
for i, (n, c) in enumerate(RING):
    wseg = bw * rings[i] / len(ITEMS)
    d.rectangle([cx_, by, cx_ + wseg, by + 8], fill=c + (204,))
    cx_ += wseg
for i, (n, c) in enumerate(RING):
    y = TY + 70 + i * 34
    d.ellipse([X0 + 20, y + 8, X0 + 26, y + 14], fill=c + (230,))
    d.text((X0 + 34, y + 11), n, font=F(11), fill=(139, 160, 180), anchor='lm')
    d.text((X0 + c1w - 20, y + 11), f'{rings[i]}', font=F(11), fill=(207, 223, 238), anchor='rm')
    d.text((X0 + c1w - 66, y + 11), f'{rings[i]/len(ITEMS)*100:.1f}%', font=F(10), fill=FAINT, anchor='rm')
    d.line([(X0 + 20, y + 26), (X0 + c1w - 20, y + 26)], fill=(255, 255, 255, 10))

x2 = X0 + c1w + 14
panel(x2, TY, c2w, CARD_H)
d.text((x2 + 20, TY + 22), '类型构成', font=F(10), fill=FAINT)
d.text((x2 + c2w - 20, TY + 22), '颜色 = 类型 × 情绪', font=F(10), fill=(84, 103, 122), anchor='ra')
dcx, dcy = x2 + c2w / 2, TY + 118
R0, R1 = 74, 46
arrt = sorted(types.items(), key=lambda kv: -kv[1])
a0 = -90
for k, v in arrt:
    a1 = a0 + v / len(ITEMS) * 360
    d.arc([dcx - R0, dcy - R0, dcx + R0, dcy + R0], a0 + 1, a1 - 1,
          fill=C.get(k, (100, 116, 139)) + (210,), width=R0 - R1)
    a0 = a1
d.text((dcx, dcy - 6), str(len(ITEMS)), font=F(26), fill=(234, 245, 255), anchor='mm')
d.text((dcx, dcy + 16), 'TOTAL', font=F(9), fill=(84, 103, 122), anchor='mm')
ly = TY + 206
for i, (k, v) in enumerate(arrt[:4]):
    yy_ = ly + i * 15
    d.ellipse([x2 + 20, yy_ - 3, x2 + 26, yy_ + 3], fill=C.get(k, (100, 116, 139)) + (230,))
    d.text((x2 + 34, yy_), k, font=F(10), fill=(139, 160, 180), anchor='lm')
    d.text((x2 + c2w / 2 - 6, yy_), str(v), font=F(10), fill=(207, 223, 238), anchor='rm')
for i, (k, v) in enumerate(arrt[4:]):
    yy_ = ly + i * 15
    d.ellipse([x2 + c2w / 2 + 14, yy_ - 3, x2 + c2w / 2 + 20, yy_ + 3], fill=C.get(k, (100, 116, 139)) + (230,))
    d.text((x2 + c2w / 2 + 28, yy_), k, font=F(10), fill=(139, 160, 180), anchor='lm')
    d.text((x2 + c2w - 20, yy_), str(v), font=F(10), fill=(207, 223, 238), anchor='rm')

x3 = x2 + c2w + 14
panel(x3, TY, c3w, CARD_H)
d.text((x3 + 20, TY + 22), '情绪剖面', font=F(10), fill=FAINT)
d.text((x3 + c3w - 20, TY + 22), '八种基调', font=F(10), fill=(84, 103, 122), anchor='ra')
rcx, rcy = x3 + c3w / 2, TY + 126
RR = 78
keys = list(EMO.keys())
maxv = max(emos.get(k, 0) for k in keys)


def pt(i, r):
    a = -math.pi / 2 + i / len(keys) * 2 * math.pi
    return rcx + math.cos(a) * r, rcy + math.sin(a) * r


for ring in range(1, 5):
    poly = [pt(i, RR * ring / 4) for i in range(len(keys))]
    d.polygon(poly, outline=(150, 195, 255, 18))
for i in range(len(keys)):
    d.line([(rcx, rcy), pt(i, RR)], fill=(150, 195, 255, 12))
poly = [pt(i, max(0.06, emos.get(k, 0) / maxv) * RR) for i, k in enumerate(keys)]
d.polygon(poly, fill=(167, 139, 250, 60), outline=(196, 181, 253, 220))
for i, k in enumerate(keys):
    x, y = pt(i, max(0.06, emos.get(k, 0) / maxv) * RR)
    d.ellipse([x - 2.2, y - 2.2, x + 2.2, y + 2.2], fill=EMO[k][1] + (255,))
    lx, ly2 = pt(i, RR + 17)
    d.text((lx, ly2), EMO[k][0], font=F(9.5), fill=(125, 146, 166), anchor='mm')
top3 = sorted(keys, key=lambda k: -emos.get(k, 0))[:3]
for i, k in enumerate(top3):
    yy_ = TY + 226 + i * 14
    d.ellipse([x3 + 20, yy_ - 3, x3 + 26, yy_ + 3], fill=EMO[k][1] + (255,))
    d.text((x3 + 34, yy_), EMO[k][0], font=F(10), fill=(139, 160, 180), anchor='lm')
    d.text((x3 + c3w - 20, yy_), f'{emos.get(k,0)} · {emos.get(k,0)/len(ITEMS)*100:.0f}%',
           font=F(10), fill=(207, 223, 238), anchor='rm')

MY = TY + CARD_H + 14
MH = 172
panel(X0, MY, X1 - X0, MH)
d.text((X0 + 20, MY + 22), '时间分布', font=F(10), fill=FAINT)
d.text((X1 - 20, MY + 22), '两年，按月', font=F(10), fill=(84, 103, 122), anchor='ra')
buckets = {}
for m in ITEMS:
    tm = _t.localtime(m['created_at'] / 1000)
    k = f'{tm.tm_year}-{tm.tm_mon:02d}'
    b = buckets.setdefault(k, [0, 0.0])
    b[0] += 1
    b[1] += m['effWeight']
kys = sorted(buckets)
maxn = max(b[0] for b in buckets.values())
mh = MH - 62
bw = (X1 - X0 - 40) / len(kys)
for i, k in enumerate(kys):
    n, wsum = buckets[k]
    bh = n / maxn * mh
    avg = wsum / n
    x = X0 + 20 + i * bw + bw * 0.16
    y = MY + MH - 34 - bh
    col = (int(70 + 110 * (1 - avg)), int(60 + 60 * (1 - avg)), int(130 + 90 * (1 - avg)))
    for step in range(int(bh)):
        a = 0.85 - 0.6 * step / max(1, bh)
        d.line([(x, y + step), (x + bw * 0.68, y + step)], fill=col + (int(a * 255),))
lastY = ''
for i, k in enumerate(kys):
    yr = k[:4]
    if yr != lastY:
        d.text((X0 + 20 + i * bw, MY + MH - 22), yr, font=F(8.5), fill=FAINT)
        lastY = yr
d.text((X1 - 20, MY + MH - 22), '每月写入条数 · 柱色随当月平均权重由紫转青',
       font=F(8.5), fill=FAINT, anchor='ra')

PY = MY + MH + 14
PH = 300
pw = (X1 - X0 - 14) * 0.42
panel(X0, PY, pw, PH)
d.text((X0 + 20, PY + 22), '人物共现', font=F(10), fill=FAINT)
d.text((X0 + pw - 20, PY + 22), '同一条记忆里一起出现', font=F(10), fill=(84, 103, 122), anchor='ra')
solo, pairs = {}, {}
for m in ITEMS:
    ps = [p for p in m.get('people', []) if p]
    for p in ps:
        solo[p] = solo.get(p, 0) + 1
    for i in range(len(ps)):
        for j in range(i + 1, len(ps)):
            kk = '|'.join(sorted([ps[i], ps[j]]))
            pairs[kk] = pairs.get(kk, 0) + 1
nodes = sorted(solo.items(), key=lambda kv: -kv[1])[:9]
maxc = max(v for _, v in nodes)
ncx, ncy = X0 + pw / 2, PY + 160
NR = min(pw, PH) / 2 - 74
pos = {}
for i, (nm, c) in enumerate(nodes):
    a = -math.pi / 2 + i / len(nodes) * 2 * math.pi
    rr = NR * (0.55 + 0.45 * (1 - c / maxc))
    pos[nm] = (ncx + math.cos(a) * rr, ncy + math.sin(a) * rr)
maxp = max(pairs.values()) if pairs else 1
for kk, v in pairs.items():
    a_, b_ = kk.split('|')
    if a_ not in pos or b_ not in pos:
        continue
    x1_, y1_ = pos[a_]
    x2_, y2_ = pos[b_]
    d.line([(x1_, y1_), (x2_, y2_)], fill=(167, 139, 250, int((0.10 + 0.42 * v / maxp) * 255)),
           width=max(1, int(0.6 + 1.4 * v / maxp)))
for nm, c in nodes:
    x, y = pos[nm]
    r = 3 + 9 * (c / maxc)
    d.ellipse([x - r, y - r, x + r, y + r], fill=(167, 139, 250, 46))
    d.ellipse([x - r * 0.52, y - r * 0.52, x + r * 0.52, y + r * 0.52], fill=(196, 181, 253, 255))
    d.text((x, y + r + 12), nm, font=F(10), fill=(157, 178, 198), anchor='mm')
    d.text((x, y + r + 24), f'{c} 条', font=F(8.5), fill=(74, 91, 108), anchor='mm')

x4 = X0 + pw + 14
w4 = X1 - x4
panel(x4, PY, w4, PH)
d.text((x4 + 20, PY + 22), '关系最密的记忆', font=F(10), fill=FAINT)
d.text((x4 + w4 - 20, PY + 22), '点击进入识海', font=F(10), fill=(84, 103, 122), anchor='ra')
tops = sorted(ITEMS, key=lambda m: -(m['effWeight'] + len(m.get('links', [])) * 0.05))[:12]
for i, m in enumerate(tops):
    yy_ = PY + 48 + i * 21
    c = C.get(m['category'], (100, 116, 139))
    d.ellipse([x4 + 20, yy_ - 3, x4 + 26, yy_ + 3], fill=c + (230,))
    d.text((x4 + 34, yy_), m['text'][:26], font=F(11), fill=(169, 189, 208), anchor='lm')
    barx = x4 + w4 - 132
    d.line([(barx, yy_), (barx + 42, yy_)], fill=(255, 255, 255, 18))
    d.line([(barx, yy_), (barx + 42 * m['effWeight'], yy_)], fill=c + (200,), width=2)
    tail = f"{m['effWeight']:.2f}" + (f" · {len(m.get('links',[]))}联" if m.get('links') else '')
    d.text((x4 + w4 - 20, yy_), tail, font=F(10), fill=(93, 114, 134), anchor='rm')
    d.line([(x4 + 20, yy_ + 10), (x4 + w4 - 20, yy_ + 10)], fill=(255, 255, 255, 8))

HY = PY + PH + 14
HH = 150
hw = (X1 - X0 - 14) / 2
panel(X0, HY, hw, HH)
d.text((X0 + 20, HY + 22), '权重分布', font=F(10), fill=FAINT)
d.text((X0 + hw - 20, HY + 22), 'effWeight 直方图', font=F(10), fill=(84, 103, 122), anchor='ra')
B = 40
bins = [0] * B
for m in ITEMS:
    bins[min(B - 1, int(m['effWeight'] * B))] += 1
mb = max(bins)
for i, v in enumerate(bins):
    bh = v / mb * (HH - 66)
    x = X0 + 20 + i * (hw - 40) / B
    col = (int(190 - 60 * i / B), int(140 - 40 * i / B), 250)
    d.rectangle([x + 1, HY + HH - 34 - bh, x + (hw - 40) / B - 1, HY + HH - 34], fill=col + (200,))

x5 = X0 + hw + 14
panel(x5, HY, hw, HH)
d.text((x5 + 20, HY + 22), '为什么是这个权重', font=F(10), fill=FAINT)
d.text((x5 + hw - 20, HY + 22), 'why · 12.4 可解释', font=F(10), fill=(84, 103, 122), anchor='ra')

HALF = {'人物': 180, '事实': 180, '群规': 180, '偏好': 90, '约定': 90, '事件': 60, '梗': 120}
wm = tops[0]
c0 = wm.get('confirmed_at') or wm['created_at']
days = (now - c0) / 86400000
half = HALF.get(wm['category'], 90)
base = 1.0
decay = 0.5 ** (days / half)
impF = 0.75 + 0.5 * wm.get('importance', 0.5)
salF = 1 + 0.35 * wm.get('emotional_salience', 0) + 0.25 * wm.get('relationship_salience', 0)

d.text((x5 + 20, HY + 46), wm['text'][:30], font=F(10.5), fill=(169, 189, 208))
nodes = [('1.000', 'base', '基础权重'), ('×', '', ''), (f'{decay:.3f}', '衰减', f'{round(days)}d/{half}d'),
         ('×', '', ''), (f'{impF:.2f}', '重要度', f'{wm.get("importance",0):.2f}'),
         ('×', '', ''), (f'{salF:.2f}', '情绪关系', f'{wm.get("emotional_salience",0):.2f}/{wm.get("relationship_salience",0):.2f}'),
         ('=', '', ''), (f'{wm["effWeight"]:.3f}', 'effWeight', '')]
cx_ = x5 + 26
for v, kk, sub in nodes:
    if kk == '':
        d.text((cx_, HY + 96), v, font=F(13), fill=(51, 65, 79), anchor='mm')
        cx_ += 22
        continue
    is_end = kk == 'effWeight'
    d.text((cx_ + 30, HY + 86), v, font=F(15 if not is_end else 19),
           fill=(207, 223, 238) if not is_end else (251, 191, 36), anchor='mm')
    d.text((cx_ + 30, HY + 104), kk, font=F(8), fill=FAINT, anchor='mm')
    if sub:
        d.text((cx_ + 30, HY + 116), sub, font=F(7.5), fill=(63, 79, 96), anchor='mm')
    cx_ += 62
d.text((x5 + 20, HY + HH - 22),
       f'被想起 {wm.get("recall_count",0)} 次 · 拆开看才判断得了半衰期和显著性权重是否合理',
       font=F(8.5), fill=FAINT)

d.text((X0, H - 24), f'数据：library.json · {len(ITEMS)} 条 · 模拟库', font=F(9), fill=(47, 60, 73))
d.text((X1, H - 24), '识海 · 进化中枢', font=F(9), fill=(47, 60, 73), anchor='ra')

img.save(OUT + '05-evolution.png')
print('saved preview-evo.png', img.size)
