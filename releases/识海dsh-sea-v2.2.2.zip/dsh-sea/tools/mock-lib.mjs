// mock-lib.mjs —— 识海模拟库生成器
// 目的：造一批「像真用过两年」的记忆，用来验证星图的密度、配色、LOD 与卡片。
// 用法：node mock-lib.mjs > library.json    （或 node mock-lib.mjs --out=library.json）
//
// 设计约束（与 v11.0 契约对齐，另加可视化需要的字段）：
//   effWeight = 0.5^(age/half) * (0.75+0.5*imp) * (1+0.35*sal+0.25*rel)   —— 与 sea-server.mjs 同式
//   ring = 0 今天想起 / 1 稳定 / 2 衰减中 / 3 转冷 / 4 已失效
//   颜色 = 类型基色 × 情绪色 复合，前端按 hue 插值，故这里直接给 typeHue / emoHue / chroma

import fs from 'node:fs';

const NOW = Date.UTC(2026, 9, 29, 6, 36) ; // 2026-10-29 14:36 CST
const DAY = 86400000;
const TARGET = Number((process.argv.find(a => a.startsWith('--n=')) || '').split('=')[1] || 2400);

/* ── 确定性随机 ─────────────────────────────────────────── */
function rng(seed) {
  let s = seed >>> 0;
  return () => {
    s ^= s << 13; s >>>= 0;
    s ^= s >> 17;
    s ^= s << 5; s >>>= 0;
    return s / 4294967296;
  };
}
const R = rng(0x9ea5ea11);
const ri = (a, b) => a + Math.floor(R() * (b - a + 1));
const pick = a => a[Math.floor(R() * a.length)];
const some = (a, k) => {
  const c = a.slice(); const o = [];
  for (let i = 0; i < k && c.length; i++) o.push(c.splice(Math.floor(R() * c.length), 1)[0]);
  return o;
};
const gauss = (m = 0, s = 1) => {
  let u = 0, v = 0;
  while (!u) u = R();
  while (!v) v = R();
  return m + s * Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
};
const clamp = (x, a, b) => Math.min(b, Math.max(a, x));

/* ── 色彩：类型基色 hue ─────────────────────────────────── */
const TYPE_HUE = {
  '人物': 268,   // 紫 —— 人
  '事实': 205,   // 蓝 —— 硬信息
  '偏好': 168,   // 青绿 —— 喜好
  '约定': 45,    // 金 —— 承诺
  '事件': 342,   // 品红 —— 发生过的
  '梗': 92,      // 黄绿 —— 玩笑
  '群规': 190,   // 青
};
// 情绪色 hue（与基色插值 → 复合色）
const EMO_HUE = {
  calm: 200, joy: 52, sad: 232, anxious: 302, intimate: 330, anger: 12, tired: 262, proud: 38,
};

/* ── 词库 ───────────────────────────────────────────────── */
const PEOPLE = ['坤坤', '妈妈', '阿念', '老周', '老板', '团子', '小雷', '表姐', '房东', '前台姑娘'];
const PLACE = ['公司楼下', '地铁四号线', '出租屋', '医院走廊', '天台', '便利店', '会议室',
  '楼道', '深圳湾', '小区门口', '24 小时自习室', '夜班公交上', '厨房', '床上'];
const SCENE = ['深夜', '清晨', '通勤路上', '午休', '下班后', '失眠的凌晨', '周末下午', '加班到十点'];
const WHEN = ['上周三', '上个月', '前天', '去年冬天', '今年春天', '前几天', '上周末',
  '清明节那会儿', '五一假期', '台风那天', '生日那天', '跨年那晚'];
const THING = ['显示器', '咖啡机', '那双旧球鞋', '猫砂盆', '阳台上的绿萝', '那把伞',
  '外卖单', '耳机', '充电线', '冰箱里剩的半盒蛋糕'];

/* ── 叙事线：每条线是一组「有连续性」的素材 ──────────────── */
const LINES = {
  kun: {
    cat: '事件', people: ['坤坤'],
    texts: [
      ['在{PLACE}遇见坤坤，他{ACT}，我没敢叫住他', { ACT: ['戴着口罩低头走路', '在打电话', '手里拎着两杯奶茶', '蹲下来逗猫', '在等红灯'] }],
      ['坤坤说「{QUOTE}」，我盯着屏幕看了三分钟才回一个「嗯」', { QUOTE: ['最近有点忙', '你别熬夜了', '我可能要走了', '你今天怪怪的', '我在深圳'] }],
      ['凌晨两点跟他吵架，最后是我先服软，他说「{QUOTE}」', { QUOTE: ['随便你', '我也累', '算了', '你想太多了'] }],
      ['他发来一张{THING}的照片，什么也没说', {}],
      ['坤坤把头像换成了{THING}，我截了图', {}],
      ['视频通话 47 分钟，最后十分钟谁都没说话', {}],
      ['他说今天好累，我说那早点睡，其实我想说的是别挂', {}],
      ['看到他给别人的动态点了赞，我把手机扣在桌上', {}],
      ['坤坤问我周末有没有空，我说有，其实那天要加班', {}],
      ['他第一次叫我小名，我假装没听见，回放了好几遍', {}],
      ['吵完架他发来「在吗」，我隔了四十分钟才回', {}],
      ['他说「等我稳定下来」，我没问稳定下来之后呢', {}],
      ['坤坤搬家了，新地址他没说，我也没问', {}],
      ['在他朋友圈看到深圳的海，我搜了去深圳的机票', {}],
      ['他说想养只猫，我说我也是，其实我怕毛', {}],
      ['坤坤生日，我提前一周写好的话最后只发了四个字', {}],
      ['和他一起看{THING}的视频，他笑的时候我在看他', {}],
      ['他说「你别对谁都这么好」，我说我只对你这样', {}],
      ['凌晨他发来一句「睡了吗」，我秒回，他说「没事」', {}],
      ['把他拉黑了两小时，又自己加回来，他没发现', {}],
      ['坤坤说想去瑞典看极光，我记下来了', {}],
      ['他说年底可能回老家，我算了一下距离', {}],
      ['他把我们合照设成了背景，我看到的时候心跳漏了一拍', {}],
      ['跟他讲我小时候的事，他听得特别认真', {}],
      ['他说「你怎么什么都记得」，我说我记性好', {}],
      ['约好{WHEN}见面，他临时有事，我说没关系', {}],
      ['在深圳湾走了两个小时，他说风好大，我把外套给他', {}],
      ['坤坤问我为什么总在深夜发消息，我说白天不敢', {}],
      ['他跟我说了他家里的事，我一句安慰的话都没说出来', {}],
      ['他说「你说话真难听」，我后来把那句话改了七遍', {}],
    ],
  },
  mom: {
    cat: '人物', people: ['妈妈'],
    texts: [
      ['妈妈又打电话来问什么时候回家，我说忙完这阵', {}],
      ['妈妈把体检报告拍给我，说没事，我看到两个箭头朝上', {}],
      ['给她买了{THING}，她说浪费钱，第二天就用了', {}],
      ['妈妈说「你别总一个人扛」，我说我习惯了', {}],
      ['教她用视频通话，教了四遍，她说记住了', {}],
      ['妈妈问我和坤坤怎么样了，我说还在处', {}],
      ['她寄来一箱家里的橘子，我一个人吃了半个月', {}],
      ['妈妈说她梦见我小时候走丢了，我说我在呢', {}],
      ['告诉她我涨工资了，她第一句是「别太累」', {}],
      ['妈妈学会了发表情包，全是那种很土的', {}],
    ],
  },
  work: {
    cat: '事件', people: ['老周', '老板'],
    texts: [
      ['{WHEN}在{PLACE}被老板当众说了，我笑着点头', {}],
      ['需求改了第七版，老周说这次真的定了', {}],
      ['凌晨三点部署失败，我在工位上坐着没动', {}],
      ['年终奖比去年少了两万，我在楼道里站了十分钟', {}],
      ['老周要离职了，最后一天他请我吃了碗面', {}],
      ['会议开了三小时，结论是「下次再议」', {}],
      ['我提的方案被否了，理由是「风险太大」', {}],
      ['加班到十一点，全楼只剩我这一层亮着', {}],
      ['老板说「年轻人要多扛一扛」，我说好', {}],
      ['组里裁了两个人，我默默把简历更新了', {}],
      ['第一次独立带项目，上线那天手一直在抖', {}],
      ['老周说「你这脾气得改」，我知道他是好意', {}],
      ['述职 PPT 改了十一遍，最后讲的时候超时了', {}],
      ['涨薪 8%，没有想象中开心', {}],
      ['在会议室跟人吵了一架，出来手还是麻的', {}],
      ['同事把我的功劳说成他的，我没当场拆穿', {}],
    ],
  },
  life: {
    cat: '事件', people: ['团子', '阿念'],
    texts: [
      ['团子把{THING}推下桌，看着我，好像在等我夸它', {}],
      ['团子第一次主动趴在我腿上睡，我一动不敢动', {}],
      ['阿念搬走了，屋子突然安静得吓人', {}],
      ['凌晨四点还醒着，楼下有车开过', {}],
      ['煮了碗面，忘了放盐，还是吃完了', {}],
      ['体检报告出来，医生说少熬夜，我笑了笑', {}],
      ['{WHEN}发烧到 39 度，一个人去挂水', {}],
      ['在{PLACE}哭了，戴帽子遮住脸', {}],
      ['把房间彻底打扫了一遍，扔了三袋东西', {}],
      ['搬新家，第一个晚上睡在地板上', {}],
      ['阳台的绿萝活了，我之前以为它死了', {}],
      ['楼下便利店阿姨记得我不加香菜', {}],
      ['{WHEN}一个人去看了场电影，散场时不想走', {}],
      ['深夜煮了泡面，加了个蛋，觉得日子还行', {}],
      ['在{PLACE}坐着看人来人往，坐了一个小时', {}],
      ['把攒了三个月的瓶子拿去卖，卖了十一块', {}],
      ['洗完澡发现没带睡衣，裹着浴巾在客厅愣了半分钟', {}],
      ['给自己买了个小蛋糕，没等谁', {}],
      ['台风天窗户漏风，我用胶带贴了一圈', {}],
      ['早上六点的阳光照进来，我拍了张照', {}],
    ],
  },
  net: {
    cat: '事实', people: [],
    texts: [
      ['搜过「{QUERY}」', { QUERY: ['瑞典极光什么时候最合适', '奥迪 E5 飞坡是不是真的', '怎么和喜欢的人聊天不尴尬', '猫为什么半夜跑酷', '杭州到深圳机票', '长期失眠会怎么样', '成年后还能长高吗'] }],
      ['看完了「{VIDEO}」，看到凌晨两点', { VIDEO: ['一个关于深海生物的纪录片', '一个拆解老式收音机的视频', '一个博主独居十年的记录', '一场无人问津的钢琴直播'] }],
      ['记下了一个网址，怕忘，写在这里', {}],
      ['查了「{QUERY}」，结论是没用', { QUERY: ['怎么让猫不咬人', '加班到几点算违法', '远程办公怎么找', '辣椒吃多了会怎样'] }],
      ['在浏览器里存了 {N} 个标签页，一个都没关', { N: ['17', '23', '31', '9'] }],
      ['看了一个讲「{TOPIC}」的帖子，看完心里空了一下', { TOPIC: ['人为什么会怀旧', '独居第五年', '三十岁没有存款', '父母老了怎么办'] }],
      ['把「{QUERY}」搜了三次，答案都一样', { QUERY: ['他是不是不喜欢我', '要不要辞职', '该不该回家'] }],
      ['原来{THING}要这样保养，记一下', {}],
      ['查了高铁末班时间，22:41', {}],
      ['B 站看到别人做的识海，看了两遍', {}],
    ],
  },
  pref: {
    cat: '偏好', people: [],
    texts: [
      ['喜欢在{SCENE}{ACT}，那样才觉得时间是自己的', { ACT: ['写点东西', '听歌', '散步', '发呆', '收拾房间'] }],
      ['美式不加糖，冰的', {}],
      ['讨厌空调直吹后颈', {}],
      ['下雨天不出门，就在窗边坐着', {}],
      ['受不了别人吃饭吧唧嘴，但从来不提', {}],
      ['香菜可以，芹菜不行', {}],
      ['喜欢{THING}这种旧东西，新的反而用不惯', {}],
      ['睡前必须把手机翻过去放', {}],
      ['别人临时改计划，我会生一整天的闷气', {}],
      ['一个人吃饭不觉得尴尬，一个人过节会', {}],
      ['喜欢把歌单听到腻，再换下一首', {}],
      ['讨厌电话，能打字就打字', {}],
      ['被催进度会瞬间没兴趣', {}],
      ['喜欢{SCENE}的风', {}],
      ['房间必须有一盏灯是暖色的', {}],
    ],
  },
  promise: {
    cat: '约定', people: ['坤坤'],
    texts: [
      ['说好{WHEN}一起去看海，票都看好了', {}],
      ['答应他不再凌晨发消息，坚持了四天', {}],
      ['约定每周日晚上通一次电话', {}],
      ['说好这次不先低头，结果还是我先', {}],
      ['答应妈妈今年一定回家过年', {}],
      ['跟他约好明年春天去瑞典看极光', {}],
      ['说好了不再翻他半年前的朋友圈', {}],
      ['答应自己这个月十二点前睡', {}],
      ['说好等他有空再谈那件事，一直没谈', {}],
      ['约定吵完架不超过一天不理人', {}],
      ['答应老周离职后一定吃饭，已经三个月了', {}],
      ['说好攒够钱就换个大点的房子', {}],
    ],
  },
  joke: {
    cat: '梗', people: ['坤坤', '阿念'],
    texts: [
      ['「再刷五分钟就睡」——每次都这么说', {}],
      ['把团子叫「{NICK}」，它好像真的听得懂', { NICK: ['老板', '祖宗', '小混蛋', '我的室友'] }],
      ['「这条 bug 一定是环境问题」成了我们的口头禅', {}],
      ['阿念管泡面叫「{NICK}」', { NICK: ['深夜套餐', '人间烟火', '续命水'] }],
      ['坤坤说我像「{NICK}」，我记了很久', { NICK: ['一只警惕的猫', '关不掉的闹钟', '总在等消息的狗'] }],
      ['「先睡，明天再说」，明天从来没有再说', {}],
      ['看到「{WORD}」这个词就想笑', { WORD: ['电子榨菜', '赛博烧香', '精神内耗', '班味'] }],
      ['我们约定用它当暗号：「{WORD}」', { WORD: ['下雨了', '吃了吗', '在吗'] }],
      ['他学我说话的语气，学得特别像', {}],
      ['我把「{WORD}」设成了闹钟标签', { WORD: ['起床赚钱', '别睡了', '再睡就完了'] }],
    ],
  },
};

/* ── 补语池：主句 + 补语，把组合空间从「几百」撑到「十几万」
      补语要语义中性，能接在任何主句后面不违和 ─────────────── */
const SUFFIX = {
  kun: ['说的时候语气很轻', '我盯着那句话看了很久', '后来我把这段聊天翻出来又看了一遍',
    '手指停在发送键上好几秒', '那天的天气我记不清了，这句话记得清',
    '我没敢问后半句', '现在想起来还是有点闷', '我把这条截图存了起来',
    '其实我更想说的是别的', '回完之后我把手机扣在桌上', '他应该不知道我记住了',
    '这句话我后来又想起过几次'],
  mom: ['她的语气听起来很平常', '我嗯了一声就过去了', '挂了电话我在原地站了一会儿',
    '我本来想说点别的', '她从来不直接说想我'],
  work: ['当时觉得没什么', '下班路上才觉得堵得慌', '我没跟任何人提',
    '第二天照常去了公司', '现在也就是一句记录了', '那天我把工位收拾了一遍',
    '我在楼道里待了很久才回座位'],
  life: ['那会儿屋里很安静', '就这样过去了', '我拍了张照，后来删了',
    '现在还记得那个温度', '没告诉任何人', '那一刻觉得也还行',
    '我当时在想要不要给谁发条消息', '最后还是什么都没做'],
  net: ['不知道为什么搜这个', '看完就关掉了', '页面我留着没关',
    '这个问题其实不是我想问的', '结论是没用', '搜完更清醒了'],
  pref: ['这个我一直很确定', '说不上为什么', '别人觉得奇怪，我不觉得',
    '改不掉，也不想改', '一直是这样'],
  promise: ['说的时候是真的', '后来就慢慢不提了', '我记得很清楚',
    '这条到现在还挂着', '谁也没说破'],
  joke: ['现在看还是想笑', '这个只有我们懂', '有点傻', '我当时笑出声了',
    '后来变成了固定说法'],
  fact: ['这个我记下了', '你只说过一次', '我核对过'],
  rule: ['这条是长期有效的', '不会过期'],
};

/* ── 事实类（硬信息，稳定） ─────────────────────────────── */
const FACTS = [
  ['你住在{PLACE}附近，通勤 40 分钟', {}],
  ['你叫{NAME}，做{BACK}，在公司待了三年', { NAME: ['林深', '陈默', '周野'], BACK: ['后端', '前端', '算法', '运维'] }],
  ['你身高 178，近视 500 度，左撇子', {}],
  ['验证码不能给任何人', {}],
  ['你身份证最后四位是 {NUM}', { NUM: ['3721', '0914', '5528'] }],
  ['团子是三花，{WHEN}捡的，当时还没断奶', {}],
  ['你公司在 12 楼，工位靠窗，下午会晒到', {}],
  ['你的手机尾号 {NUM}', { NUM: ['4402', '1873', '6690'] }],
  ['你对芒果过敏，起了疹子才知道', {}],
  ['你大学在武汉读的，专业是{MAJOR}', { MAJOR: ['自动化', '计算机', '电子信息'] }],
  ['家里的网是 {NUM} 兆，房东装的', { NUM: ['300', '500', '100'] }],
  ['你有一个同父异母的妹妹，在念高三', {}],
  ['银行卡密码没有告诉任何人', {}],
  ['你每天早上七点二十的闹钟，实际七点四十起', {}],
  ['老周的全名是{NAME}，比我大八岁', { NAME: ['周建国', '周明'] }],
  ['阿念是室友，做插画，常年昼伏夜出', {}],
  ['妈妈今年 58，退休前是护士', {}],
  ['坤坤在深圳，做{JOBS}', { JOBS: ['设计', '运营', '摄影'] }],
];

const RULES = ['群里不许发广告、不许拉人、不许深夜刷屏',
  '不许在群里发语音超过 30 秒', '不许半夜三点发「在吗」'];

/* ── AI 评语（按语气分配，不重复感靠组合） ───────────────── */
const NOTES = {
  kun: ['这句他说得很轻，但你记住了', '你没回，但你一直在看', '这条被你想起来的次数比你自己承认的多',
    '语气是硬的，内容是软的', '你当时删掉了三句话才发出这一句', '这天之后有些东西变了，你说不上来'],
  mom: ['她总是把担心说成别的事', '你回得很快，但没说实话', '这条你每次看都会停一下'],
  work: ['这天你只发了一个句号', '你把委屈写得很短', '这条你自己也觉得没什么，但你记住了'],
  life: ['日常里最不容易被记住的，恰恰是这些', '你写的时候很平静', '那天你没跟任何人说'],
  net: ['你搜它的时候，心里的问题不是这个', '这条停留时间比别人长很多', '一个没有结论的搜索'],
  pref: ['这是你说过很多次的事', '你没说过为什么，但很确定', '这条属于「不需要理由」那一类'],
  promise: ['说的时候是真的，后来也是真的没做到', '你把日期记得很清', '这条已经过期了，但你没删'],
  joke: ['你笑的时候这条被记住了', '这是你们之间的暗号', '有点傻，但你不舍得删'],
};

/* ── 生成 ───────────────────────────────────────────────── */
function fill(tpl, extra, ctx) {
  return tpl.replace(/\{(\w+)\}/g, (_, k) => {
    if (extra[k]) return pick(extra[k]);
    if (k === 'PLACE') return pick(PLACE);
    if (k === 'SCENE') return pick(SCENE);
    if (k === 'WHEN') return pick(WHEN);
    if (k === 'THING') return pick(THING);
    if (k === 'PERSON') return pick(ctx.people.length ? ctx.people : PEOPLE);
    return k;
  });
}

const HALF = { '人物': 180, '事实': 180, '群规': 180, '偏好': 90, '约定': 90, '事件': 60, '梗': 120 };
const FLOOR = { '人物': 0.35, '群规': 0.35 };
function eff(m, at) {
  const c = m.confirmed_at ?? m.created_at;
  if (!c || c > at) return 0;
  const d = (at - c) / DAY;
  const half = HALF[m.category] ?? 90;
  const imp = 0.75 + 0.5 * (m.importance ?? 0.5);
  const sal = 1 + 0.35 * (m.emotional_salience ?? 0) + 0.25 * (m.relationship_salience ?? 0);
  const raw = Math.pow(0.5, d / half) * imp * sal;
  return clamp(raw, FLOOR[m.category] ?? 0, 1);
}

// 时间：越近越密，5% 的日子是爆发日
const DAILY = 730;
const times = [];
for (let d = DAILY; d >= 0 && times.length < TARGET; d--) {
  const rec = Math.pow(1 - d / DAILY, 2.2);
  const burst = R() < 0.05;
  const c = burst ? 10 + Math.floor(R() * 18) : Math.floor(R() * 7 * rec);
  for (let k = 0; k < c && times.length < TARGET; k++) {
    times.push(NOW - d * DAY - Math.floor(R() * DAY));
  }
}
while (times.length < TARGET) times.push(NOW - Math.floor(R() * DAILY) * DAY);
times.sort((a, b) => a - b);

const lineKeys = Object.keys(LINES);
const lineWeight = { kun: 24, mom: 6, work: 14, life: 22, net: 11, pref: 8, promise: 5, joke: 10 };
const linePool = [];
for (const k of lineKeys) for (let i = 0; i < lineWeight[k]; i++) linePool.push(k);

const items = [];
const usedText = new Map();

for (let i = 0; i < times.length; i++) {
  const created = times[i];
  const ageD = (NOW - created) / DAY;
  const lk = pick(linePool);
  const line = LINES[lk];
  const people = line.people.slice();
  if (R() < 0.15) people.push(pick(PEOPLE));
  const ctx = { people };

  // 挑一条尽量没用过的句子：原句 → 原句+补语 → 原句+双补语（组合空间 12×12）
  let text = '';
  const sufPool = SUFFIX[lk] || SUFFIX.life;
  for (let tries = 0; tries < 18; tries++) {
    const row = pick(line.texts);
    const base = fill(row[0], row[1] || {}, ctx);
    const n = usedText.get(base) || 0;
    let cand = base;
    if (n >= 1) cand = base + '，' + pick(sufPool);
    if (n >= 4) {
      const s1 = pick(sufPool);
      const rest = sufPool.filter(x => x !== s1);
      cand = base + '，' + s1 + '。' + pick(rest);
    }
    if (!usedText.has(cand)) {
      usedText.set(cand, 1);
      usedText.set(base, n + 1);
      text = cand;
      break;
    }
    text = cand;
  }
  if (!text) text = fill(pick(line.texts)[0], {}, ctx);

  // 文本里出现的人名补进 people（人物归属影响关联与分舱）
  const ppl = new Set(people);
  for (const p of PEOPLE) if (text.includes(p)) ppl.add(p);
  const peopleOut = [...ppl];

  const category = line.cat;
  const kind = category === '约定' ? 'promise'
    : category === '人物' ? 'fact'
      : category === '事件' ? 'episode'
        : category === '梗' ? 'raw' : 'fact';

  // 情绪：与叙事线相关，不纯随机
  let emo;
  if (lk === 'kun') emo = pick(['intimate', 'intimate', 'anxious', 'sad', 'joy', 'calm']);
  else if (lk === 'mom') emo = pick(['intimate', 'calm', 'sad']);
  else if (lk === 'work') emo = pick(['tired', 'anger', 'anxious', 'proud', 'calm']);
  else if (lk === 'life') emo = pick(['calm', 'sad', 'joy', 'tired']);
  else if (lk === 'net') emo = pick(['calm', 'calm', 'anxious']);
  else if (lk === 'pref') emo = pick(['calm', 'joy']);
  else if (lk === 'promise') emo = pick(['intimate', 'sad', 'joy']);
  else emo = pick(['joy', 'joy', 'calm']);

  const emoBase = { intimate: 0.72, anxious: 0.62, sad: 0.60, anger: 0.66, joy: 0.56, tired: 0.40, proud: 0.52, calm: 0.20 }[emo];
  const sal = clamp(emoBase + gauss(0, 0.14), 0.02, 1);
  const rel = clamp((people.includes('坤坤') ? 0.72 : people.length ? 0.42 : 0.10) + gauss(0, 0.15), 0, 1);
  const imp = clamp((kind === 'episode' ? 0.52 : kind === 'promise' ? 0.66 : 0.48) + gauss(0, 0.18), 0.15, 1);

  const recallP = Math.max(0.04, Math.exp(-ageD / 200));
  const recalled = R() < recallP * 0.92;
  const lastRecalled = recalled
    ? Math.min(NOW - DAY * 0.2, created + R() * Math.min(ageD, 90) * DAY)
    : null;
  const recallCount = recalled ? 1 + Math.floor(Math.pow(R(), 2) * 14) : 0;

  const m = {
    id: 100000 + i,
    text,
    category,
    memory_kind: kind,
    people,
    place: text.includes('在') && R() < 0.3 ? pick(PLACE) : '',
    scene: pick(SCENE),
    emotion: emo,
    valence: +(clamp({ intimate: 0.7, joy: 0.8, calm: 0.2, proud: 0.6, sad: -0.6, anxious: -0.5, anger: -0.7, tired: -0.3 }[emo] + gauss(0, 0.12), -1, 1)).toFixed(2),
    arousal: +(clamp(sal + gauss(0, 0.08), 0, 1)).toFixed(2),
    importance: +imp.toFixed(3),
    emotional_salience: +sal.toFixed(3),
    relationship_salience: +rel.toFixed(3),
    recall_count: recallCount,
    created_at: created,
    confirmed_at: lastRecalled ?? created,
    last_recalled: lastRecalled,
    cold: 0,
    valid_to: null,
    line: lk,
    typeHue: TYPE_HUE[category] ?? 205,
    emoHue: EMO_HUE[emo] ?? 200,
    ai_note: '',
    links: [],
    subject_qq: 'owner',
  };
  m.effWeight = +eff(m, NOW).toFixed(4);

  if (category !== '人物' && category !== '群规' && imp < 0.9 && m.effWeight < 0.15) m.cold = 1;
  if (ageD < 90 && R() < 0.09) {
    m.valid_to = NOW - Math.floor(R() * Math.max(1, ageD)) * DAY;
    if (m.valid_to <= created) m.valid_to = created + DAY;
  }
  items.push(m);
}

/* ── 补：硬事实 & 群规（低频但高权重，锚定内环） ────────── */
const anchors = [];
FACTS.forEach(([tpl, ex], i) => {
  const created = NOW - (60 + i * 27) * DAY;
  const t = fill(tpl, ex, { people: [] });
  anchors.push({
    id: 200000 + i, text: t, category: '事实', memory_kind: 'fact',
    people: [], place: '', scene: pick(SCENE), emotion: 'calm', valence: 0.1, arousal: 0.25,
    importance: 0.95, emotional_salience: 0.3, relationship_salience: 0.3,
    recall_count: 4 + Math.floor(R() * 10), created_at: created, confirmed_at: created,
    last_recalled: NOW - Math.floor(R() * 40) * DAY, cold: 0, valid_to: null, line: 'fact',
    typeHue: TYPE_HUE['事实'], emoHue: EMO_HUE.calm, ai_note: '这条你说过一次，我就记住了', links: [],
    subject_qq: 'owner', effWeight: 0,
  });
});
RULES.forEach((t, i) => {
  const created = NOW - 400 * DAY;
  anchors.push({
    id: 210000 + i, text: t, category: '群规', memory_kind: 'fact',
    people: [], place: '', scene: '群设置', emotion: 'calm', valence: 0, arousal: 0.1,
    importance: 1, emotional_salience: 0.1, relationship_salience: 0.1,
    recall_count: 2, created_at: created, confirmed_at: created, last_recalled: null,
    cold: 0, valid_to: null, line: 'rule',
    typeHue: TYPE_HUE['群规'], emoHue: EMO_HUE.calm, ai_note: '规则类，长期有效', links: [],
    subject_qq: 'owner', effWeight: 0,
  });
});
anchors.forEach(a => { a.effWeight = +eff(a, NOW).toFixed(4); });
items.push(...anchors);

/* ── AI 评语 & 标签 ─────────────────────────────────────── */
items.forEach(m => {
  const pool = NOTES[m.line] || NOTES.life;
  m.ai_note = pool[Math.floor(R() * pool.length)];
  m.tags = [];
  if (m.people.length) m.tags.push(...m.people.slice(0, 2));
  m.tags.push(m.emotion);
  if (m.category === '事件') m.tags.push('情绪浓度高');
  if (m.recall_count > 6) m.tags.push('常被想起');
  if (m.valid_to) m.tags.push('已失效');
});

/* ── 关联：同叙事线 + 同人 + 词面重叠，各取最近 2 ─────────── */
const byLine = new Map();
items.forEach(m => {
  const k = m.line + '|' + (m.people[0] || '-');
  if (!byLine.has(k)) byLine.set(k, []);
  byLine.get(k).push(m);
});
for (const [, arr] of byLine) {
  for (let i = 0; i < arr.length; i++) {
    const cand = [];
    for (let j = Math.max(0, i - 6); j < Math.min(arr.length, i + 7); j++) {
      if (j !== i) cand.push(arr[j]);
    }
    cand.sort((a, b) => Math.abs(a.created_at - arr[i].created_at) - Math.abs(b.created_at - arr[i].created_at));
    arr[i].links = cand.slice(0, 3).map(x => x.id);
  }
}

/* ── 输出 ───────────────────────────────────────────────── */
items.sort((a, b) => b.effWeight - a.effWeight);

const ringOf = m => m.valid_to ? 4 : m.cold ? 3 : m.effWeight >= 0.5 ? 1 : 2;
const ringCount = [0, 0, 0, 0, 0];
const catCount = {};
let avg = 0;
items.forEach(m => {
  ringCount[ringOf(m)]++;
  catCount[m.category] = (catCount[m.category] || 0) + 1;
  avg += m.effWeight;
});
avg = +(avg / items.length).toFixed(3);

const out = {
  mode: 'mock',
  generated_at: NOW,
  count: items.length,
  stats: {
    rings: ringCount, avgEff: avg, cats: catCount,
    links: items.reduce((s, m) => s + m.links.length, 0),
    // 11.0 §4.3 stats 里的两项：候选池、叙事（模拟值，真实库由 candidates / narratives 表算）
    candidates: items.filter(m => !m.valid_to && m.effWeight >= 0.45).length,
    narratives: 3,
  },
  palette: { typeHue: TYPE_HUE, emoHue: EMO_HUE },
  items,
};

const json = JSON.stringify(out);
const outPath = (process.argv.find(a => a.startsWith('--out=')) || '').split('=')[1];
if (outPath) {
  fs.writeFileSync(outPath, json);
  const kb = (json.length / 1024).toFixed(0);
  process.stderr.write(`✓ ${outPath}  ${items.length} 条  ${kb}KB\n`);
  process.stderr.write(`  环分布 ${JSON.stringify(ringCount)}  avgEff ${avg}\n`);
  process.stderr.write(`  类型 ${JSON.stringify(catCount)}\n`);
  process.stderr.write(`  连接 ${out.stats.links} 条\n`);
} else {
  process.stdout.write(json);
}
