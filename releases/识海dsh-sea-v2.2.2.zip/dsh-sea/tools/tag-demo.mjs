/**
 * tag-demo.mjs —— 给演示库跑一遍标注，让前端有东西可显示。
 * 真实部署时这一步在 DSH 写库时做，不需要这个脚本。
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { tagHeuristic } from '../sea/tagger.mjs';

const DIR = path.dirname(fileURLToPath(import.meta.url));
const LIB = path.join(DIR, '..', 'sea', 'demo', 'library.json');

const lib = JSON.parse(fs.readFileSync(LIB, 'utf8'));
const items = lib.items || [];
let tagged = 0;

const EMO_EN = new Set(['calm','joy','sad','uneasy','anger','tired','proud','close','anxious','intimate']);
for (const m of items) {
  const t = tagHeuristic({ text: m.text, category: m.category });
  // 保留原有的人物名标签（坤坤/阿念/老周…），去掉混进来的英文情绪名
  const keep = (m.tags || []).filter(x => !EMO_EN.has(x));
  m.tags = [...new Set([...keep, ...t.tags])].slice(0, 6);
  m.emotion_profile = t.emotion;
  m.salience = +t.salience.toFixed(3);
  m.gist = t.gist;
  tagged++;
}

lib.stats = lib.stats || {};
lib.stats.tagged = items.length;
lib.taggedAt = Date.now();

fs.writeFileSync(LIB, JSON.stringify(lib));
const withTags = items.filter(m => m.tags && m.tags.length).length;
console.log(`标注完成：${tagged} 条新标，${withTags}/${items.length} 条有标签`);
const freq = {};
for (const m of items) for (const t of (m.tags || [])) freq[t] = (freq[t] || 0) + 1;
console.log('标签分布：', Object.entries(freq).sort((a, b) => b[1] - a[1]).slice(0, 12)
  .map(([k, v]) => `${k} ${v}`).join(' · '));
