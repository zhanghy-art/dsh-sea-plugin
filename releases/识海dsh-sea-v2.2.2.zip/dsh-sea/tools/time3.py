#!/usr/bin/env python3
import os
# time3.py —— 时间旅行对比图：现在 vs +180 天（真的重排过）
from PIL import Image, ImageDraw, ImageFont
from preview3 import render, hud, F

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'docs', 'screenshots') + '/'
BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'sea', 'demo') + '/'
L0 = None
import json
L180 = json.load(open(BASE + 'layout-180d.json'))


def stats(lay):
    n = lay['nodes']
    return (
        len(n),
        sum(1 for x in n if not x['cold'] and not x['inv']),
        sum(1 for x in n if x['cold'] and not x['inv']),
        sum(1 for x in n if x['inv']),
    )


def avg(lay):
    return sum(x['w'] for x in lay['nodes']) / max(1, len(lay['nodes']))


print('render 现在…')
a = render(1.0, lay=None)
print('render +180d…')
b = render(1.0, lay=L180, gas_k=0.70)

# 裁掉四角 HUD，只留星图主体，两张并排
CROP = (250, 150, 1190, 750)          # 940 × 600
ca, cb = a.crop(CROP), b.crop(CROP)
W, H = ca.size

TOP, GAP = 74, 24
canvas = Image.new('RGB', (W * 2 + GAP, H + TOP), (3, 4, 7))
canvas.paste(ca, (0, TOP))
canvas.paste(cb, (W + GAP, TOP))
d = ImageDraw.Draw(canvas, 'RGBA')

for i, (label, sub, lay) in enumerate([
        ('现在', '2421 条 · 平均权重 %.3f' % avg(L180 and json.load(open(BASE + 'layout.json'))) , None),
        ('+180 天', '2421 条 · 平均权重 %.3f' % avg(L180), None)]):
    x = i * (W + GAP) + 22
    d.text((x, 24), label, font=F(17), fill=(226, 238, 250))
    d.text((x, 48), sub, font=F(11), fill=(110, 132, 152))

# 中缝
d.line([(W + GAP // 2, TOP + 20), (W + GAP // 2, H + TOP - 20)], fill=(120, 190, 255, 26))

# 底部：三行对比说明（比角落小字好读）
import json as _j
d0 = _j.load(open(BASE + 'layout.json'))
gd0 = sum(1 for n in d0['nodes'] if not n['cold'] and not n['inv'])
gd1 = sum(1 for n in L180['nodes'] if not n['cold'] and not n['inv'])
cs0 = sum(1 for n in d0['nodes'] if n['cold'] and not n['inv'])
cs1 = sum(1 for n in L180['nodes'] if n['cold'] and not n['inv'])

rows = [('还活跃', gd0, gd1), ('已转冷', cs0, cs1), ('平均权重', avg(d0), avg(L180))]
y = H + TOP - 70
for i, (k, a_, b_) in enumerate(rows):
    yy = y + i * 20
    if isinstance(a_, float):
        txt = f'{k}　{a_:.3f} → {b_:.3f}'
    else:
        txt = f'{k}　{a_} → {b_}'
    d.text((24, yy), txt, font=F(11), fill=(150, 172, 190))

d.text((W + GAP + 24, H + TOP - 70), '内圈（今天还记得的）几乎空掉，整片往外飘', font=F(11), fill=(150, 172, 190))
d.text((W + GAP + 24, H + TOP - 50), '环半径按剩余数量重算，所以不是简单变淡，是重新排布', font=F(11), fill=(110, 130, 148))
d.text((W + GAP + 24, H + TOP - 30), '滑块每动一次，弹簧会把 2400 个点带到新位置（实测平均位移 26.7px）', font=F(11), fill=(110, 130, 148))

canvas.save(OUT + '04-time-travel.png')
print('saved preview-time.png', canvas.size)
